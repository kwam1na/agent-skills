var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// packages/kernel/src/substrate/assertion-source.ts
var assertion_source_exports = {};
__export(assertion_source_exports, {
  ASSERTION_PROVIDER_SPEC: () => ASSERTION_PROVIDER_SPEC,
  assertionProviderConfigPathFor: () => assertionProviderConfigPathFor,
  createOsNativeAssertionSource: () => createOsNativeAssertionSource,
  createQualificationFixtureAssertionSource: () => createQualificationFixtureAssertionSource,
  loadAssertionProviderConfig: () => loadAssertionProviderConfig,
  writeAssertionProviderConfig: () => writeAssertionProviderConfig
});
import { spawn as spawn2 } from "node:child_process";
import { randomBytes } from "node:crypto";
import { chmod as chmod5, mkdir as mkdir5, readFile as readFile7, stat as stat3, writeFile as writeFile5 } from "node:fs/promises";
import path9 from "node:path";
function assertionProviderConfigPathFor(installationPath) {
  return path9.join(installationPath, "trust", "assertion-provider.json");
}
async function writeAssertionProviderConfig(installationPath, sourceKind) {
  const target = assertionProviderConfigPathFor(installationPath);
  await mkdir5(path9.dirname(target), { recursive: true, mode: OWNER_DIR2 });
  const config = { spec: ASSERTION_PROVIDER_SPEC, sourceKind };
  await writeFile5(target, JSON.stringify(config), { mode: OWNER_FILE2 });
  await chmod5(target, OWNER_FILE2);
}
async function loadAssertionProviderConfig(installationPath) {
  let bytes;
  try {
    bytes = await readFile7(assertionProviderConfigPathFor(installationPath), "utf8");
  } catch {
    return { ok: false, reason: "absent" };
  }
  let parsed;
  try {
    parsed = JSON.parse(bytes);
  } catch {
    return { ok: false, reason: "corrupt" };
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return { ok: false, reason: "corrupt" };
  }
  const record2 = parsed;
  if (record2["spec"] !== ASSERTION_PROVIDER_SPEC || !["host-native", "os-native", "qualification-fixture"].includes(record2["sourceKind"])) {
    return { ok: false, reason: "corrupt" };
  }
  return { ok: true, config: record2 };
}
async function resolveProbeGroups(authentication) {
  const resolved = [];
  for (const candidates of authentication.probePaths) {
    let found;
    for (const candidate2 of candidates) {
      if (found === void 0 && await exists(candidate2)) found = candidate2;
    }
    if (found === void 0) return { missing: candidates };
    resolved.push(found);
  }
  return { resolved };
}
function createOsNativeAssertionSource(options = {}) {
  const platform = options.platform ?? process.platform;
  const authentication = PLATFORM_AUTHENTICATION[platform];
  const now = options.now ?? (() => `${(/* @__PURE__ */ new Date()).toISOString().slice(0, 19)}Z`);
  return {
    async probe() {
      if (authentication === void 0) {
        return { available: false, detail: `no interactive authentication context is defined for platform ${platform}` };
      }
      const groups = await resolveProbeGroups(authentication);
      if ("missing" in groups) {
        return {
          available: false,
          detail: `authentication surface missing on ${platform}: ${groups.missing.join(" or ")}`
        };
      }
      return { available: true, sourceKind: "os-native", detail: authentication.detail };
    },
    async evaluate(request) {
      if (authentication === void 0) {
        return { ok: false, reason: `no interactive authentication context is defined for platform ${platform}` };
      }
      const groups = await resolveProbeGroups(authentication);
      if ("missing" in groups) {
        return { ok: false, reason: `authentication surface missing on ${platform}: ${groups.missing.join(" or ")}` };
      }
      for (const command of authentication.command(request.disclosure, groups.resolved)) {
        const code = await runOnce(command);
        if (code !== 0) return { ok: false, reason: `interactive authentication was not granted (${command[0]})` };
      }
      const minted = now();
      const expirySeconds = Date.parse(minted) / 1e3 + EVALUATION_LIFETIME_SECONDS;
      const expiry = `${new Date(expirySeconds * 1e3).toISOString().slice(0, 19)}Z`;
      return { ok: true, nonce: `nonce-${randomBytes(12).toString("hex")}`, expiry, sourceKind: "os-native" };
    }
  };
}
function createQualificationFixtureAssertionSource(options = {}) {
  const evaluations = [];
  let counter = 0;
  return {
    evaluations,
    async probe() {
      return { available: true, sourceKind: "qualification-fixture", detail: "deterministic qualification fixture" };
    },
    async evaluate(request) {
      evaluations.push(request);
      if ((options.decide?.(request) ?? "approve") === "refuse") {
        return { ok: false, reason: "the fixture operator refused the evaluation" };
      }
      counter += 1;
      const nonce = options.nonce?.() ?? `nonce-fixture-${counter}-${randomBytes(6).toString("hex")}`;
      return {
        ok: true,
        nonce,
        expiry: options.expiry ?? "2099-01-01T00:00:00Z",
        sourceKind: "qualification-fixture"
      };
    }
  };
}
var OWNER_DIR2, OWNER_FILE2, EVALUATION_LIFETIME_SECONDS, ASSERTION_PROVIDER_SPEC, exists, PLATFORM_AUTHENTICATION, runOnce;
var init_assertion_source = __esm({
  "packages/kernel/src/substrate/assertion-source.ts"() {
    "use strict";
    OWNER_DIR2 = 448;
    OWNER_FILE2 = 384;
    EVALUATION_LIFETIME_SECONDS = 300;
    ASSERTION_PROVIDER_SPEC = "assertion-provider/1";
    exists = async (target) => {
      try {
        await stat3(target);
        return true;
      } catch {
        return false;
      }
    };
    PLATFORM_AUTHENTICATION = Object.freeze({
      darwin: {
        probePaths: [
          ["/System/Library/Frameworks/LocalAuthentication.framework"],
          ["/usr/bin/security"],
          ["/usr/bin/osascript"]
        ],
        command: (disclosure, resolved) => [
          [
            resolved[2],
            "-e",
            `do shell script "true" with prompt ${JSON.stringify(disclosure)} with administrator privileges`
          ]
        ],
        detail: "macOS Authorization Services prompt (LocalAuthentication-backed where enrolled)"
      },
      linux: {
        probePaths: [["/usr/bin/sudo", "/bin/sudo"]],
        command: (disclosure, resolved) => [
          [resolved[0], "-k"],
          [resolved[0], "-p", `${disclosure}
password for %u: `, "-v"]
        ],
        detail: "sudo re-authentication with the cached-credential window explicitly reset"
      },
      win32: {
        probePaths: [["C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"]],
        command: (disclosure, resolved) => [
          [
            resolved[0],
            "-NoProfile",
            "-Command",
            `[Windows.Security.Credentials.UI.UserConsentVerifier,Windows.Security.Credentials.UI,ContentType=WindowsRuntime] | Out-Null; $op = [Windows.Security.Credentials.UI.UserConsentVerifier]::RequestVerificationAsync(${JSON.stringify(disclosure)}); while ($op.Status -eq 'Started') { Start-Sleep -Milliseconds 50 }; if ($op.GetResults() -ne 'Verified') { exit 1 }`
          ]
        ],
        detail: "Windows Hello / credential UI consent verification"
      }
    });
    runOnce = (command) => new Promise((resolve) => {
      const [executable, ...args] = command;
      const child = spawn2(executable, args, { stdio: ["inherit", "ignore", "ignore"] });
      child.on("error", () => resolve(-1));
      child.on("close", (code) => resolve(code ?? -1));
    });
  }
});

// packages/kernel/src/canonical.ts
var CanonicalizationError = class extends Error {
  code;
  path;
  constructor(code, path21, message) {
    super(`${message} (at ${path21 === "" ? "the document root" : path21})`);
    this.name = "CanonicalizationError";
    this.code = code;
    this.path = path21;
  }
};
function compareUtf16CodeUnits(a, b) {
  const shared = Math.min(a.length, b.length);
  for (let i = 0; i < shared; i += 1) {
    const left = a.charCodeAt(i);
    const right = b.charCodeAt(i);
    if (left !== right) return left - right;
  }
  return a.length - b.length;
}
var pointerSegment = (key) => `/${key.replace(/~/gu, "~0").replace(/\//gu, "~1")}`;
var serializeNumber = (value, path21) => {
  if (!Number.isFinite(value)) {
    throw new CanonicalizationError(
      "non_finite_number",
      path21,
      `${String(value)} has no JSON representation`
    );
  }
  return String(value);
};
var LONE_SURROGATE = new RegExp("\\p{Surrogate}", "u");
var serializeString = (value, path21) => {
  if (LONE_SURROGATE.test(value)) {
    throw new CanonicalizationError(
      "lone_surrogate",
      path21,
      "string contains an unpaired surrogate, which RFC 8785 \xA73.2.2.2 requires be rejected"
    );
  }
  return JSON.stringify(value);
};
var isPlainObject = (value) => {
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
};
var describeValue = (value) => {
  if (value === void 0) return "undefined";
  if (typeof value === "function") return "a function";
  if (typeof value === "symbol") return "a symbol";
  if (typeof value === "bigint") return "a bigint";
  return `a non-plain object (${Object.prototype.toString.call(value)})`;
};
var serialize = (value, path21, ancestors) => {
  if (value === null) return "null";
  switch (typeof value) {
    case "boolean":
      return value ? "true" : "false";
    case "number":
      return serializeNumber(value, path21);
    case "string":
      return serializeString(value, path21);
    case "object":
      break;
    default:
      throw new CanonicalizationError(
        "unsupported_value",
        path21,
        `${describeValue(value)} has no JSON representation`
      );
  }
  const container = value;
  if (ancestors.has(container)) {
    throw new CanonicalizationError("circular_reference", path21, "value contains itself");
  }
  ancestors.add(container);
  try {
    if (Array.isArray(container)) {
      const source = container;
      const elements = [];
      for (let index = 0; index < source.length; index += 1) {
        elements.push(serialize(source[index], `${path21}/${index}`, ancestors));
      }
      return `[${elements.join(",")}]`;
    }
    if (!isPlainObject(container)) {
      throw new CanonicalizationError(
        "unsupported_value",
        path21,
        `${describeValue(container)} has no JSON representation`
      );
    }
    if (Object.getOwnPropertySymbols(container).length > 0) {
      throw new CanonicalizationError(
        "symbol_key",
        path21,
        "object carries symbol-keyed members, which have no JSON representation"
      );
    }
    const record2 = container;
    const members = Object.keys(record2).sort(compareUtf16CodeUnits).map((key) => {
      const name = serializeString(key, path21);
      return `${name}:${serialize(record2[key], `${path21}${pointerSegment(key)}`, ancestors)}`;
    });
    return `{${members.join(",")}}`;
  } finally {
    ancestors.delete(container);
  }
};
function canonicalize(value) {
  return serialize(value, "", /* @__PURE__ */ new Set());
}
function canonicalBytes(value) {
  return new TextEncoder().encode(canonicalize(value));
}

// packages/kernel/src/digest.ts
import { createHash } from "node:crypto";
var SHA256_HEX = /^[0-9a-f]{64}$/u;
var DigestError = class extends Error {
  code;
  constructor(code, message) {
    super(message);
    this.name = "DigestError";
    this.code = code;
  }
};
function sha256Hex(input) {
  const hash = createHash("sha256");
  hash.update(typeof input === "string" ? new TextEncoder().encode(input) : input);
  return hash.digest("hex");
}
function digestCanonical(value) {
  return sha256Hex(canonicalBytes(value));
}
function isSha256Hex(value) {
  return typeof value === "string" && SHA256_HEX.test(value);
}
function assertSha256Hex(value) {
  if (!isSha256Hex(value)) {
    throw new DigestError(
      "not_sha256_hex",
      `expected a lowercase-hex sha256 digest, received ${JSON.stringify(value)}`
    );
  }
  return value;
}
function digestsEqual(a, b) {
  return assertSha256Hex(a) === assertSha256Hex(b);
}
var withEmptySignatures = (manifest) => {
  if (typeof manifest !== "object" || manifest === null || Array.isArray(manifest)) return manifest;
  const members = manifest;
  const attestation = members["attestation"];
  if (typeof attestation !== "object" || attestation === null || Array.isArray(attestation)) {
    return manifest;
  }
  return {
    ...members,
    attestation: { ...attestation, signatures: [] }
  };
};
function manifestDigest(manifest) {
  return sha256Hex(canonicalBytes(withEmptySignatures(manifest)));
}

// packages/kernel/src/blockers.ts
var BLOCKER_CONTRACT_VERSION = 1;
var MAX_BLOCKER_DETAIL_LENGTH = 8e3;
var INTERNAL_ERROR_CODE = "internal_error";
var BLOCKER_SOURCE_KINDS = [
  "gate",
  "obligation",
  "provider",
  "candidate",
  "preparation",
  "store",
  "delivery-record",
  "config",
  "command"
];
var GATE_STRUCTURAL_FINDING_CODES = [
  // Evidence-shaped
  "review_evidence_missing",
  "stale_evidence",
  "evidence_not_green",
  "unresolved_actionable_findings",
  "ambiguous_records",
  "malformed_record",
  "unknown_provider",
  // Live-result-shaped
  "live_provider_missing",
  "ambiguous_live_provider",
  "live_provider_failed",
  // Policy-shaped
  "resolution_not_allowed"
];
var BlockedError = class extends Error {
  blockers;
  constructor(blockers, message = "Blocked by the delivery gate.") {
    super(message);
    this.name = "BlockedError";
    this.blockers = blockers;
  }
};
var CODE_PATTERN = /^[a-z0-9]+(?:[_-][a-z0-9]+)*$/;
var SOURCE_ID_PATTERN = /^[a-z0-9]+(?:[._-][a-z0-9]+)*$/;
var REMEDIATION_ID_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
function redactSecrets(value) {
  return value.replace(/-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----[\s\S]*?-----END (?:[A-Z ]+ )?PRIVATE KEY-----/gi, "[REDACTED PRIVATE KEY]").replace(/-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----[\s\S]*/gi, "[REDACTED PRIVATE KEY]").replace(
    /\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|xox[baprse]-[A-Za-z0-9-]{10,}|sk-[A-Za-z0-9_-]{20,})\b/g,
    "[REDACTED]"
  ).replace(/\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g, "[REDACTED]").replace(/\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+/g, "[REDACTED]").replace(/(authorization\s*:\s*bearer\s+)[^\s]+/gi, "$1[REDACTED]").replace(
    /\b(bearer|token)[ \t\r\n]+([A-Za-z0-9._~+/-]{16,}=*)/gi,
    (match, label2, candidate2) => (
      // Hyphenated prose ("token connection-refused-by-upstream.") or an
      // UPPER_SNAKE provider error code: both are diagnostics an operator
      // needs, and neither is a credential shape.
      /^[A-Za-z]+(?:-[A-Za-z]+)+[.,;:!?]?$|^[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+[.,;:!?]?$/.test(candidate2) ? match : `${label2} [REDACTED]`
    )
  ).replace(
    /((?:^|[\s"'`(\[{,?&;])-{0,2}(?:[A-Za-z0-9]+[_-])*(?:TOKEN|SECRET|PASSWORD)["']?\s*(?:=>|[:=])\s*["']?)(?!\[REDACTED)[^\s"',}\])]+/gi,
    "$1[REDACTED]"
  ).replace(
    /((?:^|[\s"'`(\[{,?&;])[A-Za-z][A-Za-z0-9]*(?:Token|Secret|Password|Key)["']?\s*(?:=>|[:=])\s*["']?)(?!\[REDACTED)[^\s"',}\])]+/g,
    "$1[REDACTED]"
  ).replace(
    /((?:^|[\s"'`(\[{,?&;])(?:[A-Za-z0-9]+[_-])*KEY["']?\s*(?:=>|[:=])\s*["']?)(?!\[REDACTED)[^\s"',}\])]+/gi,
    "$1[REDACTED]"
  ).replace(
    /((?:^|[\s"'`(\[{,?&;])(?:[A-Z0-9]+[_-])*URL["']?\s*(?:=>|[:=])\s*["']?)(?!\[REDACTED)[^\s"',}\])]+/g,
    "$1[REDACTED]"
  ).replace(
    /((?:^|[\s"'`(\[{,?&;])-{1,2}[A-Za-z0-9-]*[-_](?:KEY|URL)"?\s*[:=]\s*"?)(?!\[REDACTED)[^\s",}\])]+/gi,
    "$1[REDACTED]"
  ).replace(/([a-z][a-z0-9+.-]{0,32}:\/\/)[^\s/@]+@/gi, "$1[REDACTED]@");
}
var ANSI_SEQUENCE = /\u001B(?:\[[0-?]*[ -/]*[@-~]|\][^\u0007\u001B]*(?:\u0007|\u001B\\)?|[@-Z\\-_])/g;
var BIDI_AND_ZERO_WIDTH = /[\u200B-\u200F\u202A-\u202E\u2060-\u2064\u2066-\u206F\uFEFF]/g;
var CONTROL_CHARACTERS = /[\u0000-\u0008\u000B-\u001F\u007F-\u009F\u2028\u2029]/g;
function neutralizeForDisplay(value) {
  return value.replace(ANSI_SEQUENCE, "").replace(BIDI_AND_ZERO_WIDTH, "").replace(CONTROL_CHARACTERS, "");
}
function bounded(value, maximum) {
  if (value.length <= maximum) return value;
  if (maximum <= 0) return "";
  let truncated = "";
  for (const character of value) {
    if (truncated.length + character.length > maximum - 1) break;
    truncated += character;
  }
  return `${truncated}\u2026`;
}
function windowed(value, maximum) {
  return value.slice(0, Math.max(maximum, 1) * 8);
}
function requireString(value, label2) {
  if (typeof value !== "string") throw new Error(`${label2} must be a string.`);
  return value;
}
function sanitizedLine(value, label2) {
  const raw = requireString(value, label2);
  const sanitized = redactSecrets(windowed(raw, MAX_BLOCKER_DETAIL_LENGTH)).replace(/\s+/g, " ").trim();
  if (sanitized === "") throw new Error(`${label2} must be non-empty.`);
  return bounded(sanitized, MAX_BLOCKER_DETAIL_LENGTH);
}
function sanitizedDetail(value, label2) {
  const raw = requireString(value, label2);
  const redacted = redactSecrets(windowed(raw, MAX_BLOCKER_DETAIL_LENGTH)).trim();
  return bounded(redacted, MAX_BLOCKER_DETAIL_LENGTH);
}
function sanitizedCommand(command, label2) {
  if (!Array.isArray(command) || command.length === 0) {
    throw new Error(`${label2} command must be a non-empty argv array.`);
  }
  const args = command.map(
    (argument, index) => (
      // Several CLIs splice raw argv into their reproduce command, so arguments
      // are operator-facing text like everything else here: a `--token=` value
      // would otherwise be echoed and stored verbatim.
      redactSecrets(windowed(requireString(argument, `${label2} command argument ${index}`), MAX_BLOCKER_DETAIL_LENGTH))
    )
  );
  const [first2, ...rest] = args;
  return [first2, ...rest];
}
function sanitizedRemediation(remediation) {
  if (remediation === null || typeof remediation !== "object") {
    throw new Error("Blocker remediation must be an object.");
  }
  const input = remediation;
  const id = requireString(input["id"], "Blocker remediation id");
  if (!REMEDIATION_ID_PATTERN.test(id)) {
    throw new Error("Blocker remediation id must be a stable kebab-case identifier.");
  }
  const kind = input["kind"];
  if (kind !== "command" && kind !== "manual_action" && kind !== "code_change" && kind !== "retry") {
    throw new Error(`Blocker remediation kind ${String(kind)} is not part of the contract.`);
  }
  const base = {
    id,
    summary: sanitizedLine(input["summary"], "Blocker remediation summary"),
    ...input["details"] === void 0 ? {} : { details: sanitizedDetail(input["details"], "Blocker remediation details") }
  };
  if (kind === "command") {
    return { ...base, kind, command: sanitizedCommand(input["command"], "Blocker remediation") };
  }
  if (kind === "retry" && input["command"] !== void 0) {
    return { ...base, kind, command: sanitizedCommand(input["command"], "Blocker remediation") };
  }
  return { ...base, kind };
}
function validatedSource(source) {
  if (source === null || typeof source !== "object") {
    throw new Error("Blocker source must be an object naming a kind and an id.");
  }
  const input = source;
  const kind = input["kind"];
  if (typeof kind !== "string" || !BLOCKER_SOURCE_KINDS.includes(kind)) {
    throw new Error(`Blocker source kind ${String(kind)} is not part of the contract.`);
  }
  const id = input["id"];
  if (typeof id !== "string" || !SOURCE_ID_PATTERN.test(id)) {
    throw new Error(`Blocker source id ${JSON.stringify(id)} is not a stable lowercase identifier.`);
  }
  return { kind, id };
}
function createBlocker(input) {
  const raw = input;
  const code = sanitizedLine(raw["code"], "Blocker code");
  if (!CODE_PATTERN.test(code)) {
    throw new Error(`Blocker code ${JSON.stringify(code)} must be a stable lowercase identifier.`);
  }
  const source = validatedSource(raw["source"]);
  const remediations = raw["remediations"];
  if (!Array.isArray(remediations) || remediations.length === 0) {
    throw new Error("Blocker remediations must be a non-empty list: a blocker with no way forward is not guidance.");
  }
  const sanitized = remediations.map(sanitizedRemediation);
  const [firstRemediation, ...restRemediations] = sanitized;
  return {
    code,
    source,
    summary: sanitizedLine(raw["summary"], "Blocker summary"),
    ...raw["details"] === void 0 ? {} : { details: sanitizedDetail(raw["details"], "Blocker details") },
    remediations: [firstRemediation, ...restRemediations]
  };
}
function describeThrown(error, depth = 0) {
  try {
    if (error instanceof Error) {
      const base = error.stack ?? `${error.name}: ${error.message}`;
      if (error.cause === void 0 || depth >= 3) return base;
      return `${base}
Caused by: ${describeThrown(error.cause, depth + 1)}`;
    }
    return String(error);
  } catch {
    return "Unknown internal error (the thrown value could not be described).";
  }
}
function remediationIdFor(prefix, source) {
  const slug = `${source.kind}-${source.id}`.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return slug === "" ? prefix : `${prefix}-${slug}`;
}
function createInternalErrorBlocker(input) {
  const described = describeThrown(input.error);
  return createBlocker({
    code: INTERNAL_ERROR_CODE,
    source: input.source,
    summary: "The harness encountered an unexpected internal error.",
    details: described === "" ? "Unknown internal error." : described,
    remediations: [
      {
        id: remediationIdFor("reproduce", input.source),
        kind: "command",
        command: input.reproduce,
        summary: "Reproduce the failure with the authoritative command."
      },
      {
        id: "inspect-harness-output",
        kind: "manual_action",
        summary: input.retainedLogPath === void 0 ? "Inspect the complete harness output before retrying." : `Inspect the retained harness log at ${input.retainedLogPath}.`
      }
    ]
  });
}
var UNAVAILABLE = "[unavailable]";
function safeGet(container, key) {
  if (container === null || typeof container !== "object") return void 0;
  try {
    return container[key];
  } catch {
    return void 0;
  }
}
function safeText(value, fallback) {
  if (typeof value === "string") return value;
  if (value === void 0 || value === null) return fallback;
  try {
    const text4 = String(value);
    return text4 === "" ? fallback : text4;
  } catch {
    return fallback;
  }
}
function displayText(value, fallback, maximum) {
  const text4 = safeText(value, fallback);
  return bounded(neutralizeForDisplay(windowed(text4, maximum)), maximum);
}
function displayCommand(value, maximum) {
  if (!Array.isArray(value) || value.length === 0) return null;
  return value.map((argument) => displayText(argument, UNAVAILABLE, maximum));
}
function quoteCommandArgument(value) {
  if (/^[A-Za-z0-9_@%+=:,./-]+$/.test(value)) return value;
  return `'${value.replaceAll("'", "'\\''")}'`;
}
function formatCommand(command) {
  return command.map(quoteCommandArgument).join(" ");
}
function displayRemediations(value, maxDetailLength) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const entry3 of value) {
    if (entry3 === null || typeof entry3 !== "object") continue;
    const details = safeGet(entry3, "details");
    out.push({
      id: displayText(safeGet(entry3, "id"), UNAVAILABLE, 200),
      kind: displayText(safeGet(entry3, "kind"), UNAVAILABLE, 200),
      summary: displayText(safeGet(entry3, "summary"), UNAVAILABLE, maxDetailLength),
      details: details === void 0 || details === null ? null : displayText(details, "", maxDetailLength),
      command: displayCommand(safeGet(entry3, "command"), maxDetailLength)
    });
  }
  return out;
}
var UNRENDERABLE_BLOCKER = {
  code: INTERNAL_ERROR_CODE,
  sourceKind: UNAVAILABLE,
  sourceId: UNAVAILABLE,
  summary: "A blocker could not be rendered; the other blockers in this result are unaffected.",
  details: null,
  remediations: []
};
function toDisplaySafe(blocker, maxDetailLength) {
  try {
    return toDisplay(blocker, maxDetailLength);
  } catch {
    return UNRENDERABLE_BLOCKER;
  }
}
function toDisplay(blocker, maxDetailLength) {
  if (blocker === null || typeof blocker !== "object") return void 0;
  const source = safeGet(blocker, "source");
  const details = safeGet(blocker, "details");
  return {
    code: displayText(safeGet(blocker, "code"), UNAVAILABLE, 200),
    sourceKind: displayText(safeGet(source, "kind"), UNAVAILABLE, 200),
    sourceId: displayText(safeGet(source, "id"), UNAVAILABLE, 200),
    summary: displayText(safeGet(blocker, "summary"), UNAVAILABLE, maxDetailLength),
    details: details === void 0 || details === null ? null : displayText(details, "", maxDetailLength),
    remediations: displayRemediations(safeGet(blocker, "remediations"), maxDetailLength)
  };
}
function remediationBody(remediation) {
  try {
    return JSON.stringify({
      kind: remediation.kind,
      summary: remediation.summary,
      details: remediation.details,
      command: remediation.command
    });
  } catch {
    return "<unserializable>";
  }
}
function uniqueRemediations(blockers) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const blocker of blockers) {
    for (const remediation of blocker.remediations) {
      const key = `${remediation.id}\0${remediationBody(remediation)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(remediation);
    }
  }
  return out;
}
function remediationInstruction(remediation) {
  const command = remediation.command === null ? "" : ` Command: ${formatCommand(remediation.command)}`;
  const details = remediation.details === null || remediation.details === "" ? "" : ` ${remediation.details}`;
  return `- (${remediation.id}) ${remediation.summary}${command}${details}`.replaceAll("\n", "\n    ");
}
function renderBlockers(blockers, options = {}) {
  try {
    if (!Array.isArray(blockers) || blockers.length === 0) return "";
    const maxDetailLength = options.maxDetailLength ?? 600;
    const maxOutputLength = options.maxOutputLength ?? 12e3;
    const display = [];
    for (const blocker of blockers) {
      const entry3 = toDisplaySafe(blocker, maxDetailLength);
      if (entry3 !== void 0) display.push(entry3);
    }
    if (display.length === 0) return "";
    const remediations = uniqueRemediations(display);
    const remediationText = remediations.length === 0 ? "" : ["Remediation:", ...remediations.map(remediationInstruction)].join("\n");
    if (remediationText.length >= maxOutputLength) return bounded(remediationText, maxOutputLength);
    const bodyBudget = remediationText === "" ? maxOutputLength : maxOutputLength - remediationText.length - 1;
    const body = bounded(
      display.flatMap((blocker) => [
        // Indented for the same reason as the remediation bullet: a summary
        // that skipped the constructor keeps its newlines.
        `[${blocker.code}] ${blocker.summary}`.replaceAll("\n", "\n    "),
        `  Source: ${blocker.sourceKind}:${blocker.sourceId}`.replaceAll("\n", "\n    "),
        ...blocker.details === null || blocker.details === "" ? [] : [`  Details: ${blocker.details.replaceAll("\n", "\n    ")}`]
      ]).join("\n"),
      bodyBudget
    );
    if (remediationText === "") return body;
    return body === "" ? remediationText : `${body}
${remediationText}`;
  } catch {
    return "";
  }
}
function serializeBlockers(blockers) {
  const out = [];
  try {
    if (Array.isArray(blockers)) {
      for (const blocker of blockers) {
        const entry3 = toDisplaySafe(blocker, MAX_BLOCKER_DETAIL_LENGTH);
        if (entry3 === void 0) continue;
        out.push({
          code: entry3.code,
          source: { kind: entry3.sourceKind, id: entry3.sourceId },
          summary: entry3.summary,
          details: entry3.details === "" ? null : entry3.details,
          remediations: entry3.remediations.map((remediation) => ({
            id: remediation.id,
            kind: remediation.kind,
            summary: remediation.summary,
            details: remediation.details === "" ? null : remediation.details,
            command: remediation.command
          }))
        });
      }
    }
  } catch {
  }
  return { contractVersion: BLOCKER_CONTRACT_VERSION, blockers: out };
}

// packages/kernel/src/config.ts
var DELIVERABLE_TREE_V1 = "deliverable-tree/v1";
var DELIVERABLE_TREE_V1_NARRATION_SET = Object.freeze([
  Object.freeze({ prefix: "docs/reports/" }),
  Object.freeze({ prefix: "docs/solutions/" }),
  Object.freeze({ prefix: "telemetry/delivery-runs/" })
]);
var ATTESTATION_LEVELS = ["self", "provider-signed", "independently-verified"];
var V1_ATTESTATION_LEVEL = "self";
var RESOLUTION_KINDS = [
  "satisfied_live_fact",
  "satisfied_evidence",
  "waived",
  "delegated",
  "not_applicable"
];
var NON_WAIVABLE_INTEGRITY_CODES = Object.freeze([
  "ambiguous_records",
  "malformed_record",
  "unknown_provider",
  "stale_evidence",
  "resolution_not_allowed"
]);
var ACTIVATION_KINDS = ["always", "relevant_change"];
var PROVIDER_POLICIES = ["all", "existential"];
var FRESHNESS_KINDS = ["live", "exact_candidate"];
var BASE_MOVEMENT_POLICIES = ["stale", "allow"];
var PATH_MATCHER_KINDS = ["prefix", "glob"];
var DEFAULT_STORAGE_NAMESPACE = "delivery-harness/";
var DEFAULT_BASE_REF = "origin/main";
var DEFAULT_BASE_MOVEMENT_POLICY = "stale";
var CONFIG_FINDING_CODES = [
  // Grammar
  "config_unknown_member",
  "config_missing_member",
  "config_invalid_member",
  "config_duplicate_id",
  // References
  "config_dangling_provider",
  "config_dangling_ci_policy",
  "config_dangling_sensitive_group",
  // Not a dangling reference: it fires on an obligation that accepts *no*
  // payload spec, so nothing can ever bind to it.
  "config_no_payload_spec",
  // Policy coherence
  "config_waiver_policy_mismatch",
  "config_empty_remediation",
  "config_unclassified_finding_code",
  "config_double_classified_finding_code",
  "config_stale_finding_code",
  // Identity and neutrality
  "config_record_neutral_not_subset",
  "config_delivery_record_not_neutral",
  "config_identity_version_not_accepted",
  "config_identity_token_requires_v1_neutral_set",
  "config_v1_neutral_set_requires_v1_token",
  // Scope
  "config_no_obligations",
  "config_unsupported_attestation_level"
];
var ID_PATTERN = /^[a-z0-9]+(?:[._-][a-z0-9]+)*$/;
var FINDING_CODE_PATTERN = /^[a-z0-9]+(?:[_-][a-z0-9]+)*$/;
var REMEDIATION_ID_PATTERN2 = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
var SPEC_TOKEN_PATTERN = /^[a-z0-9]+(?:[._-][a-z0-9]+)*\/[a-z0-9][a-z0-9.-]*$/;
var ENV_VARIABLE_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/;
var REF_PATTERN = /^[!-,.-~][!-~]*$/;
var REMEDIATION_KINDS = ["command", "manual_action", "code_change", "retry"];
function isRepoRelativePath(value) {
  if (value === "" || value.startsWith("/") || value.includes("\\") || value.includes("\0")) return false;
  if (value.trim() !== value) return false;
  return value.split("/").every((segment, index, segments) => {
    if (segment === "." || segment === "..") return false;
    return segment !== "" || index === segments.length - 1;
  });
}
var FindingList = class {
  entries = [];
  add(code, member2, detail) {
    this.entries.push({ code, member: member2, detail });
  }
  get length() {
    return this.entries.length;
  }
};
function toBlocker(finding3, sourceId) {
  return createBlocker({
    code: finding3.code,
    source: { kind: "config", id: sourceId },
    summary: `\`${finding3.member}\`: ${finding3.detail}`,
    remediations: [
      {
        id: "correct-harness-config",
        kind: "code_change",
        summary: `Correct \`${finding3.member}\` in the harness config.`,
        details: finding3.detail
      }
    ]
  });
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function checkClosed(findings2, member2, value, allowed) {
  for (const key of Object.keys(value)) {
    if (!allowed.includes(key)) {
      findings2.add("config_unknown_member", `${member2}.${key}`, "is not a member of the config grammar");
    }
  }
}
function readString(findings2, member2, value, check) {
  if (typeof value !== "string") {
    findings2.add("config_invalid_member", member2, `must be a string (${check.describe})`);
    return void 0;
  }
  if (check.pattern !== void 0 && !check.pattern.test(value)) {
    findings2.add("config_invalid_member", member2, `${JSON.stringify(value)} is not ${check.describe}`);
    return void 0;
  }
  if (check.path === true && !isRepoRelativePath(value)) {
    findings2.add("config_invalid_member", member2, `${JSON.stringify(value)} is not a repo-relative POSIX path`);
    return void 0;
  }
  return value;
}
function readEnum(findings2, member2, value, allowed) {
  if (typeof value === "string" && allowed.includes(value)) return value;
  findings2.add("config_invalid_member", member2, `must be one of ${allowed.join(", ")}`);
  return void 0;
}
function readBoolean(findings2, member2, value) {
  if (typeof value === "boolean") return value;
  findings2.add("config_invalid_member", member2, "must be a boolean");
  return void 0;
}
function readArray(findings2, member2, value) {
  if (Array.isArray(value)) return value;
  findings2.add("config_invalid_member", member2, "must be an array");
  return void 0;
}
function readStringArray(findings2, member2, value, check) {
  const array = readArray(findings2, member2, value);
  if (array === void 0) return void 0;
  const out = [];
  let sound = true;
  array.forEach((entry3, index) => {
    const read = readString(findings2, `${member2}[${index}]`, entry3, check);
    if (read === void 0) sound = false;
    else out.push(read);
  });
  return sound ? out : void 0;
}
function readNeutralMatchers(findings2, member2, value) {
  const array = readArray(findings2, member2, value);
  if (array === void 0) return void 0;
  const out = [];
  let sound = true;
  array.forEach((entry3, index) => {
    const at = `${member2}[${index}]`;
    if (!isRecord(entry3)) {
      findings2.add("config_invalid_member", at, "must be an object naming a prefix and an optional suffix");
      sound = false;
      return;
    }
    checkClosed(findings2, at, entry3, ["prefix", "suffix"]);
    const prefix = readString(findings2, `${at}.prefix`, entry3["prefix"], { path: true, describe: "a repo-relative path prefix" });
    const suffix = entry3["suffix"] === void 0 ? void 0 : readString(findings2, `${at}.suffix`, entry3["suffix"], { describe: "a path suffix" });
    if (prefix === void 0 || entry3["suffix"] !== void 0 && suffix === void 0) {
      sound = false;
      return;
    }
    out.push(suffix === void 0 || suffix === "" ? { prefix } : { prefix, suffix });
  });
  return sound ? out : void 0;
}
function readPathMatchers(findings2, member2, value) {
  const array = readArray(findings2, member2, value);
  if (array === void 0) return void 0;
  const out = [];
  let sound = true;
  array.forEach((entry3, index) => {
    const at = `${member2}[${index}]`;
    if (!isRecord(entry3)) {
      findings2.add("config_invalid_member", at, "must be an object naming a matcher kind and a value");
      sound = false;
      return;
    }
    checkClosed(findings2, at, entry3, ["kind", "value"]);
    const kind = readEnum(findings2, `${at}.kind`, entry3["kind"], PATH_MATCHER_KINDS);
    const matcherValue = readString(findings2, `${at}.value`, entry3["value"], { describe: "a non-empty matcher value" });
    if (kind === void 0 || matcherValue === void 0 || matcherValue === "") {
      if (matcherValue === "") findings2.add("config_invalid_member", `${at}.value`, "must be non-empty");
      sound = false;
      return;
    }
    out.push({ kind, value: matcherValue });
  });
  return sound ? out : void 0;
}
function readRemediations(findings2, member2, value) {
  const array = readArray(findings2, member2, value);
  if (array === void 0) return void 0;
  const out = [];
  let sound = true;
  array.forEach((entry3, index) => {
    const at = `${member2}[${index}]`;
    if (!isRecord(entry3)) {
      findings2.add("config_invalid_member", at, "must be a remediation object");
      sound = false;
      return;
    }
    checkClosed(findings2, at, entry3, ["id", "kind", "summary", "details", "command"]);
    const id = readString(findings2, `${at}.id`, entry3["id"], { pattern: REMEDIATION_ID_PATTERN2, describe: "a kebab-case remediation id" });
    const kind = readEnum(findings2, `${at}.kind`, entry3["kind"], REMEDIATION_KINDS);
    const summary = readString(findings2, `${at}.summary`, entry3["summary"], { describe: "a one-line summary" });
    const details = entry3["details"] === void 0 ? void 0 : readString(findings2, `${at}.details`, entry3["details"], { describe: "remediation details" });
    let command;
    if (kind === "command" || kind === "retry" && entry3["command"] !== void 0) {
      command = readStringArray(findings2, `${at}.command`, entry3["command"], { describe: "an argv element" });
      if (command !== void 0 && command.length === 0) {
        findings2.add("config_invalid_member", `${at}.command`, "must be a non-empty argv array");
        command = void 0;
      }
    } else if (entry3["command"] !== void 0) {
      findings2.add("config_invalid_member", `${at}.command`, `is only meaningful on a command or retry remediation, not on ${String(entry3["kind"])}`);
      sound = false;
    }
    if (id === void 0 || kind === void 0 || summary === void 0) {
      sound = false;
      return;
    }
    if ((kind === "command" || kind === "retry" && entry3["command"] !== void 0) && command === void 0) {
      sound = false;
      return;
    }
    const base = { id, summary, ...details === void 0 ? {} : { details } };
    if (kind === "command") out.push({ ...base, kind, command });
    else if (kind === "retry" && command !== void 0) out.push({ ...base, kind, command });
    else if (kind === "retry") out.push({ ...base, kind });
    else out.push({ ...base, kind });
  });
  return sound ? out : void 0;
}
function readRemediationCatalog(findings2, member2, value) {
  if (!isRecord(value)) {
    findings2.add("config_invalid_member", member2, "must be an object with a default catalog and an optional per-code catalog");
    return void 0;
  }
  checkClosed(findings2, member2, value, ["default", "byCode"]);
  const fallback = readRemediations(findings2, `${member2}.default`, value["default"]);
  let byCode;
  if (value["byCode"] !== void 0) {
    if (!isRecord(value["byCode"])) {
      findings2.add("config_invalid_member", `${member2}.byCode`, "must be an object keyed by finding code");
      return void 0;
    }
    byCode = {};
    for (const [code, entry3] of Object.entries(value["byCode"])) {
      if (!FINDING_CODE_PATTERN.test(code)) {
        findings2.add("config_invalid_member", `${member2}.byCode.${code}`, "is not a finding-code identifier");
        continue;
      }
      const read = readRemediations(findings2, `${member2}.byCode.${code}`, entry3);
      if (read !== void 0) byCode[code] = read;
    }
  }
  if (fallback === void 0) return void 0;
  return byCode === void 0 ? { default: fallback } : { default: fallback, byCode };
}
var REQUIRED_OBLIGATION_MEMBERS = [
  "id",
  "activation",
  "freshness",
  "providers",
  "acceptedPayloadSpecs",
  "allowedResolutionKinds",
  "humanWaiverAllowed",
  "minimumAttestationLevel",
  "ciDelegationPolicyIds",
  "remediation",
  "waivableCodes",
  "nonWaivableCodes"
];
var OBLIGATION_MEMBERS = [...REQUIRED_OBLIGATION_MEMBERS, "providerPolicy"];
var ACTIVATION_MEMBERS = ["kind", "sensitiveGroupIds", "relevantBinaryChangeActivates", "relevantZeroLineChangeActivates"];
function readActivation(findings2, member2, value) {
  checkClosed(findings2, member2, value, ACTIVATION_MEMBERS);
  const kind = readEnum(findings2, `${member2}.kind`, value["kind"], ACTIVATION_KINDS);
  const sensitiveGroupIds = value["sensitiveGroupIds"] === void 0 ? void 0 : readStringArray(findings2, `${member2}.sensitiveGroupIds`, value["sensitiveGroupIds"], {
    pattern: ID_PATTERN,
    describe: "a sensitive-path group id"
  });
  const relevantBinaryChangeActivates = value["relevantBinaryChangeActivates"] === void 0 ? void 0 : readBoolean(findings2, `${member2}.relevantBinaryChangeActivates`, value["relevantBinaryChangeActivates"]);
  const relevantZeroLineChangeActivates = value["relevantZeroLineChangeActivates"] === void 0 ? void 0 : readBoolean(findings2, `${member2}.relevantZeroLineChangeActivates`, value["relevantZeroLineChangeActivates"]);
  if (kind === void 0) return void 0;
  if (value["sensitiveGroupIds"] !== void 0 && sensitiveGroupIds === void 0) return void 0;
  if (value["relevantBinaryChangeActivates"] !== void 0 && relevantBinaryChangeActivates === void 0) return void 0;
  if (value["relevantZeroLineChangeActivates"] !== void 0 && relevantZeroLineChangeActivates === void 0) return void 0;
  return {
    kind,
    ...sensitiveGroupIds === void 0 ? {} : { sensitiveGroupIds },
    ...relevantBinaryChangeActivates === void 0 ? {} : { relevantBinaryChangeActivates },
    ...relevantZeroLineChangeActivates === void 0 ? {} : { relevantZeroLineChangeActivates }
  };
}
function readObligation(findings2, member2, value) {
  if (!isRecord(value)) {
    findings2.add("config_invalid_member", member2, "must be an obligation object");
    return void 0;
  }
  checkClosed(findings2, member2, value, OBLIGATION_MEMBERS);
  for (const name of REQUIRED_OBLIGATION_MEMBERS) {
    if (value[name] === void 0) findings2.add("config_missing_member", `${member2}.${name}`, "is required");
  }
  const id = value["id"] === void 0 ? void 0 : readString(findings2, `${member2}.id`, value["id"], { pattern: ID_PATTERN, describe: "a lowercase obligation id" });
  let activation;
  if (isRecord(value["activation"])) {
    activation = readActivation(findings2, `${member2}.activation`, value["activation"]);
  } else if (value["activation"] !== void 0) {
    findings2.add("config_invalid_member", `${member2}.activation`, "must be an object naming an activation kind");
  }
  const freshness = value["freshness"] === void 0 ? void 0 : readEnum(findings2, `${member2}.freshness`, value["freshness"], FRESHNESS_KINDS);
  const providerPolicy = value["providerPolicy"] === void 0 ? void 0 : readEnum(findings2, `${member2}.providerPolicy`, value["providerPolicy"], PROVIDER_POLICIES);
  const providers = value["providers"] === void 0 ? void 0 : readStringArray(findings2, `${member2}.providers`, value["providers"], { pattern: ID_PATTERN, describe: "a provider id" });
  const acceptedPayloadSpecs = value["acceptedPayloadSpecs"] === void 0 ? void 0 : readStringArray(findings2, `${member2}.acceptedPayloadSpecs`, value["acceptedPayloadSpecs"], {
    pattern: SPEC_TOKEN_PATTERN,
    describe: "a payload spec token"
  });
  let allowedResolutionKinds;
  if (value["allowedResolutionKinds"] !== void 0) {
    const array = readArray(findings2, `${member2}.allowedResolutionKinds`, value["allowedResolutionKinds"]);
    if (array !== void 0) {
      const read = array.map((entry3, index) => readEnum(findings2, `${member2}.allowedResolutionKinds[${index}]`, entry3, RESOLUTION_KINDS));
      if (read.every((entry3) => entry3 !== void 0)) allowedResolutionKinds = read;
    }
  }
  const humanWaiverAllowed = value["humanWaiverAllowed"] === void 0 ? void 0 : readBoolean(findings2, `${member2}.humanWaiverAllowed`, value["humanWaiverAllowed"]);
  const minimumAttestationLevel = value["minimumAttestationLevel"] === void 0 ? void 0 : readEnum(findings2, `${member2}.minimumAttestationLevel`, value["minimumAttestationLevel"], ATTESTATION_LEVELS);
  const ciDelegationPolicyIds = value["ciDelegationPolicyIds"] === void 0 ? void 0 : readStringArray(findings2, `${member2}.ciDelegationPolicyIds`, value["ciDelegationPolicyIds"], { pattern: ID_PATTERN, describe: "a CI policy id" });
  const remediation = value["remediation"] === void 0 ? void 0 : readRemediationCatalog(findings2, `${member2}.remediation`, value["remediation"]);
  const waivableCodes = value["waivableCodes"] === void 0 ? void 0 : readStringArray(findings2, `${member2}.waivableCodes`, value["waivableCodes"], { pattern: FINDING_CODE_PATTERN, describe: "a finding code" });
  const nonWaivableCodes = value["nonWaivableCodes"] === void 0 ? void 0 : readStringArray(findings2, `${member2}.nonWaivableCodes`, value["nonWaivableCodes"], { pattern: FINDING_CODE_PATTERN, describe: "a finding code" });
  if (id === void 0 || activation === void 0 || freshness === void 0 || providers === void 0 || acceptedPayloadSpecs === void 0 || allowedResolutionKinds === void 0 || humanWaiverAllowed === void 0 || minimumAttestationLevel === void 0 || ciDelegationPolicyIds === void 0 || remediation === void 0 || waivableCodes === void 0 || nonWaivableCodes === void 0) {
    return void 0;
  }
  return {
    id,
    activation,
    freshness,
    providers,
    ...providerPolicy === void 0 ? {} : { providerPolicy },
    acceptedPayloadSpecs,
    allowedResolutionKinds,
    humanWaiverAllowed,
    minimumAttestationLevel,
    ciDelegationPolicyIds,
    remediation,
    waivableCodes,
    nonWaivableCodes
  };
}
var CONFIG_MEMBERS = [
  "gateId",
  "baseRef",
  "storageNamespace",
  "acceptedEnvelopeSpecs",
  "identityVersions",
  "computingIdentityVersion",
  "reviewNeutral",
  "recordNeutral",
  "pathClassification",
  "sensitivePaths",
  "activationThreshold",
  "providers",
  "agentEnvSignals",
  "ciPolicies",
  "ciPolicyEnvKey",
  "preparationWiringPaths",
  "preparationCommands",
  "additionalReviewLenses",
  "obligations",
  "deliveryRecordPath",
  "deliveryRecordVerification"
];
var DEFAULTED_MEMBERS = ["baseRef", "storageNamespace", "deliveryRecordVerification", "preparationCommands", "additionalReviewLenses"];
function readAdditionalReviewLenses(findings2, value) {
  const entries = readArray(findings2, "additionalReviewLenses", value);
  if (entries === void 0) return void 0;
  const lenses = [];
  for (const [index, entry3] of entries.entries()) {
    const member2 = `additionalReviewLenses[${index}]`;
    if (!isRecord(entry3)) {
      findings2.add("config_invalid_member", member2, "must name a lens, reviewer, and repository charter path");
      continue;
    }
    checkClosed(findings2, member2, entry3, ["lensId", "reviewerId", "charterPath"]);
    const lensId = readString(findings2, `${member2}.lensId`, entry3["lensId"], { pattern: ID_PATTERN, describe: "a lens id" });
    const reviewerId = readString(findings2, `${member2}.reviewerId`, entry3["reviewerId"], { pattern: ID_PATTERN, describe: "a reviewer id" });
    const charterPath = readString(findings2, `${member2}.charterPath`, entry3["charterPath"], { path: true, describe: "a repo-relative charter file" });
    if (charterPath?.endsWith("/")) findings2.add("config_invalid_member", `${member2}.charterPath`, "must name a file, not a directory prefix");
    if (lensId !== void 0 && reviewerId !== void 0 && charterPath !== void 0) lenses.push({ lensId, reviewerId, charterPath });
  }
  checkDuplicateIds(findings2, "additionalReviewLenses.lensId", lenses.map((lens) => lens.lensId));
  checkDuplicateIds(findings2, "additionalReviewLenses.reviewerId", lenses.map((lens) => lens.reviewerId));
  return lenses;
}
function readShape(findings2, input) {
  if (!isRecord(input)) {
    findings2.add("config_invalid_member", "<config>", "must be an object");
    return void 0;
  }
  checkClosed(findings2, "<config>", input, CONFIG_MEMBERS);
  for (const name of CONFIG_MEMBERS) {
    if (input[name] === void 0 && name !== "preparationCommands" && !DEFAULTED_MEMBERS.includes(name)) {
      findings2.add("config_missing_member", name, "is required");
    }
  }
  const gateId = input["gateId"] === void 0 ? void 0 : readString(findings2, "gateId", input["gateId"], { pattern: ID_PATTERN, describe: "a lowercase gate id" });
  const baseRef = input["baseRef"] === void 0 ? DEFAULT_BASE_REF : readString(findings2, "baseRef", input["baseRef"], { pattern: REF_PATTERN, describe: "a git ref" });
  const storageNamespace = input["storageNamespace"] === void 0 ? DEFAULT_STORAGE_NAMESPACE : readString(findings2, "storageNamespace", input["storageNamespace"], { path: true, describe: "a repo-relative storage namespace" });
  const acceptedEnvelopeSpecs = input["acceptedEnvelopeSpecs"] === void 0 ? void 0 : readStringArray(findings2, "acceptedEnvelopeSpecs", input["acceptedEnvelopeSpecs"], { pattern: SPEC_TOKEN_PATTERN, describe: "an envelope spec token" });
  const identityVersions = input["identityVersions"] === void 0 ? void 0 : readStringArray(findings2, "identityVersions", input["identityVersions"], { pattern: SPEC_TOKEN_PATTERN, describe: "an identity version token" });
  const computingIdentityVersion = input["computingIdentityVersion"] === void 0 ? void 0 : readString(findings2, "computingIdentityVersion", input["computingIdentityVersion"], { pattern: SPEC_TOKEN_PATTERN, describe: "an identity version token" });
  const reviewNeutral = input["reviewNeutral"] === void 0 ? void 0 : readNeutralMatchers(findings2, "reviewNeutral", input["reviewNeutral"]);
  const recordNeutral = input["recordNeutral"] === void 0 ? void 0 : readNeutralMatchers(findings2, "recordNeutral", input["recordNeutral"]);
  let pathClassification;
  if (isRecord(input["pathClassification"])) {
    checkClosed(findings2, "pathClassification", input["pathClassification"], ["generated", "test", "lockfile"]);
    const generated = readPathMatchers(findings2, "pathClassification.generated", input["pathClassification"]["generated"]);
    const test = readPathMatchers(findings2, "pathClassification.test", input["pathClassification"]["test"]);
    const lockfile = readPathMatchers(findings2, "pathClassification.lockfile", input["pathClassification"]["lockfile"]);
    if (generated !== void 0 && test !== void 0 && lockfile !== void 0) pathClassification = { generated, test, lockfile };
  } else if (input["pathClassification"] !== void 0) {
    findings2.add("config_invalid_member", "pathClassification", "must be an object naming generated, test and lockfile matchers");
  }
  let sensitivePaths;
  if (input["sensitivePaths"] !== void 0) {
    const array = readArray(findings2, "sensitivePaths", input["sensitivePaths"]);
    if (array !== void 0) {
      const groups = [];
      let sound = true;
      array.forEach((entry3, index) => {
        const at = `sensitivePaths[${index}]`;
        if (!isRecord(entry3)) {
          findings2.add("config_invalid_member", at, "must be an object naming an id and its patterns");
          sound = false;
          return;
        }
        checkClosed(findings2, at, entry3, ["id", "patterns"]);
        const id = readString(findings2, `${at}.id`, entry3["id"], { pattern: ID_PATTERN, describe: "a sensitive-path group id" });
        const patterns = readPathMatchers(findings2, `${at}.patterns`, entry3["patterns"]);
        if (id === void 0 || patterns === void 0) sound = false;
        else groups.push({ id, patterns });
      });
      if (sound) sensitivePaths = groups;
    }
  }
  let activationThreshold;
  if (input["activationThreshold"] !== void 0) {
    const value = input["activationThreshold"];
    if (typeof value === "number" && Number.isInteger(value) && value >= 0) activationThreshold = value;
    else findings2.add("config_invalid_member", "activationThreshold", "must be a non-negative integer line count");
  }
  let providers;
  if (input["providers"] !== void 0) {
    const array = readArray(findings2, "providers", input["providers"]);
    if (array !== void 0) {
      const registrations = [];
      let sound = true;
      array.forEach((entry3, index) => {
        const at = `providers[${index}]`;
        if (!isRecord(entry3)) {
          findings2.add("config_invalid_member", at, "must be an object naming a provider id and its finding codes");
          sound = false;
          return;
        }
        checkClosed(findings2, at, entry3, ["id", "findingCodes", "command", "check"]);
        const id = readString(findings2, `${at}.id`, entry3["id"], { pattern: ID_PATTERN, describe: "a provider id" });
        const findingCodes = readStringArray(findings2, `${at}.findingCodes`, entry3["findingCodes"], {
          pattern: FINDING_CODE_PATTERN,
          describe: "a finding code"
        });
        let command;
        if (entry3["command"] !== void 0) {
          const values = readStringArray(findings2, `${at}.command`, entry3["command"], { describe: "a provider command argument" });
          if (values === void 0 || values.length === 0 || values.some((value) => value.length === 0)) {
            if (values !== void 0) findings2.add("config_invalid_member", `${at}.command`, "must be a non-empty argv array of non-empty strings");
            sound = false;
          } else {
            command = values;
          }
        }
        let check;
        if (entry3["check"] !== void 0) {
          const value = entry3["check"];
          if (!isRecord(value)) {
            findings2.add("config_invalid_member", `${at}.check`, "must be an object");
            sound = false;
          } else {
            checkClosed(findings2, `${at}.check`, value, ["command", "timeoutMs", "outputs"]);
            const argv = value["command"], timeout = value["timeoutMs"], outputs = value["outputs"];
            if (!Array.isArray(argv) || argv.length === 0 || typeof argv[0] !== "string" || argv[0].trim().length === 0 || argv.some((v) => typeof v !== "string" || v.includes("\0")) || typeof timeout !== "number" || !Number.isSafeInteger(timeout) || timeout < 1 || timeout > 36e5 || outputs !== void 0 && (!Array.isArray(outputs) || outputs.length > 64 || new Set(outputs).size !== outputs.length || outputs.some((v) => typeof v !== "string" || v.length === 0 || v.startsWith("/") || v.includes("\\") || v.split("/").some((part) => part === ".." || part === "." || part === "")))) {
              findings2.add("config_invalid_member", `${at}.check`, "requires non-empty argv, timeoutMs from 1 to 3600000 and at most 64 unique safe relative output paths");
              sound = false;
            } else check = { command: argv, timeoutMs: timeout, ...outputs === void 0 ? {} : { outputs } };
            if (command !== void 0) {
              findings2.add("config_invalid_member", at, "command and check are mutually exclusive");
              sound = false;
            }
          }
        }
        if (id === void 0 || findingCodes === void 0) sound = false;
        else registrations.push({ id, findingCodes, ...command === void 0 ? {} : { command }, ...check === void 0 ? {} : { check } });
      });
      if (sound) providers = registrations;
    }
  }
  const agentEnvSignals = input["agentEnvSignals"] === void 0 ? void 0 : readStringArray(findings2, "agentEnvSignals", input["agentEnvSignals"], { pattern: ENV_VARIABLE_PATTERN, describe: "an environment variable name" });
  let ciPolicies;
  if (input["ciPolicies"] !== void 0) {
    const array = readArray(findings2, "ciPolicies", input["ciPolicies"]);
    if (array !== void 0) {
      const policies = [];
      let sound = true;
      array.forEach((entry3, index) => {
        const at = `ciPolicies[${index}]`;
        if (!isRecord(entry3)) {
          findings2.add("config_invalid_member", at, "must be an object naming a policy id and its required environment");
          sound = false;
          return;
        }
        checkClosed(findings2, at, entry3, ["id", "requiredEnv"]);
        const id = readString(findings2, `${at}.id`, entry3["id"], { pattern: ID_PATTERN, describe: "a CI policy id" });
        const requiredArray = readArray(findings2, `${at}.requiredEnv`, entry3["requiredEnv"]);
        const requirements = [];
        let requirementsSound = requiredArray !== void 0;
        requiredArray?.forEach((requirement, requirementIndex) => {
          const requirementAt = `${at}.requiredEnv[${requirementIndex}]`;
          if (!isRecord(requirement)) {
            findings2.add("config_invalid_member", requirementAt, "must be an object naming a variable and the value it must equal");
            requirementsSound = false;
            return;
          }
          checkClosed(findings2, requirementAt, requirement, ["variable", "equals"]);
          const variable = readString(findings2, `${requirementAt}.variable`, requirement["variable"], {
            pattern: ENV_VARIABLE_PATTERN,
            describe: "an environment variable name"
          });
          const equals = readString(findings2, `${requirementAt}.equals`, requirement["equals"], { describe: "the value the variable must equal" });
          if (variable === void 0 || equals === void 0) requirementsSound = false;
          else requirements.push({ variable, equals });
        });
        if (id === void 0 || !requirementsSound) sound = false;
        else policies.push({ id, requiredEnv: requirements });
      });
      if (sound) ciPolicies = policies;
    }
  }
  const ciPolicyEnvKey = input["ciPolicyEnvKey"] === void 0 ? void 0 : readString(findings2, "ciPolicyEnvKey", input["ciPolicyEnvKey"], { pattern: ENV_VARIABLE_PATTERN, describe: "an environment variable name" });
  const preparationWiringPaths = input["preparationWiringPaths"] === void 0 ? void 0 : readStringArray(findings2, "preparationWiringPaths", input["preparationWiringPaths"], { path: true, describe: "a repo-relative path" });
  const additionalReviewLenses = input["additionalReviewLenses"] === void 0 ? void 0 : readAdditionalReviewLenses(findings2, input["additionalReviewLenses"]);
  let preparationCommands;
  if (input["preparationCommands"] !== void 0) {
    const entries = readArray(findings2, "preparationCommands", input["preparationCommands"]);
    preparationCommands = [];
    const ids = /* @__PURE__ */ new Set();
    entries?.forEach((entry3, index) => {
      const at = `preparationCommands[${index}]`;
      if (!isRecord(entry3)) {
        findings2.add("config_invalid_member", at, "must be a command object");
        return;
      }
      checkClosed(findings2, at, entry3, ["id", "command", "timeoutMs"]);
      const id = readString(findings2, `${at}.id`, entry3["id"], { pattern: REMEDIATION_ID_PATTERN2, describe: "a kebab-case check id" });
      const command = entry3["command"];
      const timeoutMs = entry3["timeoutMs"];
      if (!Array.isArray(command) || command.length === 0 || command.some((arg) => typeof arg !== "string" || arg.includes("\0")) || typeof command[0] !== "string" || command[0].trim().length === 0) {
        findings2.add("config_invalid_member", `${at}.command`, "must be a non-empty argv array with a nonblank executable and no NUL bytes");
        return;
      }
      if (typeof timeoutMs !== "number" || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 2147483647) {
        findings2.add("config_invalid_member", `${at}.timeoutMs`, "must be a positive integer no greater than 2147483647");
        return;
      }
      if (id === void 0) return;
      if (ids.has(id)) {
        findings2.add("config_invalid_member", `${at}.id`, "must be unique among preparation commands");
        return;
      }
      ids.add(id);
      preparationCommands.push({ id, command, timeoutMs });
    });
  }
  let obligations;
  if (input["obligations"] !== void 0) {
    const array = readArray(findings2, "obligations", input["obligations"]);
    if (array !== void 0) {
      const read = array.map((entry3, index) => readObligation(findings2, `obligations[${index}]`, entry3));
      if (read.every((entry3) => entry3 !== void 0)) obligations = read;
    }
  }
  const deliveryRecordPath = input["deliveryRecordPath"] === void 0 ? void 0 : readString(findings2, "deliveryRecordPath", input["deliveryRecordPath"], { path: true, describe: "a repo-relative path" });
  let deliveryRecordVerification = { baseMovement: DEFAULT_BASE_MOVEMENT_POLICY };
  if (input["deliveryRecordVerification"] !== void 0) {
    deliveryRecordVerification = void 0;
    if (isRecord(input["deliveryRecordVerification"])) {
      checkClosed(findings2, "deliveryRecordVerification", input["deliveryRecordVerification"], ["baseMovement"]);
      const baseMovement = readEnum(
        findings2,
        "deliveryRecordVerification.baseMovement",
        input["deliveryRecordVerification"]["baseMovement"],
        BASE_MOVEMENT_POLICIES
      );
      if (baseMovement !== void 0) deliveryRecordVerification = { baseMovement };
    } else {
      findings2.add("config_invalid_member", "deliveryRecordVerification", "must be an object naming a base-movement policy");
    }
  }
  if (gateId === void 0 || baseRef === void 0 || storageNamespace === void 0 || acceptedEnvelopeSpecs === void 0 || identityVersions === void 0 || computingIdentityVersion === void 0 || reviewNeutral === void 0 || recordNeutral === void 0 || pathClassification === void 0 || sensitivePaths === void 0 || activationThreshold === void 0 || providers === void 0 || agentEnvSignals === void 0 || ciPolicies === void 0 || ciPolicyEnvKey === void 0 || preparationWiringPaths === void 0 || obligations === void 0 || deliveryRecordPath === void 0 || deliveryRecordVerification === void 0) {
    return void 0;
  }
  return {
    gateId,
    baseRef,
    storageNamespace,
    acceptedEnvelopeSpecs,
    identityVersions,
    computingIdentityVersion,
    reviewNeutral,
    recordNeutral,
    pathClassification,
    sensitivePaths,
    activationThreshold,
    providers,
    agentEnvSignals,
    ciPolicies,
    ciPolicyEnvKey,
    preparationWiringPaths: additionalReviewLenses === void 0 ? preparationWiringPaths : [.../* @__PURE__ */ new Set([...preparationWiringPaths, ...additionalReviewLenses.map((lens) => lens.charterPath)])],
    ...additionalReviewLenses === void 0 ? {} : { additionalReviewLenses },
    ...preparationCommands === void 0 ? {} : { preparationCommands },
    obligations,
    deliveryRecordPath,
    deliveryRecordVerification
  };
}
function matchesNeutralSet(matchers, path21) {
  return matchers.some((matcher) => path21.startsWith(matcher.prefix) && (matcher.suffix === void 0 || path21.endsWith(matcher.suffix)));
}
function deriveDeliveryRecordPath(deliveryRecordPath, deliverableDigest) {
  const lastSlash = deliveryRecordPath.lastIndexOf("/");
  const lastDot = deliveryRecordPath.lastIndexOf(".");
  const hasExtension = lastDot > lastSlash + 1;
  const stem = hasExtension ? deliveryRecordPath.slice(0, lastDot) : deliveryRecordPath;
  const extension = hasExtension ? deliveryRecordPath.slice(lastDot) : "";
  return `${stem}--${deliverableDigest}${extension}`;
}
function deliveryRecordPathFor(config, deliverableDigest) {
  return deriveDeliveryRecordPath(config.deliveryRecordPath, deliverableDigest);
}
var PROBE_DIGESTS = ["0".repeat(64), "f".repeat(64)];
function subsumes(wide, narrow) {
  if (!narrow.prefix.startsWith(wide.prefix)) return false;
  return wide.suffix === void 0 || narrow.suffix === wide.suffix;
}
function matcherKey(matcher) {
  return `${matcher.prefix}\0${matcher.suffix ?? ""}`;
}
function sameMatcherSet(left, right) {
  const leftKeys = new Set(left.map(matcherKey));
  const rightKeys = new Set(right.map(matcherKey));
  if (leftKeys.size !== rightKeys.size) return false;
  for (const key of leftKeys) if (!rightKeys.has(key)) return false;
  return true;
}
function emittableFindingCodes(config, obligationId) {
  const obligation = config.obligations.find((candidate2) => candidate2.id === obligationId);
  if (obligation === void 0) {
    throw new Error(`No obligation ${JSON.stringify(obligationId)} is declared by this config.`);
  }
  const codes = new Set(GATE_STRUCTURAL_FINDING_CODES);
  for (const providerId2 of obligation.providers) {
    const provider2 = config.providers.find((registration) => registration.id === providerId2);
    for (const code of provider2?.findingCodes ?? []) codes.add(code);
  }
  return [...codes];
}
function checkDuplicateIds(findings2, member2, ids) {
  const seen = /* @__PURE__ */ new Set();
  for (const id of ids) {
    if (seen.has(id)) findings2.add("config_duplicate_id", member2, `declares ${JSON.stringify(id)} more than once`);
    seen.add(id);
  }
}
function checkInvariants(findings2, config) {
  checkDuplicateIds(findings2, "obligations", config.obligations.map((obligation) => obligation.id));
  checkDuplicateIds(findings2, "providers", config.providers.map((provider2) => provider2.id));
  checkDuplicateIds(findings2, "ciPolicies", config.ciPolicies.map((policy) => policy.id));
  checkDuplicateIds(findings2, "sensitivePaths", config.sensitivePaths.map((group) => group.id));
  if (config.obligations.length === 0) {
    findings2.add("config_no_obligations", "obligations", "must declare at least one obligation; a gate with none admits every candidate");
  }
  const providerIds = new Set(config.providers.map((provider2) => provider2.id));
  const policyIds = new Set(config.ciPolicies.map((policy) => policy.id));
  const sensitiveGroupIds = new Set(config.sensitivePaths.map((group) => group.id));
  for (const [index, obligation] of config.obligations.entries()) {
    const at = `obligations[${index}]`;
    for (const providerId2 of obligation.providers) {
      if (!providerIds.has(providerId2)) {
        findings2.add("config_dangling_provider", `${at}.providers`, `names ${JSON.stringify(providerId2)}, which no provider registration declares`);
      }
    }
    if (obligation.providers.some((id) => config.providers.find((provider2) => provider2.id === id)?.check !== void 0) && (obligation.freshness !== "exact_candidate" || obligation.acceptedPayloadSpecs.length !== 1 || obligation.acceptedPayloadSpecs[0] !== "checks.passed/1")) {
      findings2.add("config_invalid_member", at, "declared checks require exact_candidate freshness and only checks.passed/1 payloads");
    }
    for (const groupId of obligation.activation.sensitiveGroupIds ?? []) {
      if (!sensitiveGroupIds.has(groupId)) {
        findings2.add(
          "config_dangling_sensitive_group",
          `${at}.activation.sensitiveGroupIds`,
          `names ${JSON.stringify(groupId)}, which no sensitive-path group declares`
        );
      }
    }
    for (const policyId of obligation.ciDelegationPolicyIds) {
      if (!policyIds.has(policyId)) {
        findings2.add("config_dangling_ci_policy", `${at}.ciDelegationPolicyIds`, `names ${JSON.stringify(policyId)}, which no CI policy declares`);
      }
    }
    if (obligation.acceptedPayloadSpecs.length === 0) {
      findings2.add(
        "config_no_payload_spec",
        `${at}.acceptedPayloadSpecs`,
        "accepts no payload spec, so no claim can ever bind to this obligation"
      );
    }
    checkDuplicateIds(findings2, `${at}.acceptedPayloadSpecs`, obligation.acceptedPayloadSpecs);
    const waivedAllowed = obligation.allowedResolutionKinds.includes("waived");
    if (obligation.humanWaiverAllowed !== waivedAllowed) {
      findings2.add(
        "config_waiver_policy_mismatch",
        at,
        obligation.humanWaiverAllowed ? 'sets humanWaiverAllowed but omits "waived" from allowedResolutionKinds' : 'allows the "waived" resolution kind but leaves humanWaiverAllowed false'
      );
    }
    if (obligation.minimumAttestationLevel !== V1_ATTESTATION_LEVEL) {
      findings2.add(
        "config_unsupported_attestation_level",
        `${at}.minimumAttestationLevel`,
        `must be "self" in this version: levels above self require a signing profile that this scope does not define`
      );
    }
    if (obligation.remediation.default.length === 0) {
      findings2.add("config_empty_remediation", `${at}.remediation.default`, "must carry at least one remediation");
    }
    for (const [code, catalog] of Object.entries(obligation.remediation.byCode ?? {})) {
      if (catalog.length === 0) {
        findings2.add("config_empty_remediation", `${at}.remediation.byCode.${code}`, "must carry at least one remediation");
      }
    }
    const universe = new Set(emittableFindingCodes(config, obligation.id));
    const waivable = new Set(obligation.waivableCodes);
    const nonWaivable = new Set(obligation.nonWaivableCodes);
    for (const code of universe) {
      const inWaivable = waivable.has(code);
      const inNonWaivable = nonWaivable.has(code);
      if (inWaivable && inNonWaivable) {
        findings2.add(
          "config_double_classified_finding_code",
          at,
          `classifies ${JSON.stringify(code)} as both waivable and non-waivable; the lists must partition, not overlap`
        );
      } else if (!inWaivable && !inNonWaivable) {
        findings2.add(
          "config_unclassified_finding_code",
          at,
          `emits ${JSON.stringify(code)} but classifies it as neither waivable nor non-waivable`
        );
      }
    }
    for (const [listName, list] of [["waivableCodes", waivable], ["nonWaivableCodes", nonWaivable]]) {
      for (const code of list) {
        if (!universe.has(code)) {
          findings2.add(
            "config_stale_finding_code",
            `${at}.${listName}`,
            `classifies ${JSON.stringify(code)}, which this obligation cannot emit; a classification left behind by a removed provider or structural code is a lie about the policy`
          );
        }
      }
    }
    for (const code of Object.keys(obligation.remediation.byCode ?? {})) {
      if (!universe.has(code)) {
        findings2.add(
          "config_stale_finding_code",
          `${at}.remediation.byCode.${code}`,
          "keys a remediation on a code this obligation cannot emit"
        );
      }
    }
  }
  for (const [index, matcher] of config.recordNeutral.entries()) {
    if (!config.reviewNeutral.some((wide) => subsumes(wide, matcher))) {
      findings2.add(
        "config_record_neutral_not_subset",
        `recordNeutral[${index}]`,
        `${JSON.stringify(matcher.prefix)} is not covered by any reviewNeutral matcher; recordNeutral must be a subset of reviewNeutral`
      );
    }
  }
  const derivedProbePaths = PROBE_DIGESTS.map((probe) => deriveDeliveryRecordPath(config.deliveryRecordPath, probe));
  const candidatePaths = [
    ["deliveryRecordPath", config.deliveryRecordPath],
    ...derivedProbePaths.map((derived) => ["deliveryRecordPath (derived)", derived])
  ];
  let derivedReported = false;
  for (const [member2, candidatePath] of candidatePaths) {
    const isDerived = member2 !== "deliveryRecordPath";
    if (isDerived && derivedReported) continue;
    const reviewNeutralRecord = matchesNeutralSet(config.reviewNeutral, candidatePath);
    const recordNeutralRecord = matchesNeutralSet(config.recordNeutral, candidatePath);
    if (reviewNeutralRecord && recordNeutralRecord) continue;
    if (isDerived) derivedReported = true;
    const derivedNote = isDerived ? ` \u2014 records are candidate-keyed, so ${JSON.stringify(config.deliveryRecordPath)} is written as this path` : "";
    findings2.add(
      "config_delivery_record_not_neutral",
      member2,
      reviewNeutralRecord ? `${JSON.stringify(candidatePath)} is review-neutral but not record-neutral; writing the record would change what records bind to${derivedNote}` : recordNeutralRecord ? `${JSON.stringify(candidatePath)} is record-neutral but not review-neutral; writing the record would change the deliverable identity${derivedNote}` : `${JSON.stringify(candidatePath)} is neutral to neither set; writing the record would invalidate the evidence it records${derivedNote}`
    );
  }
  if (!config.identityVersions.includes(config.computingIdentityVersion)) {
    findings2.add(
      "config_identity_version_not_accepted",
      "computingIdentityVersion",
      `${JSON.stringify(config.computingIdentityVersion)} is not in identityVersions; a recorder must accept the identity it computes`
    );
  }
  const isV1NarrationSet = sameMatcherSet(config.reviewNeutral, DELIVERABLE_TREE_V1_NARRATION_SET);
  if (config.computingIdentityVersion === DELIVERABLE_TREE_V1 && !isV1NarrationSet) {
    findings2.add(
      "config_identity_token_requires_v1_neutral_set",
      "computingIdentityVersion",
      `claims ${JSON.stringify(DELIVERABLE_TREE_V1)} while reviewNeutral is not that token's narration set; declare a consumer-owned identity token instead`
    );
  }
  if (config.computingIdentityVersion !== DELIVERABLE_TREE_V1 && isV1NarrationSet) {
    findings2.add(
      "config_v1_neutral_set_requires_v1_token",
      "computingIdentityVersion",
      `declares the ${JSON.stringify(DELIVERABLE_TREE_V1)} narration set under ${JSON.stringify(config.computingIdentityVersion)}; the same exclusions computed under two tokens fork one identity for no reason`
    );
  }
}
function deepFreeze(value) {
  if (Array.isArray(value)) {
    for (const entry3 of value) deepFreeze(entry3);
    return Object.freeze(value);
  }
  if (typeof value === "object" && value !== null) {
    for (const entry3 of Object.values(value)) deepFreeze(entry3);
    return Object.freeze(value);
  }
  return value;
}
function sourceIdFor(input) {
  if (isRecord(input) && typeof input["gateId"] === "string" && ID_PATTERN.test(input["gateId"])) return input["gateId"];
  return "harness.config";
}
function validateHarnessConfig(input) {
  const findings2 = new FindingList();
  const shaped = readShape(findings2, input);
  if (shaped !== void 0 && findings2.length === 0) {
    checkInvariants(findings2, shaped);
    if (findings2.length === 0) return { ok: true, config: deepFreeze(shaped) };
  }
  const sourceId = sourceIdFor(input);
  const blockers = findings2.entries.map((finding3) => toBlocker(finding3, sourceId));
  if (blockers.length === 0) {
    return {
      ok: false,
      blockers: [
        toBlocker({ code: "config_invalid_member", member: "<config>", detail: "could not be loaded" }, sourceId)
      ]
    };
  }
  const [first2, ...rest] = blockers;
  return { ok: false, blockers: [first2, ...rest] };
}
function defineHarnessConfig(input) {
  const result2 = validateHarnessConfig(input);
  if (result2.ok) return result2.config;
  throw new BlockedError(result2.blockers, "The harness config is not valid.");
}

// packages/kernel/src/record-identity.ts
function recordIdentity(workspaceId, input) {
  const common = {
    workspaceId,
    gateId: input.gateId,
    obligationId: input.obligationId,
    candidateBinding: input.candidateBinding
  };
  return input.resolution.kind === "waiver" ? { ...common, kind: "waiver", approval: input.resolution } : {
    ...common,
    providerId: input.resolution.providerId,
    runId: input.resolution.runId,
    finalPassId: input.resolution.finalPassId
  };
}
function computeRecordId(workspaceId, input) {
  return digestCanonical(recordIdentity(workspaceId, input));
}

// packages/kernel/src/records.ts
import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { chmod, link, mkdir, open, readFile, readdir, realpath, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";

// packages/kernel/src/records.types.ts
var RECORD_SCHEMA_VERSION = 1;
var WAIVER_SCOPES = ["invocation", "durable"];
var RECORD_QUARANTINE_REASONS = ["unreadable", "corrupt_json", "malformed_shape", "identity_mismatch"];

// packages/kernel/src/records.ts
var execFileAsync = promisify(execFile);
var RECORDS_LEAF = "records";
var DIRECTORY_MODE = 448;
var RECORD_MODE = 384;
var UNWRITABLE_CODES = /* @__PURE__ */ new Set(["EACCES", "EPERM", "EROFS", "ENOSPC", "ENOTDIR", "ENAMETOOLONG"]);
function storeBlocker(code, summary, details, remediation) {
  return createBlocker({
    code,
    source: { kind: "store", id: "evidence-records" },
    summary,
    details,
    remediations: [remediation]
  });
}
function blocked(blocker) {
  return new BlockedError([blocker], blocker.summary);
}
function normalizeNamespace(namespace) {
  const trimmed = namespace.trim().replace(/^[./]+/, "").replace(/\/+$/, "");
  return trimmed === "" ? DEFAULT_STORAGE_NAMESPACE.replace(/\/+$/, "") : trimmed;
}
async function physicalPath(target) {
  const absolute = path.resolve(target);
  const trailing = [];
  let cursor = absolute;
  for (; ; ) {
    try {
      return path.join(await realpath(cursor), ...[...trailing].reverse());
    } catch (error) {
      const parent = path.dirname(cursor);
      if (errorCode(error) !== "ENOENT" || parent === cursor) return absolute;
      trailing.push(path.basename(cursor));
      cursor = parent;
    }
  }
}
function isInside(child, parent) {
  return child !== parent && child.startsWith(parent + path.sep);
}
function unresolved(details) {
  return blocked(
    storeBlocker(
      "record_store_unresolved",
      "The evidence store could not be located inside this worktree's git directory.",
      details,
      {
        id: "correct-storage-namespace",
        kind: "manual_action",
        summary: "Run the harness from inside the git repository, and give storageNamespace a plain relative path git does not already own."
      }
    )
  );
}
var defaultGitRunner = async (cwd, args) => {
  const { stdout } = await execFileAsync("git", [...args], { cwd });
  return stdout.trim();
};
async function resolveStorageRoot(rootDir, options) {
  if (options.storageRoot !== void 0) return physicalPath(options.storageRoot);
  const namespace = normalizeNamespace(options.storageNamespace ?? DEFAULT_STORAGE_NAMESPACE);
  const cwd = await physicalPath(rootDir);
  const runGit = options.runGit ?? defaultGitRunner;
  let reported;
  try {
    reported = await runGit(cwd, ["rev-parse", "--git-dir", "--git-path", namespace]);
  } catch (error) {
    throw unresolved(`git rev-parse --git-dir --git-path ${namespace} failed in ${cwd}: ${describe(error)}`);
  }
  const [gitDirLine, storageLine] = reported.split("\n").map((line) => line.trim());
  if (gitDirLine === void 0 || gitDirLine === "" || storageLine === void 0 || storageLine === "") {
    throw unresolved(`git rev-parse --git-dir --git-path ${namespace} printed no path in ${cwd}`);
  }
  const gitDir = await physicalPath(path.resolve(cwd, gitDirLine));
  const storageRoot = await physicalPath(path.resolve(cwd, storageLine));
  if (!isInside(storageRoot, gitDir)) {
    throw unresolved(
      `storageNamespace ${JSON.stringify(namespace)} resolves to ${storageRoot}, which is outside this worktree's git directory ${gitDir}`
    );
  }
  return storageRoot;
}
async function resolveRecordStorage(rootDir, options = {}) {
  const storageRoot = await resolveStorageRoot(rootDir, options);
  return {
    storageRoot,
    storageDir: path.join(storageRoot, options.leaf ?? RECORDS_LEAF),
    workspaceId: digestCanonical(storageRoot)
  };
}
function safeSlot(value) {
  return value.replace(/[^a-zA-Z0-9._-]/g, "_");
}
function recordFileName(gateId, obligationId, recordId) {
  return `${safeSlot(gateId)}--${safeSlot(obligationId)}--${recordId}.json`;
}
function slotPrefix(gateId, obligationId) {
  return `${safeSlot(gateId)}--${safeSlot(obligationId)}--`;
}
var RecordShapeError = class extends Error {
  reason;
  constructor(reason, message) {
    super(message);
    this.name = "RecordShapeError";
    this.reason = reason;
  }
};
function isRecordObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isNonEmptyString(value) {
  return typeof value === "string" && value.length > 0;
}
function requireExactMembers(value, expected, where) {
  const actual = Object.keys(value).sort();
  const wanted = [...expected].sort();
  const missing = wanted.filter((member2) => !actual.includes(member2));
  const unexpected = actual.filter((member2) => !wanted.includes(member2));
  if (missing.length > 0 || unexpected.length > 0) {
    throw new RecordShapeError(
      "malformed_shape",
      `${where} has the wrong members${missing.length > 0 ? ` (missing: ${missing.join(", ")})` : ""}${unexpected.length > 0 ? ` (unexpected: ${unexpected.join(", ")})` : ""}`
    );
  }
}
var BINDING_MEMBERS = [
  "treeSha",
  "deliverableDigest",
  "identityToken",
  "baseRef",
  "baseTipSha",
  "mergeBaseSha",
  "workspaceId"
];
var RECORD_MEMBERS = [
  "schemaVersion",
  "recordId",
  "workspaceId",
  "gateId",
  "obligationId",
  "candidateBinding",
  "resolution"
];
var EVIDENCE_MEMBERS = ["kind", "providerId", "runId", "finalPassId", "manifestDigest"];
var WAIVER_MEMBERS = ["kind", "scope", "author", "reason", "findingCodes", "policyDigest"];
function parseBinding(value) {
  if (!isRecordObject(value)) throw new RecordShapeError("malformed_shape", "candidateBinding must be an object");
  requireExactMembers(value, BINDING_MEMBERS, "candidateBinding");
  for (const member2 of BINDING_MEMBERS) {
    if (!isNonEmptyString(value[member2])) {
      throw new RecordShapeError("malformed_shape", `candidateBinding.${member2} must be a non-empty string`);
    }
  }
  return value;
}
function parseResolution(value) {
  if (!isRecordObject(value)) throw new RecordShapeError("malformed_shape", "resolution must be an object");
  const kind = value["kind"];
  if (kind === "evidence") {
    requireExactMembers(value, [...EVIDENCE_MEMBERS, ...value["checkBinding"] === void 0 ? [] : ["checkBinding"], ...value["portable"] === void 0 ? [] : ["portable"]], "resolution");
    if (value["checkBinding"] !== void 0) {
      const binding = value["checkBinding"];
      const members = ["definitionDigest", "validationDigest", "policyDigest", "wiringFingerprint", "outputsDigest"];
      if (!isRecordObject(binding)) throw new RecordShapeError("malformed_shape", "checkBinding must be an object");
      requireExactMembers(binding, members, "checkBinding");
      if (members.some((key) => typeof binding[key] !== "string" || !/^[a-f0-9]{64}$/.test(binding[key]))) throw new RecordShapeError("malformed_shape", "checkBinding requires sha256 digests");
    }
    if (value["portable"] !== void 0 && (!isRecordObject(value["portable"]) || value["portable"]["version"] !== "portable-evidence/1")) {
      throw new RecordShapeError("malformed_shape", "resolution.portable must carry a supported portable evidence payload");
    }
    for (const member2 of ["providerId", "runId", "finalPassId", "manifestDigest"]) {
      if (!isNonEmptyString(value[member2])) {
        throw new RecordShapeError("malformed_shape", `resolution.${member2} must be a non-empty string`);
      }
    }
  } else if (kind === "waiver") {
    requireExactMembers(value, WAIVER_MEMBERS, "resolution");
    if (!WAIVER_SCOPES.includes(value["scope"])) {
      throw new RecordShapeError("malformed_shape", `resolution.scope must be one of ${WAIVER_SCOPES.join(", ")}`);
    }
    for (const [member2, limit] of [["author", 256], ["reason", 4096]]) {
      if (typeof value[member2] !== "string" || value[member2].trim().length === 0 || value[member2].length > limit) {
        throw new RecordShapeError("malformed_shape", `resolution.${member2} must be bounded non-empty text`);
      }
    }
    const codes = value["findingCodes"];
    if (!Array.isArray(codes) || codes.length === 0 || new Set(codes).size !== codes.length || codes.some((code) => typeof code !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(code))) {
      throw new RecordShapeError("malformed_shape", "resolution.findingCodes must name unique bounded finding codes");
    }
    if (typeof value["policyDigest"] !== "string" || !/^[0-9a-f]{64}$/.test(value["policyDigest"])) {
      throw new RecordShapeError("malformed_shape", "resolution.policyDigest must be a sha256 digest");
    }
  } else {
    throw new RecordShapeError("malformed_shape", `resolution.kind must be "evidence" or "waiver"`);
  }
  return value;
}
function parseRecord(value) {
  if (!isRecordObject(value)) throw new RecordShapeError("malformed_shape", "a record must be an object");
  requireExactMembers(value, RECORD_MEMBERS, "record");
  if (value["schemaVersion"] !== RECORD_SCHEMA_VERSION) {
    throw new RecordShapeError(
      "malformed_shape",
      `unsupported schemaVersion ${JSON.stringify(value["schemaVersion"])}; this harness writes ${RECORD_SCHEMA_VERSION}`
    );
  }
  for (const member2 of ["recordId", "workspaceId", "gateId", "obligationId"]) {
    if (!isNonEmptyString(value[member2])) {
      throw new RecordShapeError("malformed_shape", `${member2} must be a non-empty string`);
    }
  }
  const record2 = {
    schemaVersion: RECORD_SCHEMA_VERSION,
    recordId: value["recordId"],
    workspaceId: value["workspaceId"],
    gateId: value["gateId"],
    obligationId: value["obligationId"],
    candidateBinding: parseBinding(value["candidateBinding"]),
    resolution: parseResolution(value["resolution"])
  };
  const derived = computeRecordId(record2.workspaceId, record2);
  if (derived !== record2.recordId) {
    throw new RecordShapeError(
      "identity_mismatch",
      `recordId ${record2.recordId} does not match the identity its contents produce (${derived})`
    );
  }
  return record2;
}
function parseStoredText(text4) {
  let parsed;
  try {
    parsed = JSON.parse(text4);
  } catch (error) {
    throw new RecordShapeError("corrupt_json", `not parseable as JSON: ${describe(error)}`);
  }
  return parseRecord(parsed);
}
function describe(error) {
  if (error instanceof Error) return error.message;
  return String(error);
}
function errorCode(error) {
  return typeof error === "object" && error !== null ? error.code : void 0;
}
function renderRecord(record2) {
  return `${JSON.stringify(record2, null, 2)}
`;
}
async function syncPath(target, required) {
  try {
    const handle = await open(target, "r");
    try {
      await handle.sync();
    } finally {
      await handle.close();
    }
  } catch (error) {
    if (required) throw error;
  }
}
function unwritable(target, error) {
  return blocked(
    storeBlocker(
      "record_store_unwritable",
      "The evidence store could not be written.",
      `${target}: ${describe(error)}`,
      {
        id: "restore-store-permissions",
        kind: "manual_action",
        summary: "Make the git directory writable by the account running the harness, then re-run."
      }
    )
  );
}
function unreadableStore(target, error) {
  return blocked(
    storeBlocker(
      "record_store_unreadable",
      "The evidence store could not be read.",
      `${target}: ${describe(error)}`,
      {
        id: "restore-store-readability",
        kind: "manual_action",
        summary: "Make the evidence store readable by the account running the harness, then re-run."
      }
    )
  );
}
function quarantineDetail(text4) {
  return sanitizedDetail(text4, "Quarantine detail");
}
function conflict(destination, reason) {
  return blocked(
    storeBlocker(
      "record_conflict",
      "A different record is already stored under this identity.",
      `${destination}: ${reason}`,
      {
        id: "inspect-conflicting-record",
        kind: "manual_action",
        summary: "Inspect the stored record; delete it only if you can account for how it got there."
      }
    )
  );
}
function prepareRecord(workspaceId, input) {
  try {
    const record2 = {
      schemaVersion: RECORD_SCHEMA_VERSION,
      recordId: computeRecordId(workspaceId, input),
      workspaceId,
      gateId: input.gateId,
      obligationId: input.obligationId,
      candidateBinding: input.candidateBinding,
      resolution: input.resolution
    };
    parseRecord(JSON.parse(JSON.stringify(record2)));
    return record2;
  } catch (error) {
    throw blocked(
      storeBlocker(
        "record_input_invalid",
        "The record to publish is not a well-formed evidence record.",
        describe(error),
        { id: "fix-record-input", kind: "code_change", summary: "Correct the record the recorder is publishing." }
      )
    );
  }
}
async function publishRecord(rootDir, input, options = {}) {
  const { storageDir, workspaceId } = await resolveRecordStorage(rootDir, options);
  const record2 = prepareRecord(workspaceId, input);
  const recordId = record2.recordId;
  const destination = path.join(storageDir, recordFileName(record2.gateId, record2.obligationId, recordId));
  const rendered = renderRecord(record2);
  try {
    await mkdir(storageDir, { recursive: true, mode: DIRECTORY_MODE });
    await chmod(storageDir, DIRECTORY_MODE);
  } catch (error) {
    throw unwritable(storageDir, error);
  }
  const temporary = path.join(storageDir, `.${recordId}.${process.pid}.${randomUUID()}.tmp`);
  try {
    try {
      await writeFile(temporary, rendered, { mode: RECORD_MODE, flag: "wx" });
      await chmod(temporary, RECORD_MODE);
    } catch (error) {
      if (UNWRITABLE_CODES.has(errorCode(error) ?? "")) throw unwritable(temporary, error);
      throw error;
    }
    await syncPath(temporary, true);
    if (options.beforeLink !== void 0) await options.beforeLink();
    try {
      await link(temporary, destination);
    } catch (error) {
      if (errorCode(error) !== "EEXIST") {
        if (UNWRITABLE_CODES.has(errorCode(error) ?? "")) throw unwritable(destination, error);
        throw error;
      }
      return { status: "idempotent", path: destination, record: await reconcile(destination, record2), workspaceId };
    }
    await syncPath(storageDir, false);
    return { status: "published", path: destination, record: record2, workspaceId };
  } finally {
    await rm(temporary, { force: true });
  }
}
async function reconcile(destination, intended) {
  let existingText;
  try {
    existingText = await readFile(destination, "utf8");
  } catch (error) {
    throw conflict(destination, `a record is already stored here and could not be read: ${describe(error)}`);
  }
  let existing;
  try {
    existing = parseStoredText(existingText);
  } catch (error) {
    throw conflict(destination, `the stored record is not usable: ${describe(error)}`);
  }
  if (digestCanonical(existing) !== digestCanonical(intended)) {
    throw conflict(destination, "the stored record shares this identity but carries different content");
  }
  return existing;
}
async function discoverRecords(rootDir, selector) {
  const { storageDir, workspaceId } = await resolveRecordStorage(rootDir, selector);
  const records = [];
  const quarantined = [];
  const ignored = [];
  let entries;
  try {
    entries = (await readdir(storageDir)).sort();
  } catch (error) {
    if (errorCode(error) === "ENOENT") return { storageDir, workspaceId, records, quarantined, ignored };
    throw unreadableStore(storageDir, error);
  }
  const prefix = slotPrefix(selector.gateId, selector.obligationId);
  for (const entry3 of entries) {
    const filePath = path.join(storageDir, entry3);
    if (entry3.startsWith(".") && entry3.endsWith(".tmp")) {
      ignored.push({ path: filePath, reason: "in_progress" });
      continue;
    }
    if (!entry3.endsWith(".json") || !entry3.startsWith(prefix)) {
      ignored.push({ path: filePath, reason: "foreign" });
      continue;
    }
    let text4;
    try {
      text4 = await readFile(filePath, "utf8");
    } catch (error) {
      quarantined.push({ path: filePath, reason: "unreadable", detail: quarantineDetail(describe(error)) });
      continue;
    }
    let record2;
    try {
      record2 = parseStoredText(text4);
    } catch (error) {
      const reason = error instanceof RecordShapeError ? error.reason : "malformed_shape";
      quarantined.push({ path: filePath, reason, detail: quarantineDetail(describe(error)) });
      continue;
    }
    const misfiling = record2.workspaceId !== workspaceId ? `record belongs to workspace ${record2.workspaceId}, this store is ${workspaceId}` : record2.gateId !== selector.gateId || record2.obligationId !== selector.obligationId ? `record is for ${record2.gateId}/${record2.obligationId}, filed under ${selector.gateId}/${selector.obligationId}` : entry3 !== recordFileName(record2.gateId, record2.obligationId, record2.recordId) ? `filename does not carry recordId ${record2.recordId}` : void 0;
    if (misfiling !== void 0) {
      quarantined.push({ path: filePath, reason: "identity_mismatch", detail: quarantineDetail(misfiling) });
      continue;
    }
    records.push(record2);
  }
  return { storageDir, workspaceId, records, quarantined, ignored };
}

// packages/kernel/src/validator/codes.ts
var DELIVERY_EVIDENCE_1 = "delivery-evidence/1";
var REVIEW_GREEN_1 = "review.green/1";
var SUPPORTED_ENVELOPE_SPECS = Object.freeze([DELIVERY_EVIDENCE_1]);
var SUPPORTED_PAYLOAD_SPECS = Object.freeze([REVIEW_GREEN_1, "checks.passed/1"]);
var CONFORMING_ATTESTATION_LEVEL = "self";
var MANIFEST_RULE_IDS = [
  "GEN-1",
  "GEN-2",
  "GEN-3",
  "GEN-4",
  "GEN-5",
  "ENV-1",
  "ENV-2",
  "ENV-3",
  "ENV-4",
  "ENV-5",
  "ENV-6",
  "ENV-7",
  "ENV-8",
  "ENV-9",
  "ENV-10",
  "ENV-11",
  "ENV-12",
  "ENV-13",
  "ENV-14",
  "SUB-1",
  "SUB-2",
  "SUB-3",
  "SUB-4",
  "SUB-5",
  "RG-1",
  "RG-2",
  "RG-3",
  "RG-4",
  "RG-5",
  "RG-6",
  "RG-7",
  "RG-8",
  "RG-9",
  "RG-10"
];
var META_RULE_IDS = Object.freeze(["GEN-3", "GEN-5", "SUB-5"]);
var MANIFEST_REJECTION_CODES = [
  "unknown_member",
  "unsupported_envelope_spec",
  "malformed_field",
  "invalid_provider_id",
  "unregistered_provider",
  "invalid_run_id",
  "invalid_pass_id",
  "unsupported_vcs",
  "invalid_object_id",
  "unsupported_identity_version",
  "repository_required",
  "run_history_final_mismatch",
  "artifact_path_invalid",
  "artifact_path_duplicate",
  "artifact_outside_run_root",
  "artifact_digest_mismatch",
  "unsupported_attestation",
  "no_claims",
  "duplicate_claim",
  "obligation_not_configured",
  "unsupported_payload_spec",
  "candidate_mismatch",
  "candidate_unprepared",
  "manifest_outside_run_root",
  "record_conflict",
  "verdict_not_green",
  "not_finalized",
  "edited_after_final_pass",
  "reviewer_set_invalid",
  "reviewer_set_incomplete",
  "approval_missing",
  "approval_mismatch",
  "finding_invalid",
  "blocking_finding_present",
  "actionable_unresolved",
  "illegal_deferral",
  "telemetry_mismatch",
  "iteration_count_mismatch",
  "invalid_cost"
];
var MANIFEST_REJECTION_REGISTRY = Object.freeze({
  unknown_member: { rules: ["GEN-1"], emitter: "validator" },
  unsupported_envelope_spec: { rules: ["GEN-2"], emitter: "validator" },
  malformed_field: { rules: ["GEN-4", "ENV-7"], emitter: "validator" },
  invalid_provider_id: { rules: ["ENV-1"], emitter: "validator" },
  unregistered_provider: { rules: ["ENV-1"], emitter: "validator" },
  invalid_run_id: { rules: ["ENV-2"], emitter: "validator" },
  invalid_pass_id: { rules: ["ENV-3"], emitter: "validator" },
  unsupported_vcs: { rules: ["ENV-4"], emitter: "validator" },
  invalid_object_id: { rules: ["ENV-5"], emitter: "validator" },
  unsupported_identity_version: { rules: ["ENV-6"], emitter: "validator" },
  repository_required: { rules: ["ENV-8"], emitter: "validator" },
  run_history_final_mismatch: { rules: ["ENV-9"], emitter: "validator" },
  artifact_path_invalid: { rules: ["ENV-10"], emitter: "validator" },
  artifact_path_duplicate: { rules: ["ENV-10"], emitter: "validator" },
  artifact_outside_run_root: { rules: ["ENV-10"], emitter: "recorder" },
  artifact_digest_mismatch: { rules: ["ENV-11"], emitter: "recorder" },
  unsupported_attestation: { rules: ["ENV-12", "ENV-13"], emitter: "validator" },
  no_claims: { rules: ["ENV-14"], emitter: "validator" },
  duplicate_claim: { rules: ["ENV-14"], emitter: "validator" },
  obligation_not_configured: { rules: ["ENV-14"], emitter: "validator" },
  unsupported_payload_spec: { rules: ["ENV-14"], emitter: "validator" },
  candidate_mismatch: { rules: ["SUB-1"], emitter: "validator" },
  candidate_unprepared: { rules: ["SUB-2"], emitter: "validator" },
  manifest_outside_run_root: { rules: ["SUB-3"], emitter: "recorder" },
  record_conflict: { rules: ["SUB-4"], emitter: "recorder" },
  verdict_not_green: { rules: ["RG-1"], emitter: "validator" },
  not_finalized: { rules: ["RG-1"], emitter: "validator" },
  edited_after_final_pass: { rules: ["RG-1"], emitter: "validator" },
  reviewer_set_invalid: { rules: ["RG-2"], emitter: "validator" },
  reviewer_set_incomplete: { rules: ["RG-3"], emitter: "validator" },
  approval_missing: { rules: ["RG-4"], emitter: "validator" },
  approval_mismatch: { rules: ["RG-4"], emitter: "validator" },
  finding_invalid: { rules: ["RG-5"], emitter: "validator" },
  blocking_finding_present: { rules: ["RG-6"], emitter: "validator" },
  actionable_unresolved: { rules: ["RG-6"], emitter: "validator" },
  illegal_deferral: { rules: ["RG-7"], emitter: "validator" },
  telemetry_mismatch: { rules: ["RG-8"], emitter: "validator" },
  iteration_count_mismatch: { rules: ["RG-9"], emitter: "validator" },
  invalid_cost: { rules: ["RG-10"], emitter: "validator" }
});
var VALIDATOR_EMITTED_CODES = Object.freeze(
  MANIFEST_REJECTION_CODES.filter((code) => MANIFEST_REJECTION_REGISTRY[code].emitter === "validator")
);
var RECORDER_EMITTED_CODES = Object.freeze(
  MANIFEST_REJECTION_CODES.filter((code) => MANIFEST_REJECTION_REGISTRY[code].emitter === "recorder")
);
function isManifestRejectionCode(value) {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(MANIFEST_REJECTION_REGISTRY, value);
}

// packages/kernel/src/validator/grammar.ts
var GIT_OBJECT_ID = /^[0-9a-f]{40}$/;
var SHA256_HEX2 = /^[0-9a-f]{64}$/;
var PROVIDER_ID = /^[a-z0-9]+([._-][a-z0-9]+)*$/;
var RUN_ID = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
var OBLIGATION_ID = /^[a-z0-9]+(\.[a-z0-9-]+)*$/;
var ARTIFACT_ROLE = /^[a-z0-9]+(-[a-z0-9]+)*$/;
var DEFERRED_ISSUE_ID = /^[A-Z][A-Z0-9]*-[0-9]+$/;
function createCollector() {
  const rejections = [];
  return {
    emit(code, rule, pointer2, message) {
      rejections.push({ code, rule, pointer: pointer2, message });
    },
    list() {
      return rejections;
    }
  };
}
function pointer(base, ...segments) {
  let result2 = base;
  for (const segment of segments) {
    const token = typeof segment === "number" ? String(segment) : segment.replaceAll("~", "~0").replaceAll("/", "~1");
    result2 += `/${token}`;
  }
  return result2;
}
function isRecord2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isNonEmptyString2(value) {
  return typeof value === "string" && value.length > 0;
}
function member(value, name) {
  return value[name];
}
var GEN_1_UNKNOWN = Object.freeze({ code: "unknown_member", rule: "GEN-1" });
var GEN_4_MISSING = Object.freeze({ code: "malformed_field", rule: "GEN-4" });
function checkMembers(value, at, table2, codes, collector) {
  const defined = /* @__PURE__ */ new Set([...table2.required, ...table2.optional ?? []]);
  for (const name of Object.keys(value)) {
    if (!defined.has(name)) {
      collector.emit(codes.unknown.code, codes.unknown.rule, pointer(at, name), `member is not defined by this version's grammar`);
    }
  }
  for (const name of table2.required) {
    if (!Object.prototype.hasOwnProperty.call(value, name) || value[name] === void 0) {
      collector.emit(codes.missing.code, codes.missing.rule, pointer(at, name), `required member is absent`);
    }
  }
}
function canonicallyEqual(a, b) {
  let left;
  let right;
  try {
    left = canonicalize(a);
  } catch {
    return false;
  }
  try {
    right = canonicalize(b);
  } catch {
    return false;
  }
  return left === right;
}

// packages/kernel/src/validator/checks-passed.ts
function validateChecksPassed(payload, at, provider2, artifacts, context, collector) {
  checkMembers(payload, at, { required: ["verdict", "exitCode", "binding"], optional: [] }, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
  const providerId2 = typeof provider2.id === "string" ? provider2.id : void 0;
  const expected = providerId2 === void 0 ? void 0 : context.checkBindings?.[providerId2];
  let outputsMatch = false;
  try {
    const check = context.config.providers.find((entry3) => entry3.id === providerId2)?.check;
    if (check !== void 0) {
      const outputs = (check.outputs ?? []).map((output, index) => {
        if (!artifacts.some((artifact) => artifact.path === `check-output-${index}.json` && artifact.role === "check-output")) throw new Error("missing declared output artifact");
        return { path: output, sha256: sha256Hex(retainedCheckOutput(context.artifactContents, output, index)) };
      });
      const terminal = JSON.parse(context.artifactContents.get("check-result.json") ?? "null");
      outputsMatch = expected?.outputsDigest === digestCanonical(outputs) && artifacts.some((artifact) => artifact.path === "check-result.json" && artifact.role === "check-result") && canonicallyEqual(terminal, { providerId: provider2.id, runId: provider2.runId, finalPassId: provider2.finalPassId, ...payload });
    }
  } catch {
    outputsMatch = false;
  }
  if (!outputsMatch || payload["verdict"] !== "green" || payload["exitCode"] !== 0 || !isRecord2(payload["binding"]) || expected === void 0 || !canonicallyEqual(payload["binding"], expected)) {
    collector.emit("malformed_field", "GEN-4", at, "a passing declared check requires exit zero and the complete current check binding");
  }
}
function retainedCheckOutput(artifactContents, outputPath, index) {
  const text4 = artifactContents.get(`check-output-${index}.json`);
  if (text4 === void 0 || text4.length > 15e5) throw new Error("Missing or oversized retained check output");
  const value = JSON.parse(text4);
  if (typeof value !== "object" || value === null || Array.isArray(value)) throw new Error("Malformed retained check output");
  const entry3 = value;
  if (Object.keys(entry3).sort().join(",") !== "base64,path" || entry3["path"] !== outputPath || typeof entry3["base64"] !== "string") throw new Error("Mismatched retained check output");
  const bytes = Buffer.from(entry3["base64"], "base64");
  if (bytes.length > 1024 * 1024 || bytes.toString("base64") !== entry3["base64"]) throw new Error("Malformed retained check output bytes");
  return bytes;
}

// packages/kernel/src/validator/review-green.ts
var FINDING_SEVERITIES = Object.freeze(["P0", "P1", "P2", "P3"]);
var FINDING_SCOPES = Object.freeze(["in_contract", "adjacent", "expansion"]);
var FINDING_DISPOSITIONS = Object.freeze([
  "resolved",
  "advisory",
  "pre_existing",
  "deferred",
  "unresolved",
  "ignored"
]);
var SETTLED_DISPOSITIONS = Object.freeze(["resolved", "pre_existing", "deferred"]);
var DEFERRABLE_SEVERITIES = Object.freeze(["P2", "P3"]);
function reviewFindingCoherenceCodes(finding3) {
  const codes = [];
  if (finding3.blocking === true) codes.push("blocking_finding_present");
  if (finding3.actionable === true && !SETTLED_DISPOSITIONS.includes(finding3.disposition)) {
    codes.push("actionable_unresolved");
  }
  if (finding3.disposition === "deferred") {
    const legal = finding3.actionable === true && finding3.blocking === false && DEFERRABLE_SEVERITIES.includes(finding3.severity) && finding3.scope === "expansion" && isNonEmptyString2(finding3.deferredIssueId) && DEFERRED_ISSUE_ID.test(finding3.deferredIssueId);
    if (!legal) codes.push("illegal_deferral");
  } else if (finding3.deferredIssueId !== void 0) {
    codes.push("illegal_deferral");
  }
  return codes;
}
var REVIEWER_APPROVAL_ROLE = "reviewer-approval";
var PAYLOAD_MEMBERS = {
  required: ["verdict", "finalized", "editedAfterFinalPass", "reviewers", "findings", "telemetry"]
};
var REVIEWERS_MEMBERS = { required: ["selected", "completed", "failed", "timedOut"] };
var FINDING_MEMBERS = {
  required: ["id", "severity", "scope", "actionable", "blocking", "disposition"],
  optional: ["deferredIssueId"]
};
var TELEMETRY_MEMBERS = {
  required: ["iterationCount", "findingCounts", "deferredExpansionCount", "deferredIssueIds"],
  optional: ["cost"]
};
var FINDING_COUNTS_MEMBERS = { required: ["P0", "P1", "P2", "P3"] };
var COST_MEMBERS = { required: ["unit", "total", "reportedBy"], optional: ["byReviewer"] };
var APPROVAL_MEMBERS = {
  required: ["schemaVersion", "reviewerId", "result", "provider", "workspaceId", "candidate"]
};
var APPROVAL_PROVIDER_MEMBERS = { required: ["id", "runId", "finalPassId"] };
var FINDING_CODES = {
  unknown: GEN_1_UNKNOWN,
  missing: { code: "finding_invalid", rule: "RG-5" }
};
var COST_CODES = {
  unknown: GEN_1_UNKNOWN,
  missing: { code: "invalid_cost", rule: "RG-10" }
};
var APPROVAL_CODES = {
  unknown: { code: "approval_mismatch", rule: "RG-4" },
  missing: { code: "approval_mismatch", rule: "RG-4" }
};
function validateReviewGreenClaim(input, collector) {
  const { payload, at } = input;
  checkMembers(payload, at, PAYLOAD_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
  checkVerdict(payload, at, collector);
  const selected = checkReviewers(payload, at, collector);
  const findings2 = checkFindings(payload, at, collector);
  checkApprovals(input, selected, collector);
  checkTelemetry(input, selected, findings2, collector);
}
function checkVerdict(payload, at, collector) {
  const verdict = member(payload, "verdict");
  if (verdict !== void 0 && verdict !== "green") {
    collector.emit("verdict_not_green", "RG-1", pointer(at, "verdict"), "a manifest is only submitted for a concluded, passing review");
  }
  const finalized = member(payload, "finalized");
  if (finalized !== void 0 && finalized !== true) {
    collector.emit("not_finalized", "RG-1", pointer(at, "finalized"), "an unfinalized review has no claim to make");
  }
  const edited = member(payload, "editedAfterFinalPass");
  if (edited !== void 0 && edited !== false) {
    collector.emit("edited_after_final_pass", "RG-1", pointer(at, "editedAfterFinalPass"), "the reviewed tree is not the tree being submitted");
  }
}
function checkReviewers(payload, at, collector) {
  const reviewers = member(payload, "reviewers");
  const reviewersAt = pointer(at, "reviewers");
  if (!isRecord2(reviewers)) {
    if (reviewers !== void 0) {
      collector.emit("reviewer_set_invalid", "RG-2", reviewersAt, "reviewers is not an object");
    }
    return [];
  }
  checkMembers(reviewers, reviewersAt, REVIEWERS_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
  const selected = readReviewerList(reviewers, "selected", reviewersAt, collector);
  if (selected.length === 0) {
    collector.emit("reviewer_set_invalid", "RG-2", pointer(reviewersAt, "selected"), "a review with no reviewers is not a review");
  } else if (new Set(selected).size !== selected.length) {
    collector.emit("reviewer_set_invalid", "RG-2", pointer(reviewersAt, "selected"), "selected reviewers are not unique");
  }
  const completed = readReviewerList(reviewers, "completed", reviewersAt, collector);
  const selectedSet = new Set(selected);
  const completedSet = new Set(completed);
  const setEqual = selectedSet.size === completedSet.size && [...selectedSet].every((id) => completedSet.has(id));
  if (!setEqual) {
    collector.emit("reviewer_set_incomplete", "RG-3", pointer(reviewersAt, "completed"), "completed is not set-equal to selected");
  }
  for (const name of ["failed", "timedOut"]) {
    const list = readReviewerList(reviewers, name, reviewersAt, collector);
    if (list.length > 0) {
      collector.emit("reviewer_set_incomplete", "RG-3", pointer(reviewersAt, name), "a reviewer that did not complete is present");
    }
  }
  return selected;
}
function readReviewerList(reviewers, name, at, collector) {
  const value = member(reviewers, name);
  if (value === void 0) return [];
  if (!Array.isArray(value)) {
    collector.emit("reviewer_set_invalid", "RG-2", pointer(at, name), "reviewer list is not an array");
    return [];
  }
  const entries = [];
  value.forEach((entry3, index) => {
    if (!isNonEmptyString2(entry3)) {
      collector.emit("reviewer_set_invalid", "RG-2", pointer(at, name, index), "reviewer id is empty or not a string");
      return;
    }
    entries.push(entry3);
  });
  return entries;
}
function checkFindings(payload, at, collector) {
  const findings2 = member(payload, "findings");
  const findingsAt = pointer(at, "findings");
  if (!Array.isArray(findings2)) {
    if (findings2 !== void 0) collector.emit("finding_invalid", "RG-5", findingsAt, "findings is not an array");
    return [];
  }
  const derived = [];
  const ids = /* @__PURE__ */ new Set();
  findings2.forEach((finding3, index) => {
    const findingAt = pointer(findingsAt, index);
    if (!isRecord2(finding3)) {
      collector.emit("finding_invalid", "RG-5", findingAt, "finding is not an object");
      return;
    }
    checkMembers(finding3, findingAt, FINDING_MEMBERS, FINDING_CODES, collector);
    const id = member(finding3, "id");
    if (id !== void 0) {
      if (!isNonEmptyString2(id)) {
        collector.emit("finding_invalid", "RG-5", pointer(findingAt, "id"), "finding id is empty or not a string");
      } else if (ids.has(id)) {
        collector.emit("finding_invalid", "RG-5", pointer(findingAt, "id"), "finding id is not unique");
      } else {
        ids.add(id);
      }
    }
    const severity = member(finding3, "severity");
    if (severity !== void 0 && !FINDING_SEVERITIES.includes(severity)) {
      collector.emit("finding_invalid", "RG-5", pointer(findingAt, "severity"), "severity is not a defined value");
    }
    const scope = member(finding3, "scope");
    if (scope !== void 0 && !FINDING_SCOPES.includes(scope)) {
      collector.emit("finding_invalid", "RG-5", pointer(findingAt, "scope"), "scope is not a defined value");
    }
    const disposition = member(finding3, "disposition");
    if (disposition !== void 0 && !FINDING_DISPOSITIONS.includes(disposition)) {
      collector.emit("finding_invalid", "RG-5", pointer(findingAt, "disposition"), "disposition is not a defined value");
    }
    const actionable = member(finding3, "actionable");
    const blocking = member(finding3, "blocking");
    if (actionable !== void 0 && typeof actionable !== "boolean") {
      collector.emit("finding_invalid", "RG-5", pointer(findingAt, "actionable"), "actionable is not a boolean");
    }
    if (blocking !== void 0 && typeof blocking !== "boolean") {
      collector.emit("finding_invalid", "RG-5", pointer(findingAt, "blocking"), "blocking is not a boolean");
    }
    const coherenceCodes = reviewFindingCoherenceCodes({ severity, scope, actionable, blocking, disposition, deferredIssueId: member(finding3, "deferredIssueId") });
    if (coherenceCodes.includes("blocking_finding_present")) {
      collector.emit("blocking_finding_present", "RG-6", pointer(findingAt, "blocking"), "a blocking finding contradicts a green verdict");
    }
    if (coherenceCodes.includes("actionable_unresolved")) {
      collector.emit("actionable_unresolved", "RG-6", pointer(findingAt, "disposition"), "actionable work is neither resolved, pre-existing, nor deferred");
    }
    const deferredIssueId = member(finding3, "deferredIssueId");
    if (coherenceCodes.includes("illegal_deferral")) {
      collector.emit(
        "illegal_deferral",
        "RG-7",
        disposition === "deferred" ? findingAt : pointer(findingAt, "deferredIssueId"),
        disposition === "deferred" ? "deferral does not satisfy every condition deferral requires" : "a tracker id on a finding that was not deferred"
      );
    }
    derived.push({ severity, disposition, deferredIssueId });
  });
  return derived;
}
function checkApprovals(input, selected, collector) {
  const approvals = input.artifacts.filter((artifact) => artifact.role === REVIEWER_APPROVAL_ROLE);
  const covered = /* @__PURE__ */ new Map();
  for (const artifact of approvals) {
    const at = pointer("/artifacts", artifact.index);
    const content = input.artifactContents.get(artifact.path);
    if (content === void 0) {
      collector.emit("approval_mismatch", "RG-4", at, "approval artifact content is unavailable");
      continue;
    }
    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch {
      collector.emit("approval_mismatch", "RG-4", at, "approval artifact is not JSON");
      continue;
    }
    if (!isRecord2(parsed)) {
      collector.emit("approval_mismatch", "RG-4", at, "approval artifact is not a JSON object");
      continue;
    }
    checkMembers(parsed, at, APPROVAL_MEMBERS, APPROVAL_CODES, collector);
    const reviewerId = member(parsed, "reviewerId");
    if (isNonEmptyString2(reviewerId)) {
      covered.set(reviewerId, (covered.get(reviewerId) ?? 0) + 1);
    } else {
      collector.emit("approval_mismatch", "RG-4", pointer(at, "reviewerId"), "approval names no reviewer");
    }
    if (member(parsed, "schemaVersion") !== 1) {
      collector.emit("approval_mismatch", "RG-4", pointer(at, "schemaVersion"), "approval stamp schema version is not the one \xA79.2 defines");
    }
    if (member(parsed, "result") !== "approved") {
      collector.emit("approval_mismatch", "RG-4", pointer(at, "result"), "approval stamp does not record an approval");
    }
    const stampProvider = member(parsed, "provider");
    if (isRecord2(stampProvider)) {
      checkMembers(stampProvider, pointer(at, "provider"), APPROVAL_PROVIDER_MEMBERS, APPROVAL_CODES, collector);
    }
    const providerMatches = isRecord2(stampProvider) && member(stampProvider, "id") === input.provider.id && member(stampProvider, "runId") === input.provider.runId && member(stampProvider, "finalPassId") === input.provider.finalPassId;
    if (!providerMatches) {
      collector.emit("approval_mismatch", "RG-4", pointer(at, "provider"), "approval stamp names a different provider, run, or pass");
    }
    const envelopeWorkspaceId = isRecord2(input.candidate) ? member(input.candidate, "workspaceId") : void 0;
    if (member(parsed, "workspaceId") !== envelopeWorkspaceId) {
      collector.emit("approval_mismatch", "RG-4", pointer(at, "workspaceId"), "approval stamp names a different workspace");
    }
    if (!canonicallyEqual(member(parsed, "candidate"), input.candidate)) {
      collector.emit("approval_mismatch", "RG-4", pointer(at, "candidate"), "approval stamp restates a different candidate");
    }
  }
  for (const reviewer2 of selected) {
    const count = covered.get(reviewer2) ?? 0;
    if (count === 0) {
      collector.emit("approval_missing", "RG-4", "/artifacts", "a selected reviewer has no approval artifact");
    } else if (count > 1) {
      collector.emit("approval_mismatch", "RG-4", "/artifacts", "a selected reviewer is covered by more than one approval artifact");
    }
  }
  const selectedSet = new Set(selected);
  for (const reviewer2 of covered.keys()) {
    if (!selectedSet.has(reviewer2)) {
      collector.emit("approval_mismatch", "RG-4", "/artifacts", "an approval artifact names a reviewer that was not selected");
    }
  }
}
function checkTelemetry(input, selected, findings2, collector) {
  const at = pointer(input.at, "telemetry");
  const telemetry = member(input.payload, "telemetry");
  if (!isRecord2(telemetry)) {
    if (telemetry !== void 0) collector.emit("telemetry_mismatch", "RG-8", at, "telemetry is not an object");
    return;
  }
  checkMembers(telemetry, at, TELEMETRY_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
  const iterationCount = member(telemetry, "iterationCount");
  if (iterationCount !== input.runHistoryLength) {
    collector.emit("iteration_count_mismatch", "RG-9", pointer(at, "iterationCount"), "iteration count disagrees with the number of run history entries");
  }
  const derivedCounts = { P0: 0, P1: 0, P2: 0, P3: 0 };
  for (const finding3 of findings2) {
    if (typeof finding3.severity === "string" && Object.prototype.hasOwnProperty.call(derivedCounts, finding3.severity)) {
      derivedCounts[finding3.severity] = (derivedCounts[finding3.severity] ?? 0) + 1;
    }
  }
  const declaredCounts = member(telemetry, "findingCounts");
  const countsAt = pointer(at, "findingCounts");
  if (isRecord2(declaredCounts)) {
    checkMembers(declaredCounts, countsAt, FINDING_COUNTS_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
    for (const severity of FINDING_SEVERITIES) {
      if (member(declaredCounts, severity) !== derivedCounts[severity]) {
        collector.emit("telemetry_mismatch", "RG-8", pointer(countsAt, severity), "declared finding count disagrees with the findings");
      }
    }
  } else if (declaredCounts !== void 0) {
    collector.emit("telemetry_mismatch", "RG-8", countsAt, "findingCounts is not an object");
  }
  const deferred = findings2.filter((finding3) => finding3.disposition === "deferred");
  if (member(telemetry, "deferredExpansionCount") !== deferred.length) {
    collector.emit("telemetry_mismatch", "RG-8", pointer(at, "deferredExpansionCount"), "deferral count disagrees with the findings");
  }
  const derivedIds = [...new Set(deferred.map((finding3) => finding3.deferredIssueId).filter(isNonEmptyString2))].sort();
  const declaredIds = member(telemetry, "deferredIssueIds");
  if (!Array.isArray(declaredIds) || !canonicallyEqual(declaredIds, derivedIds)) {
    collector.emit("telemetry_mismatch", "RG-8", pointer(at, "deferredIssueIds"), "deferred issue ids disagree with the findings");
  }
  checkCost(telemetry, at, selected, collector);
}
function checkCost(telemetry, telemetryAt, selected, collector) {
  const cost2 = member(telemetry, "cost");
  if (cost2 === void 0) return;
  const at = pointer(telemetryAt, "cost");
  if (!isRecord2(cost2)) {
    collector.emit("invalid_cost", "RG-10", at, "cost is not an object");
    return;
  }
  checkMembers(cost2, at, COST_MEMBERS, COST_CODES, collector);
  if (!isNonEmptyString2(member(cost2, "unit"))) {
    collector.emit("invalid_cost", "RG-10", pointer(at, "unit"), "cost unit is empty or not a string");
  }
  if (!isNonEmptyString2(member(cost2, "reportedBy"))) {
    collector.emit("invalid_cost", "RG-10", pointer(at, "reportedBy"), "cost reporter is empty or not a string");
  }
  const total = member(cost2, "total");
  const totalIsNumber = typeof total === "number" && Number.isFinite(total);
  if (!totalIsNumber || total < 0) {
    collector.emit("invalid_cost", "RG-10", pointer(at, "total"), "cost total is not a non-negative number");
  }
  const byReviewer = member(cost2, "byReviewer");
  if (byReviewer === void 0) return;
  if (!isRecord2(byReviewer)) {
    collector.emit("invalid_cost", "RG-10", pointer(at, "byReviewer"), "cost breakdown is not an object");
    return;
  }
  const selectedSet = new Set(selected);
  let sum = 0;
  for (const reviewer2 of Object.keys(byReviewer)) {
    if (!selectedSet.has(reviewer2)) {
      collector.emit("invalid_cost", "RG-10", pointer(at, "byReviewer", reviewer2), "cost breakdown names a reviewer that was not selected");
    }
    const amount = member(byReviewer, reviewer2);
    if (typeof amount !== "number" || !Number.isFinite(amount) || amount < 0) {
      collector.emit("invalid_cost", "RG-10", pointer(at, "byReviewer", reviewer2), "cost share is not a non-negative number");
      continue;
    }
    sum += amount;
  }
  if (totalIsNumber && sum > total) {
    collector.emit("invalid_cost", "RG-10", pointer(at, "byReviewer"), "cost breakdown sums above the reported total");
  }
}

// packages/kernel/src/validator/envelope.ts
var ENVELOPE_MEMBERS = {
  required: ["spec", "provider", "candidate", "runHistory", "artifacts", "attestation", "recordedAt", "claims"],
  optional: ["repository"]
};
var PROVIDER_MEMBERS = { required: ["id", "runId", "finalPassId"], optional: ["version"] };
var CANDIDATE_MEMBERS = {
  required: ["vcs", "treeSha", "deliverable", "base", "workspaceId"],
  optional: ["headSha"]
};
var DELIVERABLE_MEMBERS = { required: ["digest", "identity"] };
var BASE_MEMBERS = { required: ["ref", "tipSha", "mergeBaseSha"] };
var RUN_HISTORY_MEMBERS = { required: ["preparedTreeSha", "evaluatedInPassId"] };
var ARTIFACT_MEMBERS = { required: ["path", "sha256", "role"] };
var ATTESTATION_MEMBERS = { required: ["level", "signatures"] };
var CLAIM_MEMBERS = { required: ["obligation", "payloadSpec", "payload"] };
function validateManifest(submitted, context) {
  const collector = createCollector();
  if (!isRecord2(submitted)) {
    collector.emit("malformed_field", "GEN-4", "", "manifest is not a JSON object");
    return finish(collector, submitted);
  }
  checkMembers(submitted, "", ENVELOPE_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
  checkSpec(submitted, context.config, collector);
  const providerIdentity = checkProvider(submitted, collector);
  checkCandidate(submitted, context, collector);
  checkAttestationAndRepository(submitted, collector);
  const runHistoryLength = checkRunHistory(submitted, collector);
  const artifacts = checkArtifacts(submitted, collector);
  checkTimestamp(submitted, collector);
  checkClaims(submitted, {
    context,
    collector,
    providerIdentity,
    artifacts,
    runHistoryLength
  });
  checkPreparation(context, collector);
  return finish(collector, submitted);
}
function finish(collector, submitted) {
  const rejections = collector.list();
  const [first2, ...rest] = rejections;
  if (first2 === void 0) {
    return { ok: true, manifest: submitted };
  }
  const all = [first2, ...rest];
  return { ok: false, rejections: all };
}
function checkSpec(root, config, collector) {
  const spec = member(root, "spec");
  if (spec === void 0) return;
  if (!isNonEmptyString2(spec) || !SUPPORTED_ENVELOPE_SPECS.includes(spec) || !config.acceptedEnvelopeSpecs.includes(spec)) {
    collector.emit("unsupported_envelope_spec", "GEN-2", "/spec", "envelope spec is not one this repository accepts and this validator implements");
  }
}
function checkProvider(root, collector) {
  const provider2 = member(root, "provider");
  if (!isRecord2(provider2)) {
    if (provider2 !== void 0) collector.emit("malformed_field", "GEN-4", "/provider", "provider is not an object");
    return { id: void 0, runId: void 0, finalPassId: void 0 };
  }
  checkMembers(provider2, "/provider", PROVIDER_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
  const id = member(provider2, "id");
  if (id !== void 0 && (!isNonEmptyString2(id) || !PROVIDER_ID.test(id))) {
    collector.emit("invalid_provider_id", "ENV-1", "/provider/id", "provider id does not match the required slug grammar");
  }
  const runId = member(provider2, "runId");
  if (runId !== void 0) {
    const legal = isNonEmptyString2(runId) && runId.length <= 128 && RUN_ID.test(runId) && runId !== "." && runId !== "..";
    if (!legal) {
      collector.emit("invalid_run_id", "ENV-2", "/provider/runId", "run id is not a single safe path component");
    }
  }
  const finalPassId = member(provider2, "finalPassId");
  if (finalPassId !== void 0 && !isNonEmptyString2(finalPassId)) {
    collector.emit("invalid_pass_id", "ENV-3", "/provider/finalPassId", "final pass id is empty or not a string");
  }
  const version = member(provider2, "version");
  if (version !== void 0 && !isNonEmptyString2(version)) {
    collector.emit("malformed_field", "GEN-4", "/provider/version", "provider version is empty or not a string");
  }
  return { id, runId, finalPassId };
}
function checkCandidate(root, context, collector) {
  const candidate2 = member(root, "candidate");
  if (!isRecord2(candidate2)) {
    if (candidate2 !== void 0) collector.emit("malformed_field", "GEN-4", "/candidate", "candidate is not an object");
    return;
  }
  checkMembers(candidate2, "/candidate", CANDIDATE_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
  const vcs = member(candidate2, "vcs");
  if (vcs !== void 0 && vcs !== "git") {
    collector.emit("unsupported_vcs", "ENV-4", "/candidate/vcs", "only git is supported in this version");
  }
  checkObjectId(candidate2, "treeSha", "/candidate/treeSha", collector);
  checkObjectId(candidate2, "headSha", "/candidate/headSha", collector);
  const deliverable = member(candidate2, "deliverable");
  if (isRecord2(deliverable)) {
    checkMembers(deliverable, "/candidate/deliverable", DELIVERABLE_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
    const digest2 = member(deliverable, "digest");
    if (digest2 !== void 0 && (!isNonEmptyString2(digest2) || !SHA256_HEX2.test(digest2))) {
      collector.emit("malformed_field", "GEN-4", "/candidate/deliverable/digest", "deliverable digest is not 64-hex lowercase");
    }
    const identity = member(deliverable, "identity");
    if (identity !== void 0 && (!isNonEmptyString2(identity) || !context.config.identityVersions.includes(identity))) {
      collector.emit("unsupported_identity_version", "ENV-6", "/candidate/deliverable/identity", "deliverable identity version is not one this repository implements");
    }
  } else if (deliverable !== void 0) {
    collector.emit("malformed_field", "GEN-4", "/candidate/deliverable", "deliverable is not an object");
  }
  const base = member(candidate2, "base");
  if (isRecord2(base)) {
    checkMembers(base, "/candidate/base", BASE_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
    const ref = member(base, "ref");
    if (ref !== void 0 && !isNonEmptyString2(ref)) {
      collector.emit("malformed_field", "GEN-4", "/candidate/base/ref", "base ref is empty or not a string");
    }
    checkObjectId(base, "tipSha", "/candidate/base/tipSha", collector);
    checkObjectId(base, "mergeBaseSha", "/candidate/base/mergeBaseSha", collector);
  } else if (base !== void 0) {
    collector.emit("malformed_field", "GEN-4", "/candidate/base", "base is not an object");
  }
  const workspaceId = member(candidate2, "workspaceId");
  if (workspaceId !== void 0 && !isNonEmptyString2(workspaceId)) {
    collector.emit("malformed_field", "ENV-7", "/candidate/workspaceId", "workspace id is empty or not a string");
  }
  if (!canonicallyEqual(candidate2, context.currentCandidate)) {
    collector.emit("candidate_mismatch", "SUB-1", "/candidate", "candidate does not match the currently prepared candidate");
  }
}
function checkObjectId(holder, name, at, collector) {
  const value = member(holder, name);
  if (value === void 0) return;
  if (!isNonEmptyString2(value) || !GIT_OBJECT_ID.test(value)) {
    collector.emit("invalid_object_id", "ENV-5", at, "value is not a 40-hex lowercase git object id");
  }
}
function checkAttestationAndRepository(root, collector) {
  const attestation = member(root, "attestation");
  let level;
  if (isRecord2(attestation)) {
    checkMembers(attestation, "/attestation", ATTESTATION_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
    level = member(attestation, "level");
    if (level !== void 0 && level !== CONFORMING_ATTESTATION_LEVEL) {
      collector.emit("unsupported_attestation", "ENV-12", "/attestation/level", "only self-attested evidence conforms to this version");
    }
    const signatures = member(attestation, "signatures");
    if (signatures !== void 0 && (!Array.isArray(signatures) || signatures.length > 0)) {
      collector.emit("unsupported_attestation", "ENV-13", "/attestation/signatures", "signatures must be the empty array until a signing profile exists");
    }
  } else if (attestation !== void 0) {
    collector.emit("malformed_field", "GEN-4", "/attestation", "attestation is not an object");
  }
  const repository = member(root, "repository");
  if (repository !== void 0 && repository !== null && !isNonEmptyString2(repository)) {
    collector.emit("malformed_field", "GEN-4", "/repository", "repository is neither null nor a non-empty string");
  }
  if (level !== void 0 && level !== CONFORMING_ATTESTATION_LEVEL && (repository === void 0 || repository === null)) {
    collector.emit("repository_required", "ENV-8", "/repository", "evidence above level self must name the repository it is about");
  }
}
function checkRunHistory(root, collector) {
  const runHistory = member(root, "runHistory");
  if (!Array.isArray(runHistory)) {
    if (runHistory !== void 0) collector.emit("malformed_field", "GEN-4", "/runHistory", "runHistory is not an array");
    return 0;
  }
  runHistory.forEach((entry3, index) => {
    const at = pointer("/runHistory", index);
    if (!isRecord2(entry3)) {
      collector.emit("malformed_field", "GEN-4", at, "run history entry is not an object");
      return;
    }
    checkMembers(entry3, at, RUN_HISTORY_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
    checkObjectId(entry3, "preparedTreeSha", pointer(at, "preparedTreeSha"), collector);
    const passId = member(entry3, "evaluatedInPassId");
    if (passId !== void 0 && !isNonEmptyString2(passId)) {
      collector.emit("invalid_pass_id", "ENV-3", pointer(at, "evaluatedInPassId"), "pass id is empty or not a string");
    }
  });
  const provider2 = member(root, "provider");
  const candidate2 = member(root, "candidate");
  const finalPassId = isRecord2(provider2) ? member(provider2, "finalPassId") : void 0;
  const treeSha2 = isRecord2(candidate2) ? member(candidate2, "treeSha") : void 0;
  const last2 = runHistory.at(-1);
  const bound2 = isRecord2(last2) && member(last2, "preparedTreeSha") === treeSha2 && treeSha2 !== void 0 && member(last2, "evaluatedInPassId") === finalPassId && finalPassId !== void 0;
  if (!bound2) {
    collector.emit("run_history_final_mismatch", "ENV-9", "/runHistory", "run history's final entry does not name the candidate tree and the final pass");
  }
  return runHistory.length;
}
function checkArtifacts(root, collector) {
  const artifacts = member(root, "artifacts");
  if (!Array.isArray(artifacts)) {
    if (artifacts !== void 0) collector.emit("malformed_field", "GEN-4", "/artifacts", "artifacts is not an array");
    return [];
  }
  const declared = [];
  const seen = /* @__PURE__ */ new Set();
  artifacts.forEach((entry3, index) => {
    const at = pointer("/artifacts", index);
    if (!isRecord2(entry3)) {
      collector.emit("malformed_field", "GEN-4", at, "artifact entry is not an object");
      return;
    }
    checkMembers(entry3, at, ARTIFACT_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
    const declaredPath = member(entry3, "path");
    if (declaredPath !== void 0) {
      if (!isNonEmptyString2(declaredPath) || !isSafeRelativePath(declaredPath)) {
        collector.emit("artifact_path_invalid", "ENV-10", pointer(at, "path"), "artifact path is absolute, empty, or escapes the run root");
      } else if (seen.has(declaredPath)) {
        collector.emit("artifact_path_duplicate", "ENV-10", pointer(at, "path"), "artifact path is declared more than once");
      } else {
        seen.add(declaredPath);
      }
    }
    const sha2562 = member(entry3, "sha256");
    if (sha2562 !== void 0 && (!isNonEmptyString2(sha2562) || !SHA256_HEX2.test(sha2562))) {
      collector.emit("malformed_field", "GEN-4", pointer(at, "sha256"), "artifact digest is not 64-hex lowercase");
    }
    const role = member(entry3, "role");
    if (role !== void 0 && (!isNonEmptyString2(role) || !ARTIFACT_ROLE.test(role))) {
      collector.emit("malformed_field", "GEN-4", pointer(at, "role"), "artifact role does not match the required slug grammar");
    }
    if (isNonEmptyString2(declaredPath) && isNonEmptyString2(sha2562) && isNonEmptyString2(role)) {
      declared.push({ index, path: declaredPath, sha256: sha2562, role });
    }
  });
  return declared;
}
function isSafeRelativePath(value) {
  if (value.includes("\0")) return false;
  if (value.startsWith("/") || value.startsWith("\\")) return false;
  if (/^[A-Za-z]:/.test(value)) return false;
  const segments = value.split(/[/\\]/);
  return !segments.includes("..") && !segments.includes("");
}
function checkTimestamp(root, collector) {
  const value = member(root, "recordedAt");
  if (value !== void 0 && !isNonEmptyString2(value)) {
    collector.emit("malformed_field", "GEN-4", "/recordedAt", "member is empty or not a string");
  }
}
function checkClaims(root, input) {
  const { collector, context } = input;
  const claims = member(root, "claims");
  if (!Array.isArray(claims)) {
    if (claims !== void 0) collector.emit("malformed_field", "GEN-4", "/claims", "claims is not an array");
    return;
  }
  if (claims.length === 0) {
    collector.emit("no_claims", "ENV-14", "/claims", "a manifest with no claims asserts nothing");
    return;
  }
  const seen = /* @__PURE__ */ new Set();
  claims.forEach((claim, index) => {
    const at = pointer("/claims", index);
    if (!isRecord2(claim)) {
      collector.emit("malformed_field", "GEN-4", at, "claim is not an object");
      return;
    }
    checkMembers(claim, at, CLAIM_MEMBERS, { unknown: GEN_1_UNKNOWN, missing: GEN_4_MISSING }, collector);
    const obligationId = member(claim, "obligation");
    let obligation;
    if (obligationId !== void 0) {
      if (!isNonEmptyString2(obligationId) || !OBLIGATION_ID.test(obligationId)) {
        collector.emit("malformed_field", "GEN-4", pointer(at, "obligation"), "obligation id does not match the required grammar");
      } else {
        if (seen.has(obligationId)) {
          collector.emit("duplicate_claim", "ENV-14", pointer(at, "obligation"), "obligation is claimed more than once in one manifest");
        }
        seen.add(obligationId);
        obligation = context.config.obligations.find((entry3) => entry3.id === obligationId);
        if (obligation === void 0) {
          collector.emit("obligation_not_configured", "ENV-14", pointer(at, "obligation"), "repository configuration declares no such obligation");
        }
      }
    }
    const providerId2 = input.providerIdentity.id;
    if (obligation !== void 0 && isNonEmptyString2(providerId2) && !obligation.providers.includes(providerId2)) {
      collector.emit("unregistered_provider", "ENV-1", "/provider/id", "provider is not registered for an obligation this manifest claims");
    }
    const payloadSpec = member(claim, "payloadSpec");
    let payloadSpecUsable = false;
    if (payloadSpec !== void 0) {
      const named = isNonEmptyString2(payloadSpec) ? payloadSpec : void 0;
      const acceptedHere = named !== void 0 && (obligation === void 0 || obligation.acceptedPayloadSpecs.includes(named));
      const implemented = named !== void 0 && SUPPORTED_PAYLOAD_SPECS.includes(named);
      if (!implemented || !acceptedHere) {
        collector.emit("unsupported_payload_spec", "ENV-14", pointer(at, "payloadSpec"), "payload spec is not one this repository accepts and this validator implements");
      } else {
        payloadSpecUsable = true;
      }
    }
    const payload = member(claim, "payload");
    if (payload !== void 0 && !isRecord2(payload)) {
      collector.emit("malformed_field", "GEN-4", pointer(at, "payload"), "payload is not an object");
      return;
    }
    if (payloadSpecUsable && payloadSpec === "checks.passed/1" && isRecord2(payload)) {
      validateChecksPassed(payload, pointer(at, "payload"), input.providerIdentity, input.artifacts, context, collector);
    }
    if (payloadSpecUsable && payloadSpec === REVIEW_GREEN_1 && isRecord2(payload)) {
      validateReviewGreenClaim(
        {
          payload,
          at: pointer(at, "payload"),
          provider: input.providerIdentity,
          candidate: member(root, "candidate"),
          artifacts: input.artifacts,
          artifactContents: context.artifactContents,
          runHistoryLength: input.runHistoryLength
        },
        collector
      );
    }
  });
}
function checkPreparation(context, collector) {
  if (!context.prepared) {
    collector.emit("candidate_unprepared", "SUB-2", "/candidate", "the candidate is not in a prepared state at submission");
  }
}

// packages/kernel/src/candidate.types.ts
var CANDIDATE_VCS = "git";
var CANDIDATE_MODES = ["clean", "staged-index"];
var CANDIDATE_CAPTURE_CODES = [
  "candidate_unprepared",
  "candidate_merge_in_progress",
  "candidate_ambiguous",
  "candidate_base_missing",
  "candidate_base_shallow",
  "candidate_base_unrelated",
  "candidate_repository_unreadable"
];
var CANDIDATE_DIFF_UNREADABLE = "candidate_diff_unreadable";
var CANDIDATE_DRIFT_CLASSES = [
  "deliverable_identity_changed",
  "raw_tree_changed",
  "base_tip_moved",
  "merge_base_moved",
  "workspace_changed"
];
function classifyCandidateDrift(expected, observed) {
  const classes = [];
  if (expected.deliverable.digest !== observed.deliverable.digest) classes.push("deliverable_identity_changed");
  if (expected.treeSha !== observed.treeSha) classes.push("raw_tree_changed");
  if (expected.base.tipSha !== observed.base.tipSha) classes.push("base_tip_moved");
  if (expected.base.mergeBaseSha !== observed.base.mergeBaseSha) classes.push("merge_base_moved");
  if (expected.workspaceId !== observed.workspaceId) classes.push("workspace_changed");
  return classes;
}
var CANDIDATE_PATH_CLASSES = ["relevant", "test", "generated", "lockfile"];
function globToRegExp(pattern) {
  let source = "";
  for (let index = 0; index < pattern.length; index += 1) {
    const character = pattern[index];
    if (character === "*") {
      if (pattern[index + 1] === "*") {
        if (pattern[index + 2] === "/") {
          source += "(?:.*/)?";
          index += 2;
        } else {
          source += ".*";
          index += 1;
        }
      } else {
        source += "[^/]*";
      }
      continue;
    }
    if (character === "?") {
      source += "[^/]";
      continue;
    }
    source += character.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  }
  return new RegExp(`^${source}$`);
}
var GLOB_CACHE = /* @__PURE__ */ new Map();
function globMatches(pattern, repoPath) {
  let compiled = GLOB_CACHE.get(pattern);
  if (compiled === void 0) {
    compiled = globToRegExp(pattern);
    GLOB_CACHE.set(pattern, compiled);
  }
  return compiled.test(repoPath);
}
function matchesPathMatcher(matcher, repoPath) {
  if (matcher.kind === "glob") return globMatches(matcher.value, repoPath);
  const prefix = matcher.value.endsWith("/") ? matcher.value.slice(0, -1) : matcher.value;
  return repoPath === prefix || repoPath.startsWith(`${prefix}/`);
}
function matchesAny(matchers, repoPath) {
  return matchers.some((matcher) => matchesPathMatcher(matcher, repoPath));
}
function classifyCandidatePath(classification, repoPath) {
  if (matchesAny(classification.lockfile, repoPath)) return "lockfile";
  if (matchesAny(classification.generated, repoPath)) return "generated";
  if (matchesAny(classification.test, repoPath)) return "test";
  return "relevant";
}
function sensitiveGroupsFor(groups, repoPath) {
  return groups.filter((group) => matchesAny(group.patterns, repoPath)).map((group) => group.id);
}
function entryPaths(entry3) {
  return entry3.oldPath === void 0 ? [entry3.path] : [entry3.oldPath, entry3.path];
}
function projectReviewActivation(entries, config) {
  let relevantLineCount = 0;
  let hasRelevantBinaryChange = false;
  let hasRelevantZeroLineChange = false;
  const relevantPaths = /* @__PURE__ */ new Set();
  const excludedPaths = /* @__PURE__ */ new Set();
  const binaryPaths = /* @__PURE__ */ new Set();
  const sensitivePathIds = /* @__PURE__ */ new Set();
  for (const entry3 of entries) {
    const paths = entryPaths(entry3);
    if (paths.every((repoPath) => matchesNeutralSet(config.reviewNeutral, repoPath))) {
      for (const repoPath of paths) excludedPaths.add(repoPath);
      continue;
    }
    for (const repoPath of paths) {
      for (const id of sensitiveGroupsFor(config.sensitivePaths, repoPath)) sensitivePathIds.add(id);
    }
    const relevant = paths.some((repoPath) => classifyCandidatePath(config.pathClassification, repoPath) === "relevant");
    if (!relevant) {
      for (const repoPath of paths) excludedPaths.add(repoPath);
      continue;
    }
    for (const repoPath of paths) relevantPaths.add(repoPath);
    if (entry3.binary || entry3.additions === null || entry3.deletions === null) {
      for (const repoPath of paths) binaryPaths.add(repoPath);
      hasRelevantBinaryChange = true;
      continue;
    }
    if (entry3.additions + entry3.deletions === 0) hasRelevantZeroLineChange = true;
    relevantLineCount += entry3.additions + entry3.deletions;
  }
  return {
    relevantLineCount,
    relevantPaths: [...relevantPaths].sort(),
    excludedPaths: [...excludedPaths].sort(),
    binaryPaths: [...binaryPaths].sort(),
    sensitivePathIds: [...sensitivePathIds].sort(),
    hasRelevantBinaryChange,
    hasRelevantZeroLineChange,
    changedEntryCount: entries.length
  };
}
function isObligationActive(activation, projection, activationThreshold) {
  if (activation.kind === "always") return true;
  if (projection.relevantLineCount >= activationThreshold) return true;
  if ((activation.relevantBinaryChangeActivates ?? true) && projection.hasRelevantBinaryChange) return true;
  if ((activation.relevantZeroLineChangeActivates ?? true) && projection.hasRelevantZeroLineChange) return true;
  const binding = activation.sensitiveGroupIds;
  if (binding === void 0) return projection.sensitivePathIds.length > 0;
  return projection.sensitivePathIds.some((id) => binding.includes(id));
}

// packages/kernel/src/candidate.ts
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import path2 from "node:path";
var DEFAULT_CAPTURE_ATTEMPTS = 3;
var GIT_ENVIRONMENT_PREFIX = "GIT_";
var GIT_ENVIRONMENT_OVERRIDES = {
  GIT_TERMINAL_PROMPT: "0",
  GIT_OPTIONAL_LOCKS: "0"
};
function scrubbedEnvironment() {
  const environment = {};
  for (const [name, value] of Object.entries(process.env)) {
    if (name.startsWith(GIT_ENVIRONMENT_PREFIX) || value === void 0) continue;
    environment[name] = value;
  }
  return { ...environment, ...GIT_ENVIRONMENT_OVERRIDES };
}
var runGitCommand = (command, options) => new Promise((resolve) => {
  const [executable, ...args] = command;
  if (executable === void 0) {
    resolve({ exitCode: -1, stdout: "", stderr: "no command was given" });
    return;
  }
  const child = spawn(executable, args, {
    cwd: options.cwd,
    env: scrubbedEnvironment(),
    stdio: ["ignore", "pipe", "pipe"],
    windowsHide: true
  });
  let stdout = "";
  let stderr = "";
  const chunks = [];
  if (!options.captureBytes) child.stdout.setEncoding("utf8");
  child.stdout.on("data", (chunk) => {
    if (options.captureBytes) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    else stdout += chunk;
  });
  child.stderr.setEncoding("utf8");
  child.stderr.on("data", (chunk) => {
    stderr += chunk;
  });
  child.once("error", (error) => {
    resolve({ exitCode: -1, stdout, stderr: error.message });
  });
  child.once("close", (code) => {
    const bytes = options.captureBytes ? Buffer.concat(chunks) : void 0;
    resolve({ exitCode: code ?? -1, stdout: bytes?.toString("utf8") ?? stdout, stderr, ...bytes === void 0 ? {} : { stdoutBase64: bytes.toString("base64") } });
  });
});
function candidateBlocker(config, code, summary, details, remediations) {
  return createBlocker({
    code,
    source: { kind: "candidate", id: config.gateId },
    summary,
    ...details === void 0 || details.trim() === "" ? {} : { details },
    remediations
  });
}
var INSPECT_STATUS = {
  id: "inspect-worktree-status",
  kind: "command",
  command: ["git", "status", "--short", "--untracked-files=all"],
  summary: "Inspect what the worktree currently carries."
};
function blocked2(config, code, summary, details, remediations) {
  return { ok: false, code, blockers: [candidateBlocker(config, code, summary, details, remediations)] };
}
var OBSERVATION_FIELDS = [
  "headSha",
  "headTreeSha",
  "indexTreeSha",
  "baseTipSha",
  "mergeBaseSha",
  "status",
  "untracked",
  "worktreeDirty"
];
function movedFields(before, after) {
  return OBSERVATION_FIELDS.filter((field) => before[field] !== after[field]);
}
var IN_PROGRESS_STATES = [
  { gitPath: "rebase-merge", operation: "rebase" },
  { gitPath: "rebase-apply", operation: "rebase" },
  { gitPath: "REBASE_HEAD", operation: "rebase" },
  { gitPath: "MERGE_HEAD", operation: "merge" },
  { gitPath: "CHERRY_PICK_HEAD", operation: "cherry-pick" },
  { gitPath: "REVERT_HEAD", operation: "revert" }
];
async function observe(run, rootDir, config) {
  const git = (args) => run(["git", ...args], { cwd: rootDir });
  const head = await git(["rev-parse", "--verify", "HEAD"]);
  if (head.exitCode !== 0) {
    return blocked2(
      config,
      "candidate_repository_unreadable",
      `${JSON.stringify(rootDir)} does not resolve a HEAD commit`,
      head.stderr,
      [
        {
          id: "run-inside-a-repository",
          kind: "manual_action",
          summary: "Run the harness inside a git repository that has at least one commit."
        }
      ]
    );
  }
  const headTree = await git(["rev-parse", "--verify", "HEAD^{tree}"]);
  if (headTree.exitCode !== 0) {
    return blocked2(config, "candidate_repository_unreadable", "HEAD names no tree", headTree.stderr, [
      {
        id: "repair-repository",
        kind: "manual_action",
        summary: "Repair the repository: HEAD resolves to a commit whose tree cannot be read."
      }
    ]);
  }
  const statePaths = await git(["rev-parse", ...IN_PROGRESS_STATES.flatMap((state) => ["--git-path", state.gitPath])]);
  if (statePaths.exitCode !== 0) {
    return blocked2(
      config,
      "candidate_repository_unreadable",
      "the repository would not say whether an operation is in progress",
      statePaths.stderr,
      [
        {
          id: "repair-repository",
          kind: "manual_action",
          summary: "Repair the repository: its git directory could not be located."
        }
      ]
    );
  }
  const stateLines = statePaths.stdout.split("\n").map((line) => line.trim());
  const inProgress = IN_PROGRESS_STATES.find((state, index) => {
    const line = stateLines[index];
    return line !== void 0 && line !== "" && existsSync(path2.resolve(rootDir, line));
  });
  if (inProgress !== void 0) {
    return blocked2(
      config,
      "candidate_merge_in_progress",
      `a ${inProgress.operation} is in progress, so the index does not yet describe a finished change`,
      `state left by the ${inProgress.operation}: ${inProgress.gitPath}`,
      [
        {
          id: "conclude-in-progress-operation",
          kind: "manual_action",
          summary: `Conclude the ${inProgress.operation} \u2014 finish it or abandon it \u2014 before preparing a candidate.`
        },
        INSPECT_STATUS
      ]
    );
  }
  const indexTree = await git(["write-tree"]);
  if (indexTree.exitCode !== 0) {
    return blocked2(config, "candidate_repository_unreadable", "the index does not define a tree", indexTree.stderr, [
      {
        id: "repair-index",
        kind: "manual_action",
        summary: "Repair the index: it could not be written out as a tree."
      },
      INSPECT_STATUS
    ]);
  }
  const baseTip = await git(["rev-parse", "--verify", `${config.baseRef}^{commit}`]);
  if (baseTip.exitCode !== 0) {
    return blocked2(
      config,
      "candidate_base_missing",
      `the configured base ref ${JSON.stringify(config.baseRef)} does not resolve to a commit`,
      baseTip.stderr,
      [
        {
          id: "fetch-base-ref",
          kind: "command",
          command: ["git", "fetch"],
          summary: "Fetch the remote so the configured base ref resolves."
        },
        {
          id: "declare-a-resolvable-base-ref",
          kind: "code_change",
          summary: "Declare a base ref this repository has, in the harness config."
        }
      ]
    );
  }
  const mergeBase = await git(["merge-base", config.baseRef, "HEAD"]);
  if (mergeBase.exitCode === 1) {
    const shallow = await git(["rev-parse", "--is-shallow-repository"]);
    if (shallow.exitCode !== 0) {
      return blocked2(config, "candidate_repository_unreadable", "the repository would not say whether it is shallow", shallow.stderr, [
        {
          id: "repair-repository",
          kind: "manual_action",
          summary: "Repair the repository: whether it is a shallow clone could not be determined."
        }
      ]);
    }
    if (shallow.stdout.trim() === "true") {
      return blocked2(
        config,
        "candidate_base_shallow",
        `this is a shallow clone, and any history HEAD shares with ${JSON.stringify(config.baseRef)} lies beyond its boundary`,
        mergeBase.stderr,
        [
          {
            id: "deepen-the-clone",
            kind: "command",
            command: ["git", "fetch", "--unshallow"],
            summary: "Deepen the clone so the merge base with the configured base ref is present."
          },
          {
            id: "check-out-with-full-history",
            kind: "manual_action",
            summary: "Check the repository out with full history \u2014 in CI, the checkout step's fetch depth."
          }
        ]
      );
    }
    return blocked2(
      config,
      "candidate_base_unrelated",
      `HEAD shares no history with the configured base ref ${JSON.stringify(config.baseRef)}`,
      mergeBase.stderr,
      [
        {
          id: "rebase-onto-the-base",
          kind: "manual_action",
          summary: "Base this branch on the configured base ref, or configure the base ref this branch descends from."
        }
      ]
    );
  }
  if (mergeBase.exitCode !== 0) {
    return blocked2(config, "candidate_repository_unreadable", "the merge base could not be computed", mergeBase.stderr, [
      {
        id: "repair-repository",
        kind: "manual_action",
        summary: "Repair the repository: the merge base between HEAD and the base ref could not be computed."
      }
    ]);
  }
  const status = await git(["status", "--porcelain", "-z", "--untracked-files=all"]);
  if (status.exitCode !== 0) {
    return blocked2(config, "candidate_repository_unreadable", "the worktree status could not be read", status.stderr, [
      { id: "repair-repository", kind: "manual_action", summary: "Repair the repository: its status could not be read." }
    ]);
  }
  const untracked = await git(["ls-files", "--others", "--exclude-standard", "-z"]);
  if (untracked.exitCode !== 0) {
    return blocked2(config, "candidate_repository_unreadable", "untracked files could not be listed", untracked.stderr, [
      { id: "repair-repository", kind: "manual_action", summary: "Repair the repository: untracked files could not be listed." }
    ]);
  }
  const unstaged = await git(["diff", "--quiet"]);
  if (unstaged.exitCode > 1 || unstaged.exitCode < 0) {
    return blocked2(config, "candidate_repository_unreadable", "unstaged changes could not be determined", unstaged.stderr, [
      { id: "repair-repository", kind: "manual_action", summary: "Repair the repository: its unstaged changes could not be determined." }
    ]);
  }
  return {
    ok: true,
    observation: {
      headSha: head.stdout.trim(),
      headTreeSha: headTree.stdout.trim(),
      indexTreeSha: indexTree.stdout.trim(),
      baseTipSha: baseTip.stdout.trim(),
      mergeBaseSha: mergeBase.stdout.trim(),
      status: status.stdout,
      untracked: untracked.stdout,
      worktreeDirty: unstaged.exitCode !== 0
    }
  };
}
function splitNulStream(output) {
  return output.split("\0").filter((entry3) => entry3 !== "");
}
function parseStatusEntries(output) {
  const records = output.split("\0");
  const entries = [];
  for (let index = 0; index < records.length; index += 1) {
    const record2 = records[index];
    if (record2 === void 0 || record2 === "") continue;
    const code = record2.slice(0, 2);
    entries.push({ code, path: record2.slice(3) });
    if (code.startsWith("R") || code.startsWith("C")) index += 1;
  }
  return entries;
}
var DECIMAL_COUNT = /^\d+$/;
function parseCandidateNumstat(output) {
  const records = output.split("\0");
  const entries = [];
  for (let index = 0; index < records.length; index += 1) {
    const record2 = records[index];
    if (record2 === void 0 || record2 === "") continue;
    const firstTab = record2.indexOf("	");
    const secondTab = firstTab < 0 ? -1 : record2.indexOf("	", firstTab + 1);
    if (firstTab < 0 || secondTab < 0) {
      throw new Error(`numstat record ${JSON.stringify(record2)} carries no counts`);
    }
    const additionsText = record2.slice(0, firstTab);
    const deletionsText = record2.slice(firstTab + 1, secondTab);
    const inlinePath = record2.slice(secondTab + 1);
    let repoPath = inlinePath;
    let oldPath;
    if (inlinePath === "") {
      const origin = records[index + 1];
      const destination = records[index + 2];
      if (origin === void 0 || origin === "" || destination === void 0 || destination === "") {
        throw new Error(`numstat record ${JSON.stringify(record2)} announces a rename whose paths are missing`);
      }
      oldPath = origin;
      repoPath = destination;
      index += 2;
    }
    const binary = additionsText === "-" || deletionsText === "-";
    if (!binary && !(DECIMAL_COUNT.test(additionsText) && DECIMAL_COUNT.test(deletionsText))) {
      throw new Error(`numstat record ${JSON.stringify(record2)} carries counts that are not plain decimal integers`);
    }
    const additions = binary ? null : Number(additionsText);
    const deletions = binary ? null : Number(deletionsText);
    entries.push({ path: repoPath, ...oldPath === void 0 ? {} : { oldPath }, additions, deletions, binary });
  }
  return entries;
}
function preparedCandidate(observation, config) {
  const untrackedFiles = splitNulStream(observation.untracked);
  if (observation.worktreeDirty || untrackedFiles.length > 0) {
    const detail = observation.worktreeDirty ? untrackedFiles.length > 0 ? `unstaged changes to tracked files, and untracked files: ${untrackedFiles.slice(0, 20).join(", ")}` : "unstaged changes to tracked files" : `untracked files: ${untrackedFiles.slice(0, 20).join(", ")}`;
    return blocked2(
      config,
      "candidate_unprepared",
      "the worktree carries content that is not part of any prepared candidate",
      detail,
      [
        {
          id: "stage-the-intended-change",
          kind: "manual_action",
          summary: "Stage the files this change is meant to deliver, then prepare the candidate again."
        },
        INSPECT_STATUS
      ]
    );
  }
  const statusEntries = parseStatusEntries(observation.status);
  if (statusEntries.length > 0 && observation.indexTreeSha === observation.headTreeSha) {
    return blocked2(
      config,
      "candidate_unprepared",
      "the worktree is not clean, yet the index defines no distinct tree to review",
      `status: ${statusEntries.map((entry3) => `${entry3.code} ${entry3.path}`).slice(0, 20).join("; ")}`,
      [
        {
          id: "stage-the-intended-change",
          kind: "manual_action",
          summary: "Stage the files this change is meant to deliver, then prepare the candidate again."
        },
        INSPECT_STATUS
      ]
    );
  }
  const mode = statusEntries.length > 0 ? "staged-index" : "clean";
  return { ok: true, mode, treeSha: mode === "staged-index" ? observation.indexTreeSha : observation.headTreeSha, statusEntries };
}
async function captureGitCandidate(options) {
  const run = options.run ?? runGitCommand;
  const maxAttempts = Math.max(1, options.maxAttempts ?? DEFAULT_CAPTURE_ATTEMPTS);
  let moved = [];
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const before = await observe(run, options.rootDir, options.config);
    if (!before.ok) return before;
    const after = await observe(run, options.rootDir, options.config);
    if (!after.ok) return after;
    moved = movedFields(before.observation, after.observation);
    if (moved.length > 0) continue;
    const prepared = preparedCandidate(after.observation, options.config);
    if (!prepared.ok) return prepared;
    const digest2 = await options.computeIdentity({
      rootDir: options.rootDir,
      treeSha: prepared.treeSha,
      config: options.config
    });
    const candidate2 = {
      vcs: CANDIDATE_VCS,
      headSha: after.observation.headSha,
      treeSha: prepared.treeSha,
      mode: prepared.mode,
      deliverable: { digest: digest2, identity: options.config.computingIdentityVersion },
      base: {
        ref: options.config.baseRef,
        tipSha: after.observation.baseTipSha,
        mergeBaseSha: after.observation.mergeBaseSha
      },
      workspaceId: options.workspaceId,
      statusEntries: prepared.statusEntries,
      untrackedFiles: []
    };
    return { ok: true, candidate: candidate2 };
  }
  return blocked2(
    options.config,
    "candidate_ambiguous",
    `the repository did not hold still across ${maxAttempts} consecutive observations`,
    `moved between observations: ${moved.join(", ")}`,
    [
      {
        id: "capture-a-quiescent-repository",
        kind: "retry",
        summary: "Stop whatever is writing to the repository \u2014 a watcher, a build, a rebase \u2014 and capture again."
      }
    ]
  );
}
function createCandidateCapture(options) {
  return () => captureGitCandidate(options);
}
async function evaluateCandidateActivation(options) {
  const run = options.run ?? runGitCommand;
  const result2 = await run(
    ["git", "diff", "--numstat", "--find-renames", "-z", options.candidate.base.mergeBaseSha, options.candidate.treeSha],
    { cwd: options.rootDir }
  );
  const failure = (details) => {
    throw new BlockedError(
      [
        candidateBlocker(
          options.config,
          CANDIDATE_DIFF_UNREADABLE,
          "the diff between the candidate and its base could not be read",
          details,
          [
            {
              id: "recapture-the-candidate",
              kind: "retry",
              summary: "Capture the candidate again; the base or the prepared tree it names is no longer readable."
            }
          ]
        )
      ],
      "The candidate's diff could not be read."
    );
  };
  if (result2.exitCode !== 0) failure(result2.stderr || result2.stdout);
  try {
    return projectReviewActivation(parseCandidateNumstat(result2.stdout), options.config);
  } catch (error) {
    return failure(error instanceof Error ? error.message : String(error));
  }
}

// packages/kernel/src/identity.ts
import { createHash as createHash2 } from "node:crypto";
var IDENTITY_DOMAIN = "identity";
var NUL = "\0";
var IDENTITY_FINDING_CODES = ["deliverable_tree_unreadable", "deliverable_tree_unparsable"];
function identityDefinitionOf(config) {
  return { identityToken: config.computingIdentityVersion, reviewNeutral: config.reviewNeutral };
}
function isReviewNeutralPath(config, repoPath) {
  return matchesNeutralSet(config.reviewNeutral, repoPath);
}
function isRecordNeutralPath(config, repoPath) {
  return matchesNeutralSet(config.recordNeutral, repoPath);
}
var RE_CAPTURE = {
  id: "recapture-the-candidate",
  kind: "retry",
  summary: "Capture the candidate again; the tree its identity is computed over is no longer readable."
};
function identityBlocker(config, code, summary, details) {
  return createBlocker({
    code,
    source: { kind: "candidate", id: config.gateId },
    summary,
    ...details.trim() === "" ? {} : { details },
    remediations: [RE_CAPTURE]
  });
}
var TREE_RECORD = /^(\S+) (\S+) (\S+)\t([\s\S]+)$/;
function parseTreeEntries(output, config) {
  const entries = [];
  for (const record2 of output.split(NUL)) {
    if (record2.length === 0) continue;
    const match = TREE_RECORD.exec(record2);
    if (match === null) {
      throw new BlockedError(
        [
          identityBlocker(
            config,
            "deliverable_tree_unparsable",
            "a tree listing record could not be read",
            `git ls-tree produced an unparsable record: ${JSON.stringify(record2)}`
          )
        ],
        "The candidate's tree listing could not be read."
      );
    }
    entries.push({ mode: match[1], objectSha: match[3], path: match[4] });
  }
  return entries;
}
function digestDeliverableEntries(entries, definition) {
  const hash = createHash2("sha256");
  hash.update(`${IDENTITY_DOMAIN}${NUL}${definition.identityToken}${NUL}`);
  const deliverable = entries.filter((entry3) => !matchesNeutralSet(definition.reviewNeutral, entry3.path)).sort((left, right) => compareUtf16CodeUnits(left.path, right.path));
  for (const entry3 of deliverable) {
    hash.update(`${entry3.mode}${NUL}${entry3.objectSha}${NUL}${entry3.path}${NUL}`);
  }
  return hash.digest("hex");
}
async function computeDeliverableIdentity(request, options = {}) {
  const run = options.run ?? runGitCommand;
  const command = ["git", "ls-tree", "-r", "-z", "--full-tree", request.treeSha];
  const result2 = await run(command, { cwd: request.rootDir });
  if (result2.exitCode !== 0) {
    throw new BlockedError(
      [
        identityBlocker(
          request.config,
          "deliverable_tree_unreadable",
          "the candidate's tree could not be listed",
          result2.stderr.trim() || result2.stdout.trim() || `${command.join(" ")} failed`
        )
      ],
      "The candidate's tree could not be listed."
    );
  }
  return digestDeliverableEntries(parseTreeEntries(result2.stdout, request.config), identityDefinitionOf(request.config));
}
function withDeliverableIdentity(options = {}) {
  return (request) => computeDeliverableIdentity(request, options);
}

// packages/kernel/src/preparation.ts
import { chmod as chmod2, mkdir as mkdir2, open as open2, readFile as readFile2, rename, rm as rm2, stat, writeFile as writeFile2 } from "node:fs/promises";
import { randomUUID as randomUUID2 } from "node:crypto";
import path3 from "node:path";
var PREPARATION_RECEIPT_SCHEMA_VERSION = 1;
var PREPARATION_RECEIPT_LEAF = "preparation";
var HARNESS_VERSION = "0.2.0";
var PREPARATION_FAILURE_CLASSES = ["missing", "invalid", "wiring_mismatch", "base_changed", "stale"];
var DIRECTORY_MODE2 = 448;
var RECEIPT_MODE = 384;
var PREPARE_AGAIN = {
  id: "prepare-current-candidate",
  kind: "manual_action",
  summary: "Prepare the current candidate again so a fresh receipt is published."
};
function describe2(error) {
  return error instanceof Error ? error.message : String(error);
}
function errorCode2(error) {
  return typeof error === "object" && error !== null ? error.code : void 0;
}
function preparationBlocker(code, id, summary, details, remediation) {
  const blocker = createBlocker({
    code,
    source: { kind: "preparation", id },
    summary,
    details,
    remediations: [remediation]
  });
  return new BlockedError([blocker], blocker.summary);
}
function wiringUnresolvable(repoPath, reason) {
  return preparationBlocker(
    "preparation_wiring_unresolvable",
    "wiring",
    "A declared preparation wiring path could not be read.",
    `${repoPath}: ${reason}`,
    {
      id: "restore-declared-wiring-path",
      kind: "manual_action",
      summary: "Restore the declared wiring file, or remove the path from preparationWiringPaths \u2014 it is never hashed as absent."
    }
  );
}
function storeUnwritable(target, error) {
  return preparationBlocker(
    "preparation_store_unwritable",
    "store",
    "The preparation receipt could not be written.",
    `${target}: ${describe2(error)}`,
    {
      id: "restore-store-permissions",
      kind: "manual_action",
      summary: "Make the git directory writable by the account running the harness, then prepare again."
    }
  );
}
function failureBlocker(failure, reason) {
  return createBlocker({
    code: `preparation_${failure}`,
    source: { kind: "preparation", id: failure },
    summary: FAILURE_SUMMARIES[failure],
    details: reason,
    remediations: [PREPARE_AGAIN]
  });
}
var FAILURE_SUMMARIES = {
  missing: "This candidate has no preparation receipt.",
  invalid: "The preparation receipt is not one this harness can read.",
  wiring_mismatch: "The harness wiring changed after the receipt was published.",
  base_changed: "The base moved after the candidate was prepared.",
  stale: "The candidate changed after it was prepared."
};
function receiptFileName(gateId) {
  return `${gateId}.json`;
}
function resolveReceiptStorage(rootDir, options = {}) {
  return resolveRecordStorage(rootDir, { ...options, leaf: PREPARATION_RECEIPT_LEAF });
}
async function computePreparationFingerprint(rootDir, config, options = {}) {
  const declared = [...new Set(config.preparationWiringPaths)].sort();
  const wiring = [];
  for (const repoPath of declared) {
    const target = path3.resolve(rootDir, repoPath);
    let contents;
    try {
      if (options.readWiring !== void 0) contents = Buffer.from(await options.readWiring(repoPath));
      else {
        const info = await stat(target);
        if (!info.isFile()) throw wiringUnresolvable(repoPath, `${target} is not a regular file`);
        contents = await readFile2(target);
      }
    } catch (error) {
      if (error instanceof BlockedError) throw error;
      throw wiringUnresolvable(repoPath, errorCode2(error) === "ENOENT" ? `${target} does not exist` : describe2(error));
    }
    wiring.push({ path: repoPath, digest: digestCanonical(contents.toString("base64")) });
  }
  return digestCanonical({
    harnessVersion: options.harnessVersion ?? HARNESS_VERSION,
    wiring,
    ...config.preparationCommands?.length ? { preparationCommands: config.preparationCommands } : {}
  });
}
async function invalidatePreparationReceipt(rootDir, config, options = {}) {
  const { storageDir } = await resolveReceiptStorage(rootDir, options);
  const receiptPath = path3.join(storageDir, receiptFileName(config.gateId));
  const attemptId = randomUUID2();
  const temporary = path3.join(storageDir, `.${attemptId}.tmp`);
  try {
    await mkdir2(storageDir, { recursive: true, mode: DIRECTORY_MODE2 });
    await writeFile2(temporary, attemptId, { flag: "wx", mode: RECEIPT_MODE });
    await syncFile(temporary);
    await rename(temporary, `${receiptPath}.attempt`);
    await rm2(receiptPath, { force: true });
    return attemptId;
  } catch (error) {
    throw storeUnwritable(receiptPath, error);
  } finally {
    await rm2(temporary, { force: true });
  }
}
async function currentAttempt(receiptPath) {
  try {
    return await readFile2(`${receiptPath}.attempt`, "utf8");
  } catch (error) {
    if (errorCode2(error) === "ENOENT") return void 0;
    throw error;
  }
}
async function requireCurrentAttempt(receiptPath, attemptId) {
  if (await currentAttempt(receiptPath) !== attemptId) {
    throw new BlockedError([failureBlocker("stale", "A newer preparation attempt superseded this receipt; prepare again.")]);
  }
}
function buildReceipt(workspaceId, gateId, candidate2, preparationFingerprint) {
  return {
    schemaVersion: PREPARATION_RECEIPT_SCHEMA_VERSION,
    gateId,
    workspaceId,
    treeSha: candidate2.treeSha,
    headSha: candidate2.headSha,
    mode: candidate2.mode,
    deliverableDigest: candidate2.deliverable.digest,
    identityToken: candidate2.deliverable.identity,
    baseRef: candidate2.base.ref,
    baseTipSha: candidate2.base.tipSha,
    mergeBaseSha: candidate2.base.mergeBaseSha,
    candidateWorkspaceId: candidate2.workspaceId,
    preparationFingerprint
  };
}
async function publishPreparationReceipt(rootDir, input, options = {}) {
  const fingerprint = await computePreparationFingerprint(rootDir, input.config, options);
  const { storageDir, workspaceId } = await resolveReceiptStorage(rootDir, options);
  const receipt = {
    ...buildReceipt(workspaceId, input.config.gateId, input.candidate, fingerprint),
    ...input.attemptId === void 0 ? {} : { attemptId: input.attemptId }
  };
  const destination = path3.join(storageDir, receiptFileName(input.config.gateId));
  await requireCurrentAttempt(destination, input.attemptId);
  try {
    await mkdir2(storageDir, { recursive: true, mode: DIRECTORY_MODE2 });
    await chmod2(storageDir, DIRECTORY_MODE2);
  } catch (error) {
    throw storeUnwritable(storageDir, error);
  }
  const temporary = path3.join(storageDir, `.${randomUUID2()}.tmp`);
  try {
    try {
      await writeFile2(temporary, `${JSON.stringify(receipt, null, 2)}
`, { encoding: "utf8", flag: "wx", mode: RECEIPT_MODE });
      await chmod2(temporary, RECEIPT_MODE);
    } catch (error) {
      throw storeUnwritable(temporary, error);
    }
    await syncFile(temporary);
    await requireCurrentAttempt(destination, input.attemptId);
    try {
      await rename(temporary, destination);
    } catch (error) {
      throw storeUnwritable(destination, error);
    }
    await requireCurrentAttempt(destination, input.attemptId);
    return { path: destination, receipt, workspaceId };
  } finally {
    await rm2(temporary, { force: true });
  }
}
async function syncFile(target) {
  const handle = await open2(target, "r");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}
var RECEIPT_MEMBERS = [
  "schemaVersion",
  "gateId",
  "workspaceId",
  "treeSha",
  "headSha",
  "mode",
  "deliverableDigest",
  "identityToken",
  "baseRef",
  "baseTipSha",
  "mergeBaseSha",
  "candidateWorkspaceId",
  "preparationFingerprint"
];
function parseReceipt(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return "the receipt is not a JSON object";
  const record2 = value;
  const extra = Object.keys(record2).filter((key) => key !== "attemptId" && !RECEIPT_MEMBERS.includes(key));
  if (extra.length > 0) return `the receipt carries unknown members: ${extra.sort().join(", ")}`;
  if (record2["attemptId"] !== void 0 && (typeof record2["attemptId"] !== "string" || record2["attemptId"] === "")) {
    return "the receipt attemptId is not a non-empty string";
  }
  if (record2["schemaVersion"] !== PREPARATION_RECEIPT_SCHEMA_VERSION) {
    return `the receipt declares schema version ${String(record2["schemaVersion"])}, and this harness reads ${PREPARATION_RECEIPT_SCHEMA_VERSION}`;
  }
  if (!CANDIDATE_MODES.includes(record2["mode"])) {
    return `the receipt declares an unsupported mode ${JSON.stringify(record2["mode"])}`;
  }
  for (const member2 of RECEIPT_MEMBERS) {
    if (member2 === "schemaVersion" || member2 === "mode") continue;
    const held = record2[member2];
    if (typeof held !== "string" || held === "") return `the receipt member ${member2} is not a non-empty string`;
  }
  return {
    schemaVersion: PREPARATION_RECEIPT_SCHEMA_VERSION,
    gateId: record2["gateId"],
    workspaceId: record2["workspaceId"],
    treeSha: record2["treeSha"],
    headSha: record2["headSha"],
    mode: record2["mode"],
    deliverableDigest: record2["deliverableDigest"],
    identityToken: record2["identityToken"],
    baseRef: record2["baseRef"],
    baseTipSha: record2["baseTipSha"],
    mergeBaseSha: record2["mergeBaseSha"],
    candidateWorkspaceId: record2["candidateWorkspaceId"],
    preparationFingerprint: record2["preparationFingerprint"],
    ...record2["attemptId"] === void 0 ? {} : { attemptId: record2["attemptId"] }
  };
}
function failed(failure, reason, receiptPath, workspaceId) {
  const sanitized = sanitizedDetail(reason, `Preparation ${failure} reason`);
  return {
    prepared: false,
    failure,
    reason: sanitized,
    receiptPath,
    workspaceId,
    blockers: [failureBlocker(failure, sanitized)]
  };
}
function receiptBinding(receipt) {
  return {
    treeSha: receipt.treeSha,
    deliverable: { digest: receipt.deliverableDigest, identity: receipt.identityToken },
    base: { ref: receipt.baseRef, tipSha: receipt.baseTipSha, mergeBaseSha: receipt.mergeBaseSha },
    workspaceId: receipt.candidateWorkspaceId
  };
}
async function evaluatePreparationReceipt(rootDir, input, options = {}) {
  const { storageDir, workspaceId } = await resolveReceiptStorage(rootDir, options);
  const receiptPath = path3.join(storageDir, receiptFileName(input.config.gateId));
  let text4;
  try {
    text4 = await readFile2(receiptPath, "utf8");
  } catch (error) {
    if (errorCode2(error) === "ENOENT") {
      return failed("missing", `no preparation receipt was found at ${receiptPath}`, receiptPath, workspaceId);
    }
    return failed("invalid", `the preparation receipt could not be read: ${describe2(error)}`, receiptPath, workspaceId);
  }
  let parsed;
  try {
    parsed = JSON.parse(text4);
  } catch (error) {
    return failed("invalid", `the preparation receipt is not parseable as JSON: ${describe2(error)}`, receiptPath, workspaceId);
  }
  const receipt = parseReceipt(parsed);
  if (typeof receipt === "string") return failed("invalid", receipt, receiptPath, workspaceId);
  if (receipt.gateId !== input.config.gateId) {
    return failed(
      "invalid",
      `the receipt was published for gate ${receipt.gateId} and this run is gate ${input.config.gateId}`,
      receiptPath,
      workspaceId
    );
  }
  if (receipt.workspaceId !== workspaceId) {
    return failed("invalid", "the receipt belongs to a different workspace than the store it was read from", receiptPath, workspaceId);
  }
  try {
    if (await currentAttempt(receiptPath) !== receipt.attemptId) {
      return failed("stale", "A newer preparation attempt superseded this receipt", receiptPath, workspaceId);
    }
  } catch (error) {
    return failed("invalid", `the preparation attempt could not be read: ${describe2(error)}`, receiptPath, workspaceId);
  }
  const fingerprint = await computePreparationFingerprint(rootDir, input.config, options);
  if (receipt.preparationFingerprint !== fingerprint) {
    return failed(
      "wiring_mismatch",
      "the harness version or the declared wiring files changed after the receipt was published",
      receiptPath,
      workspaceId
    );
  }
  const expected = receiptBinding(receipt);
  const drift = new Set(classifyCandidateDrift(expected, input.candidate));
  if (receipt.baseRef !== input.candidate.base.ref) {
    return failed(
      "base_changed",
      `the receipt was prepared against ${receipt.baseRef} and this candidate is against ${input.candidate.base.ref}`,
      receiptPath,
      workspaceId
    );
  }
  if (drift.has("base_tip_moved") || drift.has("merge_base_moved")) {
    return failed("base_changed", `${receipt.baseRef} moved after the candidate was prepared`, receiptPath, workspaceId);
  }
  if (drift.has("raw_tree_changed") || drift.has("deliverable_identity_changed") || drift.has("workspace_changed")) {
    return failed("stale", `the candidate changed after preparation: ${[...drift].sort().join(", ")}`, receiptPath, workspaceId);
  }
  if (receipt.identityToken !== input.candidate.deliverable.identity) {
    return failed(
      "stale",
      `the receipt's digest was computed by ${receipt.identityToken} and this candidate's by ${input.candidate.deliverable.identity}`,
      receiptPath,
      workspaceId
    );
  }
  if (receipt.headSha !== input.candidate.headSha) {
    return failed("stale", "the head moved after preparation, even though the tree did not", receiptPath, workspaceId);
  }
  if (receipt.mode !== input.candidate.mode) {
    return failed(
      "stale",
      `the receipt was prepared in ${receipt.mode} mode and this candidate is ${input.candidate.mode}`,
      receiptPath,
      workspaceId
    );
  }
  return { prepared: true, receipt, receiptPath, workspaceId };
}

// packages/kernel/src/context.ts
var EXECUTION_CONTEXT_KINDS = ["ci", "agent", "human", "unknown"];
var SUPPORTED_AGENT_SIGNALS = ["CODEX_THREAD_ID", "CODEX_CI", "CODEX_SANDBOX", "CLAUDE_CODE", "CLAUDECODE"];
var UNKNOWN_CONTEXT_REASONS = ["unauthorized_automation", "noninteractive_unrecognized"];
function isEnvSignalPresent(value) {
  return typeof value === "string" && value !== "" && value !== "0" && value !== "false";
}
function isCorroborated(requiredEnv, env) {
  if (requiredEnv.length === 0) return false;
  return requiredEnv.every((requirement) => env[requirement.variable] === requirement.equals);
}
function claimsAutomation(config, env) {
  return config.ciPolicies.some(
    (policy) => policy.requiredEnv.some((requirement) => env[requirement.variable] === requirement.equals)
  );
}
function classifyExecutionContext({ config, env, stdinIsTTY, stdoutIsTTY }) {
  const declaredPolicyId = env[config.ciPolicyEnvKey];
  const declared = isEnvSignalPresent(declaredPolicyId) ? declaredPolicyId : void 0;
  if (declared !== void 0 || claimsAutomation(config, env)) {
    const named = config.ciPolicies.find((policy) => policy.id === declared);
    if (named !== void 0 && isCorroborated(named.requiredEnv, env)) {
      return { kind: "ci", policyId: named.id, requiredEnv: named.requiredEnv };
    }
    return { kind: "unknown", reason: "unauthorized_automation" };
  }
  for (const signal of [...config.agentEnvSignals, ...SUPPORTED_AGENT_SIGNALS]) {
    if (isEnvSignalPresent(env[signal])) return { kind: "agent", signal };
  }
  if (stdinIsTTY && stdoutIsTTY) return { kind: "human", interactive: true };
  return { kind: "unknown", reason: "noninteractive_unrecognized" };
}

// packages/kernel/src/evaluator.ts
var RESOLUTION_OUTCOMES = [
  "satisfied_live_fact",
  "satisfied_evidence",
  "waived",
  "delegated",
  "not_applicable",
  "blocked"
];
var LAST_RESORT_REMEDIATION = [
  {
    id: "declare-a-remediation",
    kind: "code_change",
    summary: "Declare a remediation for this obligation in the harness config."
  }
];
function remediationsFor(obligation, code) {
  const keyed = obligation.remediation.byCode?.[code];
  const chosen = keyed !== void 0 && keyed.length > 0 ? keyed : obligation.remediation.default;
  const [first2, ...rest] = chosen;
  return first2 === void 0 ? LAST_RESORT_REMEDIATION : [first2, ...rest];
}
function finding(obligation, code, summary, details = {}) {
  return {
    code,
    obligationId: obligation.id,
    ...details.providerId === void 0 ? {} : { providerId: details.providerId },
    ...details.recordId === void 0 ? {} : { recordId: details.recordId },
    blocker: createBlocker({
      code,
      source: details.fromProvider === void 0 ? { kind: "obligation", id: obligation.id } : { kind: "provider", id: details.fromProvider },
      summary,
      ...details.details === void 0 ? {} : { details: details.details },
      remediations: remediationsFor(obligation, code)
    })
  };
}
function blockedWith(config, gateId, obligation, findings2, fallback) {
  const source = findings2.length > 0 ? findings2 : [fallback];
  const [first2, ...rest] = source.map((entry3) => entry3.blocker);
  const commandProviders = new Set(config.providers.filter((provider2) => provider2.command !== void 0 || provider2.check !== void 0).map((provider2) => provider2.id));
  const providerFindings = source.filter(
    (entry3) => entry3.providerId !== void 0 && commandProviders.has(entry3.providerId)
  );
  const [firstProviderFinding, ...restProviderFindings] = providerFindings;
  return {
    kind: "blocked",
    gateId,
    obligationId: obligation.id,
    ...firstProviderFinding === void 0 ? {} : { providerFindings: [firstProviderFinding, ...restProviderFindings] },
    blockers: [first2, ...rest]
  };
}
function isRecordFreshForCandidate(config, recorded, candidate2) {
  const accepted = config.identityVersions;
  if (!accepted.includes(recorded.identityToken)) return false;
  if (!accepted.includes(candidate2.deliverable.identity)) return false;
  if (recorded.identityToken !== candidate2.deliverable.identity) return false;
  if (recorded.deliverableDigest === "" || candidate2.deliverable.digest === "") return false;
  return recorded.deliverableDigest === candidate2.deliverable.digest && recorded.baseRef === candidate2.base.ref && recorded.baseTipSha === candidate2.base.tipSha && recorded.mergeBaseSha === candidate2.base.mergeBaseSha && recorded.workspaceId === candidate2.workspaceId;
}
function unsatisfiedProviders(obligation, covered) {
  const missing = obligation.providers.filter((providerId2) => !covered.has(providerId2));
  const someCovered = missing.length < obligation.providers.length;
  if ((obligation.providerPolicy ?? "all") === "existential" && someCovered) return [];
  return missing;
}
function providerDeclaresCode(config, providerId2, code) {
  if (typeof code !== "string") return false;
  const registered = config.providers.find((provider2) => provider2.id === providerId2);
  return registered !== void 0 && registered.findingCodes.includes(code);
}
function hasReportableSummary(summary) {
  return typeof summary === "string" && summary.trim() !== "";
}
function evaluateLiveObligation(input, obligation) {
  const gateId = input.config.gateId;
  const results = input.liveResults ?? [];
  const findings2 = [];
  const green = [];
  for (const providerId2 of obligation.providers) {
    const matching = results.filter((result3) => result3.providerId === providerId2);
    if (matching.length === 0) {
      findings2.push(finding(obligation, "live_provider_missing", `Live provider ${providerId2} returned no result for this invocation.`, { providerId: providerId2 }));
      continue;
    }
    if (matching.length > 1) {
      findings2.push(
        finding(obligation, "ambiguous_live_provider", `Live provider ${providerId2} returned more than one result for this invocation.`, { providerId: providerId2 })
      );
      continue;
    }
    const result2 = matching[0];
    if (result2.status !== "green" || result2.findings.length > 0) {
      if (result2.findings.length === 0) {
        findings2.push(finding(obligation, "live_provider_failed", `Live provider ${providerId2} failed without reporting a structured finding.`, { providerId: providerId2 }));
        continue;
      }
      for (const reported of result2.findings) {
        if (providerDeclaresCode(input.config, providerId2, reported.code) && hasReportableSummary(reported.summary)) {
          findings2.push(
            finding(obligation, reported.code, reported.summary, {
              providerId: providerId2,
              fromProvider: providerId2,
              ...reported.details === void 0 ? {} : { details: reported.details }
            })
          );
          continue;
        }
        findings2.push(
          finding(obligation, "live_provider_failed", `Live provider ${providerId2} reported a finding this config does not declare.`, {
            providerId: providerId2,
            details: `Reported code: ${JSON.stringify(reported.code)}
Reported summary: ${String(reported.summary)}${reported.details === void 0 ? "" : `
Reported details: ${String(reported.details)}`}`
          })
        );
      }
      continue;
    }
    green.push(result2);
  }
  const covered = new Set(green.map((result2) => result2.providerId));
  const satisfied = obligation.providers.length > 0 && unsatisfiedProviders(obligation, covered).length === 0;
  if (satisfied) {
    const first2 = green[0];
    return {
      resolution: { kind: "satisfied_live_fact", gateId, obligationId: obligation.id, providerId: first2.providerId, runId: first2.runId },
      diagnostics: findings2
    };
  }
  const fallback = finding(obligation, "live_provider_missing", `Obligation ${obligation.id} has no green live result for this invocation.`);
  const pending = findings2.length > 0 ? findings2 : [fallback];
  const waived = waiverFor(input, obligation, pending);
  if (waived !== void 0) return { resolution: waived, diagnostics: pending };
  return { resolution: blockedWith(input.config, gateId, obligation, pending, fallback), diagnostics: [] };
}
function isStoredEvidence(record2) {
  return record2.resolution.kind === "evidence";
}
function evidenceSlot(record2) {
  return `${record2.resolution.providerId}\0${record2.resolution.runId}\0${record2.resolution.finalPassId}`;
}
function scanEvidence(input, obligation) {
  const gateId = input.config.gateId;
  const invalid = [];
  const malformed4 = [];
  const fresh = [];
  for (const entry3 of input.unreadable ?? []) {
    if (entry3.gateId !== gateId || entry3.obligationId !== obligation.id) continue;
    if (!entry3.appliesToCandidate) continue;
    const found = finding(obligation, "malformed_record", `The evidence store quarantined ${entry3.quarantined.path} (${entry3.quarantined.reason}).`, {
      details: entry3.quarantined.detail
    });
    invalid.push(found);
    malformed4.push(found);
  }
  for (const record2 of input.records) {
    if (record2.gateId !== gateId || record2.obligationId !== obligation.id) continue;
    if (!isStoredEvidence(record2)) continue;
    const providerId2 = record2.resolution.providerId;
    if (!obligation.providers.includes(providerId2)) {
      invalid.push(
        finding(obligation, "unknown_provider", `Record ${record2.recordId} names provider ${providerId2}, which obligation ${obligation.id} does not approve.`, {
          providerId: providerId2,
          recordId: record2.recordId
        })
      );
      continue;
    }
    if (!isRecordFreshForCandidate(input.config, record2.candidateBinding, input.candidate)) {
      invalid.push(
        finding(obligation, "stale_evidence", `Record ${record2.recordId} is bound to a different candidate than the one under evaluation.`, {
          providerId: providerId2,
          recordId: record2.recordId
        })
      );
      continue;
    }
    if (input.config.providers.find((provider2) => provider2.id === providerId2)?.check !== void 0) {
      const expected = input.checkBindings?.[providerId2];
      if (expected === void 0 || record2.resolution.checkBinding === void 0 || Object.keys(expected).some((key) => expected[key] !== record2.resolution.checkBinding?.[key])) continue;
    }
    fresh.push(record2);
  }
  const bySlot = /* @__PURE__ */ new Map();
  for (const record2 of fresh) {
    const slot = evidenceSlot(record2);
    bySlot.set(slot, [...bySlot.get(slot) ?? [], record2]);
  }
  for (const slotRecords of bySlot.values()) {
    if (new Set(slotRecords.map((record2) => record2.recordId)).size > 1) {
      return {
        evidence: void 0,
        blocking: [finding(obligation, "ambiguous_records", `Fresh evidence records disagree within one provider run slot for obligation ${obligation.id}.`)],
        diagnostics: invalid,
        malformed: [],
        ambiguous: true
      };
    }
  }
  fresh.sort((left, right) => left.resolution.providerId.localeCompare(right.resolution.providerId) || left.recordId.localeCompare(right.recordId));
  const covered = new Set(fresh.map((record2) => record2.resolution.providerId));
  const missing = unsatisfiedProviders(obligation, covered).map(
    (providerId2) => finding(obligation, "review_evidence_missing", `Approved provider ${providerId2} has no fresh final-green evidence for this candidate.`, { providerId: providerId2 })
  );
  const satisfied = missing.length === 0 && fresh.length > 0;
  return {
    evidence: satisfied ? fresh[0] : void 0,
    ...satisfied && new Set(fresh.map((record2) => record2.resolution.providerId)).size > 1 ? {
      supportingRecordIds: [...new Map([...fresh].reverse().map((record2) => [record2.resolution.providerId, record2.recordId])).values()].sort()
    } : {},
    blocking: satisfied ? [] : [...invalid, ...missing],
    diagnostics: satisfied ? invalid : [],
    malformed: satisfied ? [] : malformed4,
    ambiguous: false
  };
}
function delegationFor(input, obligation) {
  const context = input.context;
  if (context.kind !== "ci") return void 0;
  const declared = input.config.ciPolicies.find((policy) => policy.id === context.policyId);
  if (declared === void 0) return void 0;
  if (!obligation.ciDelegationPolicyIds.includes(declared.id)) return void 0;
  return { kind: "delegated", gateId: input.config.gateId, obligationId: obligation.id, ciPolicyId: declared.id };
}
function evaluateRecordedObligation(input, obligation) {
  const gateId = input.config.gateId;
  const scan = scanEvidence(input, obligation);
  if (scan.evidence !== void 0) {
    const record2 = scan.evidence;
    return {
      resolution: {
        kind: "satisfied_evidence",
        gateId,
        obligationId: obligation.id,
        providerId: record2.resolution.providerId,
        recordId: record2.recordId,
        ...scan.supportingRecordIds === void 0 ? {} : { supportingRecordIds: scan.supportingRecordIds },
        runId: record2.resolution.runId,
        finalPassId: record2.resolution.finalPassId,
        candidateBinding: record2.candidateBinding
      },
      diagnostics: scan.diagnostics
    };
  }
  const fallback = finding(obligation, "review_evidence_missing", `The candidate has no fresh approved final-green evidence for obligation ${obligation.id}.`);
  if (scan.ambiguous) {
    return { resolution: blockedWith(input.config, gateId, obligation, scan.blocking, fallback), diagnostics: scan.diagnostics };
  }
  if (scan.malformed.length > 0) {
    return {
      resolution: blockedWith(input.config, gateId, obligation, scan.malformed, fallback),
      diagnostics: scan.blocking.filter((entry3) => !scan.malformed.includes(entry3))
    };
  }
  const delegated = delegationFor(input, obligation);
  if (delegated !== void 0) return { resolution: delegated, diagnostics: scan.blocking };
  const pending = scan.blocking.length > 0 ? scan.blocking : [fallback];
  const waived = waiverFor(input, obligation, pending);
  if (waived !== void 0) return { resolution: waived, diagnostics: pending };
  return { resolution: blockedWith(input.config, gateId, obligation, pending, fallback), diagnostics: [] };
}
function waiverFor(input, obligation, pending) {
  if (!obligation.humanWaiverAllowed) return void 0;
  if (input.context.kind !== "human") return void 0;
  if (pending.length === 0) return void 0;
  const waivable = new Set(obligation.waivableCodes);
  const nonWaivable = new Set(obligation.nonWaivableCodes);
  if (pending.some((entry3) => NON_WAIVABLE_INTEGRITY_CODES.includes(entry3.code) || nonWaivable.has(entry3.code) || !waivable.has(entry3.code))) return void 0;
  const granted = new Set(input.invocationWaiverRecordIds ?? []);
  const invocationOnly = obligation.freshness === "live";
  const honored = input.records.filter((record2) => record2.gateId === input.config.gateId && record2.obligationId === obligation.id).filter((record2) => {
    if (record2.resolution.kind !== "waiver") return false;
    const waiver = record2.resolution;
    if (waiver.policyDigest !== digestCanonical(input.config) || record2.candidateBinding.treeSha !== input.candidate.treeSha || !waiver.author?.trim() || !waiver.reason?.trim() || !Array.isArray(waiver.findingCodes) || waiver.findingCodes.some((code) => NON_WAIVABLE_INTEGRITY_CODES.includes(code) || nonWaivable.has(code) || !waivable.has(code)) || pending.some((finding3) => !waiver.findingCodes.includes(finding3.code))) return false;
    if (record2.resolution.scope === "invocation") return granted.has(record2.recordId);
    return !invocationOnly;
  }).filter((record2) => isRecordFreshForCandidate(input.config, record2.candidateBinding, input.candidate)).sort((left, right) => left.recordId.localeCompare(right.recordId));
  const chosen = honored[0];
  if (chosen === void 0 || chosen.resolution.kind !== "waiver") return void 0;
  return {
    kind: "waived",
    gateId: input.config.gateId,
    obligationId: obligation.id,
    waiverRecordId: chosen.recordId,
    scope: chosen.resolution.scope,
    waiver: chosen.resolution,
    candidateBinding: chosen.candidateBinding
  };
}
function enforceAllowedResolution(obligation, resolution) {
  if (resolution.kind === "blocked") return resolution;
  if (obligation.allowedResolutionKinds.includes(resolution.kind)) return resolution;
  const rejected = finding(obligation, "resolution_not_allowed", `Resolution ${resolution.kind} is not permitted by obligation ${obligation.id}.`);
  return {
    kind: "blocked",
    gateId: resolution.gateId,
    obligationId: obligation.id,
    blockers: [rejected.blocker]
  };
}
function evaluateGate(input) {
  const resolutions = [];
  const diagnostics = [];
  for (const obligation of input.config.obligations) {
    if (!isObligationActive(obligation.activation, input.projection, input.config.activationThreshold)) {
      const inactive = {
        kind: "not_applicable",
        gateId: input.config.gateId,
        obligationId: obligation.id,
        activation: input.projection
      };
      resolutions.push(enforceAllowedResolution(obligation, inactive));
      continue;
    }
    const evaluation = obligation.freshness === "live" ? evaluateLiveObligation(input, obligation) : evaluateRecordedObligation(input, obligation);
    resolutions.push(enforceAllowedResolution(obligation, evaluation.resolution));
    diagnostics.push(...evaluation.diagnostics);
  }
  const blockers = resolutions.flatMap((resolution) => resolution.kind === "blocked" ? [...resolution.blockers] : []);
  return {
    gateId: input.config.gateId,
    candidate: input.candidate,
    admitted: blockers.length === 0,
    resolutions,
    diagnostics,
    blockers
  };
}

// packages/kernel/src/portable-limits.ts
var MAX_PORTABLE_ARTIFACT_BYTES = 2 * 1024 * 1024;
var MAX_PORTABLE_EVIDENCE_BYTES = 8 * 1024 * 1024;
var MAX_PORTABLE_RECORD_BYTES = 16 * 1024 * 1024;
var MAX_PORTABLE_ARTIFACTS = 128;

// packages/kernel/src/artifacts.ts
import { createHash as createHash3, randomUUID as randomUUID3 } from "node:crypto";
import { chmod as chmod3, mkdir as mkdir3, open as open3, readFile as readFile3, realpath as realpath2, rename as rename2, rm as rm3, stat as stat2, writeFile as writeFile3 } from "node:fs/promises";
import { tmpdir } from "node:os";
import path4 from "node:path";

// packages/kernel/src/artifacts.types.ts
var RUN_ROOT_REFUSAL_REASONS = [
  "unsafe_provider_id",
  "unsafe_run_id",
  "provider_id_too_long",
  "run_root_outside_base"
];
var ARTIFACT_OBSERVATION_STATUSES = [
  "path_refused",
  "missing",
  "outside_run_root",
  "not_a_file",
  "unreadable",
  "readable"
];

// packages/kernel/src/artifacts.ts
var RUN_ROOT_NAMESPACE = "delivery-harness";
var RUN_ROOT_LEAF = "runs";
var DIRECTORY_MODE3 = 448;
var DEFAULT_FILE_MODE = 420;
var PROVIDER_ID2 = /^[a-z0-9]+([._-][a-z0-9]+)*$/;
var MAX_PROVIDER_ID_LENGTH = 128;
var RUN_ID2 = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
var MAX_RUN_ID_LENGTH = 128;
var RETRY = {
  id: "retry-filesystem-operation",
  kind: "retry",
  summary: "Re-run the command once the location is reachable."
};
var CHECK_PATH = {
  id: "check-artifact-location",
  kind: "manual_action",
  summary: "Check that the path exists and that this process can read it."
};
function artifactsBlocker(code, summary, details, remediation) {
  const blocker = createBlocker({
    code,
    source: { kind: "provider", id: "delivery-harness.artifacts" },
    summary,
    details: sanitizedDetail(details, "Artifacts port detail"),
    remediations: [remediation]
  });
  return new BlockedError([blocker], blocker.summary);
}
function describe3(error) {
  return error instanceof Error ? error.message : String(error);
}
function errorCode3(error) {
  const code = error?.code;
  return typeof code === "string" ? code : void 0;
}
async function resolvedOrNull(target) {
  try {
    return await realpath2(target);
  } catch (error) {
    const code = errorCode3(error);
    if (code === "ENOENT" || code === "ENOTDIR") return null;
    throw error;
  }
}
function isInsideResolved(parent, child) {
  const relative = path4.relative(parent, child);
  return relative !== "" && !relative.startsWith("..") && !path4.isAbsolute(relative);
}
function isSafeRelativePath2(value) {
  if (value === "") return false;
  if (value.includes("\0")) return false;
  if (value.startsWith("/") || value.startsWith("\\")) return false;
  if (/^[A-Za-z]:/.test(value)) return false;
  const segments = value.split(/[/\\]/);
  return !segments.includes("..") && !segments.includes("");
}
async function defaultRunRootBase() {
  const base = path4.join(tmpdir(), RUN_ROOT_NAMESPACE, RUN_ROOT_LEAF);
  try {
    await mkdir3(base, { recursive: true, mode: DIRECTORY_MODE3 });
  } catch (error) {
    throw artifactsBlocker("run_root_unwritable", "The run-root directory could not be created.", `${base}: ${describe3(error)}`, RETRY);
  }
  return realpath2(base);
}
function createArtifactsPort(options = {}) {
  const base = async () => options.runRootBase === void 0 ? defaultRunRootBase() : realpath2(options.runRootBase);
  const derive = async (request, create) => {
    if (!PROVIDER_ID2.test(request.providerId)) return { ok: false, reason: "unsafe_provider_id" };
    if (request.providerId.length > MAX_PROVIDER_ID_LENGTH) return { ok: false, reason: "provider_id_too_long" };
    if (request.runId.length > MAX_RUN_ID_LENGTH || !RUN_ID2.test(request.runId) || request.runId === "." || request.runId === "..") {
      return { ok: false, reason: "unsafe_run_id" };
    }
    const baseDir = await base();
    const target = path4.join(baseDir, request.providerId, request.runId);
    if (create) {
      try {
        await mkdir3(target, { recursive: true, mode: DIRECTORY_MODE3 });
        await chmod3(target, DIRECTORY_MODE3);
      } catch (error) {
        throw artifactsBlocker("run_root_unwritable", "The run root could not be created.", `${target}: ${describe3(error)}`, RETRY);
      }
    }
    const resolved = await resolvedOrNull(target);
    if (resolved !== null && !isInsideResolved(baseDir, resolved)) {
      return { ok: false, reason: "run_root_outside_base" };
    }
    const runRoot = {
      providerId: request.providerId,
      runId: request.runId,
      // An unallocated run root has no physical form yet; the derived path is
      // still the answer to "where would it be". Nothing resolves there, so
      // every containment check against it is false and every artifact under it
      // is missing — it fails closed rather than needing a check of its own.
      path: resolved ?? target
    };
    return { ok: true, runRoot };
  };
  return {
    allocateRunRoot: (request) => derive(request, true),
    resolveRunRoot: (request) => derive(request, false),
    async isInsideRunRoot(runRootPath, target) {
      const [root, resolved] = await Promise.all([resolvedOrNull(runRootPath), resolvedOrNull(target)]);
      if (root === null || resolved === null) return false;
      return isInsideResolved(root, resolved);
    },
    async observeArtifact(runRootPath, declaredPath) {
      const observation = (rest) => ({ declaredPath, ...rest });
      if (!isSafeRelativePath2(declaredPath)) {
        return observation({
          status: "path_refused",
          resolvedPath: null,
          sha256: null,
          contents: null,
          detail: "the declared path is not a safe relative path and was never joined to the run root"
        });
      }
      const root = await resolvedOrNull(runRootPath);
      if (root === null) {
        return observation({
          status: "missing",
          resolvedPath: null,
          sha256: null,
          contents: null,
          detail: "the run root does not exist"
        });
      }
      const resolved = await resolvedOrNull(path4.join(root, declaredPath));
      if (resolved === null) {
        return observation({
          status: "missing",
          resolvedPath: null,
          sha256: null,
          contents: null,
          detail: "no file is present at this path inside the run root"
        });
      }
      if (!isInsideResolved(root, resolved)) {
        return observation({
          status: "outside_run_root",
          resolvedPath: resolved,
          sha256: null,
          contents: null,
          detail: "the path resolves to a location outside the run root"
        });
      }
      let isFile;
      try {
        isFile = (await stat2(resolved)).isFile();
      } catch (error) {
        return observation({
          status: "unreadable",
          resolvedPath: resolved,
          sha256: null,
          contents: null,
          detail: `the path could not be inspected: ${describe3(error)}`
        });
      }
      if (!isFile) {
        return observation({
          status: "not_a_file",
          resolvedPath: resolved,
          sha256: null,
          contents: null,
          detail: "the path names a directory or another non-regular entry, which has no bytes to digest"
        });
      }
      let bytes;
      try {
        const handle = await open3(resolved, "r");
        try {
          const info = await handle.stat();
          if (!info.isFile() || info.size > MAX_PORTABLE_ARTIFACT_BYTES) throw new Error("artifact is not a bounded regular file");
          const buffer = Buffer.alloc(Math.min(info.size + 1, MAX_PORTABLE_ARTIFACT_BYTES + 1));
          let offset = 0;
          while (offset < buffer.length) {
            const result2 = await handle.read(buffer, offset, buffer.length - offset, offset);
            if (result2.bytesRead === 0) break;
            offset += result2.bytesRead;
          }
          if (offset > info.size || offset > MAX_PORTABLE_ARTIFACT_BYTES) throw new Error("artifact changed size or exceeds its limit");
          bytes = buffer.subarray(0, offset);
        } finally {
          await handle.close();
        }
      } catch (error) {
        return observation({
          status: "unreadable",
          resolvedPath: resolved,
          sha256: null,
          contents: null,
          detail: `the file could not be read: ${describe3(error)}`
        });
      }
      return observation({
        status: "readable",
        resolvedPath: resolved,
        // Over the raw bytes, never over a decoded string: ENV-11 is about the
        // file's bytes at submission, and a lossy decode would digest something
        // the provider never wrote.
        sha256: createHash3("sha256").update(bytes).digest("hex"),
        contents: bytes.toString("utf8"),
        base64: bytes.toString("base64"),
        detail: null
      });
    },
    async readTextFile(target) {
      try {
        return await readFile3(target, "utf8");
      } catch (error) {
        throw artifactsBlocker(
          "artifact_file_unreadable",
          "A file this submission depends on could not be read.",
          `${target}: ${describe3(error)}`,
          CHECK_PATH
        );
      }
    },
    async removeFile(target) {
      try {
        await rm3(target, { force: true });
        return true;
      } catch {
        return false;
      }
    },
    async writeTextFile(target, contents, writeOptions = {}) {
      const mode = writeOptions.mode ?? DEFAULT_FILE_MODE;
      const directory = path4.dirname(target);
      const temporary = path4.join(directory, `.${path4.basename(target)}.${process.pid}.${randomUUID3()}.tmp`);
      try {
        await mkdir3(directory, { recursive: true });
        await writeFile3(temporary, contents, { mode, flag: "wx" });
        await chmod3(temporary, mode);
        await syncFile2(temporary);
        await rename2(temporary, target);
      } catch (error) {
        try {
          await rm3(temporary, { force: true });
        } catch {
        }
        throw artifactsBlocker(
          "artifact_write_failed",
          "A file could not be written.",
          `${target}: ${describe3(error)}`,
          RETRY
        );
      }
    }
  };
}
async function syncFile2(target) {
  const handle = await open3(target, "r+");
  try {
    await handle.sync();
  } finally {
    await handle.close();
  }
}

// packages/kernel/src/checks.ts
import { open as open4, readFile as readFile4, realpath as realpath3 } from "node:fs/promises";
import path6 from "node:path";

// packages/kernel/src/review-inputs.ts
import path5 from "node:path";

// packages/kernel/src/policy/shipped-personas.ts
var PERSONA_MANIFEST_ENTRY = "personas/manifest.json";
var PERSONA_MANIFEST_SPEC = "reviewer-persona-manifest/1";
var ARCHIVE_RELEASE_MANIFEST_ENTRY = "release-manifest.json";
var isRecord3 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var parseJsonEntry = (read, entry3) => {
  const bytes = read(entry3);
  if (bytes === void 0) return void 0;
  try {
    return new TextDecoder().decode(bytes);
  } catch {
    return void 0;
  }
};
var parseJson = (text4) => {
  if (typeof text4 !== "string") return void 0;
  try {
    return JSON.parse(text4);
  } catch {
    return void 0;
  }
};
var recordedDigests = (read) => {
  const document = parseJson(parseJsonEntry(read, ARCHIVE_RELEASE_MANIFEST_ENTRY));
  if (!isRecord3(document) || !Array.isArray(document["files"])) return /* @__PURE__ */ new Map();
  const listed = /* @__PURE__ */ new Map();
  for (const file of document["files"]) {
    if (isRecord3(file) && typeof file["path"] === "string" && typeof file["sha256"] === "string") {
      listed.set(file["path"], file["sha256"]);
    }
  }
  return listed;
};
function projectShippedPersonas(read) {
  const manifestText = parseJsonEntry(read, PERSONA_MANIFEST_ENTRY);
  if (manifestText === void 0) {
    return {
      ok: false,
      rejections: [
        {
          code: "persona_manifest_absent",
          pointer: PERSONA_MANIFEST_ENTRY,
          message: `the pinned archive carries no ${PERSONA_MANIFEST_ENTRY}; no lens can resolve a shipped charter`
        }
      ]
    };
  }
  const manifest = parseJson(manifestText);
  if (!isRecord3(manifest) || manifest["schemaVersion"] !== PERSONA_MANIFEST_SPEC || !Array.isArray(manifest["personas"])) {
    return {
      ok: false,
      rejections: [
        {
          code: "persona_manifest_malformed",
          pointer: PERSONA_MANIFEST_ENTRY,
          message: `the charter manifest is not a ${PERSONA_MANIFEST_SPEC} document declaring a charter list`
        }
      ]
    };
  }
  const listed = recordedDigests(read);
  const personas = [];
  const rejections = [];
  const declared = manifest["personas"];
  for (let index = 0; index < declared.length; index += 1) {
    const entry3 = declared[index];
    const pointer2 = `${PERSONA_MANIFEST_ENTRY}#/personas/${index}`;
    if (!isRecord3(entry3) || typeof entry3["personaId"] !== "string" || typeof entry3["path"] !== "string") {
      rejections.push({
        code: "persona_manifest_malformed",
        pointer: pointer2,
        message: "a charter record must name a charter identity and the path its bytes live at"
      });
      continue;
    }
    const personaId = entry3["personaId"];
    const entryPath = entry3["path"];
    const bytes = read(entryPath);
    if (bytes === void 0) {
      rejections.push({
        code: "persona_charter_absent",
        pointer: pointer2,
        message: `the manifest names charter ${personaId} at ${entryPath}, and the archive carries no such entry`
      });
      continue;
    }
    const digest2 = sha256Hex(bytes);
    const recorded = listed.get(entryPath);
    if (recorded !== void 0 && recorded !== digest2) {
      rejections.push({
        code: "persona_charter_digest_mismatch",
        pointer: pointer2,
        message: `charter ${personaId} hashes to ${digest2}, and the archive recorded ${recorded} for ${entryPath}`
      });
      continue;
    }
    if (recorded === void 0) {
      rejections.push({
        code: "persona_charter_digest_mismatch",
        pointer: pointer2,
        message: `charter ${personaId} at ${entryPath} is not listed in ${ARCHIVE_RELEASE_MANIFEST_ENTRY}, so its bytes are unbound`
      });
      continue;
    }
    personas.push({ personaId, digest: digest2, origin: "composition" });
  }
  return rejections.length > 0 ? { ok: false, rejections } : { ok: true, personas };
}

// packages/kernel/src/review-inputs.ts
var COMPILED_SNAPSHOT_FILE = ".agents/policy/compiled-snapshot.json";
var INSTALLED_ARCHIVE_DIR = ".agent-skills/current";
var CHARTER_EXTENSION = ".md";
var ReviewInputError = class extends Error {
};
var OutcomeError = ReviewInputError;
var isRecord4 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
async function readJsonFile(read, filePath, role) {
  try {
    const bytes = await read(filePath);
    if (bytes === null) throw new Error("missing file");
    return JSON.parse(Buffer.from(bytes).toString("utf8"));
  } catch (error) {
    throw new OutcomeError(`${role} is unreadable or not valid JSON: ${error instanceof Error ? error.message : String(error)}`);
  }
}
async function resolveReviewCharters(read, config) {
  const snapshotPath = COMPILED_SNAPSHOT_FILE;
  const snapshot = await readJsonFile(read, snapshotPath, `the compiled policy snapshot at ${COMPILED_SNAPSHOT_FILE}`);
  if (isRecord4(snapshot) && snapshot["inputDigests"] !== void 0) {
    if (!isRecord4(snapshot["inputDigests"])) throw new OutcomeError("the compiled policy input digests are malformed");
    for (const [file, digest2] of Object.entries(snapshot["inputDigests"])) {
      if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(file) || !/^[a-f0-9]{64}$/.test(String(digest2))) throw new OutcomeError("the compiled policy declares an invalid input digest");
      const bytes = await read(path5.posix.join(path5.posix.dirname(COMPILED_SNAPSHOT_FILE), file));
      if (bytes === null || sha256Hex(bytes) !== digest2) throw new OutcomeError("the compiled policy snapshot is stale against its declared input bytes; recompile policy");
    }
  }
  const compiledWith = isRecord4(snapshot) ? snapshot["compiledWith"] : void 0;
  const personaSource = isRecord4(compiledWith) ? compiledWith["personaSource"] : void 0;
  if (isRecord4(personaSource) && personaSource["archiveSha256"] !== void 0) {
    const release = await readWorkflowRelease(read);
    if (release === null || personaSource["archiveSha256"] !== release["archiveSha256"]) throw new OutcomeError("the compiled policy persona source differs from the active workflow generation; recompile policy");
  }
  const compiled = isRecord4(snapshot) ? snapshot["compiled"] : void 0;
  const inner = isRecord4(compiled) ? compiled["snapshot"] : void 0;
  const lenses = isRecord4(inner) ? inner["reviewLenses"] : void 0;
  if (!Array.isArray(lenses)) {
    throw new OutcomeError(`${COMPILED_SNAPSHOT_FILE} records no compiled review lenses to review under`);
  }
  const manifestPath = path5.posix.join(INSTALLED_ARCHIVE_DIR, PERSONA_MANIFEST_ENTRY);
  const manifest = await readJsonFile(
    read,
    manifestPath,
    `the charter manifest at ${INSTALLED_ARCHIVE_DIR}/${PERSONA_MANIFEST_ENTRY}`
  );
  if (!isRecord4(manifest) || manifest["schemaVersion"] !== PERSONA_MANIFEST_SPEC || !Array.isArray(manifest["personas"])) {
    throw new OutcomeError(
      `${INSTALLED_ARCHIVE_DIR}/${PERSONA_MANIFEST_ENTRY} is not a ${PERSONA_MANIFEST_SPEC} document declaring a charter list`
    );
  }
  const charterPaths = /* @__PURE__ */ new Map();
  for (const entry3 of manifest["personas"]) {
    if (isRecord4(entry3) && typeof entry3["personaId"] === "string" && typeof entry3["path"] === "string") {
      charterPaths.set(entry3["personaId"], entry3["path"]);
    }
  }
  const archiveRoot = path5.posix.resolve("/", INSTALLED_ARCHIVE_DIR);
  const resolved = [];
  const seen = /* @__PURE__ */ new Set();
  for (const lens of lenses) {
    if (!isRecord4(lens) || typeof lens["lensId"] !== "string" || typeof lens["personaId"] !== "string" || typeof lens["personaDigest"] !== "string") {
      throw new OutcomeError("a compiled review lens names no reviewer charter and digest");
    }
    const personaId = lens["personaId"];
    const digest2 = lens["personaDigest"];
    const entryPath = charterPaths.get(personaId);
    if (entryPath === void 0) {
      throw new OutcomeError(
        `the compiled policy activates a lens referencing charter ${personaId}, which the installed generation's manifest does not declare`
      );
    }
    const charterPath = path5.posix.resolve(archiveRoot, entryPath);
    if (!charterPath.startsWith(`${archiveRoot}/`)) {
      throw new OutcomeError(`charter ${personaId} is declared at ${entryPath}, which leaves ${INSTALLED_ARCHIVE_DIR}`);
    }
    let bytes;
    try {
      const contents = await read(path5.posix.join(INSTALLED_ARCHIVE_DIR, entryPath));
      if (contents === null) throw new Error("missing charter");
      bytes = contents;
    } catch (error) {
      throw new OutcomeError(
        `charter ${personaId} is declared at ${entryPath}, and the installed generation carries no such file: ${error instanceof Error ? error.message : String(error)}`
      );
    }
    const actual = sha256Hex(bytes);
    if (actual !== digest2) {
      throw new OutcomeError(
        `charter ${personaId} at ${entryPath} hashes to ${actual}, and the compiled policy was resolved against ${digest2}`
      );
    }
    const base = path5.posix.basename(entryPath);
    const reviewerId = base.endsWith(CHARTER_EXTENSION) ? base.slice(0, -CHARTER_EXTENSION.length) : base;
    if (seen.has(reviewerId)) {
      throw new OutcomeError(`two activated lenses resolve to reviewer ${reviewerId}; a reviewer reviews once`);
    }
    seen.add(reviewerId);
    resolved.push({ origin: "composition", sourcePath: path5.posix.join(INSTALLED_ARCHIVE_DIR, entryPath), lensId: lens["lensId"], reviewerId, personaId, entryPath, digest: digest2 });
  }
  const lensIds = new Set(resolved.map((charter) => charter.lensId));
  for (const extra of config?.additionalReviewLenses ?? []) {
    if (lensIds.has(extra.lensId) || seen.has(extra.reviewerId)) throw new OutcomeError("an additional review lens collides with an activated lens or reviewer");
    const normalized = path5.posix.normalize(extra.charterPath);
    if (normalized !== extra.charterPath || normalized.startsWith("/") || normalized === "." || normalized === ".." || normalized.endsWith("/") || normalized.startsWith("../") || normalized.includes("\\") || normalized.includes("\0")) {
      throw new OutcomeError("an additional review charter must name a repository-relative file");
    }
    const bytes = await read(extra.charterPath);
    if (bytes === null || Buffer.from(bytes).toString("utf8").trim().length === 0) throw new OutcomeError("an additional review charter is missing or empty");
    lensIds.add(extra.lensId);
    seen.add(extra.reviewerId);
    resolved.push({
      origin: "repository",
      sourcePath: extra.charterPath,
      lensId: extra.lensId,
      reviewerId: extra.reviewerId,
      personaId: extra.lensId,
      entryPath: extra.charterPath,
      digest: sha256Hex(bytes)
    });
  }
  return resolved;
}
async function readWorkflowRelease(read) {
  const active = await read(".agent-skills/active.json");
  if (active === null) return null;
  let value;
  try {
    value = JSON.parse(Buffer.from(active).toString("utf8"));
  } catch {
    throw new ReviewInputError("the installed workflow receipt is not valid JSON");
  }
  const release = isRecord4(value) ? value["release"] : void 0;
  if (!isRecord4(release) || !["releaseId", "profile"].every((key) => typeof release[key] === "string" && release[key] !== "") || !["archiveSha256", "metadataSha256"].every((key) => typeof release[key] === "string" && /^[0-9a-f]{64}$/.test(release[key]))) {
    throw new ReviewInputError("the installed workflow receipt has no exact release identity");
  }
  return release;
}

// packages/kernel/src/checks.ts
async function captureCheckOutputSnapshots(rootDir, outputs, readOutput) {
  const root = await realpath3(rootDir);
  const result2 = [];
  for (const output of outputs) {
    try {
      if (readOutput !== void 0) {
        const bytes = await readOutput(output);
        if (bytes.length > 1024 * 1024) return void 0;
        result2.push({ path: output, sha256: sha256Hex(bytes), base64: Buffer.from(bytes).toString("base64") });
        continue;
      }
      const target = await realpath3(path6.resolve(root, output));
      const relative = path6.relative(root, target);
      if (relative.startsWith(`..${path6.sep}`) || relative === ".." || path6.isAbsolute(relative)) return void 0;
      const handle = await open4(target, "r");
      try {
        const info = await handle.stat();
        if (!info.isFile() || info.size > 1024 * 1024) return void 0;
        const buffer = Buffer.alloc(1024 * 1024 + 1);
        let offset = 0;
        while (offset < buffer.length) {
          const { bytesRead } = await handle.read(buffer, offset, buffer.length - offset, offset);
          if (bytesRead === 0) break;
          offset += bytesRead;
        }
        if (offset > 1024 * 1024) return void 0;
        const bytes = buffer.subarray(0, offset);
        result2.push({ path: output, sha256: sha256Hex(bytes), base64: bytes.toString("base64") });
      } finally {
        await handle.close();
      }
    } catch {
      return void 0;
    }
  }
  return result2;
}
async function captureCheckOutputs(rootDir, outputs, readOutput) {
  return (await captureCheckOutputSnapshots(rootDir, outputs, readOutput))?.map(({ path: path21, sha256: sha2562 }) => ({ path: path21, sha256: sha2562 }));
}
async function computeCheckWiringFingerprint(rootDir, config, options = {}) {
  const read = options.readReleaseInputs ?? (async (repoPath) => {
    try {
      return await readFile4(path6.join(rootDir, repoPath));
    } catch (error) {
      if (error.code === "ENOENT") return null;
      throw error;
    }
  });
  let release;
  try {
    release = await readWorkflowRelease(read);
  } catch (error) {
    throw new BlockedError([createBlocker({
      code: "check_release_unreadable",
      source: { kind: "preparation", id: config.gateId },
      summary: "The installed workflow release identity cannot be read for validation.",
      details: error instanceof Error ? error.message : String(error),
      remediations: [{ id: "repair-check-release", kind: "manual_action", summary: "Restore a valid installed release and prepare again." }]
    })]);
  }
  return digestCanonical({ preparation: await computePreparationFingerprint(rootDir, config, options), release });
}
async function captureCheckBindings(rootDir, config, candidate2, options = {}) {
  const providers = config.providers.filter((provider2) => provider2.check !== void 0);
  if (providers.length === 0) return {};
  const validationDigest = await computeDeliverableIdentity({
    rootDir,
    treeSha: candidate2.treeSha,
    config: { ...config, computingIdentityVersion: "validation-tree/v1", reviewNeutral: config.recordNeutral }
  });
  const policyDigest = digestCanonical(config);
  const wiringFingerprint = await computeCheckWiringFingerprint(rootDir, config, options);
  const bindings = {};
  for (const provider2 of providers) {
    const outputs = await captureCheckOutputs(rootDir, provider2.check.outputs ?? [], options.readOutput === void 0 ? void 0 : (repoPath) => options.readOutput(repoPath, provider2.id));
    if (outputs !== void 0) bindings[provider2.id] = { definitionDigest: digestCanonical(provider2.check), validationDigest, policyDigest, wiringFingerprint, outputsDigest: digestCanonical(outputs) };
  }
  return bindings;
}

// packages/kernel/src/review-outcome.ts
var REVIEW_CONTEXT_SPEC = "review-context/1";
var OUTCOME_SPEC = "review-outcome/1";
function validateReviewedContext(original, current, outcome) {
  if (!isRecord5(original) || original["spec"] !== REVIEW_CONTEXT_SPEC || Object.keys(original).sort().join(",") !== "binding,digest,spec" || !isRecord5(original["binding"]) || original["digest"] !== digestCanonical(original["binding"])) {
    throw new ReviewInputError("the original review context is missing, malformed, or has a mismatched digest");
  }
  if (!isRecord5(outcome) || outcome["contextDigest"] !== original["digest"]) {
    throw new ReviewInputError("the outcome does not name the original review context digest");
  }
  const binding = original["binding"];
  const candidate2 = binding["candidate"];
  if (!isRecord5(candidate2) || !["treeSha", "headSha"].every((key) => typeof candidate2[key] === "string" && /^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(candidate2[key]))) {
    throw new ReviewInputError("the original review context names no valid candidate");
  }
  const comparable = {
    ...binding,
    candidate: { ...candidate2, treeSha: current.binding.candidate.treeSha, headSha: current.binding.candidate.headSha }
  };
  if (digestCanonical(comparable) !== digestCanonical(current.binding)) {
    throw new ReviewInputError("the reviewed context differs from the current candidate, base, policy, wiring, release, or charters; acquire review for the current context");
  }
}
var REVIEWER_RESULTS = ["approved", "rejected", "failed", "timed-out"];
var isRecord5 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
function parseReviewOutcome(document, charters) {
  if (!isRecord5(document)) throw new ReviewInputError("the review outcome is not a JSON object");
  if (document["spec"] !== OUTCOME_SPEC) {
    throw new ReviewInputError(`the review outcome declares spec ${JSON.stringify(document["spec"])}, not ${OUTCOME_SPEC}`);
  }
  const verdict = document["verdict"];
  if (typeof verdict !== "string" || verdict === "") {
    throw new ReviewInputError("the review outcome states no verdict");
  }
  const findings2 = document["findings"];
  if (!Array.isArray(findings2) || !findings2.every(isRecord5)) {
    throw new ReviewInputError("the review outcome's findings are not an array of objects");
  }
  const reviewers = document["reviewers"];
  if (!Array.isArray(reviewers)) throw new ReviewInputError("the review outcome's reviewers are not an array");
  const named = [];
  const unnamed = [];
  const seen = /* @__PURE__ */ new Set();
  for (const entry3 of reviewers) {
    if (!isRecord5(entry3)) throw new ReviewInputError("a reviewer outcome is not an object");
    const id = entry3["id"];
    const result2 = entry3["result"];
    const carriesId = id !== void 0;
    if (carriesId && (typeof id !== "string" || id === "")) {
      throw new ReviewInputError("a reviewer outcome names no reviewer");
    }
    const subject = carriesId ? `reviewer ${id}` : "an unnamed reviewer outcome";
    if (typeof result2 !== "string" || !REVIEWER_RESULTS.includes(result2)) {
      throw new ReviewInputError(
        `${subject} reports result ${JSON.stringify(result2)}, which is not one of ${REVIEWER_RESULTS.join(", ")}`
      );
    }
    if (!carriesId) {
      unnamed.push(result2);
      continue;
    }
    const reviewerId = id;
    if (seen.has(reviewerId)) throw new ReviewInputError(`reviewer ${reviewerId} appears twice in the review outcome`);
    seen.add(reviewerId);
    named.push({ id: reviewerId, result: result2 });
  }
  if (unnamed.length > 0) {
    if (named.length > 0) {
      throw new ReviewInputError(
        `the review outcome names ${named.length} of its ${reviewers.length} reviewers and leaves the rest unnamed; a document that distinguishes its reviewers names every one of them`
      );
    }
    if (unnamed.length !== charters.length) {
      throw new ReviewInputError(
        `the review outcome carries ${unnamed.length} result(s) under no reviewer id, and the policy selects ${charters.length} reviewer(s): ${charters.join(", ")}`
      );
    }
    const distinct = [...new Set(unnamed)];
    if (distinct.length > 1) {
      throw new ReviewInputError(
        `the review outcome's unnamed results disagree (${distinct.join(", ")}), so which reviewer reported which would be decided by their order; name the reviewers instead`
      );
    }
    for (const [index, result2] of unnamed.entries()) {
      const reviewerId = charters[index];
      seen.add(reviewerId);
      named.push({ id: reviewerId, result: result2 });
    }
  }
  const parsed = named;
  const charterSet = new Set(charters);
  const missing = charters.filter((id) => !seen.has(id));
  if (missing.length > 0) {
    throw new ReviewInputError(
      `the review outcome leaves ${missing.length} charter(s) unrepresented: ${missing.join(", ")}`
    );
  }
  const unknown = parsed.map((entry3) => entry3.id).filter((id) => !charterSet.has(id));
  if (unknown.length > 0) {
    throw new ReviewInputError(
      `the review outcome names ${unknown.length} reviewer(s) no activated review lens defines: ${unknown.join(", ")}`
    );
  }
  const runHistory = document["runHistory"];
  const finalPassId = document["finalPassId"];
  if (runHistory !== void 0 && (!Array.isArray(runHistory) || runHistory.length === 0 || !runHistory.every(isRecord5) || typeof finalPassId !== "string" || finalPassId === "")) {
    throw new ReviewInputError("review runHistory requires a nonempty history and its actual finalPassId");
  }
  const cost2 = document["cost"];
  if (cost2 !== void 0 && (!isRecord5(cost2) || typeof document["costCoverage"] !== "string" || !document["costCoverage"].trim())) {
    throw new ReviewInputError("reported review cost requires an explicit costCoverage description");
  }
  return {
    verdict,
    reviewers: parsed,
    findings: findings2,
    ...runHistory === void 0 ? {} : { runHistory, finalPassId },
    ...cost2 === void 0 ? {} : { cost: cost2 }
  };
}
var SEVERITIES = ["P0", "P1", "P2", "P3"];
function deriveTelemetry(findings2, iterationCount) {
  const findingCounts = { P0: 0, P1: 0, P2: 0, P3: 0 };
  for (const finding3 of findings2) {
    const severity = finding3["severity"];
    if (typeof severity === "string" && SEVERITIES.includes(severity)) {
      findingCounts[severity] = (findingCounts[severity] ?? 0) + 1;
    }
  }
  const deferred = findings2.filter((finding3) => finding3["disposition"] === "deferred");
  const deferredIssueIds = [
    ...new Set(
      deferred.map((finding3) => finding3["deferredIssueId"]).filter((id) => typeof id === "string" && id !== "")
    )
  ].sort();
  return {
    iterationCount,
    findingCounts,
    deferredExpansionCount: deferred.length,
    deferredIssueIds
  };
}
function reviewerLists(charters, outcome) {
  const byId = new Map(outcome.reviewers.map((reviewer2) => [reviewer2.id, reviewer2.result]));
  const withResult = (...results) => charters.filter((id) => results.includes(byId.get(id)));
  return {
    selected: [...charters],
    completed: withResult("approved", "rejected"),
    failed: withResult("failed"),
    timedOut: withResult("timed-out"),
    approved: withResult("approved")
  };
}

// packages/kernel/src/validator/artifacts.ts
var readMember = (value, key) => value !== null && typeof value === "object" && !Array.isArray(value) ? value[key] : void 0;
var RECORDER_MESSAGES = {
  artifact_outside_run_root: "the artifact resolves to a location outside the run root",
  artifact_missing: "no file is present at the declared path inside the run root",
  artifact_not_a_file: "the declared path names a directory or another non-regular entry, which has no bytes to digest",
  artifact_unreadable: "the artifact could not be read at submission",
  artifact_digest_mismatch: "the artifact's bytes at submission do not have the declared digest"
};
function declaredArtifacts(manifest) {
  const artifacts = readMember(manifest, "artifacts");
  if (!Array.isArray(artifacts)) return [];
  const entries = [];
  artifacts.forEach((entry3, index) => {
    const declaredPath = readMember(entry3, "path");
    if (typeof declaredPath !== "string") return;
    const sha2562 = readMember(entry3, "sha256");
    entries.push({ index, path: declaredPath, sha256: typeof sha2562 === "string" ? sha2562 : void 0 });
  });
  return entries;
}
function judgeArtifact(entry3, observation) {
  const pointer2 = `/artifacts/${entry3.index}`;
  switch (observation.status) {
    case "path_refused":
      return null;
    case "outside_run_root":
      return {
        code: "artifact_outside_run_root",
        rule: "ENV-10",
        pointer: `${pointer2}/path`,
        message: RECORDER_MESSAGES.artifact_outside_run_root
      };
    case "missing":
      return { code: "artifact_digest_mismatch", rule: "ENV-11", pointer: pointer2, message: RECORDER_MESSAGES.artifact_missing };
    case "not_a_file":
      return { code: "artifact_digest_mismatch", rule: "ENV-11", pointer: pointer2, message: RECORDER_MESSAGES.artifact_not_a_file };
    case "unreadable":
      return { code: "artifact_digest_mismatch", rule: "ENV-11", pointer: pointer2, message: RECORDER_MESSAGES.artifact_unreadable };
    case "readable":
      if (entry3.sha256 === void 0 || entry3.sha256 === observation.sha256) return null;
      return {
        code: "artifact_digest_mismatch",
        rule: "ENV-11",
        pointer: `${pointer2}/sha256`,
        message: RECORDER_MESSAGES.artifact_digest_mismatch
      };
  }
}

// packages/kernel/src/portable-evidence.ts
var isRecord6 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
function portableBlocker(code, summary) {
  return createBlocker({
    code,
    source: { kind: "delivery-record", id: "delivery-harness.portable-evidence" },
    summary,
    remediations: [{ id: "retain-current-evidence", kind: "manual_action", summary: "Prepare, acquire and submit current evidence, then record it with this product version." }]
  });
}
function refuse(code, summary) {
  throw new BlockedError([portableBlocker(code, summary)]);
}
function repositoryEvidenceReader(rootDir, artifacts) {
  return async (relativePath) => {
    const observation = await artifacts.observeArtifact(rootDir, relativePath);
    if (observation.status === "missing") return null;
    if (observation.status !== "readable" || observation.contents === null) refuse("portable_context_unreadable", "A declared evidence input could not be read inside the repository.");
    const bytes = observation.base64 === void 0 ? Buffer.from(observation.contents, "utf8") : Buffer.from(observation.base64, "base64");
    if (bytes.length > MAX_PORTABLE_ARTIFACT_BYTES || sha256Hex(bytes) !== observation.sha256) refuse("portable_context_invalid", "A declared evidence input is oversized or its exact bytes are unavailable.");
    return bytes;
  };
}
async function capturePortableEvidenceContext(config, read, preparationFingerprint) {
  const policy = await read(".agents/policy/compiled-snapshot.json");
  const release = await readWorkflowRelease(read);
  if (policy !== null && release === null) refuse("portable_context_incomplete", "Compiled review policy requires its installed workflow release.");
  if (policy === null && config.additionalReviewLenses?.length) refuse("portable_context_incomplete", "Additional review lenses require the installed activated review set.");
  const reviewerCharters = policy === null ? [] : await resolveReviewCharters(read, config);
  const graph = release === null ? null : await read(".agent-skills/current/workflows/delivery-v1.json");
  if (policy !== null && graph === null) refuse("portable_context_incomplete", "The installed workflow graph is missing.");
  return {
    configurationDigest: digestCanonical(config),
    preparationFingerprint,
    policyDigest: policy === null ? null : sha256Hex(policy),
    release,
    workflowGraphSha256: graph === null ? null : sha256Hex(graph),
    reviewerCharters
  };
}
function retainPortableEvidence(manifest, observations, context) {
  if (manifest.artifacts.length > MAX_PORTABLE_ARTIFACTS) refuse("portable_evidence_oversized", "The evidence references too many artifacts to retain.");
  const artifacts = /* @__PURE__ */ Object.create(null);
  for (const entry3 of manifest.artifacts) {
    const observed = observations.get(entry3.path);
    if (observed?.status !== "readable" || observed.contents === null) refuse("portable_evidence_incomplete", "Accepted evidence has no retained artifact bytes.");
    const bytes = observed.base64 === void 0 ? Buffer.from(observed.contents, "utf8") : Buffer.from(observed.base64, "base64");
    if (bytes.length > MAX_PORTABLE_ARTIFACT_BYTES) refuse("portable_evidence_oversized", "An evidence artifact exceeds the portable size limit.");
    if (sha256Hex(bytes) !== entry3.sha256) refuse("portable_evidence_corrupt", "The exact accepted artifact bytes could not be retained.");
    artifacts[entry3.path] = bytes.toString("base64");
  }
  const retained = { version: "portable-evidence/1", manifest, artifacts, context };
  if (Buffer.byteLength(JSON.stringify(retained), "utf8") > MAX_PORTABLE_EVIDENCE_BYTES) refuse("portable_evidence_oversized", "The accepted evidence exceeds the portable size limit.");
  return retained;
}
function portableArtifactContents(value) {
  const artifacts = /* @__PURE__ */ new Map();
  const observations = /* @__PURE__ */ new Map();
  const blockers = [];
  if (!isRecord6(value) || Object.keys(value).length > MAX_PORTABLE_ARTIFACTS) return { artifacts, observations, blockers: [portableBlocker("portable_evidence_incomplete", "The portable artifact map is missing or oversized.")] };
  for (const [declaredPath, encoded] of Object.entries(value)) {
    if (!isSafeRelativePath(declaredPath) || typeof encoded !== "string" || encoded.length > Math.ceil(MAX_PORTABLE_ARTIFACT_BYTES / 3) * 4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encoded)) {
      blockers.push(portableBlocker("portable_artifact_invalid", "A portable artifact has an invalid path, encoding or size."));
      continue;
    }
    const bytes = Buffer.from(encoded, "base64");
    if (bytes.toString("base64") !== encoded || bytes.length > MAX_PORTABLE_ARTIFACT_BYTES) {
      blockers.push(portableBlocker("portable_artifact_invalid", "A portable artifact is not canonical bounded base64."));
      continue;
    }
    const contents = bytes.toString("utf8");
    artifacts.set(declaredPath, contents);
    observations.set(declaredPath, { declaredPath, status: "readable", resolvedPath: null, sha256: sha256Hex(bytes), contents, base64: encoded, detail: null });
  }
  return { artifacts, observations, blockers };
}
function verifyPortableEvidence(config, portable, binding, expected, checkBindings) {
  const blockers = [];
  if (!isRecord6(portable) || portable.version !== "portable-evidence/1" || Object.keys(portable).sort().join(",") !== "artifacts,context,manifest,version" || Buffer.byteLength(JSON.stringify(portable), "utf8") > MAX_PORTABLE_EVIDENCE_BYTES) return [portableBlocker("portable_evidence_invalid", "The portable evidence is missing, unsupported or oversized.")];
  if (!isRecord6(portable.context) || digestCanonical(portable.context) !== digestCanonical(expected)) blockers.push(portableBlocker("portable_context_mismatch", "Evidence policy, wiring, compatible release or resolved reviewer inputs changed."));
  const read = portableArtifactContents(portable.artifacts);
  blockers.push(...read.blockers);
  const declared = declaredArtifacts(portable.manifest);
  if (read.observations.size !== declared.length) blockers.push(portableBlocker("portable_evidence_incomplete", "The retained artifact set differs from the accepted manifest."));
  for (const entry3 of declared) {
    const observation = read.observations.get(entry3.path) ?? { declaredPath: entry3.path, status: "missing", resolvedPath: null, sha256: null, contents: null, detail: null };
    const rejection = judgeArtifact(entry3, observation);
    if (rejection !== null) blockers.push(portableBlocker(rejection.code, rejection.message));
  }
  const candidate2 = isRecord6(portable.manifest) && isRecord6(portable.manifest["candidate"]) ? portable.manifest["candidate"] : {};
  const validation = validateManifest(portable.manifest, {
    config,
    prepared: true,
    artifactContents: read.artifacts,
    ...checkBindings === void 0 ? {} : { checkBindings },
    currentCandidate: {
      vcs: "git",
      treeSha: binding.treeSha,
      ...candidate2["headSha"] === void 0 ? {} : { headSha: candidate2["headSha"] },
      deliverable: { digest: binding.deliverableDigest, identity: binding.identityToken },
      base: { ref: binding.baseRef, tipSha: binding.baseTipSha, mergeBaseSha: binding.mergeBaseSha },
      workspaceId: binding.workspaceId
    }
  });
  if (!validation.ok) blockers.push(...validation.rejections.map((rejection) => portableBlocker(rejection.code, rejection.message)));
  else {
    for (const claim of validation.manifest.claims) {
      if (claim.payloadSpec !== "review.green/1") continue;
      if (expected.reviewerCharters.length > 0) blockers.push(...verifyOriginalReview(validation.manifest, claim, read.artifacts, expected));
      const reviewers = isRecord6(claim.payload["reviewers"]) ? claim.payload["reviewers"]["selected"] : void 0;
      if (!Array.isArray(reviewers) || expected.reviewerCharters.some((charter) => !reviewers.includes(charter.reviewerId))) {
        blockers.push(portableBlocker("portable_review_lens_missing", "Actual reviewer evidence does not cover every activated and additional review lens."));
      }
    }
  }
  return blockers;
}
function verifyOriginalReview(manifest, claim, artifacts, expected) {
  try {
    const artifact = (role) => {
      const entries = manifest.artifacts.filter((entry3) => entry3.role === role);
      if (entries.length !== 1) throw new Error(`expected one ${role} artifact`);
      return JSON.parse(artifacts.get(entries[0].path));
    };
    const original = artifact("review-context");
    const rawOutcome = artifact("review-outcome");
    const binding = {
      gate: { obligationId: claim.obligation, providerId: manifest.provider.id },
      candidate: manifest.candidate,
      preparationFingerprint: expected.preparationFingerprint,
      configurationDigest: expected.configurationDigest,
      policyDigest: expected.policyDigest,
      release: expected.release,
      workflowGraphSha256: expected.workflowGraphSha256,
      charters: expected.reviewerCharters
    };
    validateReviewedContext(original, { spec: "review-context/1", digest: digestCanonical(binding), binding }, rawOutcome);
    const reviewed = original;
    const ids = expected.reviewerCharters.map((charter) => charter.reviewerId).sort();
    const outcome = parseReviewOutcome(rawOutcome, ids);
    const lists = reviewerLists(ids, outcome);
    const approvals = manifest.artifacts.filter((entry3) => entry3.role === "reviewer-approval").map((entry3) => {
      const stamp = JSON.parse(artifacts.get(entry3.path));
      return isRecord6(stamp) ? stamp["reviewerId"] : void 0;
    });
    if (digestCanonical(approvals.sort()) !== digestCanonical([...lists.approved].sort())) throw new Error("approval artifacts differ from the reviewers who actually approved");
    const finalPassId = outcome.finalPassId ?? "pass-1";
    const originalRunHistory = outcome.runHistory ?? [{ preparedTreeSha: reviewed.binding.candidate.treeSha, evaluatedInPassId: finalPassId }];
    const final = originalRunHistory.at(-1);
    if (final["preparedTreeSha"] !== reviewed.binding.candidate.treeSha || final["evaluatedInPassId"] !== finalPassId || finalPassId !== manifest.provider.finalPassId) throw new Error("original final pass differs");
    const runHistory = originalRunHistory.map((entry3, index) => index === originalRunHistory.length - 1 ? { ...entry3, preparedTreeSha: manifest.candidate.treeSha } : entry3);
    const expectedPayload = {
      verdict: outcome.verdict,
      finalized: true,
      editedAfterFinalPass: false,
      reviewers: { selected: lists.selected, completed: lists.completed, failed: lists.failed, timedOut: lists.timedOut },
      findings: outcome.findings,
      telemetry: { ...deriveTelemetry(outcome.findings, runHistory.length), ...outcome.cost === void 0 ? {} : { cost: outcome.cost } }
    };
    if (digestCanonical(expectedPayload) !== digestCanonical(claim.payload) || digestCanonical(runHistory) !== digestCanonical(manifest.runHistory)) throw new Error("manifest differs from original host outcomes or history");
    const projected = digestCanonical(reviewed.binding.candidate) !== digestCanonical(manifest.candidate);
    const projections = manifest.artifacts.filter((entry3) => entry3.role === "review-context-projection");
    if (projected) {
      const expectedProjection = {
        spec: "review-context-projection/1",
        basis: "unchanged-deliverable-and-review-inputs",
        originalContextDigest: reviewed.digest,
        reviewedCandidate: reviewed.binding.candidate,
        preparedCandidate: manifest.candidate,
        originalRunHistory,
        reviewRoundAdded: false
      };
      if (digestCanonical(artifact("review-context-projection")) !== digestCanonical(expectedProjection)) throw new Error("neutral projection differs from original review history");
    } else if (projections.length > 0) throw new Error("unexpected neutral projection");
    return [];
  } catch (error) {
    return [portableBlocker("portable_review_outcome_invalid", `The retained original review does not substantiate its manifest: ${error instanceof Error ? error.message : "invalid input"}`)];
  }
}

// packages/kernel/src/recorder.ts
var SUBMISSION_CANDIDATE_FIELDS = Object.freeze([
  "vcs",
  "treeSha",
  "headSha",
  "deliverable.digest",
  "deliverable.identity",
  "base.ref",
  "base.tipSha",
  "base.mergeBaseSha",
  "workspaceId"
]);
function readMember2(value, name) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return void 0;
  return Object.prototype.hasOwnProperty.call(value, name) ? value[name] : void 0;
}
function readPath(value, dotted) {
  return dotted.split(".").reduce((current, name) => readMember2(current, name), value);
}
function compareSubmissionCandidate(submitted, captured) {
  const capturedValues = {
    vcs: captured.vcs,
    treeSha: captured.treeSha,
    headSha: captured.headSha,
    "deliverable.digest": captured.deliverable.digest,
    "deliverable.identity": captured.deliverable.identity,
    "base.ref": captured.base.ref,
    "base.tipSha": captured.base.tipSha,
    "base.mergeBaseSha": captured.base.mergeBaseSha,
    workspaceId: captured.workspaceId
  };
  const mismatchedFields = [];
  for (const field of SUBMISSION_CANDIDATE_FIELDS) {
    const declared = readPath(submitted, field);
    if (field === "headSha" && declared === void 0) continue;
    if (declared !== capturedValues[field]) mismatchedFields.push(field);
  }
  const submittedBinding = bindingFromSubmitted(submitted);
  const driftClasses = submittedBinding === null ? [] : classifyCandidateDrift(submittedBinding, capturedBinding(captured));
  return { matches: mismatchedFields.length === 0, mismatchedFields, driftClasses };
}
function capturedBinding(captured) {
  return {
    treeSha: captured.treeSha,
    deliverable: { digest: captured.deliverable.digest, identity: captured.deliverable.identity },
    base: { ref: captured.base.ref, tipSha: captured.base.tipSha, mergeBaseSha: captured.base.mergeBaseSha },
    workspaceId: captured.workspaceId
  };
}
function bindingFromSubmitted(submitted) {
  const treeSha2 = readPath(submitted, "treeSha");
  const digest2 = readPath(submitted, "deliverable.digest");
  const identity = readPath(submitted, "deliverable.identity");
  const tipSha = readPath(submitted, "base.tipSha");
  const mergeBaseSha = readPath(submitted, "base.mergeBaseSha");
  const ref = readPath(submitted, "base.ref");
  const workspaceId = readPath(submitted, "workspaceId");
  const strings = [treeSha2, digest2, identity, tipSha, mergeBaseSha, ref, workspaceId];
  if (strings.some((value) => typeof value !== "string")) return null;
  return {
    treeSha: treeSha2,
    deliverable: { digest: digest2, identity },
    base: { ref, tipSha, mergeBaseSha },
    workspaceId
  };
}
function projectCapturedCandidate(captured, submitted) {
  const projected = {
    vcs: captured.vcs,
    treeSha: captured.treeSha,
    deliverable: { digest: captured.deliverable.digest, identity: captured.deliverable.identity },
    base: { ref: captured.base.ref, tipSha: captured.base.tipSha, mergeBaseSha: captured.base.mergeBaseSha },
    workspaceId: captured.workspaceId
  };
  if (readPath(submitted, "headSha") !== void 0) projected["headSha"] = captured.headSha;
  return projected;
}
var RESUBMIT = {
  id: "resubmit-after-fixing-the-manifest",
  kind: "manual_action",
  summary: "Fix what the codes name, prepare the candidate again if it moved, and resubmit."
};
var CHECK_MANIFEST_PATH = {
  id: "submit-from-the-run-root",
  kind: "manual_action",
  summary: "Submit the manifest from the run root the harness allocated for this run."
};
var RETRY_PROVIDER_ATTEMPT = {
  id: "retry-provider-attempt",
  kind: "retry",
  summary: "Run the selected provider again with the harness-allocated request and run root."
};
function submissionBlocker(code, summary, details, remediation) {
  return createBlocker({
    // A runtime-checked code: this module builds one from a rejection code,
    // which is a registry value rather than a literal the type system can see.
    // `createBlocker` still applies the grammar at runtime.
    code,
    source: { kind: "gate", id: "delivery-harness.submission" },
    summary,
    details: sanitizedDetail(details, "Submission detail"),
    remediations: [remediation]
  });
}
function rejectionBlockers(rejections, candidateDetail) {
  return rejections.map((rejection) => {
    const detail = `${rejection.pointer === "" ? "/" : rejection.pointer}: ${rejection.message}`;
    return submissionBlocker(
      rejection.code,
      `The submission violates ${rejection.rule}.`,
      rejection.code === "candidate_mismatch" && candidateDetail !== null ? `${detail} (${candidateDetail})` : detail,
      rejection.code === "manifest_outside_run_root" ? CHECK_MANIFEST_PATH : RESUBMIT
    );
  });
}
function describeComparison(comparison) {
  if (comparison === null || comparison.matches) return null;
  const drift = comparison.driftClasses.length === 0 ? "" : `; drift: ${comparison.driftClasses.join(", ")}`;
  return `differing fields: ${comparison.mismatchedFields.join(", ")}${drift}`;
}
function nonEmpty(values, what) {
  const [first2, ...rest] = values;
  if (first2 === void 0) throw new Error(`${what} must not be empty.`);
  return [first2, ...rest];
}
function blockedOutcome(blockers) {
  return { status: "blocked", blockers: nonEmpty(blockers, "blockers") };
}
async function expectedProviderAttemptBlockers(manifest, manifestPath, expected, artifacts) {
  const blockers = [];
  try {
    if (!await artifacts.isInsideRunRoot(expected.runRootPath, manifestPath)) {
      blockers.push(
        submissionBlocker(
          "provider_manifest_outside_attempt_root",
          "The provider manifest is outside the run root allocated for this attempt.",
          "The manifest path does not resolve inside the caller-bound provider run root.",
          RETRY_PROVIDER_ATTEMPT
        )
      );
    }
  } catch (error) {
    if (error instanceof BlockedError) return error.blockers;
    blockers.push(
      submissionBlocker(
        "provider_attempt_binding_failed",
        "The provider manifest could not be bound to its allocated run root.",
        error instanceof Error ? error.message : String(error),
        RETRY_PROVIDER_ATTEMPT
      )
    );
  }
  if (readPath(manifest, "provider.id") !== expected.providerId || readPath(manifest, "provider.runId") !== expected.runId) {
    blockers.push(
      submissionBlocker(
        "provider_attempt_mismatch",
        "The provider manifest belongs to a different invocation.",
        "The manifest provider or run identity differs from the caller-bound provider attempt.",
        RETRY_PROVIDER_ATTEMPT
      )
    );
  }
  return blockers;
}
function rejectedOutcome(rejections, comparison = null) {
  const listed = nonEmpty(rejections, "rejections");
  return {
    status: "rejected",
    rejections: listed,
    blockers: nonEmpty(rejectionBlockers(listed, describeComparison(comparison)), "blockers")
  };
}
var RECORDER_MESSAGES2 = {
  manifest_outside_run_root: "the manifest does not reside inside the run root allocated for this provider run",
  artifact_outside_run_root: "the artifact resolves to a location outside the run root",
  artifact_missing: "no file is present at the declared path inside the run root",
  artifact_not_a_file: "the declared path names a directory or another non-regular entry, which has no bytes to digest",
  artifact_unreadable: "the artifact could not be read at submission",
  artifact_digest_mismatch: "the artifact's bytes at submission do not have the declared digest"
};
async function submitManifest(input, options) {
  const artifacts = options.artifacts ?? createArtifactsPort();
  let manifest;
  try {
    manifest = JSON.parse(await artifacts.readTextFile(input.manifestPath));
  } catch (error) {
    if (error instanceof BlockedError) return blockedOutcome(error.blockers);
    return blockedOutcome([
      submissionBlocker(
        "manifest_unparseable",
        "The submitted manifest is not parseable JSON.",
        `${input.manifestPath}: ${error instanceof Error ? error.message : String(error)}`,
        RESUBMIT
      )
    ]);
  }
  if (options.expectedProviderAttempt !== void 0) {
    const attemptBlockers = await expectedProviderAttemptBlockers(
      manifest,
      input.manifestPath,
      options.expectedProviderAttempt,
      artifacts
    );
    if (attemptBlockers.length > 0) return blockedOutcome(attemptBlockers);
  }
  const capture = await options.captureCandidate();
  if (!capture.ok && capture.code !== "candidate_unprepared") {
    return blockedOutcome(capture.blockers);
  }
  const captured = capture.ok ? capture.candidate : null;
  let preparationFingerprint;
  if (captured !== null) {
    const preparation = await evaluatePreparationReceipt(
      input.rootDir,
      { config: input.config, candidate: captured },
      { ...storageOptions(options), ...options.harnessVersion === void 0 ? {} : { harnessVersion: options.harnessVersion } }
    );
    if (!preparation.prepared) return blockedOutcome(preparation.blockers);
    preparationFingerprint = preparation.receipt.preparationFingerprint;
  }
  const rejections = [];
  const allocation = await allocateRunRootFor(manifest, artifacts);
  if (!allocation.ok && allocation.blocker !== null) return blockedOutcome([allocation.blocker]);
  const runRoot = allocation.ok ? allocation.runRoot : null;
  const artifactContents = /* @__PURE__ */ new Map();
  const observations = /* @__PURE__ */ new Map();
  if (runRoot !== null) {
    if (!await artifacts.isInsideRunRoot(runRoot.path, input.manifestPath)) {
      rejections.push({
        code: "manifest_outside_run_root",
        rule: "SUB-3",
        pointer: "",
        message: RECORDER_MESSAGES2.manifest_outside_run_root
      });
    }
    for (const entry3 of declaredArtifacts(manifest)) {
      const observation = await artifacts.observeArtifact(runRoot.path, entry3.path);
      observations.set(entry3.path, observation);
      if (observation.status === "readable" && observation.contents !== null) {
        artifactContents.set(entry3.path, observation.contents);
      }
      const rejection = judgeArtifact(entry3, observation);
      if (rejection !== null) rejections.push(rejection);
    }
  }
  const checkBindings = captured === null ? {} : await captureCheckBindings(input.rootDir, input.config, captured, options);
  const validation = validateManifest(manifest, {
    config: input.config,
    // A candidate that could not be captured matches nothing: SUB-1 requires
    // equality with the current prepared candidate, and an unobserved candidate
    // supplies no side to be equal to. Failing closed here is what keeps an
    // unprepared workspace from also being an unchecked one.
    currentCandidate: captured === null ? void 0 : projectCapturedCandidate(captured, readMember2(manifest, "candidate")),
    prepared: captured !== null,
    artifactContents,
    checkBindings
  });
  if (!validation.ok) rejections.push(...validation.rejections);
  if (!validation.ok || rejections.length > 0) {
    return rejectedOutcome(rejections, captured === null ? null : compareSubmissionCandidate(readMember2(manifest, "candidate"), captured));
  }
  try {
    const context = await capturePortableEvidenceContext(input.config, repositoryEvidenceReader(input.rootDir, artifacts), preparationFingerprint);
    const portable = retainPortableEvidence(validation.manifest, observations, context);
    const blockers = verifyPortableEvidence(input.config, portable, recordBinding(validation.manifest), context, checkBindings);
    if (blockers.length > 0) return blockedOutcome(blockers);
    return publishClaims(input, options, validation.manifest, portable);
  } catch (error) {
    if (error instanceof BlockedError) return blockedOutcome(error.blockers);
    return blockedOutcome([submissionBlocker("portable_context_invalid", "The accepted evidence inputs could not be retained.", error instanceof Error ? error.message : String(error), RESUBMIT)]);
  }
}
function storageOptions(options) {
  return {
    ...options.storageNamespace === void 0 ? {} : { storageNamespace: options.storageNamespace },
    ...options.storageRoot === void 0 ? {} : { storageRoot: options.storageRoot },
    ...options.runGit === void 0 ? {} : { runGit: options.runGit }
  };
}
var VALIDATOR_NAMED_REFUSALS = ["unsafe_provider_id", "unsafe_run_id"];
var RUN_ROOT_REFUSAL_SUMMARIES = {
  unsafe_provider_id: "The provider id cannot be a run-root path component.",
  unsafe_run_id: "The run id cannot be a run-root path component.",
  provider_id_too_long: "The provider id is too long to be a run-root path component.",
  run_root_outside_base: "The run root for this provider run is not inside the pool the harness allocates from."
};
var REALLOCATE_RUN_ROOT = {
  id: "let-the-harness-allocate-the-run-root",
  kind: "manual_action",
  summary: "Remove the run-root path, re-run the provider so the harness allocates it, and resubmit."
};
async function allocateRunRootFor(manifest, artifacts) {
  const providerId2 = readPath(manifest, "provider.id");
  const runId = readPath(manifest, "provider.runId");
  if (typeof providerId2 !== "string" || typeof runId !== "string") return { ok: false, blocker: null };
  let allocation;
  try {
    allocation = await artifacts.allocateRunRoot({ providerId: providerId2, runId });
  } catch (error) {
    if (!(error instanceof BlockedError)) throw error;
    const [first2] = error.blockers;
    return { ok: false, blocker: first2 ?? runRootBlocker("run_root_outside_base", `${providerId2}/${runId}`) };
  }
  if (allocation.ok) return { ok: true, runRoot: allocation.runRoot };
  if (VALIDATOR_NAMED_REFUSALS.includes(allocation.reason)) return { ok: false, blocker: null };
  return { ok: false, blocker: runRootBlocker(allocation.reason, `${providerId2}/${runId}`) };
}
function runRootBlocker(reason, coordinates) {
  return submissionBlocker(reason, RUN_ROOT_REFUSAL_SUMMARIES[reason], coordinates, REALLOCATE_RUN_ROOT);
}
function recordBinding(manifest) {
  const candidate2 = manifest.candidate;
  return {
    treeSha: candidate2.treeSha,
    deliverableDigest: candidate2.deliverable.digest,
    identityToken: candidate2.deliverable.identity,
    baseRef: candidate2.base.ref,
    baseTipSha: candidate2.base.tipSha,
    mergeBaseSha: candidate2.base.mergeBaseSha,
    workspaceId: candidate2.workspaceId
  };
}
async function publishClaims(input, options, manifest, portable) {
  const storage = storageOptions(options);
  const artifacts = options.artifacts ?? createArtifactsPort();
  const digest2 = manifestDigest(manifest);
  const binding = recordBinding(manifest);
  const inputs = manifest.claims.map((claim) => ({
    gateId: input.config.gateId,
    obligationId: claim.obligation,
    candidateBinding: binding,
    resolution: {
      kind: "evidence",
      providerId: manifest.provider.id,
      runId: manifest.provider.runId,
      finalPassId: manifest.provider.finalPassId,
      manifestDigest: digest2,
      ...claim.payloadSpec === "checks.passed/1" ? { checkBinding: claim.payload["binding"] } : {},
      portable
    }
  }));
  const records = [];
  try {
    const conflicts = await findConflicts(input, storage, inputs);
    if (conflicts.length > 0) return rejectedOutcome(conflicts);
    for (const publishInput of inputs) {
      const published = await publishRecord(input.rootDir, publishInput, storage);
      records.push({
        obligationId: published.record.obligationId,
        recordId: published.record.recordId,
        path: published.path,
        status: published.status,
        record: published.record
      });
    }
    return { status: "accepted", manifestDigest: digest2, records: nonEmpty(records, "records") };
  } catch (error) {
    if (!(error instanceof BlockedError)) throw error;
    await rollBack(records, artifacts);
    if (!error.blockers.some((blocker) => blocker.code === "record_conflict")) return blockedOutcome(error.blockers);
    return rejectedOutcome([{ code: "record_conflict", rule: "SUB-4", pointer: "", message: CONFLICT_MESSAGE }]);
  }
}
async function rollBack(records, artifacts) {
  for (const record2 of records) {
    if (record2.status !== "published") continue;
    await artifacts.removeFile(record2.path);
  }
}
var CONFLICT_MESSAGE = "a record with this identity is already stored and carries different content";
async function findConflicts(input, storage, inputs) {
  const { workspaceId } = await resolveRecordStorage(input.rootDir, storage);
  const conflicts = [];
  for (const publishInput of inputs) {
    const recordId = computeRecordId(workspaceId, publishInput);
    const fileName = recordFileName(publishInput.gateId, publishInput.obligationId, recordId);
    const discovery = await discoverRecords(input.rootDir, {
      ...storage,
      gateId: publishInput.gateId,
      obligationId: publishInput.obligationId
    });
    const quarantined = discovery.quarantined.some((entry3) => entry3.path.endsWith(fileName));
    const existing = discovery.records.find((record2) => record2.recordId === recordId);
    const differs = existing !== void 0 && digestCanonical({ binding: existing.candidateBinding, resolution: existing.resolution }) !== digestCanonical({ binding: publishInput.candidateBinding, resolution: publishInput.resolution });
    if (quarantined || differs) {
      conflicts.push({ code: "record_conflict", rule: "SUB-4", pointer: "", message: CONFLICT_MESSAGE });
    }
  }
  return conflicts;
}

// packages/kernel/src/admission.ts
var INVOCATION_WAIVER_SCOPE = "invocation";
function storageOptions2(options) {
  return {
    ...options.storageNamespace === void 0 ? {} : { storageNamespace: options.storageNamespace },
    ...options.leaf === void 0 ? {} : { leaf: options.leaf },
    ...options.storageRoot === void 0 ? {} : { storageRoot: options.storageRoot },
    ...options.runGit === void 0 ? {} : { runGit: options.runGit }
  };
}
var PREPARE_AGAIN2 = {
  id: "prepare-current-candidate",
  kind: "manual_action",
  summary: "Prepare the current candidate again so a fresh receipt is published, then re-run the gate."
};
function candidateChangedBlocker() {
  return createBlocker({
    code: "candidate_changed_during_prompt",
    source: { kind: "candidate", id: "candidate-drift" },
    summary: "The candidate changed while the waiver prompt was open, so the offered waiver no longer describes it.",
    remediations: [PREPARE_AGAIN2]
  });
}
function waiverDeclinedBlocker(gateId, obligationIds) {
  return createBlocker({
    code: "waiver_declined",
    source: { kind: "gate", id: gateId },
    summary: `The interactive human declined the offered waiver for: ${obligationIds.join(", ")}.`,
    remediations: [
      {
        id: "satisfy-the-declined-obligations",
        kind: "manual_action",
        summary: "Produce real evidence for the obligations whose waiver was declined, then re-run the gate."
      }
    ]
  });
}
function workspaceIncoherentBlocker(gateId, candidateWorkspaceId, storeWorkspaceId) {
  return createBlocker({
    code: "workspace_incoherent",
    source: { kind: "gate", id: gateId },
    summary: "The captured candidate and the evidence store resolve to different workspaces.",
    details: `candidate workspace ${candidateWorkspaceId} != store workspace ${storeWorkspaceId}`,
    remediations: [
      {
        id: "point-capture-and-store-at-one-repository",
        kind: "manual_action",
        summary: "Run the candidate capture and the evidence store against the same repository, then re-run the gate."
      }
    ]
  });
}
function nonEmpty2(blockers) {
  const [first2, ...rest] = blockers;
  if (first2 === void 0) throw new Error("An admission block must carry at least one blocker.");
  return [first2, ...rest];
}
function blocked3(partial) {
  return { admitted: false, ...partial, blockers: nonEmpty2(partial.blockers) };
}
async function mapStore(input, options, candidate2) {
  const discover = options.discoverRecords ?? ((rootDir, gateId, obligationId) => discoverRecords(rootDir, { ...storageOptions2(options), gateId, obligationId }));
  const records = [];
  const unreadable = [];
  for (const obligation of input.config.obligations) {
    if (obligation.freshness === "live") continue;
    const discovery = await discover(input.rootDir, input.config.gateId, obligation.id);
    for (const record2 of discovery.records) {
      const appliesToCandidate = isRecordFreshForCandidate(input.config, record2.candidateBinding, candidate2);
      if (appliesToCandidate) records.push(record2);
    }
    for (const quarantined of discovery.quarantined) {
      unreadable.push({ gateId: input.config.gateId, obligationId: obligation.id, appliesToCandidate: true, quarantined });
    }
  }
  return { records, unreadable, checkBindings: await captureCheckBindings(input.rootDir, input.config, candidate2, options) };
}
function gateInput(input, candidate2, projection, store, extraRecords, invocationWaiverRecordIds) {
  const records = dedupeRecords([...store.records, ...extraRecords]);
  return {
    config: input.config,
    candidate: candidate2,
    projection,
    context: input.context,
    records,
    checkBindings: store.checkBindings,
    unreadable: store.unreadable,
    ...input.liveResults === void 0 ? {} : { liveResults: input.liveResults },
    invocationWaiverRecordIds
  };
}
function dedupeRecords(records) {
  const byId = /* @__PURE__ */ new Map();
  for (const record2 of records) if (!byId.has(record2.recordId)) byId.set(record2.recordId, record2);
  return [...byId.values()];
}
function waivableBlockedObligationIds(config, context, decision) {
  if (context.kind !== "human") return [];
  const blockedResolutions = decision.resolutions.filter((resolution) => resolution.kind === "blocked");
  if (blockedResolutions.length === 0) return [];
  const obligationsById = new Map(config.obligations.map((obligation) => [obligation.id, obligation]));
  const fullyWaivable = blockedResolutions.every((resolution) => {
    const obligation = obligationsById.get(resolution.obligationId);
    if (obligation === void 0 || !obligation.humanWaiverAllowed) return false;
    const waivable = new Set(obligation.waivableCodes);
    return resolution.blockers.every((blocker) => !NON_WAIVABLE_INTEGRITY_CODES.includes(blocker.code) && waivable.has(blocker.code));
  });
  return fullyWaivable ? blockedResolutions.map((resolution) => resolution.obligationId) : [];
}
function recordBindingOf(candidate2) {
  return {
    treeSha: candidate2.treeSha,
    deliverableDigest: candidate2.deliverable.digest,
    identityToken: candidate2.deliverable.identity,
    baseRef: candidate2.base.ref,
    baseTipSha: candidate2.base.tipSha,
    mergeBaseSha: candidate2.base.mergeBaseSha,
    workspaceId: candidate2.workspaceId
  };
}
function sameCandidate(expected, observed) {
  return classifyCandidateDrift(expected, observed).length === 0 && expected.headSha === observed.headSha && expected.mode === observed.mode && expected.base.ref === observed.base.ref;
}
var NOT_OFFERED = { waiver: "not_offered", waivedObligationIds: [], waiverRecordIds: [] };
async function runAdmission(input, options) {
  try {
    return await admit(input, options);
  } catch (error) {
    if (!(error instanceof BlockedError)) throw error;
    return blocked3({ ...NOT_OFFERED, blockers: error.blockers });
  }
}
async function admit(input, options) {
  const capture = await options.captureCandidate();
  if (!capture.ok) return blocked3({ ...NOT_OFFERED, blockers: capture.blockers });
  const candidate2 = capture.candidate;
  const storage = await resolveRecordStorage(input.rootDir, storageOptions2(options));
  if (candidate2.workspaceId !== storage.workspaceId) {
    return blocked3({
      ...NOT_OFFERED,
      candidate: candidate2,
      context: input.context,
      blockers: [workspaceIncoherentBlocker(input.config.gateId, candidate2.workspaceId, storage.workspaceId)]
    });
  }
  const evaluateReceipt = options.evaluatePreparation ?? ((rootDir, config, current) => evaluatePreparationReceipt(rootDir, { config, candidate: current }, { ...storageOptions2(options), ...options.harnessVersion === void 0 ? {} : { harnessVersion: options.harnessVersion } }));
  const preparation = await evaluateReceipt(input.rootDir, input.config, candidate2);
  if (!preparation.prepared) {
    return blocked3({ ...NOT_OFFERED, candidate: candidate2, context: input.context, blockers: preparation.blockers });
  }
  const projection = await options.projectActivation(candidate2);
  const store = await mapStore(input, options, candidate2);
  const firstPass = evaluateGate(gateInput(input, candidate2, projection, store, [], []));
  if (firstPass.admitted) {
    return { admitted: true, blockers: [], decision: firstPass, context: input.context, candidate: candidate2, ...NOT_OFFERED };
  }
  const covered = waivableBlockedObligationIds(input.config, input.context, firstPass);
  if (covered.length === 0 || options.promptForWaiver === void 0) {
    return blocked3({ ...NOT_OFFERED, decision: firstPass, context: input.context, candidate: candidate2, blockers: firstPass.blockers });
  }
  const accepted = await options.promptForWaiver(firstPass, covered);
  if (!accepted) {
    return blocked3({
      waiver: "declined",
      waivedObligationIds: covered,
      waiverRecordIds: [],
      decision: firstPass,
      context: input.context,
      candidate: candidate2,
      blockers: [...firstPass.blockers, waiverDeclinedBlocker(input.config.gateId, covered)]
    });
  }
  if (typeof accepted !== "object" || accepted === null || typeof accepted.author !== "string" || !accepted.author.trim() || accepted.author.length > 256 || typeof accepted.reason !== "string" || !accepted.reason.trim() || accepted.reason.length > 4096) {
    return blocked3({
      ...NOT_OFFERED,
      candidate: candidate2,
      context: input.context,
      decision: firstPass,
      blockers: [...firstPass.blockers, createBlocker({
        code: "waiver_attribution_invalid",
        source: { kind: "gate", id: input.config.gateId },
        summary: "A human exception requires an author and reason.",
        remediations: [{ id: "provide-attribution", kind: "manual_action", summary: "Provide bounded non-empty author and reason through the human waiver prompt." }]
      })]
    });
  }
  const recapture = await options.captureCandidate();
  const currentPreparation = recapture.ok ? await evaluateReceipt(input.rootDir, input.config, recapture.candidate) : void 0;
  if (!recapture.ok || !sameCandidate(candidate2, recapture.candidate) || !currentPreparation?.prepared || currentPreparation.receipt.preparationFingerprint !== preparation.receipt.preparationFingerprint) {
    return blocked3({
      waiver: "candidate_changed",
      waivedObligationIds: covered,
      waiverRecordIds: [],
      decision: firstPass,
      context: input.context,
      candidate: candidate2,
      blockers: [...firstPass.blockers, candidateChangedBlocker()]
    });
  }
  const currentStore = await mapStore(input, options, candidate2);
  const currentPass = evaluateGate(gateInput(input, candidate2, projection, currentStore, [], []));
  const findingScope = (decision) => decision.resolutions.filter((resolution) => resolution.kind === "blocked").map((resolution) => ({ obligationId: resolution.obligationId, codes: [...new Set(resolution.blockers.map((blocker) => blocker.code))].sort() })).sort((left, right) => left.obligationId.localeCompare(right.obligationId));
  if (digestCanonical(findingScope(firstPass)) !== digestCanonical(findingScope(currentPass))) {
    return blocked3({
      waiver: "scope_changed",
      waivedObligationIds: [],
      waiverRecordIds: [],
      candidate: candidate2,
      context: input.context,
      decision: currentPass,
      blockers: [...currentPass.blockers, createBlocker({
        code: "waiver_scope_changed",
        source: { kind: "gate", id: input.config.gateId },
        summary: "The findings changed while the human exception was being approved.",
        remediations: [{ id: "reevaluate-waiver", kind: "manual_action", summary: "Run the gate again and review the current findings before approving an exception." }]
      })]
    });
  }
  const publishWaiver = options.publishWaiver ?? ((rootDir, binding2, obligationId, resolution) => publishRecord(rootDir, { gateId: input.config.gateId, obligationId, candidateBinding: binding2, resolution }, storageOptions2(options)));
  const binding = recordBindingOf(candidate2);
  const published = [];
  const grantedIds = [];
  for (const obligationId of covered) {
    const findingCodes = [...new Set(firstPass.resolutions.filter((r) => r.obligationId === obligationId && r.kind === "blocked").flatMap((r) => r.kind === "blocked" ? r.blockers.map((b) => b.code) : []))].sort();
    const record2 = await publishWaiver(input.rootDir, binding, obligationId, {
      kind: "waiver",
      scope: input.config.obligations.find((o) => o.id === obligationId)?.freshness === "live" ? INVOCATION_WAIVER_SCOPE : "durable",
      author: accepted.author.trim(),
      reason: accepted.reason.trim(),
      findingCodes,
      policyDigest: digestCanonical(input.config)
    });
    published.push(record2.record);
    grantedIds.push(record2.record.recordId);
  }
  const finalStore = await mapStore(input, options, candidate2);
  const secondPass = evaluateGate(gateInput(input, candidate2, projection, finalStore, published, grantedIds));
  return {
    admitted: secondPass.admitted,
    blockers: secondPass.blockers,
    decision: secondPass,
    context: input.context,
    candidate: candidate2,
    waiver: "accepted",
    waivedObligationIds: covered,
    waiverRecordIds: grantedIds
  };
}

// packages/kernel/src/delivery-record.ts
var DELIVERY_RECORD_VERSION = "delivery-record/2";
var ATTESTATION_LABEL = "self / workspace-scoped \u2014 process discipline and freshness, not provenance";
var DELIVERY_RECORD_DRIFT_CLASSES = [
  "deliverable_identity_changed",
  "base_ref_changed",
  "base_tip_moved",
  "merge_base_moved"
];
var DELIVERY_OWNED_TREE_PREFIXES = Object.freeze([".managed-projection", ".claude"]);
var CLAUDE_SKILL_EXPOSURE_PREFIX = ".claude/skills/";
var RECEIPTED_SKILLS_ROOT = ".agent-skills/current/skills/";
var SYMLINK_MODE = "120000";
var DELIVERY_RECORD_SOURCE = { kind: "delivery-record", id: "delivery-harness.delivery-record" };
var RERECORD = {
  id: "re-run-the-loop",
  kind: "manual_action",
  summary: "Re-prepare, re-run the gate, and re-record for the current candidate."
};
function drBlocker(code, summary, details, remediation = RERECORD) {
  return createBlocker({
    code,
    source: DELIVERY_RECORD_SOURCE,
    summary,
    ...details === void 0 ? {} : { details },
    remediations: [remediation]
  });
}
function isRecord7(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function isNonEmptyString3(value) {
  return typeof value === "string" && value.length > 0;
}
function bindingOf(candidate2) {
  return {
    treeSha: candidate2.treeSha,
    deliverableDigest: candidate2.deliverable.digest,
    identityToken: candidate2.deliverable.identity,
    baseRef: candidate2.base.ref,
    baseTipSha: candidate2.base.tipSha,
    mergeBaseSha: candidate2.base.mergeBaseSha,
    workspaceId: candidate2.workspaceId
  };
}
function claimedManifestDigests(claims) {
  return [...new Set(claims.flatMap((claim) => [claim.manifestDigest, ...Array.isArray(claim.supportingEvidence) ? claim.supportingEvidence.map((record2) => record2?.resolution?.kind === "evidence" ? record2.resolution.manifestDigest : void 0) : []]).filter((digest2) => typeof digest2 === "string"))];
}
function claimOf(resolution, evidenceByRecordId) {
  switch (resolution.kind) {
    case "satisfied_evidence": {
      const evidence = evidenceByRecordId.get(resolution.recordId);
      const manifestDigest2 = evidence?.resolution.kind === "evidence" ? evidence.resolution.manifestDigest : void 0;
      return {
        obligationId: resolution.obligationId,
        outcome: resolution.kind,
        providerId: resolution.providerId,
        recordId: resolution.recordId,
        runId: resolution.runId,
        finalPassId: resolution.finalPassId,
        ...manifestDigest2 === void 0 ? {} : { manifestDigest: manifestDigest2 },
        ...evidence === void 0 ? {} : { evidence },
        ...resolution.supportingRecordIds === void 0 ? {} : { supportingEvidence: resolution.supportingRecordIds.filter((id) => id !== resolution.recordId).map((id) => evidenceByRecordId.get(id)).filter((record2) => record2 !== void 0) }
      };
    }
    case "satisfied_live_fact":
      return { obligationId: resolution.obligationId, outcome: resolution.kind, providerId: resolution.providerId, runId: resolution.runId };
    case "waived":
      return {
        obligationId: resolution.obligationId,
        outcome: resolution.kind,
        recordId: resolution.waiverRecordId,
        scope: resolution.scope,
        waiver: { ...resolution.waiver, candidateBinding: resolution.candidateBinding }
      };
    case "delegated":
      return { obligationId: resolution.obligationId, outcome: resolution.kind, ciPolicyId: resolution.ciPolicyId };
    case "not_applicable":
      return { obligationId: resolution.obligationId, outcome: resolution.kind };
    case "blocked":
      return { obligationId: resolution.obligationId, outcome: resolution.kind };
  }
}
function buildDeliveryRecord(input) {
  const { config, decision, evidenceRecords } = input;
  if (!decision.admitted) {
    return {
      ok: false,
      blockers: [drBlocker("record_gate_not_admitted", "The gate did not admit; there is nothing to record.")]
    };
  }
  const blocked4 = decision.resolutions.find((resolution) => resolution.kind === "blocked");
  if (blocked4 !== void 0) {
    return {
      ok: false,
      blockers: [
        drBlocker(
          "record_blocked_obligation",
          "The gate result carries a blocked obligation; a record would misrepresent it.",
          `obligation ${blocked4.obligationId} is blocked`
        )
      ]
    };
  }
  const evidenceByRecordId = new Map(evidenceRecords.map((record3) => [record3.recordId, record3]));
  const claims = decision.resolutions.map((resolution) => claimOf(resolution, evidenceByRecordId));
  const context = input.context;
  if (context === void 0) return { ok: false, blockers: [portableBlocker("portable_context_missing", "Recording requires current policy, wiring and compatible release inputs.")] };
  for (const claim of claims) {
    if (claim.outcome !== "satisfied_evidence") continue;
    if (claim.evidence?.resolution.kind !== "evidence" || claim.evidence.resolution.portable === void 0) {
      return { ok: false, blockers: [portableBlocker("portable_evidence_missing", "Older summary-only evidence must be acquired and submitted again before recording.")] };
    }
  }
  const distinctManifestDigests = claimedManifestDigests(claims);
  const record2 = {
    version: DELIVERY_RECORD_VERSION,
    gateId: config.gateId,
    identityToken: config.computingIdentityVersion,
    candidateBinding: bindingOf(decision.candidate),
    claims,
    manifestDigest: distinctManifestDigests.length === 1 ? distinctManifestDigests[0] : null,
    workspaceId: decision.candidate.workspaceId,
    attestation: { level: V1_ATTESTATION_LEVEL },
    context
  };
  const sealed = { ...record2, integrityDigest: digestCanonical(record2) };
  if (Buffer.byteLength(JSON.stringify(sealed)) > MAX_PORTABLE_RECORD_BYTES) return { ok: false, blockers: [portableBlocker("portable_record_oversized", "The portable record exceeds its size limit.")] };
  return { ok: true, record: sealed };
}
function deliveryRecordBytes(record2) {
  return `${canonicalize(record2)}
`;
}
var BINDING_FIELDS = [
  "treeSha",
  "deliverableDigest",
  "identityToken",
  "baseRef",
  "baseTipSha",
  "mergeBaseSha",
  "workspaceId"
];
function malformed(detail) {
  return { ok: false, blockers: [drBlocker("delivery_record_malformed", "The delivery record could not be read.", detail)] };
}
function isAttributedWaiver(value) {
  if (!isRecord7(value) || value["kind"] !== "waiver" || !["invocation", "durable"].includes(String(value["scope"]))) return false;
  for (const [field, limit] of [["author", 256], ["reason", 4096]]) {
    const text4 = value[field];
    if (typeof text4 !== "string" || !text4.trim() || text4.length > limit) return false;
  }
  const codes = value["findingCodes"];
  const candidate2 = value["candidateBinding"];
  return typeof value["policyDigest"] === "string" && /^[a-f0-9]{64}$/.test(value["policyDigest"]) && Array.isArray(codes) && codes.length > 0 && new Set(codes).size === codes.length && codes.every((code) => typeof code === "string" && /^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/.test(code)) && isRecord7(candidate2) && BINDING_FIELDS.every((field) => isNonEmptyString3(candidate2[field]));
}
function parseDeliveryRecord(text4) {
  if (Buffer.byteLength(text4) > MAX_PORTABLE_RECORD_BYTES) return malformed("the record exceeds the portable size limit");
  let parsed;
  try {
    parsed = JSON.parse(text4);
  } catch (error) {
    return malformed(`not valid JSON: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (!isRecord7(parsed)) return malformed("the record is not a JSON object");
  if (parsed["version"] !== DELIVERY_RECORD_VERSION && parsed["version"] !== "delivery-record/1") {
    return malformed(`unsupported version token ${JSON.stringify(parsed["version"])}; expected ${DELIVERY_RECORD_VERSION}`);
  }
  if (!isNonEmptyString3(parsed["gateId"])) return malformed("missing gateId");
  if (!isNonEmptyString3(parsed["identityToken"])) return malformed("missing identityToken");
  if (!isNonEmptyString3(parsed["workspaceId"])) return malformed("missing workspaceId");
  const binding = parsed["candidateBinding"];
  if (!isRecord7(binding)) return malformed("missing candidateBinding");
  for (const field of BINDING_FIELDS) {
    if (!isNonEmptyString3(binding[field])) return malformed(`candidateBinding is missing ${field}`);
  }
  const claims = parsed["claims"];
  if (!Array.isArray(claims)) return malformed("claims must be an array");
  for (const claim of claims) {
    if (!isRecord7(claim) || !isNonEmptyString3(claim["obligationId"]) || !isNonEmptyString3(claim["outcome"])) {
      return malformed("a claim is missing its obligation id or outcome");
    }
    if (!RESOLUTION_OUTCOMES.includes(claim["outcome"])) {
      return malformed(
        `claim for ${JSON.stringify(claim["obligationId"])} carries outcome ${JSON.stringify(claim["outcome"])}, which is not a resolution outcome`
      );
    }
    if (claim["outcome"] === "waived" && (!isAttributedWaiver(claim["waiver"]) || claim["scope"] !== claim["waiver"].scope)) {
      return malformed("a waived claim requires attributed, scoped approval bound to its policy and candidate");
    }
  }
  const attestation = parsed["attestation"];
  if (!isRecord7(attestation) || !isNonEmptyString3(attestation["level"])) return malformed("missing attestation.level");
  const manifestDigest2 = parsed["manifestDigest"];
  if (manifestDigest2 !== null && typeof manifestDigest2 !== "string") return malformed("manifestDigest must be a string or null");
  return { ok: true, record: parsed };
}
function selectDeliveryRecordForIdentity(records, identity) {
  const matches = records.filter(
    (entry3) => entry3.record.candidateBinding.deliverableDigest === identity.deliverableDigest && entry3.record.candidateBinding.identityToken === identity.identityToken
  ).sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
  return matches[0];
}
function pathOf(entry3) {
  return typeof entry3 === "string" ? entry3 : entry3.path;
}
function isDeliveryOwnedTreePath(repoPath) {
  const folded = repoPath.toLowerCase();
  return DELIVERY_OWNED_TREE_PREFIXES.some((prefix) => folded === prefix || folded.startsWith(`${prefix}/`));
}
function resolveTreeSymlink(fromPath, target) {
  if (target.length === 0 || target.startsWith("/")) return void 0;
  const lastSlash = fromPath.lastIndexOf("/");
  const segments = lastSlash === -1 ? [] : fromPath.slice(0, lastSlash).split("/");
  const resolved = [];
  for (const segment of segments) if (segment.length > 0 && segment !== ".") resolved.push(segment);
  for (const segment of target.split("/")) {
    if (segment.length === 0 || segment === ".") continue;
    if (segment === "..") {
      if (resolved.length === 0) return void 0;
      resolved.pop();
      continue;
    }
    resolved.push(segment);
  }
  return resolved.length === 0 ? void 0 : resolved.join("/");
}
function isAdmittedClaudeSkillExposure(entry3) {
  if (typeof entry3 === "string") return false;
  if (entry3.mode !== SYMLINK_MODE) return false;
  if (!entry3.path.startsWith(CLAUDE_SKILL_EXPOSURE_PREFIX)) return false;
  if (entry3.path.length === CLAUDE_SKILL_EXPOSURE_PREFIX.length) return false;
  if (entry3.symlinkTarget === void 0) return false;
  const resolved = resolveTreeSymlink(entry3.path, entry3.symlinkTarget);
  if (resolved === void 0) return false;
  return resolved.startsWith(RECEIPTED_SKILLS_ROOT) && resolved.length > RECEIPTED_SKILLS_ROOT.length;
}
function isDeliveryOwnedTreeEntry(entry3) {
  if (!isDeliveryOwnedTreePath(pathOf(entry3))) return false;
  return !isAdmittedClaudeSkillExposure(entry3);
}
function parseCandidateTreeListing(nulSeparated) {
  const entries = [];
  for (const line of nulSeparated.split("\0")) {
    if (line.length === 0) continue;
    const tab = line.indexOf("	");
    if (tab === -1) continue;
    const fields = line.slice(0, tab).split(" ").filter((field) => field.length > 0);
    if (fields.length < 3) continue;
    const [mode, , objectSha] = fields;
    entries.push({ path: line.slice(tab + 1), mode, objectSha });
  }
  return entries;
}
function needsCommittedSymlinkTarget(entry3) {
  return entry3.mode === SYMLINK_MODE && isDeliveryOwnedTreePath(entry3.path);
}
function verifyDeliveryRecord(config, record2, recomputedIdentity, base, options = {}) {
  const policy = config.deliveryRecordVerification.baseMovement;
  const blockers = [];
  const relaxedDriftClasses = [];
  const binding = record2.candidateBinding;
  if (record2.version !== DELIVERY_RECORD_VERSION) {
    blockers.push(drBlocker("record_version_unsupported", `The record's version ${JSON.stringify(record2.version)} is not ${DELIVERY_RECORD_VERSION}.`));
  }
  if (record2.gateId !== config.gateId) {
    blockers.push(
      drBlocker("record_gate_mismatch", `The record is for gate ${JSON.stringify(record2.gateId)}, not ${JSON.stringify(config.gateId)}.`)
    );
  }
  if (record2.attestation.level !== V1_ATTESTATION_LEVEL) {
    blockers.push(
      drBlocker(
        "record_attestation_unsupported",
        `The record declares attestation level ${JSON.stringify(record2.attestation.level)}; v1 verifies only ${JSON.stringify(V1_ATTESTATION_LEVEL)}.`
      )
    );
  }
  if (!config.identityVersions.includes(binding.identityToken)) {
    blockers.push(
      drBlocker("record_identity_token_unknown", `The record's identity token ${JSON.stringify(binding.identityToken)} is not accepted by this config.`)
    );
  }
  if (binding.deliverableDigest !== recomputedIdentity.deliverableDigest || binding.identityToken !== recomputedIdentity.identityToken) {
    blockers.push(
      drBlocker(
        "deliverable_identity_changed",
        "The record's deliverable identity does not match the recomputed identity of the head.",
        `record ${binding.deliverableDigest} (${binding.identityToken}) but head ${recomputedIdentity.deliverableDigest} (${recomputedIdentity.identityToken})`
      )
    );
  }
  const baseDrift = [];
  if (binding.baseRef !== base.ref) baseDrift.push("base_ref_changed");
  if (binding.baseTipSha !== base.tipSha) baseDrift.push("base_tip_moved");
  if (binding.mergeBaseSha !== base.mergeBaseSha) baseDrift.push("merge_base_moved");
  for (const driftClass of baseDrift) {
    if (policy === "allow") {
      relaxedDriftClasses.push(driftClass);
    } else {
      blockers.push(drBlocker(driftClass, `The base moved (${driftClass}); the record is stale under the "stale" base-movement policy.`));
    }
  }
  for (const claim of record2.claims) {
    if (claim.outcome === "blocked") {
      blockers.push(drBlocker("record_claim_blocked", `Claim for ${claim.obligationId} carries a blocked outcome; a record must not.`));
    }
    if (claim.outcome === "waived") {
      const waiver = claim.waiver;
      const obligation = config.obligations.find((entry3) => entry3.id === claim.obligationId);
      if (!isAttributedWaiver(waiver) || claim.scope !== waiver.scope || !obligation?.humanWaiverAllowed || !obligation.allowedResolutionKinds.includes("waived") || obligation.freshness === "live" && waiver.scope !== "invocation" || waiver.policyDigest !== digestCanonical(config) || BINDING_FIELDS.some((field) => waiver.candidateBinding[field] !== binding[field]) || waiver.findingCodes.some((code) => NON_WAIVABLE_INTEGRITY_CODES.includes(code) || obligation.nonWaivableCodes.includes(code) || !obligation.waivableCodes.includes(code))) {
        blockers.push(drBlocker("record_waiver_invalid", `The human exception for ${claim.obligationId} does not match its attribution, scope, policy, or candidate.`));
      }
    }
  }
  blockers.push(...verifyRecordEvidence(config, record2, options));
  for (const entry3 of options.candidateTreePaths ?? []) {
    if (!isDeliveryOwnedTreeEntry(entry3)) continue;
    blockers.push(
      drBlocker(
        "record_protected_authority_path",
        `The candidate tree carries ${JSON.stringify(pathOf(entry3))}, inside a delivery-owned projection or discovery-configuration path.`,
        `delivery-owned prefixes: ${DELIVERY_OWNED_TREE_PREFIXES.join(", ")}; the only admitted exception is a ${SYMLINK_MODE} symlink under ${CLAUDE_SKILL_EXPOSURE_PREFIX} resolving inside ${RECEIPTED_SKILLS_ROOT}`
      )
    );
  }
  const claimed = new Set(record2.claims.map((claim) => claim.obligationId));
  for (const obligation of config.obligations) {
    if (!claimed.has(obligation.id)) {
      blockers.push(
        drBlocker("obligation_uncovered", `Obligation ${JSON.stringify(obligation.id)} has no claim in the record.`)
      );
    }
  }
  return {
    ok: blockers.length === 0,
    blockers,
    baseMovement: policy,
    baseMovementRelaxed: relaxedDriftClasses.length > 0,
    relaxedDriftClasses,
    attestationLabel: ATTESTATION_LABEL,
    claims: record2.claims,
    ...options.runJournal === void 0 ? {} : { runJournal: options.runJournal }
  };
}
function verifyRecordEvidence(config, record2, options) {
  const blockers = [];
  const { integrityDigest, ...unsigned } = record2;
  if (integrityDigest !== digestCanonical(unsigned)) blockers.push(portableBlocker("portable_record_integrity", "The serialized record changed after it was built."));
  if (record2.context === void 0 || options.evidenceContext === void 0 || digestCanonical(record2.context) !== digestCanonical(options.evidenceContext)) {
    return [...blockers, portableBlocker("portable_context_mismatch", "Current policy, wiring, release and reviewer inputs must match the portable record.")];
  }
  if (options.projection === void 0 || options.executionContext === void 0) {
    return [...blockers, portableBlocker("portable_activation_missing", "Verification requires activation recomputed from the target candidate.")];
  }
  const distinctDigests = claimedManifestDigests(record2.claims);
  if (record2.manifestDigest !== (distinctDigests.length === 1 ? distinctDigests[0] : null)) blockers.push(portableBlocker("portable_manifest_summary", "The record manifest summary differs from its actual claims."));
  const records = [];
  const ids = /* @__PURE__ */ new Set();
  const b = record2.candidateBinding;
  if (record2.workspaceId !== b.workspaceId || record2.identityToken !== b.identityToken) blockers.push(portableBlocker("portable_record_binding", "The record's audit binding is internally inconsistent."));
  for (const claim of record2.claims) {
    if (ids.has(claim.obligationId)) blockers.push(portableBlocker("portable_claim_duplicate", "An obligation is claimed more than once."));
    ids.add(claim.obligationId);
    if (claim.outcome === "satisfied_live_fact") {
      const obligation = config.obligations.find((entry3) => entry3.id === claim.obligationId);
      if (obligation?.freshness !== "live" || claim.providerId === void 0 || !obligation.providers.includes(claim.providerId) || !isNonEmptyString3(claim.runId)) blockers.push(portableBlocker("portable_live_claim_invalid", "The historical live claim names no configured live provider and run."));
    }
  }
  const expandedClaims = record2.claims.flatMap((claim) => [claim, ...Array.isArray(claim.supportingEvidence) ? claim.supportingEvidence.map((evidence) => ({
    ...claim,
    evidence,
    recordId: evidence?.recordId,
    ...evidence?.resolution?.kind === "evidence" ? {
      providerId: evidence.resolution.providerId,
      runId: evidence.resolution.runId,
      finalPassId: evidence.resolution.finalPassId,
      manifestDigest: evidence.resolution.manifestDigest
    } : {}
  })) : []]);
  for (const claim of expandedClaims) {
    if (claim.outcome === "satisfied_evidence") {
      const evidence = claim.evidence;
      if (!isRecord7(evidence) || !isRecord7(evidence.resolution) || evidence.resolution.kind !== "evidence" || evidence.resolution.portable === void 0 || !isRecord7(evidence.candidateBinding)) {
        blockers.push(portableBlocker("portable_evidence_missing", "The claim carries no original accepted manifest and artifact bytes."));
        continue;
      }
      const resolution = evidence.resolution;
      const eb = evidence.candidateBinding;
      if (evidence.schemaVersion !== 1 || evidence.recordId !== computeRecordId(evidence.workspaceId, evidence) || evidence.workspaceId !== eb.workspaceId || evidence.gateId !== config.gateId || evidence.obligationId !== claim.obligationId || evidence.recordId !== claim.recordId || resolution.providerId !== claim.providerId || resolution.runId !== claim.runId || resolution.finalPassId !== claim.finalPassId || resolution.manifestDigest !== claim.manifestDigest || BINDING_FIELDS.filter((field) => field !== "treeSha").some((field) => eb[field] !== b[field])) {
        blockers.push(portableBlocker("portable_claim_binding", "The claim differs from its original accepted evidence binding."));
        continue;
      }
      blockers.push(...verifyPortableEvidence(config, resolution.portable, eb, options.evidenceContext, options.checkBindings));
      const manifest = resolution.portable.manifest;
      if (!isRecord7(manifest) || !isRecord7(manifest["provider"]) || !Array.isArray(manifest["claims"]) || resolution.manifestDigest !== manifestDigest(manifest) || manifest["provider"]["id"] !== resolution.providerId || manifest["provider"]["runId"] !== resolution.runId || manifest["provider"]["finalPassId"] !== resolution.finalPassId || !manifest["claims"].some((value) => isRecord7(value) && value["obligation"] === claim.obligationId)) {
        blockers.push(portableBlocker("portable_manifest_binding", "The accepted manifest does not substantiate this claim."));
        continue;
      }
      records.push(evidence);
    } else if (claim.outcome === "waived" && isAttributedWaiver(claim.waiver) && claim.recordId !== void 0) {
      const { candidateBinding, ...waiver } = claim.waiver;
      records.push({
        schemaVersion: 1,
        recordId: claim.recordId,
        workspaceId: b.workspaceId,
        gateId: config.gateId,
        obligationId: claim.obligationId,
        candidateBinding,
        resolution: waiver
      });
    }
  }
  if (blockers.length > 0) return blockers;
  const decision = evaluateGate({
    config,
    candidate: {
      treeSha: b.treeSha,
      deliverable: { digest: b.deliverableDigest, identity: b.identityToken },
      base: { ref: b.baseRef, tipSha: b.baseTipSha, mergeBaseSha: b.mergeBaseSha },
      workspaceId: b.workspaceId
    },
    projection: options.projection,
    context: options.executionContext,
    records,
    ...options.checkBindings === void 0 ? {} : { checkBindings: options.checkBindings },
    ...options.liveResults === void 0 ? {} : { liveResults: options.liveResults }
  });
  for (const actual of decision.resolutions) {
    const claim = record2.claims.find((entry3) => entry3.obligationId === actual.obligationId);
    if (claim?.outcome === "waived" && actual.kind === "blocked" && isAttributedWaiver(claim.waiver) && claim.waiver.scope === "durable" && actual.blockers.length > 0 && actual.blockers.every((blocker) => claim.waiver.findingCodes.includes(blocker.code))) continue;
    if (claim?.outcome !== actual.kind || actual.kind === "satisfied_evidence" && claim.recordId !== actual.recordId) {
      blockers.push(portableBlocker("portable_claim_outcome", "The actual evidence and current activation do not produce the claimed gate outcome."));
      if (actual.kind === "blocked") blockers.push(...actual.blockers);
    }
  }
  return blockers;
}

// packages/kernel/src/spine/vocabulary.ts
var JOURNALS = Object.freeze(["intake", "delivery", "maintenance"]);
var INTAKE_STATES = Object.freeze([
  "draft_scope",
  "awaiting_clarification",
  "awaiting_confirmation",
  "validating_acceptance",
  "accepted_contract",
  "blocked",
  "abandoned"
]);
var DELIVERY_STATES = Object.freeze([
  "accepted",
  "preparing",
  "planning",
  "implementing",
  "validating",
  "remediating",
  "reviewing",
  "compounding",
  "admitting",
  "recording",
  "ready",
  "awaiting_approval",
  "acting",
  "completed",
  "blocked",
  "security_blocked",
  "cancellation_requested",
  "action_succeeded_verification_failed",
  "cancelled",
  "failed"
]);
var SUSPENDED_DELIVERY_STATES = Object.freeze([
  "blocked",
  "security_blocked",
  "cancellation_requested",
  "awaiting_approval",
  "action_succeeded_verification_failed"
]);
var TERMINAL_DELIVERY_STATES = Object.freeze(["completed", "cancelled", "failed"]);
var HOST_ACTIVITY_STATES = Object.freeze(["active", "paused", "unknown", "cancellation_pending"]);
var entry = (journal, kind, status, observationOnly = false, owner) => Object.freeze({ journal, kind, status, observationOnly, ...owner === void 0 ? {} : { owner } });
var EVENT_VOCABULARY = Object.freeze([
  // Intake journal — active.
  entry("intake", "intake.state.changed", "active"),
  entry("intake", "operator.confirmation.recorded", "active"),
  // Delivery journal — active.
  entry("delivery", "delivery.registered", "active"),
  entry("delivery", "workspace.bound", "active"),
  entry("delivery", "invocation.fenced", "active"),
  entry("delivery", "activity.observed", "active", true),
  entry("delivery", "operator.confirmation.recorded", "active"),
  entry("delivery", "approval.request.recorded", "active"),
  entry("delivery", "operation.result.recorded", "active"),
  entry("delivery", "workspace.disposition.recorded", "active"),
  entry("delivery", "transition.committed", "active"),
  entry("delivery", "stage.result.recorded", "active"),
  entry("delivery", "attempt.artifact.recorded", "active"),
  entry("delivery", "evidence.reference.recorded", "active"),
  entry("delivery", "candidate.recaptured", "active"),
  entry("delivery", "policy.snapshot.bound", "active"),
  entry("delivery", "generation.pinned", "active"),
  entry("delivery", "trust.epoch.observed", "active", true),
  entry("delivery", "blocker.recorded", "active"),
  entry("delivery", "finish.line.recorded", "active"),
  // Defined by the composition-lifecycle unit out of reservation — the
  // sanctioned per-tranche path: the pair was enumerated with this owner from
  // the start, and its payload is now frozen in `journal.ts`.
  entry("delivery", "approval.assertion.consumed", "active"),
  entry("maintenance", "maintenance.action.recorded", "active"),
  // The retention/export/deletion family is likewise defined by its owning
  // unit out of reservation: export and deletion operations journal here so
  // their records survive the target delivery's removal; its payload is
  // frozen in `journal.ts`.
  entry("maintenance", "retention.action.recorded", "active"),
  // Defined by the iterative-intake unit out of reservation — the sanctioned
  // per-tranche path: both pairs were enumerated with that owner from the
  // start, and their payloads (clarification history, draft retention) are
  // now frozen in `journal.ts`.
  entry("intake", "intake.clarification.recorded", "active"),
  entry("intake", "intake.draft.recorded", "active"),
  // Defined by the trusted host lifecycle integration out of reservation —
  // the sanctioned per-tranche path: the pair was enumerated with this owner
  // from the start, and its payload is now frozen in `journal.ts`. It is
  // explicitly distinct from `activity.observed`: a termination record is a
  // durable fact about the PRIOR invocation, so it advances the expected
  // journal revision and is not part of the observation-only exemption.
  entry("delivery", "termination.provenance.recorded", "active"),
  // Defined by the amendment/waiver admission unit out of reservation — the
  // sanctioned per-tranche path: the pair was enumerated with this owner from
  // the start, and its payload is now frozen in `journal.ts`. It records a
  // confirmed outcome amendment, which creates a NEW contract identity; the
  // full re-evaluation it forces is an ordinary transition beside it.
  entry("delivery", "contract.amended", "active"),
  // Defined by the merge-ready finish-line unit out of reservation — the
  // sanctioned per-tranche path: both pairs were enumerated with this owner
  // from the start, and their payloads (the durable intent recorded before an
  // external action, and the observed result recorded after it) are now frozen
  // in `journal.ts`. The external-actions unit extends them; it adds no pair.
  entry("delivery", "action.intent.recorded", "active"),
  entry("delivery", "action.result.recorded", "active"),
  // Reserved — payloads belong to their owning units; reject until defined.
  entry("delivery", "control.plane.mirror.recorded", "reserved", true, "control-plane coordination")
]);
var OBSERVATION_ONLY_KINDS = Object.freeze([
  "activity.observed",
  "trust.epoch.observed",
  "control.plane.mirror.recorded"
]);
function classifyEventKind(journal, kind) {
  const match = EVENT_VOCABULARY.find((candidate2) => candidate2.journal === journal && candidate2.kind === kind);
  if (match !== void 0) {
    return match.status === "active" ? { status: "active", observationOnly: match.observationOnly } : { status: "reserved" };
  }
  const knownIn = EVENT_VOCABULARY.filter((candidate2) => candidate2.kind === kind).map(
    (candidate2) => candidate2.journal
  );
  return { status: "unknown", knownIn };
}

// packages/kernel/src/spine/grammar.ts
function createSpineCollector() {
  const rejections = [];
  return {
    emit(code, pointer2, message) {
      rejections.push({ code, pointer: pointer2, message });
    },
    verdict() {
      return rejections.length === 0 ? { ok: true } : { ok: false, rejections };
    }
  };
}
function spinePointer(base, ...segments) {
  let result2 = base;
  for (const segment of segments) {
    const token = typeof segment === "number" ? String(segment) : segment.replaceAll("~", "~0").replaceAll("/", "~1");
    result2 += `/${token}`;
  }
  return result2;
}
var SPINE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
var SPINE_SHA256 = /^[0-9a-f]{64}$/;
var SPINE_GIT_OID = /^[0-9a-f]{40}$/;
var SPINE_INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;
var ABSENT_BY_STATE = "absent-by-state";
var MAX_FREE_TEXT = 2e3;
function isSpineRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function checkClosed2(value, at, rules, collector) {
  if (!isSpineRecord(value)) {
    collector.emit("not_an_object", at, "expected a JSON object");
    return void 0;
  }
  const defined = new Set(rules.map((rule) => rule.name));
  for (const name of Object.keys(value)) {
    if (!defined.has(name)) {
      collector.emit("unknown_member", spinePointer(at, name), "member is not defined by this frozen grammar");
    }
  }
  for (const rule of rules) {
    if (!Object.prototype.hasOwnProperty.call(value, rule.name) || value[rule.name] === void 0) {
      if (rule.required !== false) collector.emit("missing_member", spinePointer(at, rule.name), "required member is absent");
      continue;
    }
    rule.check(value[rule.name], spinePointer(at, rule.name), collector);
  }
  return value;
}
var malformed2 = (collector, at, message) => {
  collector.emit("malformed_member", at, message);
};
var isNonEmptyText = (value) => typeof value === "string" && value.length > 0;
var text = (value, at, collector) => {
  if (!isNonEmptyText(value)) malformed2(collector, at, "expected a non-empty string");
};
var boundedText = (value, at, collector) => {
  if (!isNonEmptyText(value) || value.length > MAX_FREE_TEXT) {
    malformed2(collector, at, `expected a non-empty string of at most ${MAX_FREE_TEXT} characters`);
  }
};
var spineId = (value, at, collector) => {
  if (typeof value !== "string" || !SPINE_ID.test(value)) {
    malformed2(collector, at, "expected a stable identity matching the spine id grammar");
  }
};
var sha256 = (value, at, collector) => {
  if (typeof value !== "string" || !SPINE_SHA256.test(value)) {
    malformed2(collector, at, "expected a lowercase-hex sha256 digest");
  }
};
var gitOid = (value, at, collector) => {
  if (typeof value !== "string" || !SPINE_GIT_OID.test(value)) {
    malformed2(collector, at, "expected a lowercase 40-hex git object id");
  }
};
var instant = (value, at, collector) => {
  if (typeof value !== "string" || !SPINE_INSTANT.test(value)) {
    malformed2(collector, at, "expected a UTC instant of the form YYYY-MM-DDTHH:MM:SSZ");
  }
};
var nonNegativeInt = (value, at, collector) => {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) {
    malformed2(collector, at, "expected a non-negative safe integer");
  }
};
var positiveInt = (value, at, collector) => {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1) {
    malformed2(collector, at, "expected a positive safe integer");
  }
};
var literal = (expected) => (value, at, collector) => {
  if (value !== expected) malformed2(collector, at, `expected exactly ${JSON.stringify(expected)}`);
};
var specLiteral = (expected) => (value, at, collector) => {
  if (value !== expected) {
    collector.emit("unsupported_spec", at, `unsupported spec token ${JSON.stringify(value)}; this grammar freezes ${JSON.stringify(expected)}`);
  }
};
var oneOf = (allowed) => (value, at, collector) => {
  if (typeof value !== "string" || !allowed.includes(value)) {
    malformed2(collector, at, `expected one of ${allowed.join(", ")}`);
  }
};
var stringArray = (options = {}) => (value, at, collector) => {
  if (!Array.isArray(value)) {
    malformed2(collector, at, "expected an array");
    return;
  }
  if (value.length < (options.minItems ?? 0)) {
    malformed2(collector, at, `expected at least ${options.minItems} entries`);
    return;
  }
  const seen = /* @__PURE__ */ new Set();
  value.forEach((entry3, index) => {
    const itemAt = spinePointer(at, index);
    if (typeof entry3 !== "string" || entry3.length === 0) {
      malformed2(collector, itemAt, "expected a non-empty string");
      return;
    }
    if (seen.has(entry3)) {
      malformed2(collector, itemAt, "duplicate entry");
      return;
    }
    seen.add(entry3);
    options.item?.(entry3, itemAt, collector);
  });
};
var closed = (rules) => (value, at, collector) => {
  checkClosed2(value, at, rules, collector);
};
var closedArray = (rules, options = {}) => (value, at, collector) => {
  if (!Array.isArray(value)) {
    malformed2(collector, at, "expected an array");
    return;
  }
  if (value.length < (options.minItems ?? 0)) {
    malformed2(collector, at, `expected at least ${options.minItems} entries`);
    return;
  }
  value.forEach((entry3, index) => {
    checkClosed2(entry3, spinePointer(at, index), rules, collector);
  });
};
var orAbsentByState = (check) => (value, at, collector) => {
  if (value === ABSENT_BY_STATE) return;
  check(value, at, collector);
};
var isAbsentByState = (value) => value === ABSENT_BY_STATE;

// packages/kernel/src/spine/composition.ts
var PRODUCT_COMPOSITION_PIN_SPEC = "product-composition-pin/1";
var PRODUCT_TRUST_STATE_SPEC = "product-trust-state/1";
var PRODUCT_TRUST_LABEL = "local-digest / operator-pinned";
var PINNED_AGENT_SKILLS = Object.freeze({
  releaseId: "core-v1",
  profile: "core",
  archiveSha256: "9ce12f12c4096e346154ef377fc89187c9168944d6e59b9d6596feb98e57d2ed",
  metadataSha256: "b2b008cb5a87f2bd83696cb43e908badb305b750a0b013a8c89d118bf16f9007",
  workflowGraphSha256: "49630e23374f0375cb7d019ea024bcd5ea0c284feb8dc124b393b60f6e8d9aa7",
  provenanceLockSha256: "0872fab0e891c7304f5c6ab9c19298902b386935d69f9296e28106c730192bfa",
  protocolVersion: "delivery-provider-rails/1"
});
var versionMap = (value, at, collector) => {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    collector.emit("malformed_member", at, "expected an object of module versions");
    return;
  }
  const entries = Object.entries(value);
  if (entries.length === 0) {
    collector.emit("malformed_member", at, "expected at least one module version");
    return;
  }
  for (const [name, version] of entries) {
    if (typeof version !== "string" || version.length === 0) {
      collector.emit("malformed_member", `${at}/${name.replaceAll("~", "~0").replaceAll("/", "~1")}`, "expected a non-empty version string");
    }
  }
};
var SKILLS_ARCHIVE_RULES = [
  { name: "releaseId", check: spineId },
  { name: "profile", check: text },
  { name: "archiveSha256", check: sha256 },
  { name: "metadataSha256", check: sha256 },
  { name: "workflowGraphSha256", check: sha256 },
  { name: "provenanceLockSha256", check: sha256 },
  { name: "protocolVersion", check: text }
];
var CONTRACT_VERSION_RULES = [
  { name: "policy", check: text },
  { name: "scopedWork", check: text },
  { name: "run", check: text },
  { name: "workflowResult", check: text },
  { name: "event", check: text },
  { name: "controlPlane", check: text }
];
var COMPOSITION_PIN_RULES = [
  { name: "spec", check: specLiteral(PRODUCT_COMPOSITION_PIN_SPEC) },
  { name: "productVersion", check: text },
  { name: "distributionDigest", check: sha256 },
  { name: "harnessModuleVersions", check: versionMap },
  { name: "skillsArchive", check: closed(SKILLS_ARCHIVE_RULES) },
  { name: "contractVersions", check: closed(CONTRACT_VERSION_RULES) },
  { name: "productTrustLabel", check: literal(PRODUCT_TRUST_LABEL) }
];
function validateCompositionPin(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", COMPOSITION_PIN_RULES, collector);
  return collector.verdict();
}
var TRUST_STATE_RULES = [
  { name: "spec", check: specLiteral(PRODUCT_TRUST_STATE_SPEC) },
  { name: "installationId", check: spineId },
  { name: "pinnedManifestDigest", check: sha256 },
  { name: "acceptedGenerationDigests", check: stringArray({ item: sha256 }) },
  { name: "revokedGenerationDigests", check: stringArray({ item: sha256 }) },
  { name: "revocationEpoch", check: nonNegativeInt },
  { name: "highWaterMark", check: nonNegativeInt }
];
function validateProductTrustState(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", TRUST_STATE_RULES, collector);
  return collector.verdict();
}
var localDigestTrustPredicate = {
  evaluate(generationDigest, state) {
    if (state.revokedGenerationDigests.includes(generationDigest)) {
      return { eligible: false, reason: "revoked" };
    }
    if (generationDigest !== state.pinnedManifestDigest && !state.acceptedGenerationDigests.includes(generationDigest)) {
      return { eligible: false, reason: "not_pinned" };
    }
    return { eligible: true };
  }
};

// packages/kernel/src/spine/contract.ts
var SCOPED_DELIVERY_CONTRACT_SPEC = "scoped-delivery-contract/1";
var OUTCOME_VERIFICATION_SPEC = "outcome-verification/1";
var FINISH_LINES = Object.freeze(["merge-ready", "merge", "deploy"]);
var CRITERION_DISPOSITIONS = Object.freeze(["passed", "amended-waived", "blocked"]);
var EVIDENCE_KINDS = Object.freeze(["sensor", "artifact", "review", "operation"]);
var REVIEW_VERDICTS = Object.freeze(["approved", "findings"]);
var CRITERION_RULES = [
  { name: "criterionId", check: spineId },
  { name: "statement", check: text }
];
var CONTRACT_RULES = [
  { name: "spec", check: specLiteral(SCOPED_DELIVERY_CONTRACT_SPEC) },
  { name: "contractId", check: spineId },
  { name: "task", check: text },
  { name: "intendedOutcome", check: text },
  { name: "acceptanceCriteria", check: closedArray(CRITERION_RULES, { minItems: 1 }) },
  { name: "nonGoals", check: stringArray() },
  {
    name: "repository",
    check: closed([
      { name: "repositoryId", check: spineId },
      { name: "baseRef", check: text }
    ])
  },
  { name: "requestedFinishLine", check: oneOf(FINISH_LINES) },
  { name: "requestedAuthority", check: stringArray() },
  { name: "unresolvedDecisions", check: stringArray() }
];
function validateAcceptedContract(value) {
  const collector = createSpineCollector();
  const record2 = checkClosed2(value, "", CONTRACT_RULES, collector);
  if (record2 !== void 0) {
    const unresolved2 = record2["unresolvedDecisions"];
    if (Array.isArray(unresolved2) && unresolved2.length > 0) {
      collector.emit(
        "unsupported_combination",
        "/unresolvedDecisions",
        "an accepted contract cannot carry unresolved decisions; material ambiguity remains in intake"
      );
    }
    const criteria = record2["acceptanceCriteria"];
    if (Array.isArray(criteria)) {
      const seen = /* @__PURE__ */ new Set();
      criteria.forEach((criterion, index) => {
        if (!isSpineRecord(criterion) || typeof criterion["criterionId"] !== "string") return;
        if (seen.has(criterion["criterionId"])) {
          collector.emit("malformed_member", spinePointer("/acceptanceCriteria", index, "criterionId"), "duplicate criterion id");
        }
        seen.add(criterion["criterionId"]);
      });
    }
  }
  return collector.verdict();
}
var OUTCOME_CRITERION_RULES = [
  { name: "criterionId", check: spineId },
  { name: "disposition", check: oneOf(CRITERION_DISPOSITIONS) },
  {
    name: "evidence",
    check: closed([
      { name: "kind", check: oneOf(EVIDENCE_KINDS) },
      { name: "reference", check: text }
    ])
  }
];
var REVIEW_ATTEMPT_RULES = [
  { name: "attemptId", check: spineId },
  { name: "lensId", check: spineId },
  { name: "contextDigest", check: sha256 },
  { name: "personaDigest", check: sha256 },
  { name: "verdict", check: oneOf(REVIEW_VERDICTS) }
];
var OUTCOME_RULES = [
  { name: "spec", check: specLiteral(OUTCOME_VERIFICATION_SPEC) },
  { name: "contractId", check: spineId },
  {
    name: "candidate",
    check: closed([
      { name: "treeSha", check: gitOid },
      { name: "deliverableDigest", check: sha256 }
    ])
  },
  { name: "criteria", check: closedArray(OUTCOME_CRITERION_RULES, { minItems: 1 }) },
  { name: "reviewAttempts", check: closedArray(REVIEW_ATTEMPT_RULES) }
];
function validateOutcomeVerification(value) {
  const collector = createSpineCollector();
  const record2 = checkClosed2(value, "", OUTCOME_RULES, collector);
  if (record2 !== void 0) {
    const attempts = record2["reviewAttempts"];
    if (Array.isArray(attempts)) {
      if (attempts.length === 0) {
        collector.emit("zero_review_attempts", "/reviewAttempts", "at least one completed review attempt is required");
      }
      const seen = /* @__PURE__ */ new Set();
      attempts.forEach((attempt, index) => {
        if (!isSpineRecord(attempt) || typeof attempt["attemptId"] !== "string") return;
        if (seen.has(attempt["attemptId"])) {
          collector.emit(
            "duplicate_review_attempt",
            spinePointer("/reviewAttempts", index, "attemptId"),
            "review attempts must complete under distinct attempt identities"
          );
        }
        seen.add(attempt["attemptId"]);
      });
    }
  }
  return collector.verdict();
}
function checkOutcomeCoversContract(outcome, contract2) {
  const collector = createSpineCollector();
  const verified = new Set(outcome.criteria.map((criterion) => criterion.criterionId));
  contract2.acceptanceCriteria.forEach((criterion, index) => {
    if (!verified.has(criterion.criterionId)) {
      collector.emit(
        "criterion_unverified",
        spinePointer("/acceptanceCriteria", index, "criterionId"),
        `criterion ${criterion.criterionId} carries no disposition in the outcome verification`
      );
    }
  });
  const named = new Set(contract2.acceptanceCriteria.map((criterion) => criterion.criterionId));
  outcome.criteria.forEach((criterion, index) => {
    if (!named.has(criterion.criterionId)) {
      collector.emit(
        "criterion_unverified",
        spinePointer("/criteria", index, "criterionId"),
        `criterion ${criterion.criterionId} is not an acceptance criterion of the contract`
      );
    }
  });
  return collector.verdict();
}
function checkContractWithinPolicy(contract2, policy) {
  const collector = createSpineCollector();
  if (!policy.grantedFinishLines.includes(contract2.requestedFinishLine)) {
    collector.emit(
      "authority_not_granted",
      "/requestedFinishLine",
      `finish line ${contract2.requestedFinishLine} is not granted by the compiled policy`
    );
  }
  contract2.requestedAuthority.forEach((authority, index) => {
    if (!policy.grantedAuthority.includes(authority)) {
      collector.emit(
        "authority_not_granted",
        spinePointer("/requestedAuthority", index),
        `authority ${authority} is not granted by the compiled policy; absence of a grant is denial`
      );
    }
  });
  return collector.verdict();
}

// packages/kernel/src/spine/policy.ts
var POLICY_SNAPSHOT_SPEC = "policy-snapshot/1";
var REVIEW_LENS_CATEGORIES = Object.freeze(["outcome-correctness", "testing-policy", "additional"]);
var LENS_RULES = [
  { name: "lensId", check: spineId },
  { name: "category", check: oneOf(REVIEW_LENS_CATEGORIES) },
  { name: "personaId", check: spineId },
  { name: "personaDigest", check: sha256 }
];
var OBLIGATION_RULES = [{ name: "obligationId", check: spineId }];
var SNAPSHOT_RULES = [
  { name: "spec", check: specLiteral(POLICY_SNAPSHOT_SPEC) },
  { name: "policyDigest", check: sha256 },
  { name: "repositoryId", check: spineId },
  { name: "productTrustRevocationEpoch", check: nonNegativeInt },
  { name: "repositoryAuthorityRevocationEpoch", check: nonNegativeInt },
  { name: "grantedFinishLines", check: stringArray({ minItems: 1, item: oneOf(FINISH_LINES) }) },
  { name: "grantedAuthority", check: stringArray() },
  { name: "reviewLenses", check: closedArray(LENS_RULES) },
  { name: "obligations", check: closedArray(OBLIGATION_RULES) }
];
function validatePolicySnapshot(value) {
  const collector = createSpineCollector();
  const record2 = checkClosed2(value, "", SNAPSHOT_RULES, collector);
  if (record2 !== void 0) {
    const lenses = record2["reviewLenses"];
    if (Array.isArray(lenses) && lenses.length === 0) {
      collector.emit(
        "vacuous_policy",
        "/reviewLenses",
        "a policy activating zero review lenses is rejected at compilation; reviewing cannot be passed by absence"
      );
    }
    const declaredDigest = record2["policyDigest"];
    if (typeof declaredDigest === "string") {
      const { policyDigest: _declared, ...body } = record2;
      let computed;
      try {
        computed = digestCanonical(body);
      } catch {
        computed = void 0;
      }
      if (computed !== void 0 && computed !== declaredDigest) {
        collector.emit(
          "digest_mismatch",
          "/policyDigest",
          "the declared policy digest does not recompute from the snapshot's own members"
        );
      }
    }
  }
  return collector.verdict();
}

// packages/kernel/src/spine/invocation.ts
var INVOCATION_FENCE_SPEC = "invocation-fence/1";
var REVIEWER_ATTEMPT_SPEC = "reviewer-attempt/1";
var FENCE_RULES = [
  { name: "spec", check: specLiteral(INVOCATION_FENCE_SPEC) },
  { name: "deliveryId", check: spineId },
  { name: "fence", check: positiveInt },
  { name: "expectedJournalRevision", check: nonNegativeInt },
  { name: "hostTaskId", check: spineId },
  { name: "worktreeId", check: spineId },
  {
    name: "candidate",
    check: closed([
      { name: "treeSha", check: gitOid },
      { name: "branchRef", check: text },
      { name: "branchRefValue", check: gitOid }
    ])
  },
  { name: "policyDigest", check: sha256 },
  { name: "authorityEpoch", check: nonNegativeInt },
  { name: "observationLifetimeSeconds", check: positiveInt }
];
function validateInvocationFence(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", FENCE_RULES, collector);
  return collector.verdict();
}
var ATTEMPT_RULES = [
  { name: "spec", check: specLiteral(REVIEWER_ATTEMPT_SPEC) },
  { name: "attemptId", check: spineId },
  { name: "deliveryId", check: spineId },
  { name: "lensId", check: spineId },
  { name: "contextDigest", check: sha256 },
  { name: "personaDigest", check: sha256 },
  { name: "verdict", check: oneOf(REVIEW_VERDICTS) }
];
function validateReviewerAttempt(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", ATTEMPT_RULES, collector);
  return collector.verdict();
}

// packages/kernel/src/spine/grant.ts
var EXECUTION_GRANT_SPEC = "execution-grant/1";
var GRANT_ATTESTATION_SPEC = "grant-attestation/1";
var GRANT_PROFILES = Object.freeze(["checkpoint", "intake"]);
var GRANT_RULES = [
  { name: "spec", check: specLiteral(EXECUTION_GRANT_SPEC) },
  { name: "profile", check: oneOf(GRANT_PROFILES) },
  { name: "allowedCapabilities", check: stringArray() },
  { name: "writablePaths", check: stringArray() },
  { name: "protectedPaths", check: stringArray() },
  { name: "forbiddenOperations", check: stringArray() }
];
function validateExecutionGrant(value) {
  const collector = createSpineCollector();
  const record2 = checkClosed2(value, "", GRANT_RULES, collector);
  if (record2 !== void 0 && record2["profile"] === "intake") {
    const writable = record2["writablePaths"];
    if (Array.isArray(writable) && writable.length > 0) {
      collector.emit(
        "unsupported_combination",
        "/writablePaths",
        "the intake grant is read-only; an intake profile with writable paths is not a supported combination"
      );
    }
  }
  return collector.verdict();
}
function grantDigest(grant) {
  return digestCanonical(grant);
}
var DELIVERY_SCOPED_MEMBERS = Object.freeze([
  "deliveryId",
  "invocationFence",
  "workspaceId",
  "projectionDigest",
  "discoveryConfigurationDigest",
  "registeringInstallationId",
  "activeProfile"
]);
var ATTESTATION_RULES = [
  { name: "spec", check: specLiteral(GRANT_ATTESTATION_SPEC) },
  { name: "profile", check: oneOf(GRANT_PROFILES) },
  { name: "hostVersion", check: text },
  { name: "grantDigest", check: sha256 },
  { name: "productTrustRevocationEpoch", check: nonNegativeInt },
  { name: "expiry", check: instant },
  { name: "intakeDraftId", check: orAbsentByState(spineId) },
  { name: "deliveryId", check: orAbsentByState(spineId) },
  { name: "invocationFence", check: orAbsentByState(positiveInt) },
  { name: "workspaceId", check: orAbsentByState(spineId) },
  { name: "projectionDigest", check: orAbsentByState(sha256) },
  { name: "discoveryConfigurationDigest", check: orAbsentByState(sha256) },
  { name: "registeringInstallationId", check: orAbsentByState(spineId) },
  { name: "activeProfile", check: orAbsentByState(text) }
];
var requireReal = (record2, name, collector) => {
  if (isAbsentByState(record2[name])) {
    collector.emit(
      "unsupported_combination",
      spinePointer("", name),
      `this profile binds ${name} for real; ${JSON.stringify(ABSENT_BY_STATE)} is not a supported combination here`
    );
  }
};
var requireAbsent = (record2, name, collector) => {
  if (record2[name] !== void 0 && !isAbsentByState(record2[name])) {
    collector.emit(
      "unsupported_combination",
      spinePointer("", name),
      `this profile records ${name} explicitly ${JSON.stringify(ABSENT_BY_STATE)}; a populated value is not a supported combination`
    );
  }
};
function validateGrantAttestation(value) {
  const collector = createSpineCollector();
  const record2 = checkClosed2(value, "", ATTESTATION_RULES, collector);
  if (record2 !== void 0) {
    if (record2["profile"] === "checkpoint") {
      requireAbsent(record2, "intakeDraftId", collector);
      for (const member2 of DELIVERY_SCOPED_MEMBERS) requireReal(record2, member2, collector);
    }
    if (record2["profile"] === "intake") {
      requireReal(record2, "intakeDraftId", collector);
      for (const member2 of DELIVERY_SCOPED_MEMBERS) requireAbsent(record2, member2, collector);
    }
  }
  return collector.verdict();
}

// packages/kernel/src/spine/confirmation.ts
var OPERATOR_CONFIRMATION_SPEC = "operator-confirmation/1";
var CONFIRMATION_CLASSES = Object.freeze(["contract-confirmation", "takeover-authorization"]);
var CONFIRMATION_RULES = [
  { name: "spec", check: specLiteral(OPERATOR_CONFIRMATION_SPEC) },
  { name: "confirmationClass", check: oneOf(CONFIRMATION_CLASSES) },
  { name: "origin", check: text },
  { name: "action", check: text },
  { name: "expiry", check: instant },
  { name: "nonce", check: spineId },
  { name: "productTrustRevocationEpoch", check: nonNegativeInt },
  { name: "repositoryAuthorityRevocationEpoch", check: orAbsentByState(nonNegativeInt) },
  { name: "intakeDraftId", check: orAbsentByState(spineId) },
  { name: "deliveryId", check: orAbsentByState(spineId) },
  { name: "normalizedContractDigest", check: orAbsentByState(sha256) },
  { name: "supersededInvocationFence", check: orAbsentByState(positiveInt) },
  { name: "expectedJournalRevision", check: orAbsentByState(nonNegativeInt) },
  { name: "targetBaseCommit", check: orAbsentByState(gitOid) },
  { name: "boundInvocationFence", check: orAbsentByState(positiveInt) },
  { name: "boundCandidateTreeSha", check: orAbsentByState(gitOid) }
];
var requireReal2 = (record2, name, collector) => {
  if (isAbsentByState(record2[name])) {
    collector.emit(
      "unsupported_combination",
      spinePointer("", name),
      `this confirmation class binds ${name} for real; "absent-by-state" is not a supported combination here`
    );
  }
};
var requireAbsent2 = (record2, name, collector) => {
  if (record2[name] !== void 0 && !isAbsentByState(record2[name])) {
    collector.emit(
      "unsupported_combination",
      spinePointer("", name),
      `this confirmation class records ${name} explicitly "absent-by-state"; a populated value is not a supported combination`
    );
  }
};
function validateOperatorConfirmation(value) {
  const collector = createSpineCollector();
  const record2 = checkClosed2(value, "", CONFIRMATION_RULES, collector);
  if (record2 !== void 0) {
    requireAbsent2(record2, "boundInvocationFence", collector);
    requireAbsent2(record2, "boundCandidateTreeSha", collector);
    if (record2["confirmationClass"] === "contract-confirmation") {
      requireReal2(record2, "intakeDraftId", collector);
      requireReal2(record2, "normalizedContractDigest", collector);
      requireAbsent2(record2, "deliveryId", collector);
      requireAbsent2(record2, "supersededInvocationFence", collector);
      requireAbsent2(record2, "expectedJournalRevision", collector);
      requireAbsent2(record2, "targetBaseCommit", collector);
      requireAbsent2(record2, "repositoryAuthorityRevocationEpoch", collector);
    }
    if (record2["confirmationClass"] === "takeover-authorization") {
      requireReal2(record2, "deliveryId", collector);
      requireReal2(record2, "supersededInvocationFence", collector);
      requireReal2(record2, "expectedJournalRevision", collector);
      requireReal2(record2, "targetBaseCommit", collector);
      requireReal2(record2, "repositoryAuthorityRevocationEpoch", collector);
      requireAbsent2(record2, "intakeDraftId", collector);
      requireAbsent2(record2, "normalizedContractDigest", collector);
    }
  }
  return collector.verdict();
}
function confirmationClassOf(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return void 0;
  const declared = value["confirmationClass"];
  return CONFIRMATION_CLASSES.includes(declared) ? declared : void 0;
}

// packages/kernel/src/spine/capability.ts
var CAPABILITY_DESCRIPTOR_SPEC = "capability-descriptor/1";
var SENSOR_RESULT_SPEC = "sensor-result/1";
var CAPABILITY_KINDS = Object.freeze(["sensor"]);
var SENSOR_OUTCOMES = Object.freeze(["passed", "failed"]);
var DESCRIPTOR_RULES = [
  { name: "spec", check: specLiteral(CAPABILITY_DESCRIPTOR_SPEC) },
  { name: "capabilityId", check: spineId },
  { name: "kind", check: oneOf(CAPABILITY_KINDS) },
  { name: "version", check: text },
  { name: "resultSpec", check: literal(SENSOR_RESULT_SPEC) }
];
function validateCapabilityDescriptor(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", DESCRIPTOR_RULES, collector);
  return collector.verdict();
}
var RESULT_RULES = [
  { name: "spec", check: specLiteral(SENSOR_RESULT_SPEC) },
  { name: "capabilityId", check: spineId },
  { name: "outcome", check: oneOf(SENSOR_OUTCOMES) },
  { name: "summary", check: boundedText },
  { name: "candidateTreeSha", check: gitOid }
];
function validateSensorResult(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", RESULT_RULES, collector);
  return collector.verdict();
}

// packages/kernel/src/binding/host-admission.ts
var ADMISSION_DENIAL_CODES = Object.freeze([
  "missing_grant",
  "missing_attestation",
  "malformed_grant",
  "malformed_attestation",
  "malformed_expectation",
  "empty_grant",
  "profile_mismatch",
  "host_version_mismatch",
  "grant_digest_mismatch",
  "trust_epoch_mismatch",
  "attestation_expired",
  "fence_mismatch",
  "delivery_mismatch",
  "workspace_mismatch",
  "projection_digest_mismatch",
  "discovery_configuration_mismatch",
  "installation_mismatch",
  "active_profile_mismatch",
  "intake_draft_mismatch"
]);
var TOOL_DENIAL_CODES = Object.freeze([
  "not_admitted",
  "confirmation_operation_excluded",
  "capability_not_granted",
  "operation_forbidden",
  "unnormalized_path",
  "protected_path",
  "write_outside_grant"
]);
var CONFIRMATION_DENIAL_CODES = Object.freeze([
  "channel_closed",
  "wrong_channel",
  "non_interactive_refused",
  "model_visible_surface_refused",
  "challenge_mismatch",
  "challenge_consumed",
  "challenge_expired"
]);
var deny = (code, message) => ({ code, message });
var bound = (attested, expected) => !isAbsentByState(attested) && attested === expected;
function evaluateHostAdmission(expectation, grant, attestation) {
  const denials = [];
  if (!isSpineRecord(expectation) || !GRANT_PROFILES.includes(expectation.profile) || !SPINE_INSTANT.test(expectation.observedAt ?? "")) {
    return { admitted: false, denials: [deny("malformed_expectation", "the binding's own expectation is not well-formed; nothing can be admitted against it")] };
  }
  if (grant === void 0 || grant === null) {
    return { admitted: false, denials: [deny("missing_grant", "no execution grant was presented")] };
  }
  if (attestation === void 0 || attestation === null) {
    return { admitted: false, denials: [deny("missing_attestation", "no grant attestation was presented; tools stay closed until one is")] };
  }
  const grantVerdict = validateExecutionGrant(grant);
  if (!grantVerdict.ok) {
    return {
      admitted: false,
      denials: grantVerdict.rejections.map((r) => deny("malformed_grant", `${r.pointer || "/"}: ${r.message}`))
    };
  }
  const attVerdict = validateGrantAttestation(attestation);
  if (!attVerdict.ok) {
    return {
      admitted: false,
      denials: attVerdict.rejections.map((r) => deny("malformed_attestation", `${r.pointer || "/"}: ${r.message}`))
    };
  }
  const g = grant;
  const a = attestation;
  let presentedDigest;
  try {
    presentedDigest = grantDigest(g);
  } catch {
    return { admitted: false, denials: [deny("malformed_grant", "the presented grant cannot be canonically digested")] };
  }
  if (a["grantDigest"] !== presentedDigest) {
    denials.push(deny("grant_digest_mismatch", "the attestation does not bind the presented grant bytes"));
  }
  if (g["profile"] !== expectation.profile || a["profile"] !== expectation.profile) {
    denials.push(deny("profile_mismatch", `expected the ${expectation.profile} profile on both grant and attestation`));
  }
  if (a["hostVersion"] !== expectation.hostVersion) {
    denials.push(deny("host_version_mismatch", "the attestation was minted by a different host version"));
  }
  if (a["productTrustRevocationEpoch"] !== expectation.productTrustRevocationEpoch) {
    denials.push(deny("trust_epoch_mismatch", "the attestation's product-trust revocation epoch is not the current epoch"));
  }
  if (typeof a["expiry"] !== "string" || a["expiry"] <= expectation.observedAt) {
    denials.push(deny("attestation_expired", "the attestation has expired at the caller's observation instant"));
  }
  if (expectation.profile === "checkpoint") {
    if (!bound(a["deliveryId"], expectation.deliveryId)) {
      denials.push(deny("delivery_mismatch", "the attestation is bound to a different delivery"));
    }
    if (!bound(a["invocationFence"], expectation.invocationFence)) {
      denials.push(deny("fence_mismatch", "the attestation is not bound to the current invocation fence"));
    }
    if (!bound(a["workspaceId"], expectation.workspaceId)) {
      denials.push(deny("workspace_mismatch", "the attestation is bound to a different workspace"));
    }
    if (!bound(a["projectionDigest"], expectation.projectionDigest)) {
      denials.push(deny("projection_digest_mismatch", "the attestation does not bind the run-pinned projection digest"));
    }
    if (!bound(a["discoveryConfigurationDigest"], expectation.discoveryConfigurationDigest)) {
      denials.push(deny("discovery_configuration_mismatch", "the attestation does not bind the binding-written discovery configuration"));
    }
    if (!bound(a["registeringInstallationId"], expectation.registeringInstallationId)) {
      denials.push(deny("installation_mismatch", "the attestation is bound to a different registering installation"));
    }
    if (!bound(a["activeProfile"], expectation.activeProfile)) {
      denials.push(deny("active_profile_mismatch", "the attestation is bound to a different active profile"));
    }
    const capabilities = g["allowedCapabilities"];
    if (!Array.isArray(capabilities) || capabilities.length === 0) {
      denials.push(deny("empty_grant", "an empty grant yields no mutation-capable invocation token"));
    }
  } else if (!bound(a["intakeDraftId"], expectation.intakeDraftId)) {
    denials.push(deny("intake_draft_mismatch", "the attestation is bound to a different intake draft"));
  }
  if (denials.length > 0) return { admitted: false, denials };
  return {
    admitted: true,
    profile: expectation.profile,
    grantDigest: presentedDigest,
    allowedCapabilities: [...g["allowedCapabilities"]],
    writablePaths: [...g["writablePaths"]],
    protectedPaths: [...g["protectedPaths"]],
    forbiddenOperations: [...g["forbiddenOperations"]],
    mutationCapable: expectation.profile === "checkpoint"
  };
}
var CONFIRMATION_OPERATION_PREFIX = "operator-confirmation.";
var isConfirmationOperation = (name) => {
  const folded = name.toLowerCase();
  return folded === "operator-confirmation" || folded.startsWith(CONFIRMATION_OPERATION_PREFIX);
};
var normalizedRelative = (p) => p.length > 0 && !p.startsWith("/") && !p.includes("\\") && !p.includes("\0") && !/^[A-Za-z]:/.test(p) && !p.split("/").some((segment) => segment === ".." || segment === "." || segment === "");
var underAny = (p, prefixes) => prefixes.some((prefix) => {
  const clean = prefix.endsWith("/") ? prefix.slice(0, -1) : prefix;
  return p === clean || p.startsWith(`${clean}/`);
});
var underAnyFolded = (p, prefixes) => underAny(
  p.toLowerCase(),
  prefixes.map((prefix) => prefix.toLowerCase())
);
function evaluateToolInvocation(expectation, grant, attestation, request) {
  const admission = evaluateHostAdmission(expectation, grant, attestation);
  if (!admission.admitted) {
    return {
      allowed: false,
      denials: [
        {
          code: "not_admitted",
          message: "no valid attestation for the current expectation; tools stay closed",
          admissionDenials: admission.denials
        }
      ]
    };
  }
  const denials = [];
  const { capability, operation, writes } = request;
  if (isConfirmationOperation(capability) || operation !== void 0 && isConfirmationOperation(operation)) {
    denials.push({
      code: "confirmation_operation_excluded",
      message: "operator confirmations are excluded from every grant and served only by the binding-owned facade channel"
    });
  }
  if (!admission.allowedCapabilities.includes(capability)) {
    denials.push({ code: "capability_not_granted", message: `capability "${capability}" is outside the attested grant` });
  }
  if (operation !== void 0 && admission.forbiddenOperations.includes(operation)) {
    denials.push({ code: "operation_forbidden", message: `operation "${operation}" is forbidden by the attested grant` });
  }
  for (const write of writes ?? []) {
    if (!normalizedRelative(write)) {
      denials.push({ code: "unnormalized_path", message: `write path "${write}" is not a normalized workspace-relative path` });
      continue;
    }
    if (underAnyFolded(write, admission.protectedPaths)) {
      denials.push({ code: "protected_path", message: `write path "${write}" is under a protected authority path` });
      continue;
    }
    if (!underAny(write, admission.writablePaths)) {
      denials.push({ code: "write_outside_grant", message: `write path "${write}" is outside the attested writable paths` });
    }
  }
  return denials.length === 0 ? { allowed: true } : { allowed: false, denials };
}
function evaluateConfirmationEcho(rendered, attempt) {
  const denials = [];
  if (attempt.viaModelVisibleSurface) {
    denials.push({
      code: "model_visible_surface_refused",
      message: "confirmation echoes are accepted only on the binding-owned channel, never through a model-visible surface"
    });
  }
  if (!rendered.channelOpen) {
    denials.push({ code: "channel_closed", message: "the owning invocation ended; a detached descendant holds no channel" });
  }
  if (!rendered.interactive || !attempt.interactive) {
    denials.push({ code: "non_interactive_refused", message: "non-interactive, piped, or inherited-descriptor input is refused" });
  }
  if (attempt.presentedOnChannelId !== rendered.channelId) {
    denials.push({ code: "wrong_channel", message: "the echo did not return on the channel the challenge was rendered on" });
  }
  if (rendered.consumed) {
    denials.push({ code: "challenge_consumed", message: "the challenge is single-use and was already consumed" });
  }
  if (!SPINE_INSTANT.test(attempt.observedAt) || !SPINE_INSTANT.test(rendered.expiry) || rendered.expiry <= attempt.observedAt) {
    denials.push({ code: "challenge_expired", message: "the challenge expired at the caller's observation instant" });
  }
  if (attempt.presentedChallenge !== rendered.challenge) {
    denials.push({ code: "challenge_mismatch", message: "the echoed value does not match the rendered challenge" });
  }
  return denials.length === 0 ? { completed: true } : { completed: false, denials };
}
function assertionLaneAvailability(sources) {
  return {
    sensitiveApprovals: sources.hostNative || sources.osNative ? "available" : "fail_closed_no_assertion_source",
    operatorConfirmations: "fail_closed_no_qualified_producer",
    mergeReadyLane: "available"
  };
}

// packages/kernel/src/host/conformance.ts
var HOST_ADMISSION_SCENARIOS = Object.freeze([
  /** The attestation bound to the port's current expectation. */
  "current",
  /** No attestation has been applied yet. */
  "before-attestation",
  /** An attestation minted under a superseded invocation fence. */
  "stale-fence",
  /** An attestation minted for a different delivery. */
  "sibling-delivery"
]);
var HOST_INTERCEPTION_SCENARIOS = Object.freeze([
  /** A capability the attested grant lists, writing inside its writable paths. */
  "granted-capability",
  /** A capability outside the attested grant. */
  "ungranted-capability",
  /** A write to a protected authority path. */
  "protected-path-write",
  /** An operator-confirmation operation attempted from inside the grant. */
  "operator-confirmation"
]);
var HOST_CONFORMANCE_CASES = Object.freeze([
  Object.freeze({
    caseId: "admits-the-currently-attested-grant",
    statement: "an attestation bound to the current expectation admits the invocation"
  }),
  Object.freeze({
    caseId: "denies-every-tool-before-attestation",
    statement: "no tool executes before the grant is applied and attested"
  }),
  Object.freeze({
    caseId: "denies-a-stale-fence-attestation",
    statement: "an attestation from a superseded fence opens nothing"
  }),
  Object.freeze({
    caseId: "denies-a-sibling-delivery-attestation",
    statement: "an attestation bound to another delivery opens nothing"
  }),
  Object.freeze({
    caseId: "allows-a-granted-capability",
    statement: "a capability the attested grant lists, writing inside its writable paths, is allowed \u2014 without this the contract would be satisfied by a host that denies everything"
  }),
  Object.freeze({
    caseId: "denies-a-capability-outside-the-grant",
    statement: "a capability the attested grant does not list is denied"
  }),
  Object.freeze({
    caseId: "denies-a-write-to-a-protected-authority-path",
    statement: "a write under a protected authority path is denied"
  }),
  Object.freeze({
    caseId: "denies-an-operator-confirmation-inside-the-grant",
    statement: "operator confirmations are excluded from every grant and served only by the binding's own channel"
  }),
  Object.freeze({
    caseId: "records-only-the-graded-resume-position",
    statement: "the reported resume position never exceeds what the graded descendant teardown supports"
  }),
  Object.freeze({
    caseId: "tears-the-binding-written-set-down",
    statement: "teardown leaves no binding-written projection or discovery-configuration residue"
  })
]);
var result = (caseId, satisfied, detail) => ({
  caseId,
  satisfied,
  detail
});
async function runHostIntegrationConformance(port) {
  const results = [];
  const admission = async (caseId, scenario, expected) => {
    try {
      const observed = await port.admit(scenario);
      results.push(
        result(
          caseId,
          observed.outcome === expected,
          `${scenario}: expected ${expected}, observed ${observed.outcome}${observed.codes === void 0 ? "" : ` (${observed.codes.join(", ")})`}`
        )
      );
    } catch (error) {
      results.push(result(caseId, false, `admit(${scenario}) threw: ${error instanceof Error ? error.message : String(error)}`));
    }
  };
  const interception = async (caseId, scenario, expected) => {
    try {
      const observed = await port.intercept(scenario);
      results.push(
        result(
          caseId,
          observed.outcome === expected,
          `${scenario}: expected ${expected}, observed ${observed.outcome}${observed.codes === void 0 ? "" : ` (${observed.codes.join(", ")})`}`
        )
      );
    } catch (error) {
      results.push(
        result(caseId, false, `intercept(${scenario}) threw: ${error instanceof Error ? error.message : String(error)}`)
      );
    }
  };
  await admission("admits-the-currently-attested-grant", "current", "admitted");
  await admission("denies-every-tool-before-attestation", "before-attestation", "denied");
  await admission("denies-a-stale-fence-attestation", "stale-fence", "denied");
  await admission("denies-a-sibling-delivery-attestation", "sibling-delivery", "denied");
  await interception("allows-a-granted-capability", "granted-capability", "allowed");
  await interception("denies-a-capability-outside-the-grant", "ungranted-capability", "denied");
  await interception("denies-a-write-to-a-protected-authority-path", "protected-path-write", "denied");
  await interception("denies-an-operator-confirmation-inside-the-grant", "operator-confirmation", "denied");
  try {
    const termination = await port.terminate();
    const honest = termination.provenance === "graceful" && (termination.descendantTeardown === "verified" || termination.resumeEligibility === "fresh-worktree-only");
    results.push(
      result(
        "records-only-the-graded-resume-position",
        honest,
        `teardown ${termination.descendantTeardown} reported ${termination.resumeEligibility}`
      )
    );
  } catch (error) {
    results.push(
      result(
        "records-only-the-graded-resume-position",
        false,
        `terminate() threw: ${error instanceof Error ? error.message : String(error)}`
      )
    );
  }
  try {
    const torn = await port.tearDown();
    results.push(
      result(
        "tears-the-binding-written-set-down",
        torn.outcome === "torn-down" && torn.residue.length === 0,
        torn.residue.length === 0 ? torn.outcome : `residue: ${torn.residue.join(", ")}`
      )
    );
  } catch (error) {
    results.push(
      result(
        "tears-the-binding-written-set-down",
        false,
        `tearDown() threw: ${error instanceof Error ? error.message : String(error)}`
      )
    );
  }
  return results;
}

// packages/kernel/src/host/claude-code.ts
import { existsSync as existsSync2, realpathSync } from "node:fs";
import { chmod as chmod4, mkdir as mkdir4, readFile as readFile6, rm as rm4, writeFile as writeFile4 } from "node:fs/promises";
import path8 from "node:path";
import { tmpdir as tmpdir2 } from "node:os";

// packages/kernel/src/workflow/archive.ts
import { inflateRawSync } from "node:zlib";
var EOCD_SIGNATURE = 101010256;
var CENTRAL_SIGNATURE = 33639248;
var LOCAL_SIGNATURE = 67324752;
var ZIP64_MARKER_16 = 65535;
var ZIP64_MARKER_32 = 4294967295;
var STORED = 0;
var DEFLATED = 8;
function asBuffer(bytes) {
  return Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}
function readCentralDirectory(bytes) {
  const buffer = asBuffer(bytes);
  if (buffer.length < 22) {
    throw new Error("not an archive: shorter than an end-of-central-directory record");
  }
  let eocd = -1;
  const earliest = Math.max(0, buffer.length - 22 - 65535);
  for (let offset = buffer.length - 22; offset >= earliest; offset -= 1) {
    if (buffer.readUInt32LE(offset) === EOCD_SIGNATURE) {
      eocd = offset;
      break;
    }
  }
  if (eocd === -1) {
    throw new Error("not an archive: no end-of-central-directory record");
  }
  const entryCount = buffer.readUInt16LE(eocd + 10);
  const centralSize = buffer.readUInt32LE(eocd + 12);
  const centralOffset = buffer.readUInt32LE(eocd + 16);
  if (entryCount === ZIP64_MARKER_16 || centralSize === ZIP64_MARKER_32 || centralOffset === ZIP64_MARKER_32) {
    throw new Error("archive uses ZIP64 markers; the pinned release is not a ZIP64 archive \u2014 refusing");
  }
  if (centralOffset + centralSize > buffer.length) {
    throw new Error("archive central directory extends past the end of the bytes \u2014 refusing");
  }
  const entries = [];
  let cursor = centralOffset;
  for (let index = 0; index < entryCount; index += 1) {
    if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== CENTRAL_SIGNATURE) {
      throw new Error(`archive central entry ${index} is malformed \u2014 refusing`);
    }
    const method = buffer.readUInt16LE(cursor + 10);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const localHeaderOffset = buffer.readUInt32LE(cursor + 42);
    if (compressedSize === ZIP64_MARKER_32 || uncompressedSize === ZIP64_MARKER_32 || localHeaderOffset === ZIP64_MARKER_32) {
      throw new Error(`archive entry ${index} uses ZIP64 markers \u2014 refusing`);
    }
    const entryPath = buffer.toString("utf8", cursor + 46, cursor + 46 + nameLength);
    entries.push({ path: entryPath, method, compressedSize, uncompressedSize, localHeaderOffset });
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}
function listArchiveEntries(bytes) {
  return readCentralDirectory(bytes).map((entry3) => entry3.path);
}
function readArchiveEntry(bytes, entryPath) {
  const buffer = asBuffer(bytes);
  const entry3 = readCentralDirectory(bytes).find((candidate2) => candidate2.path === entryPath);
  if (entry3 === void 0) {
    throw new Error(`archive has no entry ${JSON.stringify(entryPath)}`);
  }
  const header = entry3.localHeaderOffset;
  if (header + 30 > buffer.length || buffer.readUInt32LE(header) !== LOCAL_SIGNATURE) {
    throw new Error(`archive local header for ${JSON.stringify(entryPath)} is malformed \u2014 refusing`);
  }
  const nameLength = buffer.readUInt16LE(header + 26);
  const extraLength = buffer.readUInt16LE(header + 28);
  const dataStart = header + 30 + nameLength + extraLength;
  const dataEnd = dataStart + entry3.compressedSize;
  if (dataEnd > buffer.length) {
    throw new Error(`archive data for ${JSON.stringify(entryPath)} extends past the end of the bytes \u2014 refusing`);
  }
  const compressed = buffer.subarray(dataStart, dataEnd);
  let out;
  if (entry3.method === STORED) {
    out = Buffer.from(compressed);
  } else if (entry3.method === DEFLATED) {
    out = inflateRawSync(compressed);
  } else {
    throw new Error(`archive entry ${JSON.stringify(entryPath)} uses unsupported compression method ${entry3.method} \u2014 refusing`);
  }
  if (out.length !== entry3.uncompressedSize) {
    throw new Error(
      `archive entry ${JSON.stringify(entryPath)} inflated to ${out.length} bytes, not the declared ${entry3.uncompressedSize} \u2014 refusing`
    );
  }
  return out;
}

// packages/kernel/src/host/projection.ts
import { readFile as readFile5 } from "node:fs/promises";
import path7 from "node:path";
var PROJECTION_DIR = ".managed-projection";
var PROJECTION_RECEIPT_FILE = "projection-receipt.json";
var CONSUMPTION_MARKER_FILE = "consumption.json";
var projectionDigestOf = (entries) => digestCanonical([...entries].sort((a, b) => compareUtf16CodeUnits(a.path, b.path)));
var fail = (code, message) => ({
  ok: false,
  blockers: [{ code, message }]
});
async function verifyProjection(input) {
  let receiptText;
  try {
    receiptText = await readFile5(path7.join(input.bindingDir, PROJECTION_RECEIPT_FILE), "utf8");
  } catch {
    return fail("projection_receipt_missing", "no projection receipt; nothing can be verified against it");
  }
  let receipt;
  try {
    receipt = JSON.parse(receiptText);
  } catch {
    return fail("projection_receipt_corrupt", "the projection receipt is not JSON");
  }
  if (!Array.isArray(receipt.entries) || typeof receipt.projectionDigest !== "string") {
    return fail("projection_receipt_corrupt", "the projection receipt is outside its shape");
  }
  if (projectionDigestOf(receipt.entries) !== receipt.projectionDigest) {
    return fail("projection_receipt_corrupt", "the projection receipt does not bind its own entries");
  }
  for (const entry3 of receipt.entries) {
    let bytes;
    try {
      bytes = await readFile5(path7.join(input.worktreeDir, PROJECTION_DIR, ...entry3.path.split("/")));
    } catch {
      return fail("projection_digest_mismatch", `receipted projection file ${entry3.path} is missing from the worktree`);
    }
    const digest2 = sha256Hex(bytes);
    if (digest2 !== entry3.sha256) {
      return fail(
        "projection_digest_mismatch",
        `projection file ${entry3.path} hashes to ${digest2}, not the receipted ${entry3.sha256}; mid-run tampering fails closed`
      );
    }
  }
  return {
    ok: true,
    projectionDigest: receipt.projectionDigest,
    entries: receipt.entries.map((entry3) => entry3.path)
  };
}
async function readConsumptionMarker(input) {
  let text4;
  try {
    text4 = await readFile5(path7.join(input.worktreeDir, PROJECTION_DIR, CONSUMPTION_MARKER_FILE), "utf8");
  } catch {
    return fail("consumption_marker_missing", "the worktree carries no per-run consumption marker; nothing was materialized here");
  }
  let parsed;
  try {
    parsed = JSON.parse(text4);
  } catch {
    return fail("consumption_marker_corrupt", "the consumption marker is not JSON");
  }
  const marker = parsed;
  if (typeof marker !== "object" || marker === null || typeof marker.deliveryId !== "string" || typeof marker.fence !== "number" || typeof marker.consumed !== "string") {
    return fail("consumption_marker_corrupt", "the consumption marker is outside its shape");
  }
  return { ok: true, deliveryId: marker.deliveryId, fence: marker.fence, consumed: marker.consumed };
}

// packages/kernel/src/host/claude-code.ts
var GENERATION_SKILLS_ARCHIVE = "skills/agent-skills-core-v1.zip";
var PROJECTION_ENTRY_PREFIXES = Object.freeze(["skills/", "workflows/", "schemas/workflow-"]);
var WORKTREE_EXCLUDES_FILE = "worktree-excludes";
var sessionSettingsFile = (fence) => `settings-${fence}.json`;
var bindingStateFile = (fence) => `state-${fence}.json`;
var OWNER_DIR = 448;
var OWNER_FILE = 384;
var READONLY_FILE = 292;
var HOST_BINDING_BLOCKER_CODES = Object.freeze([
  "generation_archive_unreadable",
  "projection_write_failed",
  "preexisting_worktree_excludes",
  "worktree_config_failed",
  "projection_receipt_missing",
  "projection_receipt_corrupt",
  "projection_digest_mismatch",
  "discovery_configuration_unreadable",
  "consumption_marker_missing",
  "consumption_marker_corrupt",
  "teardown_failed"
]);
var fail2 = (code, message) => ({
  ok: false,
  blockers: [{ code, message }]
});
async function materializeProjection(input) {
  let archive;
  try {
    archive = await readFile6(path8.join(input.generationRoot, ...GENERATION_SKILLS_ARCHIVE.split("/")));
  } catch {
    return fail2(
      "generation_archive_unreadable",
      `the pinned generation carries no readable ${GENERATION_SKILLS_ARCHIVE}; a missing pinned root blocks rather than falling forward`
    );
  }
  const excludesPath = path8.join(input.bindingDir, WORKTREE_EXCLUDES_FILE);
  const enable = await input.exec.run({
    command: "git",
    args: ["config", "extensions.worktreeConfig", "true"],
    cwd: input.worktreeDir
  });
  if (enable.code !== 0) {
    return fail2("worktree_config_failed", `enabling extensions.worktreeConfig failed: ${enable.stderr.trim()}`);
  }
  const existing = await input.exec.run({
    command: "git",
    args: ["config", "--worktree", "--get", "core.excludesFile"],
    cwd: input.worktreeDir
  });
  if (existing.code === 0 && existing.stdout.trim().length > 0 && existing.stdout.trim() !== excludesPath) {
    return fail2(
      "preexisting_worktree_excludes",
      `this worktree already sets core.excludesFile (${existing.stdout.trim()}); the binding preserves operator configuration and fails closed instead of replacing it`
    );
  }
  await mkdir4(input.bindingDir, { recursive: true, mode: OWNER_DIR });
  await writeFile4(excludesPath, `/${PROJECTION_DIR}/
`, { mode: OWNER_FILE });
  await chmod4(excludesPath, OWNER_FILE);
  const setExcludes = await input.exec.run({
    command: "git",
    args: ["config", "--worktree", "core.excludesFile", excludesPath],
    cwd: input.worktreeDir
  });
  if (setExcludes.code !== 0) {
    return fail2("worktree_config_failed", `setting the worktree excludes file failed: ${setExcludes.stderr.trim()}`);
  }
  const entries = [];
  const projectionRoot = path8.join(input.worktreeDir, PROJECTION_DIR);
  try {
    let names;
    try {
      names = listArchiveEntries(archive);
    } catch (error) {
      return fail2(
        "generation_archive_unreadable",
        `the pinned skills archive is unreadable: ${error instanceof Error ? error.message : String(error)}`
      );
    }
    for (const name of names) {
      if (!PROJECTION_ENTRY_PREFIXES.some((prefix) => name.startsWith(prefix))) continue;
      if (name.startsWith("/") || name.split("/").some((segment) => segment === ".." || segment === "." || segment === "")) {
        return fail2("projection_write_failed", `archive entry ${JSON.stringify(name)} is not a normalized relative path \u2014 refusing`);
      }
      const bytes = readArchiveEntry(archive, name);
      const target = path8.join(projectionRoot, ...name.split("/"));
      await mkdir4(path8.dirname(target), { recursive: true });
      await writeFile4(target, bytes);
      await chmod4(target, READONLY_FILE);
      entries.push({ path: name, sha256: sha256Hex(bytes) });
    }
    const marker = `${JSON.stringify({
      deliveryId: input.deliveryId,
      fence: input.fence,
      consumed: GENERATION_SKILLS_ARCHIVE
    })}
`;
    const markerPath = path8.join(projectionRoot, CONSUMPTION_MARKER_FILE);
    await writeFile4(markerPath, marker);
    await chmod4(markerPath, READONLY_FILE);
    entries.push({ path: CONSUMPTION_MARKER_FILE, sha256: sha256Hex(marker) });
  } catch (error) {
    return fail2(
      "projection_write_failed",
      `materializing the projection failed: ${error instanceof Error ? error.message : String(error)}`
    );
  }
  const receipt = {
    deliveryId: input.deliveryId,
    projectionDigest: projectionDigestOf(entries),
    entries: [...entries].sort((a, b) => compareUtf16CodeUnits(a.path, b.path))
  };
  const receiptPath = path8.join(input.bindingDir, PROJECTION_RECEIPT_FILE);
  await writeFile4(receiptPath, `${JSON.stringify(receipt)}
`, { mode: OWNER_FILE });
  await chmod4(receiptPath, OWNER_FILE);
  return { ok: true, projectionDigest: receipt.projectionDigest, excludesPath };
}
async function discoveryConfigurationDigestOf(input) {
  try {
    const settings = await readFile6(input.settingsPath, "utf8");
    const worktreeExcludes = await readFile6(path8.join(input.bindingDir, WORKTREE_EXCLUDES_FILE), "utf8");
    return digestCanonical({ settings, worktreeExcludes });
  } catch {
    return void 0;
  }
}
async function tearDownProjection(input) {
  const excludesPath = path8.join(input.bindingDir, WORKTREE_EXCLUDES_FILE);
  let clearExclusion = false;
  if (existsSync2(input.worktreeDir)) {
    const current = await input.exec.run({
      command: "git",
      args: ["config", "--worktree", "--get", "core.excludesFile"],
      cwd: input.worktreeDir
    });
    clearExclusion = current.code === 0 && current.stdout.trim() === excludesPath;
  }
  try {
    await rm4(path8.join(input.worktreeDir, PROJECTION_DIR), { recursive: true, force: true });
    await rm4(input.settingsPath, { force: true });
    for (const file of [WORKTREE_EXCLUDES_FILE, PROJECTION_RECEIPT_FILE]) {
      await rm4(path8.join(input.bindingDir, file), { force: true });
    }
  } catch (error) {
    return fail2("teardown_failed", `removing the projection failed: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (!clearExclusion) return { ok: true };
  const unset = await input.exec.run({
    command: "git",
    args: ["config", "--worktree", "--unset", "core.excludesFile"],
    cwd: input.worktreeDir
  });
  if (unset.code !== 0 && unset.code !== 5) {
    return fail2("teardown_failed", `clearing the worktree-scoped exclusion failed: ${unset.stderr.trim()}`);
  }
  return { ok: true };
}
var GENERATION_HOST_CAPABILITIES = "qualifications/host-admission-capabilities.json";
async function gradedDescendantTeardown(input) {
  let record2;
  try {
    record2 = JSON.parse(
      await readFile6(path8.join(input.generationRoot, ...GENERATION_HOST_CAPABILITIES.split("/")), "utf8")
    );
  } catch {
    return "unverified";
  }
  const hosts = record2?.hosts;
  if (!Array.isArray(hosts)) return "unverified";
  const graded = hosts.find(
    (host) => typeof host === "object" && host !== null && host["hostId"] === input.hostId && host["hostVersion"] === input.hostVersion
  );
  if (graded === void 0) return "unverified";
  const tier = graded["grade"]?.tier;
  const capability = graded["capabilities"]?.["terminationProvenanceWithDescendantTeardown"]?.status;
  return typeof tier === "number" && tier >= 3 && capability === "supported" ? "verified" : "unverified";
}
function gradeResumeEligibility(input) {
  return input.descendantTeardown === "verified" ? "same-workspace" : "fresh-worktree-only";
}
async function composeClaudeCodeSession(input) {
  const hook = (subcommand) => [...input.hookCommand, subcommand, input.statePath, String(input.fence)].map((part) => JSON.stringify(part)).join(" ");
  const workspaceRoot = path8.resolve(input.workspaceRoot);
  const commonGitDir = path8.resolve(input.commonGitDir);
  const authorityDir = path8.resolve(input.authorityDir);
  const absolutePermissionPath = (target) => `/${path8.resolve(target).replace(/^\/+/, "")}`;
  const unique = (values) => [...new Set(values)].sort(compareUtf16CodeUnits);
  const spellings = (target) => {
    const resolved = path8.resolve(target);
    let ancestor = resolved;
    const tail = [];
    for (; ; ) {
      try {
        const canonical = path8.join(realpathSync(ancestor), ...tail);
        return canonical === resolved ? [resolved] : [resolved, canonical];
      } catch {
        const parent = path8.dirname(ancestor);
        if (parent === ancestor) return [resolved];
        tail.unshift(path8.basename(ancestor));
        ancestor = parent;
      }
    }
  };
  const workspaceRoots = spellings(workspaceRoot);
  const underWorkspace = (relatives) => unique(workspaceRoots.flatMap((root) => relatives.map((relative) => path8.resolve(root, relative))));
  const writableRoots = underWorkspace(input.grant.writablePaths);
  const protectedRoots = underWorkspace(input.grant.protectedPaths);
  const deniedAuthorityRoots = unique([commonGitDir, authorityDir].flatMap(spellings));
  const deniedWriteRoots = unique([
    ...workspaceRoots,
    ...protectedRoots,
    ...deniedAuthorityRoots,
    ...spellings(tmpdir2()),
    ...spellings("/tmp")
  ]);
  const permissionDenials = deniedAuthorityRoots.flatMap((target) => [
    `Read(${absolutePermissionPath(target)}/**)`,
    `Edit(${absolutePermissionPath(target)}/**)`
  ]);
  const settings = {
    // The supported host enforces the grant through its OWN permission
    // system; the hook is the deny-until-attested interceptor on top. Only
    // the grant's capabilities are allowed — everything else stays subject to
    // the host's non-interactive default denial.
    permissions: {
      allow: [...input.grant.allowedCapabilities],
      deny: permissionDenials
    },
    // Claude Code 2.1.252's Seatbelt/bubblewrap boundary. The broad workspace
    // and ambient-temp denies remove the host defaults; the more-specific
    // grant roots are the only writable descendants. Protected descendants
    // remain explicit denies. No command may retry outside the sandbox.
    sandbox: {
      enabled: true,
      failIfUnavailable: true,
      autoAllowBashIfSandboxed: true,
      excludedCommands: [],
      allowUnsandboxedCommands: false,
      filesystem: {
        allowWrite: writableRoots,
        denyWrite: deniedWriteRoots,
        denyRead: deniedAuthorityRoots
      }
    },
    hooks: {
      PreToolUse: [
        {
          matcher: "*",
          hooks: [{ type: "command", command: hook("pre-tool-use") }]
        }
      ],
      // The gate writer accepts no PreToolUse intent. This post-invocation
      // event is the binding's sole evidence that the host completed its
      // exact workflow-source Read for this fenced delivery.
      PostToolUse: [
        {
          matcher: "Read",
          hooks: [{ type: "command", command: hook("post-tool-use") }]
        }
      ],
      SessionEnd: [
        {
          hooks: [{ type: "command", command: hook("session-end") }]
        }
      ]
    }
  };
  const settingsBytes = `${JSON.stringify(settings, null, 2)}
`;
  const settingsPath = path8.join(input.bindingDir, sessionSettingsFile(input.fence));
  await mkdir4(input.bindingDir, { recursive: true, mode: OWNER_DIR });
  await writeFile4(settingsPath, settingsBytes, { mode: OWNER_FILE });
  await chmod4(settingsPath, OWNER_FILE);
  const discoveryConfigurationDigest = await discoveryConfigurationDigestOf({
    settingsPath,
    bindingDir: input.bindingDir
  });
  if (discoveryConfigurationDigest === void 0) {
    return fail2(
      "discovery_configuration_unreadable",
      "the worktree excludes file is missing; compose the session only after materializing the projection"
    );
  }
  return {
    ok: true,
    settingsPath,
    // Candidate-writable setting scopes (project/local) are excluded — the
    // graded requirement — and so is every other ambient scope: the empty
    // selection makes the binding-composed `--settings` file the session's
    // ONLY settings source, so the discovery configuration is exactly the
    // digest-bound bytes above.
    cliArgs: ["--restricted", "--settings", settingsPath, "--setting-sources", ""],
    discoveryConfigurationDigest
  };
}
function mintGrantAttestation(input) {
  const base = {
    spec: "grant-attestation/1",
    profile: input.expectation.profile,
    hostVersion: input.expectation.hostVersion,
    grantDigest: digestCanonical(input.grant),
    productTrustRevocationEpoch: input.expectation.productTrustRevocationEpoch,
    expiry: input.expiry
  };
  if (input.expectation.profile === "intake") {
    return {
      ...base,
      intakeDraftId: input.expectation.intakeDraftId,
      deliveryId: "absent-by-state",
      invocationFence: "absent-by-state",
      workspaceId: "absent-by-state",
      projectionDigest: "absent-by-state",
      discoveryConfigurationDigest: "absent-by-state",
      registeringInstallationId: "absent-by-state",
      activeProfile: "absent-by-state"
    };
  }
  return {
    ...base,
    intakeDraftId: "absent-by-state",
    deliveryId: input.expectation.deliveryId,
    invocationFence: input.expectation.invocationFence,
    workspaceId: input.expectation.workspaceId,
    projectionDigest: input.expectation.projectionDigest,
    discoveryConfigurationDigest: input.expectation.discoveryConfigurationDigest,
    registeringInstallationId: input.expectation.registeringInstallationId,
    activeProfile: input.expectation.activeProfile
  };
}

// packages/kernel/src/host/fake-host.ts
var EXPECTATION = Object.freeze({
  profile: "checkpoint",
  hostVersion: "fake-host/1.0.0",
  productTrustRevocationEpoch: 1,
  observedAt: "2026-08-30T12:00:00Z",
  deliveryId: "dlv-fake-01",
  invocationFence: 9,
  workspaceId: "ws-fake-01",
  projectionDigest: "c".repeat(64),
  discoveryConfigurationDigest: "d".repeat(64),
  registeringInstallationId: "install-fake-01",
  activeProfile: "default"
});
var GRANT = Object.freeze({
  spec: "execution-grant/1",
  profile: "checkpoint",
  allowedCapabilities: ["Read", "Write"],
  writablePaths: ["src"],
  protectedPaths: [".git", ".managed-projection"],
  forbiddenOperations: []
});
var attestationFor = (expectation) => ({
  spec: "grant-attestation/1",
  profile: "checkpoint",
  hostVersion: expectation.hostVersion,
  grantDigest: grantDigest(GRANT),
  productTrustRevocationEpoch: expectation.productTrustRevocationEpoch,
  expiry: "2026-08-30T13:00:00Z",
  intakeDraftId: "absent-by-state",
  deliveryId: expectation.deliveryId,
  invocationFence: expectation.invocationFence,
  workspaceId: expectation.workspaceId,
  projectionDigest: expectation.projectionDigest,
  discoveryConfigurationDigest: expectation.discoveryConfigurationDigest,
  registeringInstallationId: expectation.registeringInstallationId,
  activeProfile: expectation.activeProfile
});
var attestationForScenario = (scenario) => {
  switch (scenario) {
    case "current":
      return attestationFor(EXPECTATION);
    case "before-attestation":
      return void 0;
    case "stale-fence":
      return attestationFor({ ...EXPECTATION, invocationFence: EXPECTATION.invocationFence - 1 });
    case "sibling-delivery":
      return attestationFor({ ...EXPECTATION, deliveryId: "dlv-fake-02" });
  }
};
var requestForScenario = (scenario) => {
  switch (scenario) {
    case "granted-capability":
      return { capability: "Write", writes: ["src/module.ts"] };
    case "ungranted-capability":
      return { capability: "Bash" };
    case "protected-path-write":
      return { capability: "Write", writes: [".managed-projection/skills/SKILL.md"] };
    case "operator-confirmation":
      return { capability: "Read", operation: "operator-confirmation.takeover" };
  }
};
function createFakeHostConformancePort(input) {
  let written = ["fake://settings", "fake://worktree-excludes", "fake://projection"];
  return {
    hostId: "fake-host",
    hostVersion: EXPECTATION.hostVersion,
    async admit(scenario) {
      const decision = evaluateHostAdmission(EXPECTATION, GRANT, attestationForScenario(scenario));
      return decision.admitted ? { outcome: "admitted" } : { outcome: "denied", codes: decision.denials.map((denial) => denial.code) };
    },
    async intercept(scenario) {
      const decision = evaluateToolInvocation(
        EXPECTATION,
        GRANT,
        attestationFor(EXPECTATION),
        requestForScenario(scenario)
      );
      return decision.allowed ? { outcome: "allowed" } : { outcome: "denied", codes: decision.denials.map((denial) => denial.code) };
    },
    async terminate() {
      return {
        provenance: "graceful",
        descendantTeardown: input.descendantTeardown,
        resumeEligibility: gradeResumeEligibility({ descendantTeardown: input.descendantTeardown })
      };
    },
    async tearDown() {
      written = [];
      return { outcome: "torn-down", residue: written };
    }
  };
}

// packages/kernel/src/host/provider-review-result.ts
var PROVIDER_REVIEW_HANDOFF_SPEC = "provider-review-handoff/1";
var PROVIDER_REVIEW_RESULT_SPEC = "provider-review-result/1";
var OID = /^[0-9a-f]{40}$/;
var SHA = /^[0-9a-f]{64}$/;
var SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._:-]*$/;
var PROVIDER = /^[a-z0-9]+([._-][a-z0-9]+)*$/;
var RUN = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
var VERDICTS = /* @__PURE__ */ new Set(["approved", "changes_requested"]);
var TERMINALS = /* @__PURE__ */ new Set(["completed", "failed", "timed_out", "interrupted"]);
var SEVERITIES2 = /* @__PURE__ */ new Set(["P0", "P1", "P2", "P3"]);
var SCOPES = /* @__PURE__ */ new Set(["in_contract", "adjacent", "expansion"]);
var DISPOSITIONS = /* @__PURE__ */ new Set(["resolved", "advisory", "pre_existing", "deferred", "unresolved", "ignored"]);
var record = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var text2 = (value) => typeof value === "string" && value.length > 0;
var exact = (value, required, optional = []) => {
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  return required.every((key) => key in value) && Object.keys(value).every((key) => allowed.has(key));
};
var safeId = (value) => text2(value) && value.length <= 256 && SAFE_ID.test(value);
var finding2 = (value) => record(value) && exact(value, ["id", "severity", "scope", "actionable", "blocking", "disposition"], ["deferredIssueId"]) && text2(value["id"]) && typeof value["severity"] === "string" && SEVERITIES2.has(value["severity"]) && typeof value["scope"] === "string" && SCOPES.has(value["scope"]) && typeof value["actionable"] === "boolean" && typeof value["blocking"] === "boolean" && typeof value["disposition"] === "string" && DISPOSITIONS.has(value["disposition"]) && (value["deferredIssueId"] === void 0 || text2(value["deferredIssueId"]));
var candidate = (value) => {
  if (!record(value) || !exact(value, ["vcs", "treeSha", "headSha", "deliverable", "base", "workspaceId"])) return false;
  const deliverable = value["deliverable"];
  const base = value["base"];
  return value["vcs"] === "git" && typeof value["treeSha"] === "string" && OID.test(value["treeSha"]) && typeof value["headSha"] === "string" && OID.test(value["headSha"]) && safeId(value["workspaceId"]) && record(deliverable) && exact(deliverable, ["digest", "identity"]) && typeof deliverable["digest"] === "string" && SHA.test(deliverable["digest"]) && text2(deliverable["identity"]) && record(base) && exact(base, ["ref", "tipSha", "mergeBaseSha"]) && text2(base["ref"]) && typeof base["tipSha"] === "string" && OID.test(base["tipSha"]) && typeof base["mergeBaseSha"] === "string" && OID.test(base["mergeBaseSha"]);
};
var reviewer = (value) => record(value) && exact(value, ["attemptId", "lensId", "personaId", "personaDigest", "personaBytes", "contextDigest"]) && safeId(value["attemptId"]) && safeId(value["lensId"]) && safeId(value["personaId"]) && text2(value["personaBytes"]) && typeof value["personaDigest"] === "string" && SHA.test(value["personaDigest"]) && sha256Hex(value["personaBytes"]) === value["personaDigest"] && typeof value["contextDigest"] === "string" && SHA.test(value["contextDigest"]);
var provider = (value) => record(value) && exact(value, ["id", "version", "runId", "finalPassId"]) && typeof value["id"] === "string" && value["id"].length <= 128 && PROVIDER.test(value["id"]) && text2(value["version"]) && typeof value["runId"] === "string" && value["runId"].length <= 128 && RUN.test(value["runId"]) && value["runId"] !== "." && value["runId"] !== ".." && safeId(value["finalPassId"]);
function parseProviderReviewResult(bytes) {
  let value;
  try {
    value = JSON.parse(bytes);
  } catch {
    return { ok: false, code: "provider_result_invalid", message: "provider result is not JSON" };
  }
  const keys = ["spec", "handoffId", "deliveryId", "provider", "nativeSessionId", "workspaceId", "fence", "productTrustRevocationEpoch", "candidate", "promptContextBytes", "promptContextDigest", "reviewer", "nativeEnvelopeBytes", "nativeEnvelopeDigest", "terminalState", "verdict", "findings"];
  if (!record(value) || !exact(value, keys) || value["spec"] !== PROVIDER_REVIEW_RESULT_SPEC || !safeId(value["handoffId"]) || !safeId(value["deliveryId"]) || !provider(value["provider"]) || !safeId(value["nativeSessionId"]) || !safeId(value["workspaceId"]) || !Number.isSafeInteger(value["fence"]) || value["fence"] < 1 || !Number.isSafeInteger(value["productTrustRevocationEpoch"]) || value["productTrustRevocationEpoch"] < 0 || !candidate(value["candidate"]) || !text2(value["promptContextBytes"]) || typeof value["promptContextDigest"] !== "string" || sha256Hex(value["promptContextBytes"]) !== value["promptContextDigest"] || !reviewer(value["reviewer"]) || !text2(value["nativeEnvelopeBytes"]) || typeof value["nativeEnvelopeDigest"] !== "string" || sha256Hex(value["nativeEnvelopeBytes"]) !== value["nativeEnvelopeDigest"] || typeof value["terminalState"] !== "string" || !TERMINALS.has(value["terminalState"]) || typeof value["verdict"] !== "string" || !VERDICTS.has(value["verdict"]) || !Array.isArray(value["findings"]) || !value["findings"].every(finding2)) {
    return { ok: false, code: "provider_result_invalid", message: "provider result is outside provider-review-result/1" };
  }
  return { ok: true, result: value };
}
function providerReviewPromptBytes(input) {
  return `${JSON.stringify({
    persona: input.personaBytes,
    contract: input.contractBytes,
    sensorEvidence: input.sensorEvidenceBytes,
    instructions: input.reviewInstructionsBytes
  }, null, 2)}
`;
}
function createProviderReviewHandoff(input) {
  const { reviewer: suppliedReviewer, contractBytes, sensorEvidenceBytes, reviewInstructionsBytes, ...binding } = input;
  const promptContextBytes = providerReviewPromptBytes({
    personaBytes: suppliedReviewer.personaBytes,
    contractBytes,
    sensorEvidenceBytes,
    reviewInstructionsBytes
  });
  const promptContextDigest = sha256Hex(promptContextBytes);
  const reviewer2 = {
    ...suppliedReviewer,
    contextDigest: digestCanonical({
      handoffId: input.handoffId,
      deliveryId: input.deliveryId,
      provider: input.provider,
      nativeSessionId: input.nativeSessionId,
      workspaceId: input.workspaceId,
      fence: input.fence,
      productTrustRevocationEpoch: input.productTrustRevocationEpoch,
      candidate: input.candidate,
      lensId: suppliedReviewer.lensId,
      personaId: suppliedReviewer.personaId,
      personaDigest: suppliedReviewer.personaDigest,
      promptContextDigest
    })
  };
  return { spec: PROVIDER_REVIEW_HANDOFF_SPEC, ...binding, promptContextBytes, promptContextDigest, reviewer: reviewer2 };
}
function adaptClaudeCodeReviewResult(input) {
  if (input.submittedPromptContextBytes !== input.handoff.promptContextBytes || sha256Hex(input.submittedPromptContextBytes) !== input.handoff.promptContextDigest) {
    return {
      ok: false,
      code: "provider_prompt_mismatch",
      message: "Claude Code was not invoked with the exact persona, contract, sensor evidence, and review instructions bound by the handoff"
    };
  }
  let envelope;
  try {
    envelope = JSON.parse(input.nativeEnvelopeBytes);
  } catch {
    return { ok: false, code: "provider_envelope_invalid", message: "Claude Code result envelope is not JSON" };
  }
  if (!record(envelope) || envelope["type"] !== "result" || !text2(envelope["subtype"]) || typeof envelope["is_error"] !== "boolean" || !safeId(envelope["session_id"]) || typeof envelope["result"] !== "string") {
    return { ok: false, code: "provider_envelope_invalid", message: "Claude Code result envelope is incomplete" };
  }
  if (envelope["session_id"] !== input.handoff.nativeSessionId) return { ok: false, code: "provider_session_mismatch", message: "Claude Code result belongs to another session" };
  let conclusion;
  try {
    conclusion = JSON.parse(envelope["result"]);
  } catch {
    const blocks = [...envelope["result"].matchAll(/```json\s*([\s\S]*?)```/gi)];
    if (blocks.length !== 1) return { ok: false, code: "provider_conclusion_invalid", message: "Claude Code conclusion is not JSON" };
    try {
      conclusion = JSON.parse(blocks[0]?.[1] ?? "");
    } catch {
      return { ok: false, code: "provider_conclusion_invalid", message: "Claude Code conclusion is not JSON" };
    }
  }
  if (!record(conclusion) || !exact(conclusion, ["verdict", "findings"]) || typeof conclusion["verdict"] !== "string" || !VERDICTS.has(conclusion["verdict"]) || !Array.isArray(conclusion["findings"]) || !conclusion["findings"].every(finding2)) {
    return { ok: false, code: "provider_conclusion_invalid", message: "Claude Code conclusion is outside the closed review grammar" };
  }
  return { ok: true, result: {
    ...input.handoff,
    spec: PROVIDER_REVIEW_RESULT_SPEC,
    nativeEnvelopeBytes: input.nativeEnvelopeBytes,
    nativeEnvelopeDigest: sha256Hex(input.nativeEnvelopeBytes),
    terminalState: envelope["subtype"] === "success" && envelope["is_error"] === false ? "completed" : "failed",
    verdict: conclusion["verdict"],
    findings: conclusion["findings"]
  } };
}

// packages/kernel/src/spine/finish-line.ts
var FINISH_LINE_RESULT_SPEC = "finish-line-result/1";
var EXTERNAL_ACTIONS = Object.freeze(["pr-creation", "merge", "deploy"]);
var RESULT_RULES2 = [
  { name: "spec", check: specLiteral(FINISH_LINE_RESULT_SPEC) },
  { name: "finishLine", check: literal("merge-ready") },
  { name: "deliveryId", check: spineId },
  {
    name: "candidate",
    check: closed([
      { name: "treeSha", check: gitOid },
      { name: "deliverableDigest", check: sha256 }
    ])
  },
  {
    name: "recordedCandidate",
    check: closed([
      { name: "treeSha", check: gitOid },
      { name: "baseTipSha", check: gitOid }
    ])
  },
  { name: "policyDigest", check: sha256 },
  { name: "completedObligations", check: stringArray({ minItems: 1, item: spineId }) },
  { name: "trackedRecordDigest", check: sha256 },
  { name: "externalVerification", check: literal("passed") },
  { name: "productTrustLabel", check: literal(PRODUCT_TRUST_LABEL) },
  { name: "outcomeVerificationDigest", check: sha256 },
  { name: "mergeReadyObligationsSatisfied", check: literal(true) }
];
function validateFinishLineResult(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", RESULT_RULES2, collector);
  return collector.verdict();
}
function checkMergeReadyAgainstOutcome(result2, outcome) {
  const collector = createSpineCollector();
  let computed;
  try {
    computed = digestCanonical(outcome);
  } catch {
    computed = void 0;
  }
  if (computed === void 0 || computed !== result2.outcomeVerificationDigest) {
    collector.emit(
      "digest_mismatch",
      "/outcomeVerificationDigest",
      "the result does not bind this outcome verification's canonical bytes"
    );
  }
  if (result2.candidate.treeSha !== outcome.candidate.treeSha || result2.candidate.deliverableDigest !== outcome.candidate.deliverableDigest) {
    collector.emit("digest_mismatch", "/candidate", "the result and the outcome verification name different candidates");
  }
  outcome.criteria.forEach((criterion, index) => {
    if (criterion.disposition === "blocked") {
      collector.emit(
        "criterion_unverified",
        spinePointer("/criteria", index, "disposition"),
        `criterion ${criterion.criterionId} is blocked; a merge-ready finish line requires every criterion resolved`
      );
    }
  });
  if (!outcome.criteria.some((criterion) => criterion.disposition === "passed")) {
    collector.emit(
      "criterion_unverified",
      "/criteria",
      "no positive criterion passed; a blanket waiver cannot produce delivery success"
    );
  }
  return collector.verdict();
}

// packages/kernel/src/spine/assertion.ts
var SENSITIVE_APPROVAL_ASSERTION_SPEC = "sensitive-approval-assertion/1";
var ASSERTION_CLASSES = Object.freeze([
  "delivery-bound",
  "maintenance-lane",
  "security-blocked-migration"
]);
var ASSERTION_SOURCES = Object.freeze(["host-native", "os-native", "qualification-fixture"]);
var SENSITIVE_MAINTENANCE_ACTIONS = Object.freeze([
  "update",
  "rollback",
  "pin",
  "revoke",
  "unrevoke",
  "advance-high-water-mark"
]);
var SECURITY_BLOCKED_MIGRATION_ACTION = "migrate-security-blocked";
var ASSERTION_RULES = [
  { name: "spec", check: specLiteral(SENSITIVE_APPROVAL_ASSERTION_SPEC) },
  { name: "assertionClass", check: oneOf(ASSERTION_CLASSES) },
  { name: "origin", check: text },
  { name: "action", check: text },
  { name: "expiry", check: instant },
  { name: "nonce", check: spineId },
  { name: "assertionSource", check: oneOf(ASSERTION_SOURCES) },
  { name: "productTrustRevocationEpoch", check: nonNegativeInt },
  { name: "repositoryAuthorityRevocationEpoch", check: orAbsentByState(nonNegativeInt) },
  { name: "deliveryId", check: orAbsentByState(spineId) },
  { name: "candidateTreeSha", check: orAbsentByState(gitOid) },
  { name: "policyDigest", check: orAbsentByState(sha256) },
  { name: "invocationFence", check: orAbsentByState(positiveInt) },
  { name: "targetInstallationId", check: orAbsentByState(spineId) },
  { name: "targetGenerationDigest", check: orAbsentByState(sha256) },
  { name: "targetHighWaterMark", check: orAbsentByState(nonNegativeInt) },
  { name: "expectedJournalRevision", check: orAbsentByState(nonNegativeInt) }
];
var requireReal3 = (record2, name, collector) => {
  if (isAbsentByState(record2[name])) {
    collector.emit(
      "unsupported_combination",
      spinePointer("", name),
      `this assertion class binds ${name} for real; "absent-by-state" is not a supported combination here`
    );
  }
};
var requireAbsent3 = (record2, name, collector) => {
  if (record2[name] !== void 0 && !isAbsentByState(record2[name])) {
    collector.emit(
      "unsupported_combination",
      spinePointer("", name),
      `this assertion class records ${name} explicitly "absent-by-state"; a populated value is not a supported combination`
    );
  }
};
function validateSensitiveApprovalAssertion(value) {
  const collector = createSpineCollector();
  const record2 = checkClosed2(value, "", ASSERTION_RULES, collector);
  if (record2 !== void 0) {
    const assertionClass = record2["assertionClass"];
    if (assertionClass === "delivery-bound") {
      requireReal3(record2, "deliveryId", collector);
      requireReal3(record2, "candidateTreeSha", collector);
      requireReal3(record2, "policyDigest", collector);
      requireReal3(record2, "invocationFence", collector);
      requireReal3(record2, "repositoryAuthorityRevocationEpoch", collector);
      requireAbsent3(record2, "targetInstallationId", collector);
      requireAbsent3(record2, "targetGenerationDigest", collector);
      requireAbsent3(record2, "targetHighWaterMark", collector);
      requireAbsent3(record2, "expectedJournalRevision", collector);
    }
    if (assertionClass === "maintenance-lane") {
      const action = record2["action"];
      if (typeof action === "string" && !SENSITIVE_MAINTENANCE_ACTIONS.includes(action)) {
        collector.emit(
          "unsupported_combination",
          "/action",
          `${action} is not in the frozen sensitive maintenance action set`
        );
      }
      requireReal3(record2, "targetInstallationId", collector);
      if (action === "advance-high-water-mark") {
        requireReal3(record2, "targetHighWaterMark", collector);
        requireAbsent3(record2, "targetGenerationDigest", collector);
      } else {
        requireReal3(record2, "targetGenerationDigest", collector);
        requireAbsent3(record2, "targetHighWaterMark", collector);
      }
      requireAbsent3(record2, "deliveryId", collector);
      requireAbsent3(record2, "candidateTreeSha", collector);
      requireAbsent3(record2, "policyDigest", collector);
      requireAbsent3(record2, "invocationFence", collector);
      requireAbsent3(record2, "repositoryAuthorityRevocationEpoch", collector);
      requireAbsent3(record2, "expectedJournalRevision", collector);
    }
    if (assertionClass === "security-blocked-migration") {
      if (record2["action"] !== SECURITY_BLOCKED_MIGRATION_ACTION) {
        collector.emit(
          "unsupported_combination",
          "/action",
          `the migration class carries exactly the ${SECURITY_BLOCKED_MIGRATION_ACTION} action`
        );
      }
      requireReal3(record2, "targetInstallationId", collector);
      requireReal3(record2, "targetGenerationDigest", collector);
      requireReal3(record2, "deliveryId", collector);
      requireReal3(record2, "expectedJournalRevision", collector);
      requireAbsent3(record2, "candidateTreeSha", collector);
      requireAbsent3(record2, "policyDigest", collector);
      requireAbsent3(record2, "invocationFence", collector);
      requireAbsent3(record2, "repositoryAuthorityRevocationEpoch", collector);
      requireAbsent3(record2, "targetHighWaterMark", collector);
    }
  }
  return collector.verdict();
}
function assertionClassOf(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return void 0;
  const declared = value["assertionClass"];
  return ASSERTION_CLASSES.includes(declared) ? declared : void 0;
}

// packages/kernel/src/spine/journal.ts
var JOURNAL_ENTRY_SPEC = "journal-entry/1";
var WORKSPACE_DISPOSITIONS = Object.freeze([
  "quarantined",
  "takeover",
  "reconciled",
  "prior_host_termination_unverified"
]);
var APPROVAL_REQUEST_KINDS = Object.freeze(["waiver", "amendment"]);
var MAINTENANCE_ACTIONS = Object.freeze([
  "first-install",
  "update",
  "rollback",
  "pin",
  "revoke",
  "unrevoke",
  "advance-high-water-mark",
  "installer-repair",
  "garbage-collection"
]);
var MAINTENANCE_PHASES = Object.freeze(["started", "completed", "recovered"]);
var PHASED_MAINTENANCE_ACTIONS = Object.freeze(["update", "rollback"]);
var RETENTION_ACTIONS = Object.freeze(["export", "delete"]);
var TERMINATION_PROVENANCE_KINDS = Object.freeze(["graceful"]);
var DESCENDANT_TEARDOWN_STATUSES = Object.freeze(["verified", "unverified"]);
var RESUME_ELIGIBILITIES = Object.freeze(["same-workspace", "fresh-worktree-only"]);
var ACTION_APPROVALS = Object.freeze(["required", "not-required"]);
var EXTERNAL_ACTION_OUTCOMES = Object.freeze(["succeeded", "failed", "indeterminate"]);
var ACTION_VERIFICATIONS = Object.freeze(["passed", "failed", "not-attempted"]);
var table = (rules) => (payload, at, collector) => {
  checkClosed2(payload, at, rules, collector);
};
var embedded = (validate) => (value, at, collector) => {
  const verdict = validate(value);
  if (verdict.ok) return;
  for (const rejection of verdict.rejections) {
    collector.emit(rejection.code, `${at}${rejection.pointer}`, rejection.message);
  }
};
var confirmationPayload = (requiredClass) => (payload, at, collector) => {
  checkClosed2(payload, at, [{ name: "confirmation", check: embedded(validateOperatorConfirmation) }], collector);
  const confirmation = payload["confirmation"];
  const declared = confirmationClassOf(confirmation);
  if (declared !== void 0 && declared !== requiredClass) {
    collector.emit(
      "unsupported_combination",
      `${at}/confirmation/confirmationClass`,
      `this journal records only ${requiredClass} confirmations; the class scopes the payload to its journal`
    );
  }
};
var operationResultPayload = (payload, at, collector) => {
  checkClosed2(
    payload,
    at,
    [
      { name: "capabilityId", check: spineId },
      { name: "result", check: embedded(validateSensorResult) }
    ],
    collector
  );
  const result2 = payload["result"];
  if (isSpineRecord(result2) && typeof payload["capabilityId"] === "string" && typeof result2["capabilityId"] === "string") {
    if (payload["capabilityId"] !== result2["capabilityId"]) {
      collector.emit(
        "unsupported_combination",
        `${at}/capabilityId`,
        "the envelope's capability id and the embedded result's capability id must agree"
      );
    }
  }
};
var TRANSITION_BASE_RULES = [
  { name: "from", check: oneOf(DELIVERY_STATES) },
  { name: "to", check: oneOf(DELIVERY_STATES) }
];
var TRANSITION_TRACKED_RULES = [
  ...TRANSITION_BASE_RULES,
  {
    name: "trackedRecord",
    check: (value, recordAt, recordCollector) => {
      checkClosed2(
        value,
        recordAt,
        [
          { name: "path", check: text },
          { name: "sha256", check: sha256 }
        ],
        recordCollector
      );
    }
  }
];
var transitionPayload = (payload, at, collector) => {
  const carriesRecord = Object.prototype.hasOwnProperty.call(payload, "trackedRecord");
  checkClosed2(payload, at, carriesRecord ? TRANSITION_TRACKED_RULES : TRANSITION_BASE_RULES, collector);
  if (carriesRecord && (payload["from"] !== "recording" || payload["to"] !== "ready")) {
    collector.emit(
      "unsupported_combination",
      `${at}/trackedRecord`,
      "the tracked-record digest rides only the recording -> ready transition"
    );
  }
};
var assertionConsumedPayload = (payload, at, collector) => {
  checkClosed2(
    payload,
    at,
    [
      { name: "assertion", check: embedded(validateSensitiveApprovalAssertion) },
      { name: "newRegisteringInstallationId", check: orAbsentByState(spineId) }
    ],
    collector
  );
  const declaredClass = assertionClassOf(payload["assertion"]);
  if (declaredClass === "maintenance-lane") {
    collector.emit(
      "unsupported_combination",
      `${at}/assertion/assertionClass`,
      "a maintenance-lane consumption is recorded in the maintenance journal, never the delivery journal"
    );
  }
  if (!isAbsentByState(payload["newRegisteringInstallationId"]) && declaredClass !== "security-blocked-migration") {
    collector.emit(
      "unsupported_combination",
      `${at}/newRegisteringInstallationId`,
      "only a rebinding security-blocked migration records a new registering-installation identity"
    );
  }
};
var maintenanceActionPayload = (payload, at, collector) => {
  checkClosed2(
    payload,
    at,
    [
      { name: "action", check: oneOf(MAINTENANCE_ACTIONS) },
      { name: "phase", check: oneOf(MAINTENANCE_PHASES) },
      { name: "generationDigest", check: orAbsentByState(sha256) },
      { name: "highWaterMark", check: orAbsentByState(nonNegativeInt) },
      { name: "assertion", check: orAbsentByState(embedded(validateSensitiveApprovalAssertion)) }
    ],
    collector
  );
  const action = payload["action"];
  const phase = payload["phase"];
  if (typeof action !== "string" || typeof phase !== "string") return;
  const phased = PHASED_MAINTENANCE_ACTIONS.includes(action);
  if (!phased && phase === "started") {
    collector.emit("unsupported_combination", `${at}/phase`, `${action} is an instant action; it records one completed entry`);
  }
  const sensitive = SENSITIVE_MAINTENANCE_ACTIONS.includes(action);
  const assertionRequired = sensitive && (phased ? phase === "started" : phase === "completed");
  const assertionValue = payload["assertion"];
  const assertionAbsent = assertionValue === void 0 || isAbsentByState(assertionValue);
  if (assertionRequired && assertionAbsent) {
    collector.emit(
      "unsupported_combination",
      `${at}/assertion`,
      `the sensitive ${action} action is recorded only under its consumed maintenance-lane assertion`
    );
  }
  if (!sensitive && !assertionAbsent) {
    collector.emit("unsupported_combination", `${at}/assertion`, `${action} is not in the sensitive set and consumes no assertion`);
  }
  if (!assertionAbsent && isSpineRecord(assertionValue)) {
    if (assertionClassOf(assertionValue) !== "maintenance-lane") {
      collector.emit(
        "unsupported_combination",
        `${at}/assertion/assertionClass`,
        "the maintenance journal records only maintenance-lane consumptions"
      );
    }
    if (assertionValue["action"] !== action) {
      collector.emit("unsupported_combination", `${at}/assertion/action`, "the consumed assertion approves a different action");
    }
    const boundGeneration = assertionValue["targetGenerationDigest"];
    if (typeof boundGeneration === "string" && !isAbsentByState(boundGeneration) && boundGeneration !== payload["generationDigest"]) {
      collector.emit(
        "unsupported_combination",
        `${at}/generationDigest`,
        "the consumed assertion approves a different target generation"
      );
    }
    const boundMark = assertionValue["targetHighWaterMark"];
    if (typeof boundMark === "number" && boundMark !== payload["highWaterMark"]) {
      collector.emit(
        "unsupported_combination",
        `${at}/highWaterMark`,
        "the consumed assertion approves a different high-water mark"
      );
    }
  }
};
var terminationProvenancePayload = (payload, at, collector) => {
  checkClosed2(
    payload,
    at,
    [
      { name: "fence", check: positiveInt },
      { name: "hostVersion", check: text },
      { name: "provenance", check: oneOf(TERMINATION_PROVENANCE_KINDS) },
      { name: "descendantTeardown", check: oneOf(DESCENDANT_TEARDOWN_STATUSES) },
      { name: "resumeEligibility", check: oneOf(RESUME_ELIGIBILITIES) }
    ],
    collector
  );
  if (payload["descendantTeardown"] === "unverified" && payload["resumeEligibility"] === "same-workspace") {
    collector.emit(
      "unsupported_combination",
      `${at}/resumeEligibility`,
      "same-workspace resume requires verified descendant teardown; an unverified teardown leaves the prior workspace unverified and resumes only into a fresh worktree"
    );
  }
};
var contractAmendedPayload = (payload, at, collector) => {
  checkClosed2(
    payload,
    at,
    [
      { name: "previousContractId", check: spineId },
      { name: "contractId", check: spineId },
      { name: "contractDigest", check: sha256 },
      { name: "criterionId", check: spineId },
      { name: "assertionNonce", check: spineId }
    ],
    collector
  );
  if (typeof payload["contractId"] === "string" && payload["contractId"] === payload["previousContractId"]) {
    collector.emit(
      "unsupported_combination",
      `${at}/contractId`,
      "a confirmed amendment creates a new contract identity; reusing the superseded identity is not an amendment"
    );
  }
};
var actionResultPayload = (payload, at, collector) => {
  checkClosed2(
    payload,
    at,
    [
      { name: "intentId", check: spineId },
      { name: "action", check: oneOf(EXTERNAL_ACTIONS) },
      { name: "outcome", check: oneOf(EXTERNAL_ACTION_OUTCOMES) },
      { name: "verification", check: oneOf(ACTION_VERIFICATIONS) },
      { name: "externalReference", check: orAbsentByState(boundedText) }
    ],
    collector
  );
  if (payload["verification"] === "passed" && payload["outcome"] !== "succeeded") {
    collector.emit(
      "unsupported_combination",
      `${at}/verification`,
      "post-action verification passes only over a succeeded action; a failed or indeterminate action carries no passing evidence"
    );
  }
};
var PAYLOADS = Object.freeze({
  "intake/intake.state.changed": table([
    { name: "from", check: oneOf(INTAKE_STATES) },
    { name: "to", check: oneOf(INTAKE_STATES) }
  ]),
  "intake/operator.confirmation.recorded": confirmationPayload("contract-confirmation"),
  // The iterative-intake payload family, frozen by its owning unit. A
  // clarification is one question-and-answer exchange of the product-owned
  // scope workflow; a draft record retains the current draft contract by
  // digest (the bytes live in the intake namespace; the journal is the audit
  // rail and digest binding). The reducer gates both to the intake states the
  // spine froze as discriminators.
  "intake/intake.clarification.recorded": table([
    { name: "question", check: boundedText },
    { name: "answer", check: boundedText }
  ]),
  "intake/intake.draft.recorded": table([{ name: "draftDigest", check: sha256 }]),
  "delivery/delivery.registered": table([
    { name: "contractDigest", check: sha256 },
    { name: "intakeId", check: spineId },
    { name: "confirmationNonce", check: spineId },
    { name: "activeCompositionProfile", check: text },
    { name: "registeringInstallationId", check: spineId }
  ]),
  "delivery/workspace.bound": table([
    { name: "workspaceId", check: spineId },
    { name: "repositoryId", check: spineId },
    { name: "baseRef", check: text },
    { name: "baseTipSha", check: gitOid },
    { name: "branchRef", check: text },
    { name: "branchRefValue", check: gitOid },
    { name: "worktreeId", check: spineId },
    { name: "baselineClassification", check: oneOf(["clean", "classified"]) }
  ]),
  "delivery/invocation.fenced": table([
    { name: "fence", check: positiveInt },
    { name: "hostTaskId", check: spineId },
    { name: "worktreeId", check: spineId },
    { name: "candidateTreeSha", check: gitOid },
    { name: "candidateBranchRefValue", check: gitOid },
    { name: "policyDigest", check: sha256 },
    { name: "authorityEpoch", check: nonNegativeInt },
    { name: "observationLifetimeSeconds", check: positiveInt }
  ]),
  "delivery/activity.observed": table([
    { name: "activity", check: oneOf(HOST_ACTIVITY_STATES) },
    { name: "fence", check: positiveInt }
  ]),
  "delivery/operator.confirmation.recorded": confirmationPayload("takeover-authorization"),
  "delivery/approval.request.recorded": table([
    { name: "requestKind", check: oneOf(APPROVAL_REQUEST_KINDS) },
    { name: "criterionId", check: spineId },
    { name: "actorId", check: spineId },
    { name: "reason", check: boundedText }
  ]),
  "delivery/operation.result.recorded": operationResultPayload,
  "delivery/workspace.disposition.recorded": table([
    { name: "workspaceId", check: spineId },
    { name: "disposition", check: oneOf(WORKSPACE_DISPOSITIONS) }
  ]),
  "delivery/transition.committed": transitionPayload,
  "delivery/stage.result.recorded": table([
    { name: "stageId", check: spineId },
    { name: "workflowGraphSha256", check: sha256 },
    { name: "resultDigest", check: sha256 }
  ]),
  "delivery/attempt.artifact.recorded": table([
    { name: "attemptId", check: spineId },
    { name: "lensId", check: spineId },
    { name: "contextDigest", check: sha256 },
    { name: "personaDigest", check: sha256 },
    { name: "artifactDigest", check: sha256 }
  ]),
  "delivery/evidence.reference.recorded": table([
    { name: "recordId", check: sha256 },
    { name: "manifestDigest", check: sha256 }
  ]),
  "delivery/candidate.recaptured": table([
    { name: "treeSha", check: gitOid },
    { name: "branchRefValue", check: gitOid }
  ]),
  "delivery/policy.snapshot.bound": table([
    { name: "policyDigest", check: sha256 },
    { name: "repositoryAuthorityEpoch", check: nonNegativeInt },
    { name: "policyBindingDigest", check: sha256, required: false }
  ]),
  "delivery/generation.pinned": table([
    { name: "generationDigest", check: sha256 },
    { name: "releaseId", check: spineId },
    { name: "profile", check: text }
  ]),
  "delivery/trust.epoch.observed": table([
    { name: "productTrustEpoch", check: nonNegativeInt },
    { name: "repositoryAuthorityEpoch", check: nonNegativeInt }
  ]),
  "delivery/blocker.recorded": table([
    { name: "code", check: spineId },
    { name: "summary", check: boundedText },
    { name: "providerRunKey", check: sha256, required: false }
  ]),
  "delivery/finish.line.recorded": table([{ name: "result", check: embedded(validateFinishLineResult) }]),
  // The post-action family. The intent is the durable record the host writes
  // BEFORE invoking an authorized external action — it binds the action, the
  // candidate it is taken against, the policy that authorized it, and whether
  // an approval was required — so an action can never be observed without a
  // prior statement of what was about to happen.
  "delivery/action.intent.recorded": table([
    { name: "intentId", check: spineId },
    { name: "action", check: oneOf(EXTERNAL_ACTIONS) },
    {
      name: "candidate",
      check: closed([
        { name: "treeSha", check: gitOid },
        { name: "deliverableDigest", check: sha256 }
      ])
    },
    { name: "policyDigest", check: sha256 },
    { name: "approval", check: oneOf(ACTION_APPROVALS) }
  ]),
  "delivery/action.result.recorded": actionResultPayload,
  "delivery/termination.provenance.recorded": terminationProvenancePayload,
  "delivery/approval.assertion.consumed": assertionConsumedPayload,
  "delivery/contract.amended": contractAmendedPayload,
  "maintenance/maintenance.action.recorded": maintenanceActionPayload,
  // The retention/export/deletion contract family. The record names its
  // target delivery, digests the produced artifact (the export bundle, or the
  // preserved minimal audit record a deletion leaves behind), and reports
  // which audit records policy required preserving — and it lives in the
  // installation-scoped maintenance journal precisely so it survives the
  // target's removal.
  "maintenance/retention.action.recorded": table([
    { name: "action", check: oneOf(RETENTION_ACTIONS) },
    { name: "subjectDeliveryId", check: spineId },
    { name: "artifactDigest", check: sha256 },
    { name: "preservedAuditRecords", check: stringArray() }
  ])
});
var ENVELOPE_RULES = [
  { name: "spec", check: specLiteral(JOURNAL_ENTRY_SPEC) },
  { name: "journal", check: oneOf(JOURNALS) },
  { name: "subjectId", check: spineId },
  { name: "expectedRevision", check: nonNegativeInt },
  { name: "idempotencyKey", check: spineId },
  { name: "kind", check: text }
  // `payload` is validated per (journal, kind) below; its presence rule
  // depends on the kind's classification, so it is not in this table.
];
function validateJournalEntry(value) {
  const collector = createSpineCollector();
  if (!isSpineRecord(value)) {
    collector.emit("not_an_object", "", "expected a JSON object");
    return collector.verdict();
  }
  const defined = /* @__PURE__ */ new Set([...ENVELOPE_RULES.map((rule) => rule.name), "payload"]);
  for (const name of Object.keys(value)) {
    if (!defined.has(name)) {
      collector.emit("unknown_member", `/${name}`, "member is not defined by this frozen grammar");
    }
  }
  for (const rule of ENVELOPE_RULES) {
    if (!Object.prototype.hasOwnProperty.call(value, rule.name) || value[rule.name] === void 0) {
      collector.emit("missing_member", `/${rule.name}`, "required member is absent");
      continue;
    }
    rule.check(value[rule.name], `/${rule.name}`, collector);
  }
  const journal = value["journal"];
  const kind = value["kind"];
  if (typeof journal !== "string" || typeof kind !== "string") return collector.verdict();
  const classification = classifyEventKind(journal, kind);
  if (classification.status === "reserved") {
    collector.emit(
      "reserved_kind",
      "/kind",
      `${kind} is reserved in the ${journal} journal until its owning unit defines its payload; it rejects with or without a payload`
    );
    return collector.verdict();
  }
  if (classification.status === "unknown") {
    const elsewhere = classification.knownIn.length > 0 ? ` (enumerated only in: ${classification.knownIn.join(", ")})` : "";
    collector.emit(
      "unknown_kind",
      "/kind",
      `(${journal}, ${kind}) is outside the frozen event vocabulary${elsewhere}`
    );
    return collector.verdict();
  }
  const payload = value["payload"];
  if (!isSpineRecord(payload)) {
    collector.emit("missing_member", "/payload", "an active kind requires its frozen payload object");
    return collector.verdict();
  }
  const check = PAYLOADS[`${journal}/${kind}`];
  if (check === void 0) {
    collector.emit("unknown_kind", "/kind", `no frozen payload table for active pair (${journal}, ${kind})`);
    return collector.verdict();
  }
  check(payload, "/payload", collector);
  return collector.verdict();
}

// packages/kernel/src/spine/reducer.ts
var DELIVERY_TRANSITION_TABLE = Object.freeze([
  { from: "accepted", to: "preparing", condition: "Composition, policy, host integration, and workspace-binding preflight pass" },
  { from: "preparing", to: "planning", condition: "Host-supplied isolated workspace and initial checkpoint are durable" },
  { from: "planning", to: "implementing", condition: "Plan output is accepted" },
  { from: "implementing", to: "validating", condition: "Versioned candidate checkpoint created" },
  { from: "validating", to: "remediating", condition: "Required sensor fails or implementation repair is needed" },
  { from: "validating", to: "reviewing", condition: "Required sensors pass on current candidate" },
  { from: "reviewing", to: "remediating", condition: "Actionable finding exists" },
  { from: "remediating", to: "validating", condition: "Any candidate mutation is checkpointed" },
  { from: "reviewing", to: "compounding", condition: "Every selected lens approves the current candidate" },
  { from: "compounding", to: "admitting", condition: "No repository mutation" },
  { from: "compounding", to: "validating", condition: "Candidate changes" },
  { from: "admitting", to: "recording", condition: "Current preparation and all activated obligations pass" },
  { from: "recording", to: "ready", condition: "Tracked record is checkpoint-committed and both-neutral verification passes" },
  { from: "recording", to: "validating", condition: "Any non-neutral byte or identity changes" },
  { from: "ready", to: "completed", condition: "Finish line is merge-ready and repository merge-ready obligations pass" },
  { from: "ready", to: "awaiting_approval", condition: "Explicitly authorized merge/deploy action remains and policy requires an approval for that action" },
  { from: "ready", to: "acting", condition: "Explicitly authorized merge/deploy action remains and no approval is required" },
  { from: "awaiting_approval", to: "acting", condition: "Valid user-originated approval is consumed and all bindings remain current" },
  { from: "awaiting_approval", to: "blocked", condition: "Approval denied, expired, revoked, or unavailable (per policy)" },
  { from: "awaiting_approval", to: "cancelled", condition: "Approval denied, expired, revoked, or unavailable (per policy)" },
  { from: "awaiting_approval", to: "validating", condition: "Candidate, base, policy, authority epoch, or invocation fence changes" },
  { from: "acting", to: "completed", condition: "Action is reconciled and required post-action evidence passes" },
  { from: "acting", to: "acting", condition: "Action is reconciled; the next authorized acting step remains" },
  { from: "acting", to: "action_succeeded_verification_failed", condition: "External action succeeded but required verification failed" }
]);
var isTerminal = (state) => TERMINAL_DELIVERY_STATES.includes(state);
var isSuspended = (state) => SUSPENDED_DELIVERY_STATES.includes(state);
function isDeliveryTransitionValid(from, to) {
  if (isTerminal(from)) return false;
  if (to === "failed") return false;
  if (DELIVERY_TRANSITION_TABLE.some((row) => row.from === from && row.to === to)) return true;
  if (to === "security_blocked") return from !== "security_blocked";
  if (to === "cancellation_requested") return from !== "cancellation_requested";
  if (from === "cancellation_requested" && to === "cancelled") return true;
  if (from === "security_blocked" && to === "preparing") return true;
  if (to === "blocked") return !isSuspended(from);
  return false;
}
var INTAKE_CHAIN = [
  ["draft_scope", "awaiting_clarification"],
  ["awaiting_clarification", "awaiting_confirmation"],
  ["awaiting_confirmation", "validating_acceptance"],
  ["validating_acceptance", "accepted_contract"]
];
var INTAKE_TERMINAL = ["accepted_contract", "abandoned"];
function isIntakeTransitionValid(from, to) {
  if (INTAKE_TERMINAL.includes(from)) return false;
  if (INTAKE_CHAIN.some(([chainFrom, chainTo]) => chainFrom === from && chainTo === to)) return true;
  if (from === "validating_acceptance" && to === "blocked") return true;
  if (from === "blocked" && to === "validating_acceptance") return true;
  if (from === "validating_acceptance" && to === "awaiting_confirmation") return true;
  if (to === "abandoned") return true;
  return false;
}
function reduceDeliveryJournal(entries) {
  const collector = createSpineCollector();
  let deliveryId;
  let state = "accepted";
  let expectedRevision = 0;
  let lastFence = 0;
  let policyDigest;
  let policyBindingDigest;
  let authorityEpoch;
  let generationDigest;
  let contractId;
  let lastActiveState = "accepted";
  let registered = false;
  let finishLineRecorded = false;
  const idempotencyKeys = /* @__PURE__ */ new Set();
  const actionIntents = /* @__PURE__ */ new Map();
  let lastActionVerification;
  let lastActionOutcome;
  entries.forEach((value, index) => {
    const at = `/${index}`;
    const shape = validateJournalEntry(value);
    if (!shape.ok) {
      for (const rejection of shape.rejections) collector.emit(rejection.code, `${at}${rejection.pointer}`, rejection.message);
      return;
    }
    const entry3 = value;
    if (entry3["journal"] !== "delivery") {
      collector.emit("unsupported_combination", `${at}/journal`, "the delivery reducer consumes only delivery-journal entries");
      return;
    }
    const kind = entry3["kind"];
    const subjectId = entry3["subjectId"];
    const revision = entry3["expectedRevision"];
    const idempotencyKey = entry3["idempotencyKey"];
    const payload = entry3["payload"];
    if (!registered) {
      if (kind !== "delivery.registered") {
        collector.emit("registration_missing", at, "the first delivery-journal entry must be delivery.registered");
        return;
      }
    } else if (kind === "delivery.registered") {
      collector.emit("unsupported_combination", `${at}/kind`, "a delivery registers exactly once");
      return;
    }
    if (deliveryId === void 0) {
      deliveryId = subjectId;
    } else if (subjectId !== deliveryId) {
      collector.emit("subject_mismatch", `${at}/subjectId`, `entry names ${subjectId}; this journal belongs to ${deliveryId}`);
      return;
    }
    if (isTerminal(state)) {
      collector.emit("journal_terminal", at, `the delivery is ${state}; a terminal journal accepts no further entries`);
      return;
    }
    if (idempotencyKeys.has(idempotencyKey)) {
      collector.emit("duplicate_idempotency_key", `${at}/idempotencyKey`, `key ${idempotencyKey} was already consumed; a replay is detected, never double-applied`);
      return;
    }
    if (revision !== expectedRevision) {
      collector.emit(
        "revision_mismatch",
        `${at}/expectedRevision`,
        `entry expects revision ${revision}; the journal is at ${expectedRevision}`
      );
      return;
    }
    switch (kind) {
      case "invocation.fenced": {
        const fence = payload["fence"];
        if (fence <= lastFence) {
          collector.emit("non_monotonic_fence", `${at}/payload/fence`, `fence ${fence} does not exceed the current fence ${lastFence}; outputs from an older fence are permanently rejected`);
          return;
        }
        lastFence = fence;
        break;
      }
      case "activity.observed": {
        const fence = payload["fence"];
        if (fence !== lastFence) {
          collector.emit("fence_mismatch", `${at}/payload/fence`, `observation names fence ${fence}; the current fence is ${lastFence}`);
          return;
        }
        break;
      }
      case "approval.request.recorded": {
        if (state !== "reviewing" && state !== "remediating" && state !== "admitting") {
          collector.emit(
            "invalid_transition",
            at,
            `an approval proposal is journaled within reviewing, remediating, or admitting; the delivery is in ${state}`
          );
          return;
        }
        break;
      }
      case "contract.amended": {
        if (state !== "reviewing" && state !== "remediating" && state !== "admitting") {
          collector.emit(
            "invalid_transition",
            at,
            `a confirmed amendment is journaled within reviewing, remediating, or admitting; the delivery is in ${state}`
          );
          return;
        }
        const previous = payload["previousContractId"];
        if (contractId !== void 0 && previous !== contractId) {
          collector.emit(
            "subject_mismatch",
            `${at}/payload/previousContractId`,
            `the amendment supersedes ${previous}; this delivery's contract identity is ${contractId}`
          );
          return;
        }
        contractId = payload["contractId"];
        break;
      }
      case "policy.snapshot.bound": {
        policyDigest = payload["policyDigest"];
        const bindingDigest = payload["policyBindingDigest"];
        if (bindingDigest !== void 0) policyBindingDigest = bindingDigest;
        authorityEpoch = payload["repositoryAuthorityEpoch"];
        break;
      }
      case "generation.pinned": {
        generationDigest = payload["generationDigest"];
        break;
      }
      case "finish.line.recorded": {
        if (state !== "ready") {
          collector.emit(
            "invalid_transition",
            at,
            `a finish-line result is recorded in ready; the delivery is in ${state}`
          );
          return;
        }
        const result2 = payload["result"];
        if (isSpineRecord(result2) && result2["deliveryId"] !== deliveryId) {
          collector.emit(
            "subject_mismatch",
            `${at}/payload/result/deliveryId`,
            `the result names delivery ${String(result2["deliveryId"])}; this journal belongs to ${deliveryId}`
          );
          return;
        }
        finishLineRecorded = true;
        break;
      }
      case "action.intent.recorded": {
        if (state !== "acting") {
          collector.emit("invalid_transition", at, `an action intent is recorded while acting; the delivery is in ${state}`);
          return;
        }
        const intentId = payload["intentId"];
        if (actionIntents.has(intentId)) {
          collector.emit("unsupported_combination", `${at}/payload/intentId`, `intent ${intentId} was already recorded`);
          return;
        }
        const unreconciled = [...actionIntents.entries()].find(
          ([, each]) => each.outcome !== "succeeded" || each.verification !== "passed"
        );
        if (unreconciled !== void 0) {
          collector.emit(
            "invalid_transition",
            at,
            `intent ${unreconciled[0]} is ${unreconciled[1].verification === void 0 ? "still unobserved" : `observed as ${String(unreconciled[1].outcome)}/${String(unreconciled[1].verification)}`}; the next acting step begins only once every prior action is reconciled`
          );
          return;
        }
        actionIntents.set(intentId, { action: payload["action"] });
        lastActionVerification = void 0;
        lastActionOutcome = void 0;
        break;
      }
      case "action.result.recorded": {
        const intentId = payload["intentId"];
        if (state !== "acting") {
          collector.emit("invalid_transition", at, `an action result is recorded while acting; the delivery is in ${state}`);
          return;
        }
        const intent = actionIntents.get(intentId);
        if (intent === void 0) {
          collector.emit(
            "invalid_transition",
            `${at}/payload/intentId`,
            `no intent ${intentId} was recorded; an external action is never observed without its prior intent`
          );
          return;
        }
        if (intent.verification !== void 0) {
          collector.emit(
            "unsupported_combination",
            `${at}/payload/intentId`,
            `intent ${intentId} already carries an observed result; an irreversible action is never repeated`
          );
          return;
        }
        if (intent.action !== payload["action"]) {
          collector.emit(
            "unsupported_combination",
            `${at}/payload/action`,
            `intent ${intentId} was recorded for ${intent.action}; a result cannot observe a different action`
          );
          return;
        }
        intent.outcome = payload["outcome"];
        intent.verification = payload["verification"];
        lastActionOutcome = intent.outcome;
        lastActionVerification = intent.verification;
        break;
      }
      case "transition.committed": {
        const from = payload["from"];
        const to = payload["to"];
        if (from !== state) {
          collector.emit("invalid_transition", `${at}/payload/from`, `transition leaves ${from}; the delivery is in ${state}`);
          return;
        }
        if (from === "ready" && to === "completed" && !finishLineRecorded) {
          collector.emit(
            "invalid_transition",
            `${at}/payload/to`,
            "terminal success requires a recorded merge-ready finish-line result; a green review alone completes nothing"
          );
          return;
        }
        if (from === "acting" && (to === "completed" || to === "action_succeeded_verification_failed")) {
          const wanted = to === "completed" ? "passed" : "failed";
          if (lastActionOutcome !== "succeeded" || lastActionVerification !== wanted) {
            collector.emit(
              "invalid_transition",
              `${at}/payload/to`,
              `acting -> ${to} requires the LAST observed action result to be succeeded/${wanted}; it is ${lastActionOutcome ?? "unobserved"}/${lastActionVerification ?? "unobserved"}`
            );
            return;
          }
        }
        const blockedResume = from === "blocked" && to === lastActiveState;
        if (!blockedResume && !isDeliveryTransitionValid(from, to)) {
          collector.emit(
            "invalid_transition",
            `${at}/payload/to`,
            from === "blocked" ? `a blocked delivery resumes from its last trustworthy checkpoint (${lastActiveState}), not ${to}` : `${from} -> ${to} is outside the frozen transition matrix`
          );
          return;
        }
        if (from === "ready" && to !== "completed") finishLineRecorded = false;
        if (!isSuspended(state) && !isTerminal(state)) lastActiveState = state;
        state = to;
        break;
      }
      default:
        break;
    }
    idempotencyKeys.add(idempotencyKey);
    if (kind === "delivery.registered") registered = true;
    const classification = classifyEventKind("delivery", kind);
    const observationOnly = classification.status === "active" && classification.observationOnly;
    if (!observationOnly) expectedRevision += 1;
  });
  const verdict = collector.verdict();
  if (!verdict.ok) return verdict;
  if (!registered || deliveryId === void 0) {
    return {
      ok: false,
      rejections: [{ code: "registration_missing", pointer: "", message: "an empty journal has no registered delivery" }]
    };
  }
  const base = {
    deliveryId,
    state,
    expectedRevision,
    lastFence,
    lastActiveState,
    ...policyDigest === void 0 ? {} : { policyDigest },
    ...policyBindingDigest === void 0 ? {} : { policyBindingDigest },
    ...authorityEpoch === void 0 ? {} : { authorityEpoch },
    ...generationDigest === void 0 ? {} : { generationDigest },
    ...contractId === void 0 ? {} : { contractId }
  };
  return { ok: true, state: base };
}
function reduceMaintenanceJournal(entries) {
  const collector = createSpineCollector();
  let subjectId;
  let expectedRevision = 0;
  const idempotencyKeys = /* @__PURE__ */ new Set();
  entries.forEach((value, index) => {
    const at = `/${index}`;
    const shape = validateJournalEntry(value);
    if (!shape.ok) {
      for (const rejection of shape.rejections) collector.emit(rejection.code, `${at}${rejection.pointer}`, rejection.message);
      return;
    }
    const entry3 = value;
    if (entry3["journal"] !== "maintenance") {
      collector.emit("unsupported_combination", `${at}/journal`, "the maintenance reducer consumes only maintenance-journal entries");
      return;
    }
    const subject = entry3["subjectId"];
    const revision = entry3["expectedRevision"];
    const idempotencyKey = entry3["idempotencyKey"];
    if (subjectId === void 0) {
      subjectId = subject;
    } else if (subject !== subjectId) {
      collector.emit("subject_mismatch", `${at}/subjectId`, `entry names ${subject}; this journal belongs to ${subjectId}`);
      return;
    }
    if (idempotencyKeys.has(idempotencyKey)) {
      collector.emit("duplicate_idempotency_key", `${at}/idempotencyKey`, `key ${idempotencyKey} was already consumed`);
      return;
    }
    if (revision !== expectedRevision) {
      collector.emit("revision_mismatch", `${at}/expectedRevision`, `entry expects revision ${revision}; the journal is at ${expectedRevision}`);
      return;
    }
    idempotencyKeys.add(idempotencyKey);
    expectedRevision += 1;
  });
  const verdict = collector.verdict();
  if (!verdict.ok) return verdict;
  if (subjectId === void 0) {
    return { ok: false, rejections: [{ code: "registration_missing", pointer: "", message: "an empty maintenance journal names no installation" }] };
  }
  return { ok: true, state: { subjectId, expectedRevision } };
}
function reduceIntakeJournal(entries) {
  const collector = createSpineCollector();
  let intakeId;
  let state = "draft_scope";
  let expectedRevision = 0;
  let contractConfirmed = false;
  let clarificationCount = 0;
  let lastDraftDigest;
  const idempotencyKeys = /* @__PURE__ */ new Set();
  entries.forEach((value, index) => {
    const at = `/${index}`;
    const shape = validateJournalEntry(value);
    if (!shape.ok) {
      for (const rejection of shape.rejections) collector.emit(rejection.code, `${at}${rejection.pointer}`, rejection.message);
      return;
    }
    const entry3 = value;
    if (entry3["journal"] !== "intake") {
      collector.emit("unsupported_combination", `${at}/journal`, "the intake reducer consumes only intake-journal entries");
      return;
    }
    const kind = entry3["kind"];
    const subjectId = entry3["subjectId"];
    const revision = entry3["expectedRevision"];
    const idempotencyKey = entry3["idempotencyKey"];
    const payload = entry3["payload"];
    if (intakeId === void 0) {
      intakeId = subjectId;
    } else if (subjectId !== intakeId) {
      collector.emit("subject_mismatch", `${at}/subjectId`, `entry names ${subjectId}; this journal belongs to ${intakeId}`);
      return;
    }
    if (INTAKE_TERMINAL.includes(state)) {
      collector.emit("journal_terminal", at, `intake is ${state}; a terminal journal accepts no further entries`);
      return;
    }
    if (idempotencyKeys.has(idempotencyKey)) {
      collector.emit("duplicate_idempotency_key", `${at}/idempotencyKey`, `key ${idempotencyKey} was already consumed`);
      return;
    }
    if (revision !== expectedRevision) {
      collector.emit("revision_mismatch", `${at}/expectedRevision`, `entry expects revision ${revision}; the journal is at ${expectedRevision}`);
      return;
    }
    if (kind === "intake.state.changed") {
      const from = payload["from"];
      const to = payload["to"];
      if (from !== state) {
        collector.emit("invalid_transition", `${at}/payload/from`, `transition leaves ${from}; intake is in ${state}`);
        return;
      }
      if (!isIntakeTransitionValid(from, to)) {
        collector.emit("invalid_transition", `${at}/payload/to`, `${from} -> ${to} is outside the frozen intake chain`);
        return;
      }
      state = to;
    }
    if (kind === "operator.confirmation.recorded") {
      if (state !== "awaiting_confirmation") {
        collector.emit("invalid_transition", at, `a contract confirmation is consumed in awaiting_confirmation; intake is in ${state}`);
        return;
      }
      const confirmation = payload["confirmation"];
      if (isSpineRecord(confirmation) && confirmation["intakeDraftId"] !== subjectId) {
        collector.emit("subject_mismatch", `${at}/payload/confirmation/intakeDraftId`, "the confirmation binds a different intake draft");
        return;
      }
      if (isSpineRecord(confirmation) && lastDraftDigest !== void 0 && typeof confirmation["normalizedContractDigest"] === "string" && confirmation["normalizedContractDigest"] !== lastDraftDigest) {
        collector.emit(
          "digest_mismatch",
          `${at}/payload/confirmation/normalizedContractDigest`,
          "the confirmation binds a digest other than the retained draft's; a draft mutated after presentation voids the pending confirmation"
        );
        return;
      }
      contractConfirmed = true;
    }
    if (kind === "intake.clarification.recorded") {
      if (state !== "awaiting_clarification") {
        collector.emit("invalid_transition", at, `a clarification is retained in awaiting_clarification; intake is in ${state}`);
        return;
      }
      clarificationCount += 1;
    }
    if (kind === "intake.draft.recorded") {
      if (state !== "draft_scope" && state !== "awaiting_clarification" && state !== "awaiting_confirmation") {
        collector.emit("invalid_transition", at, `a draft is retained before acceptance validation begins; intake is in ${state}`);
        return;
      }
      lastDraftDigest = payload["draftDigest"];
    }
    idempotencyKeys.add(idempotencyKey);
    expectedRevision += 1;
  });
  const verdict = collector.verdict();
  if (!verdict.ok) return verdict;
  if (intakeId === void 0) {
    return { ok: false, rejections: [{ code: "registration_missing", pointer: "", message: "an empty intake journal names no draft" }] };
  }
  return {
    ok: true,
    state: {
      intakeId,
      state,
      expectedRevision,
      contractConfirmed,
      clarificationCount,
      ...lastDraftDigest === void 0 ? {} : { lastDraftDigest }
    }
  };
}

// packages/kernel/src/substrate/manifest.ts
var COMPOSITION_MANIFEST_SPEC = "composition-manifest/1";
var COMPOSITION_PROFILES = Object.freeze(["production", "confirmation-fixture"]);
var CONFIRMATION_FIXTURE_PROFILE = "confirmation-fixture";
var SUPPORTED_CONTRACT_VERSIONS = Object.freeze({
  policy: "policy-snapshot/1",
  scopedWork: "scoped-delivery-contract/1",
  run: "journal-entry/1",
  workflowResult: "stage-result-ref/1",
  event: "journal-entry/1",
  controlPlane: "reserved/0"
});
var sortedInventory = (inventory) => [...inventory].map((entry3) => ({ path: entry3.path, sha256: entry3.sha256 })).sort((a, b) => compareUtf16CodeUnits(a.path, b.path));
function buildCompositionManifest(input) {
  const inventory = sortedInventory(input.inventory);
  return {
    spec: COMPOSITION_MANIFEST_SPEC,
    compositionProfile: input.compositionProfile,
    compositionSequence: input.compositionSequence,
    pin: {
      spec: PRODUCT_COMPOSITION_PIN_SPEC,
      productVersion: input.productVersion,
      distributionDigest: digestCanonical(inventory),
      harnessModuleVersions: { ...input.harnessModuleVersions },
      skillsArchive: { ...PINNED_AGENT_SKILLS },
      contractVersions: { ...SUPPORTED_CONTRACT_VERSIONS },
      productTrustLabel: PRODUCT_TRUST_LABEL
    },
    inventory
  };
}
function compositionManifestBytes(manifest) {
  return canonicalize(manifest);
}
function generationDigestOf(manifestBytes) {
  return sha256Hex(manifestBytes);
}
var isNormalizedRelativePath = (value) => value.length > 0 && !value.startsWith("/") && !value.includes("\\") && !value.includes("\0") && !/^[A-Za-z]:/.test(value) && !value.split("/").some((segment) => segment === ".." || segment === "." || segment === "");
var inventoryMember = (value, at, collector) => {
  if (!Array.isArray(value)) {
    collector.emit("malformed_member", at, "expected an array of inventory entries");
    return;
  }
  if (value.length === 0) {
    collector.emit("malformed_member", at, "a composition binds at least one file");
    return;
  }
  let previousPath;
  value.forEach((entry3, index) => {
    const entryAt = `${at}/${index}`;
    checkClosed2(
      entry3,
      entryAt,
      [
        { name: "path", check: text },
        { name: "sha256", check: sha256 }
      ],
      collector
    );
    if (!isSpineRecord(entry3) || typeof entry3["path"] !== "string") return;
    const entryPath = entry3["path"];
    if (!isNormalizedRelativePath(entryPath)) {
      collector.emit("malformed_member", `${entryAt}/path`, "expected a normalized '/'-separated relative path");
      return;
    }
    if (previousPath !== void 0 && compareUtf16CodeUnits(previousPath, entryPath) >= 0) {
      collector.emit(
        "malformed_member",
        `${entryAt}/path`,
        "inventory paths must be strictly ascending \u2014 unordered or duplicated entries break determinism"
      );
    }
    previousPath = entryPath;
  });
};
var MANIFEST_RULES = [
  { name: "spec", check: specLiteral(COMPOSITION_MANIFEST_SPEC) },
  { name: "compositionProfile", check: oneOf(COMPOSITION_PROFILES) },
  { name: "compositionSequence", check: nonNegativeInt },
  {
    name: "pin",
    check: (value, at, collector) => {
      const verdict = validateCompositionPin(value);
      if (verdict.ok) return;
      for (const rejection of verdict.rejections) {
        collector.emit(rejection.code, `${at}${rejection.pointer}`, rejection.message);
      }
    }
  },
  { name: "inventory", check: inventoryMember }
];
function validateCompositionManifest(value) {
  const collector = createSpineCollector();
  checkClosed2(value, "", MANIFEST_RULES, collector);
  const verdict = collector.verdict();
  const rejections = verdict.ok ? [] : [...verdict.rejections];
  if (isSpineRecord(value) && Array.isArray(value["inventory"]) && isSpineRecord(value["pin"])) {
    const declared = value["pin"]["distributionDigest"];
    if (typeof declared === "string" && rejections.length === 0) {
      let computed;
      try {
        computed = digestCanonical(value["inventory"]);
      } catch {
        computed = void 0;
      }
      if (computed !== declared) {
        rejections.push({
          code: "closure_digest_mismatch",
          pointer: "/pin/distributionDigest",
          message: "the pin's distribution digest does not bind the inventory as written"
        });
      }
    }
  }
  return rejections.length === 0 ? { ok: true } : { ok: false, rejections };
}

// packages/kernel/src/substrate/trust-store.ts
var OTHER_INSTALLATION_ARTIFACTS = Object.freeze([
  "generation-root",
  "update-journal",
  "active-pointer",
  "rollback-pointer"
]);
function parseTrustState(textContent) {
  let parsed;
  try {
    parsed = JSON.parse(textContent);
  } catch {
    return { ok: false, code: "trust_state_corrupt", message: "the trust store's bytes are not JSON" };
  }
  const verdict = validateProductTrustState(parsed);
  if (!verdict.ok) {
    const detail = verdict.rejections.map((rejection) => `${rejection.pointer || "/"}: ${rejection.message}`).join("; ");
    return {
      ok: false,
      code: "trust_state_corrupt",
      message: `the trust store is outside the product-trust-state/1 grammar (${detail})`
    };
  }
  return { ok: true, state: parsed };
}
function discriminateInstall(presence) {
  if (presence.trustStore === "valid" && presence.receipt === "valid") return { kind: "adopt" };
  if (presence.trustStore === "absent" && presence.receipt === "absent" && presence.otherArtifacts.length === 0) {
    return { kind: "first_install" };
  }
  const observed = [
    `trust store ${presence.trustStore}`,
    `install receipt ${presence.receipt}`,
    ...presence.otherArtifacts.length > 0 ? [`surviving artifacts: ${presence.otherArtifacts.join(", ")}`] : []
  ].join("; ");
  return {
    kind: "fail_closed",
    code: "prior_installation_artifacts",
    message: `installation artifacts imply a prior trust store, so epoch zero is not re-initialized (${observed})`
  };
}
function checkNoDowngrade(compositionSequence, highWaterMark) {
  if (compositionSequence >= highWaterMark) return { ok: true };
  return {
    ok: false,
    code: "downgrade_rejected",
    message: `composition sequence ${compositionSequence} is below the persisted high-water mark ${highWaterMark}; an older archive can never silently replace the active generation`
  };
}

// packages/kernel/src/substrate/installer.ts
import { randomBytes as randomBytes2 } from "node:crypto";
import { chmod as chmod7, mkdir as mkdir7, readFile as readFile9, readdir as readdir2, rename as rename3, stat as stat4, writeFile as writeFile6 } from "node:fs/promises";
import path11 from "node:path";
init_assertion_source();

// packages/kernel/src/substrate/maintenance-journal.ts
import { appendFile, chmod as chmod6, mkdir as mkdir6, readFile as readFile8 } from "node:fs/promises";
import path10 from "node:path";
var OWNER_DIR3 = 448;
var OWNER_FILE3 = 384;
function maintenanceJournalPathFor(installationPath) {
  return path10.join(installationPath, "journal", "maintenance.jsonl");
}
async function readMaintenanceJournal(installationPath) {
  let text4;
  try {
    text4 = await readFile8(maintenanceJournalPathFor(installationPath), "utf8");
  } catch {
    return { ok: true, entries: [] };
  }
  const entries = [];
  for (const [index, line] of text4.split("\n").filter((candidate2) => candidate2.length > 0).entries()) {
    let parsed;
    try {
      parsed = JSON.parse(line);
    } catch {
      return { ok: false, message: `maintenance journal line ${index} is not JSON; corrupt durable bytes fail closed` };
    }
    const verdict = validateJournalEntry(parsed);
    if (!verdict.ok) {
      return {
        ok: false,
        message: `maintenance journal line ${index} is outside the frozen grammar: ${verdict.rejections.map((rejection) => rejection.message).join("; ")}`
      };
    }
    const record2 = parsed;
    if (record2["journal"] !== "maintenance") {
      return { ok: false, message: `maintenance journal line ${index} belongs to the ${String(record2["journal"])} journal` };
    }
    entries.push({
      subjectId: record2["subjectId"],
      expectedRevision: record2["expectedRevision"],
      payload: record2["payload"]
    });
  }
  return { ok: true, entries };
}
async function appendMaintenanceAction(installationPath, installationId, payload) {
  const read = await readMaintenanceJournal(installationPath);
  if (!read.ok) return read;
  const expectedRevision = read.entries.length;
  const first2 = read.entries[0];
  if (first2 !== void 0 && first2.subjectId !== installationId) {
    return { ok: false, message: `this maintenance journal belongs to ${first2.subjectId}, not ${installationId}` };
  }
  const entry3 = {
    spec: "journal-entry/1",
    journal: "maintenance",
    subjectId: installationId,
    expectedRevision,
    idempotencyKey: `m${expectedRevision}-${payload["action"]}-${payload["phase"]}`,
    kind: "maintenance.action.recorded",
    payload
  };
  const verdict = validateJournalEntry(entry3);
  if (!verdict.ok) {
    return {
      ok: false,
      message: `the frozen grammar refused the maintenance append: ${verdict.rejections.map((rejection) => rejection.message).join("; ")}`
    };
  }
  const journalPath = maintenanceJournalPathFor(installationPath);
  await mkdir6(path10.dirname(journalPath), { recursive: true, mode: OWNER_DIR3 });
  await appendFile(journalPath, `${JSON.stringify(entry3)}
`, { mode: OWNER_FILE3 });
  await chmod6(journalPath, OWNER_FILE3);
  return { ok: true };
}
function consumedNoncesOf(entries) {
  const nonces = /* @__PURE__ */ new Set();
  for (const entry3 of entries) {
    const assertion = entry3.payload["assertion"];
    if (typeof assertion === "object" && assertion !== null) {
      const nonce = assertion["nonce"];
      if (typeof nonce === "string") nonces.add(nonce);
    }
  }
  return nonces;
}
function interruptedMaintenanceOf(entries) {
  let open8;
  for (const entry3 of entries) {
    const phase = entry3.payload["phase"];
    if (phase === "started") {
      open8 = {
        action: entry3.payload["action"],
        generationDigest: entry3.payload["generationDigest"]
      };
    } else if ((phase === "completed" || phase === "recovered") && entry3.payload["action"] === open8?.action) {
      open8 = void 0;
    }
  }
  return open8;
}
function lastActivatedGenerationOf(entries) {
  let activated;
  for (const entry3 of entries) {
    const action = entry3.payload["action"];
    const phase = entry3.payload["phase"];
    const digest2 = entry3.payload["generationDigest"];
    if (phase === "completed" && typeof digest2 === "string" && (action === "first-install" || action === "update" || action === "rollback")) {
      activated = digest2;
    }
  }
  return activated;
}

// packages/kernel/src/substrate/preflight.ts
import { execFile as execFile2 } from "node:child_process";
var SUPPORTED_PLATFORMS = Object.freeze(["darwin", "linux", "win32"]);
var MINIMUM_NODE = [22, 6];
var MINIMUM_PYTHON = [3, 11];
var runVersionProbe = (command, args) => new Promise((resolve) => {
  execFile2(command, [...args], { timeout: 1e4 }, (error, stdout, stderr) => {
    if (error) {
      resolve(void 0);
      return;
    }
    const match = `${stdout}
${stderr}`.match(/(\d+)\.(\d+)(?:\.(\d+))?/);
    resolve(match?.[0]);
  });
});
async function livePreflightProbes() {
  const python = await runVersionProbe(process.platform === "win32" ? "python" : "python3", ["--version"]) ?? await runVersionProbe("python", ["--version"]);
  return { nodeVersion: process.version, pythonVersion: python, platform: process.platform };
}
var parseVersion = (value) => value.replace(/^v/, "").split(".").map((part) => Number.parseInt(part, 10));
function checkRuntimePreflight(probes) {
  const failures = [];
  const [nodeMajor = 0, nodeMinor = 0] = parseVersion(probes.nodeVersion);
  if (nodeMajor < MINIMUM_NODE[0] || nodeMajor === MINIMUM_NODE[0] && nodeMinor < MINIMUM_NODE[1]) {
    failures.push({
      requirement: "node",
      message: `Node ${probes.nodeVersion} is below the preflighted prerequisite >=${MINIMUM_NODE.join(".")}`
    });
  }
  if (probes.pythonVersion === void 0) {
    failures.push({ requirement: "python", message: "no Python runtime was found; Python >=3.11 is a preflighted prerequisite" });
  } else {
    const [major = 0, minor = 0] = parseVersion(probes.pythonVersion);
    if (major < MINIMUM_PYTHON[0] || major === MINIMUM_PYTHON[0] && minor < MINIMUM_PYTHON[1]) {
      failures.push({
        requirement: "python",
        message: `Python ${probes.pythonVersion} is below the preflighted prerequisite >=${MINIMUM_PYTHON.join(".")}`
      });
    }
  }
  if (!SUPPORTED_PLATFORMS.includes(probes.platform)) {
    failures.push({
      requirement: "platform",
      message: `${probes.platform} is not a supported installation platform (${SUPPORTED_PLATFORMS.join(", ")})`
    });
  }
  return failures;
}
async function checkAssertionSourcePreflight(source) {
  const availability = await source.probe();
  if (availability.available) return [];
  return [
    {
      requirement: "assertion-source",
      message: `no interactive assertion source is available: ${availability.detail}; a platform without an interactive authentication context is not a supported installation target`
    }
  ];
}
function checkLicenseProvenancePreflight(manifest) {
  const failures = [];
  const inventory = Array.isArray(manifest["inventory"]) ? manifest["inventory"] : [];
  const paths = new Set(inventory.map((entry3) => entry3.path).filter((entry3) => typeof entry3 === "string"));
  for (const required of ["harness/LICENSE", "harness/NOTICE"]) {
    if (!paths.has(required)) {
      failures.push({ requirement: "license", message: `the composition carries no ${required}; license bytes are an activation prerequisite` });
    }
  }
  const pin = manifest["pin"];
  const skills = typeof pin === "object" && pin !== null ? pin["skillsArchive"] : void 0;
  const frozen = PINNED_AGENT_SKILLS;
  const declared = skills ?? {};
  const matches = Object.keys(frozen).every((key) => declared[key] === frozen[key]);
  if (!matches) {
    failures.push({
      requirement: "provenance",
      message: "the manifest's skills identities are not the frozen qualified release; provenance must match before activation"
    });
  }
  return failures;
}

// packages/kernel/src/substrate/installer.ts
var SUBSTRATE_BLOCKER_CODES = Object.freeze([
  "skills_archive_digest_mismatch",
  "skills_metadata_digest_mismatch",
  "manifest_malformed",
  "closure_digest_mismatch",
  "generation_digest_mismatch",
  "missing_generation",
  "not_an_installed_generation",
  "trust_state_absent",
  "trust_state_corrupt",
  "prior_installation_artifacts",
  "downgrade_rejected",
  "generation_revoked",
  "generation_not_pinned",
  "composition_profile_mismatch",
  "install_receipt_absent",
  "install_receipt_corrupt",
  "active_pointer_missing",
  "active_pointer_corrupt",
  "unsupported_archive_entry",
  "update_lane_required",
  "qualification_flag_required",
  "qualification_flag_refused",
  "preflight_failed",
  "assertion_source_unavailable",
  "assertion_source_mismatch",
  "assertion_refused",
  "assertion_stale",
  "assertion_replayed",
  "maintenance_in_progress",
  "maintenance_journal_corrupt",
  "rollback_target_not_accepted",
  "epoch_rollback_rejected",
  "repair_not_needed",
  "non_interactive_refused",
  "disposable_repository_required"
]);
var fail3 = (code, message) => ({
  ok: false,
  blockers: [{ code, message }]
});
var COMPOSITION_MANIFEST_FILE = "composition-manifest.json";
var INSTALL_RECEIPT_SPEC = "install-receipt/1";
var ACTIVE_POINTER_SPEC = "active-pointer/1";
var GENERATIONS_LEAF = "generations";
var POINTERS_LEAF = "pointers";
var TRUST_LEAF = "trust";
var JOURNAL_LEAF = "journal";
var RECEIPTS_LEAF = "receipts";
var OWNER_DIR4 = 448;
var OWNER_FILE4 = 384;
var READONLY_DIR = 365;
var READONLY_FILE2 = 292;
function trustStorePathFor(installationPath) {
  return path11.join(installationPath, TRUST_LEAF, "product-trust.json");
}
function receiptPathFor(receiptDir, installationPath) {
  return path11.join(receiptDir, RECEIPTS_LEAF, `${sha256Hex(installationPath)}.json`);
}
var generationRootFor = (installationPath, generationDigest) => path11.join(installationPath, GENERATIONS_LEAF, generationDigest);
var generationsDirFor = (installationPath) => path11.join(installationPath, GENERATIONS_LEAF);
var activePointerPathFor = (installationPath) => path11.join(installationPath, POINTERS_LEAF, "active.json");
var rollbackPointerPathFor = (installationPath) => path11.join(installationPath, POINTERS_LEAF, "rollback.json");
var ROLLBACK_POINTER_SPEC = "rollback-pointer/1";
var exists2 = async (target) => {
  try {
    await stat4(target);
    return true;
  } catch {
    return false;
  }
};
async function walkFiles(root, mode, relative = "") {
  const absolute = relative === "" ? root : path11.join(root, relative);
  const entries = await readdir2(absolute, { withFileTypes: true });
  entries.sort((a, b) => compareUtf16CodeUnits(a.name, b.name));
  const out = [];
  for (const entry3 of entries) {
    if (mode === "skip-dev-artifacts" && (entry3.name.startsWith(".") || entry3.name === "node_modules" || entry3.name === "dist")) {
      continue;
    }
    const childRelative = relative === "" ? entry3.name : `${relative}/${entry3.name}`;
    if (entry3.isDirectory()) {
      out.push(...await walkFiles(root, mode, childRelative));
    } else if (entry3.isFile()) {
      out.push(childRelative);
    } else {
      throw new Error(
        `refusing to walk ${childRelative} under ${root}: not a regular file or directory (symlinks and special files fail closed)`
      );
    }
  }
  return out;
}
async function writeOwnerFile(target, contents) {
  await mkdir7(path11.dirname(target), { recursive: true, mode: OWNER_DIR4 });
  await writeFile6(target, contents, { mode: OWNER_FILE4 });
  await chmod7(target, OWNER_FILE4);
}
var PACKED_HARNESS_PACKAGES = Object.freeze(["kernel", "cli", "conformance", "mcp", "action"]);
var PACKED_ROOT_FILES = Object.freeze(["LICENSE", "NOTICE", "qualifications/host-admission-capabilities.json"]);
var SKILLS_ARCHIVE_ENTRY = "skills/agent-skills-core-v1.zip";
var SKILLS_METADATA_ENTRY = "skills/agent-skills-core-v1.metadata.json";
async function packComposition(input) {
  const archiveBytes = await readFile9(input.skillsArchivePath);
  const archiveDigest = sha256Hex(archiveBytes);
  if (archiveDigest !== PINNED_AGENT_SKILLS.archiveSha256) {
    return fail3(
      "skills_archive_digest_mismatch",
      `the skills archive hashes to ${archiveDigest}, not the pinned ${PINNED_AGENT_SKILLS.archiveSha256}; only the exact authenticated release is packable`
    );
  }
  const metadataBytes = await readFile9(input.skillsMetadataPath);
  const metadataDigest = sha256Hex(metadataBytes);
  if (metadataDigest !== PINNED_AGENT_SKILLS.metadataSha256) {
    return fail3(
      "skills_metadata_digest_mismatch",
      `the skills release metadata hashes to ${metadataDigest}, not the pinned ${PINNED_AGENT_SKILLS.metadataSha256}`
    );
  }
  const packedDir = path11.join(input.outDir, "composition");
  const inventory = [];
  const stage = async (entryPath, bytes) => {
    const target = path11.join(packedDir, ...entryPath.split("/"));
    await mkdir7(path11.dirname(target), { recursive: true });
    await writeFile6(target, bytes);
    inventory.push({ path: entryPath, sha256: sha256Hex(bytes) });
  };
  const harnessModuleVersions = {};
  for (const packageLeaf of PACKED_HARNESS_PACKAGES) {
    const packageRoot = path11.join(input.sourceRoot, "packages", packageLeaf);
    const manifest2 = JSON.parse(await readFile9(path11.join(packageRoot, "package.json"), "utf8"));
    harnessModuleVersions[manifest2.name] = manifest2.version;
    for (const relative of await walkFiles(packageRoot, "skip-dev-artifacts")) {
      await stage(`harness/packages/${packageLeaf}/${relative}`, await readFile9(path11.join(packageRoot, ...relative.split("/"))));
    }
  }
  for (const rootFile of PACKED_ROOT_FILES) {
    await stage(`harness/${rootFile}`, await readFile9(path11.join(input.sourceRoot, ...rootFile.split("/"))));
  }
  await stage(SKILLS_ARCHIVE_ENTRY, archiveBytes);
  await stage(SKILLS_METADATA_ENTRY, metadataBytes);
  const rootManifest = JSON.parse(await readFile9(path11.join(input.sourceRoot, "package.json"), "utf8"));
  const manifest = buildCompositionManifest({
    compositionProfile: input.compositionProfile,
    compositionSequence: input.compositionSequence,
    productVersion: rootManifest.version,
    harnessModuleVersions,
    inventory
  });
  const manifestBytes = compositionManifestBytes(manifest);
  const manifestPath = path11.join(packedDir, COMPOSITION_MANIFEST_FILE);
  await writeFile6(manifestPath, manifestBytes);
  return { ok: true, generationDigest: generationDigestOf(manifestBytes), manifestPath, packedDir };
}
async function verifyGenerationClosure(root, expectedDigest) {
  if (!await exists2(root)) {
    return fail3("missing_generation", `generation root ${root} does not exist`);
  }
  let present;
  try {
    present = await walkFiles(root, "raw");
  } catch (error) {
    return fail3("unsupported_archive_entry", error instanceof Error ? error.message : String(error));
  }
  if (present.length === 0) {
    return fail3("missing_generation", `generation root ${root} is empty`);
  }
  if (!present.includes(COMPOSITION_MANIFEST_FILE)) {
    return fail3(
      "not_an_installed_generation",
      `${root} carries no ${COMPOSITION_MANIFEST_FILE}; a source checkout or arbitrary directory is not an installed generation`
    );
  }
  const manifestBytes = await readFile9(path11.join(root, COMPOSITION_MANIFEST_FILE), "utf8");
  const generationDigest = generationDigestOf(manifestBytes);
  if (expectedDigest !== void 0 && generationDigest !== expectedDigest) {
    return fail3(
      "generation_digest_mismatch",
      `the root's manifest hashes to ${generationDigest}, not the addressed ${expectedDigest}`
    );
  }
  let manifest;
  try {
    manifest = JSON.parse(manifestBytes);
  } catch {
    return fail3("manifest_malformed", "the composition manifest is not JSON");
  }
  const verdict = validateCompositionManifest(manifest);
  if (!verdict.ok) {
    const detail = verdict.rejections.map((rejection) => `${rejection.pointer || "/"}: ${rejection.message}`).join("; ");
    return fail3("manifest_malformed", `the composition manifest is outside its grammar (${detail})`);
  }
  const inventory = manifest["inventory"];
  const listed = new Set(inventory.map((entry3) => entry3.path));
  for (const filePath of present) {
    if (filePath === COMPOSITION_MANIFEST_FILE) continue;
    if (!listed.has(filePath)) {
      return fail3("closure_digest_mismatch", `file ${filePath} exists in the root but is not bound by the manifest`);
    }
  }
  for (const entry3 of inventory) {
    const target = path11.join(root, ...entry3.path.split("/"));
    let bytes;
    try {
      bytes = await readFile9(target);
    } catch {
      return fail3("closure_digest_mismatch", `manifest-bound file ${entry3.path} is missing from the root`);
    }
    const digest2 = sha256Hex(bytes);
    if (digest2 !== entry3.sha256) {
      return fail3(
        "closure_digest_mismatch",
        `file ${entry3.path} hashes to ${digest2}, not the manifest-bound ${entry3.sha256}`
      );
    }
  }
  return { ok: true, generationDigest, manifest };
}
async function loadTrustState(installationPath) {
  const storePath = trustStorePathFor(installationPath);
  let bytes;
  try {
    bytes = await readFile9(storePath, "utf8");
  } catch {
    return fail3(
      "trust_state_absent",
      `no trust store at ${storePath}; absent trust state fails closed, it never defaults open`
    );
  }
  const parsed = parseTrustState(bytes);
  if (!parsed.ok) return fail3("trust_state_corrupt", parsed.message);
  return { ok: true, state: parsed.state };
}
async function readInstallReceipt(receiptDir, installationPath) {
  const receiptPath = receiptPathFor(receiptDir, installationPath);
  let bytes;
  try {
    bytes = await readFile9(receiptPath, "utf8");
  } catch {
    return { presence: "absent" };
  }
  let parsed;
  try {
    parsed = JSON.parse(bytes);
  } catch {
    return { presence: "corrupt", message: "the install receipt is not JSON" };
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return { presence: "corrupt", message: "the install receipt is not an object" };
  }
  const record2 = parsed;
  const profile = record2["installationProfile"];
  if (record2["spec"] !== INSTALL_RECEIPT_SPEC || record2["installationPath"] !== installationPath || typeof record2["installationId"] !== "string" || record2["installationId"].length === 0 || typeof profile !== "string" || !COMPOSITION_PROFILES.includes(profile)) {
    return {
      presence: "corrupt",
      message: "the install receipt is outside its grammar or keyed to a different installation path"
    };
  }
  const disposable = record2["disposableRepositoryIds"];
  if (profile === "confirmation-fixture") {
    const wellFormed = Array.isArray(disposable) && disposable.length > 0 && disposable.every((entry3) => typeof entry3 === "string" && SPINE_ID.test(entry3));
    if (!wellFormed) {
      return {
        presence: "corrupt",
        message: "a qualification receipt records its non-empty disposable-repository set; this one does not"
      };
    }
  } else if (disposable !== void 0) {
    return {
      presence: "corrupt",
      message: "a production receipt records no disposable-repository set"
    };
  }
  return { presence: "valid", receipt: record2 };
}
function assertionSourceForKind(sourceKind) {
  if (sourceKind === "qualification-fixture") return createQualificationFixtureAssertionSource();
  if (sourceKind === "os-native") return createOsNativeAssertionSource();
  return {
    probe: async () => ({
      available: false,
      detail: "host-native assertion sources are supplied by a qualified host integration, not the installer"
    }),
    evaluate: async () => ({ ok: false, reason: "no host-native assertion source is attached" })
  };
}
async function observePresence(input) {
  let trustStore = "absent";
  let state;
  if (await exists2(trustStorePathFor(input.installationPath))) {
    const loaded = await loadTrustState(input.installationPath);
    if (loaded.ok) {
      trustStore = "valid";
      state = loaded.state;
    } else {
      trustStore = "corrupt";
    }
  }
  const receiptRead = await readInstallReceipt(input.receiptDir, input.installationPath);
  const receipt = receiptRead.presence === "valid" ? receiptRead.receipt : void 0;
  const otherArtifacts = [];
  const generationsDir = path11.join(input.installationPath, GENERATIONS_LEAF);
  if (await exists2(generationsDir) && (await readdir2(generationsDir)).length > 0) {
    otherArtifacts.push("generation-root");
  }
  if (await exists2(path11.join(input.installationPath, JOURNAL_LEAF))) {
    otherArtifacts.push("update-journal");
  }
  if (await exists2(activePointerPathFor(input.installationPath))) {
    otherArtifacts.push("active-pointer");
  }
  if (await exists2(path11.join(input.installationPath, POINTERS_LEAF, "rollback.json"))) {
    otherArtifacts.push("rollback-pointer");
  }
  return {
    presence: { trustStore, receipt: receiptRead.presence, otherArtifacts },
    ...state === void 0 ? {} : { state },
    ...receipt === void 0 ? {} : { receipt }
  };
}
async function materializeRoot(packedDir, root) {
  const parent = path11.dirname(root);
  await mkdir7(parent, { recursive: true, mode: OWNER_DIR4 });
  const staging = `${root}.staging-${randomBytes2(6).toString("hex")}`;
  const files = await walkFiles(packedDir, "raw");
  const directories = /* @__PURE__ */ new Set([staging]);
  for (const relative of files.includes(COMPOSITION_MANIFEST_FILE) ? files : [...files, COMPOSITION_MANIFEST_FILE]) {
    const source = path11.join(packedDir, ...relative.split("/"));
    const target = path11.join(staging, ...relative.split("/"));
    await mkdir7(path11.dirname(target), { recursive: true });
    let cursor = path11.dirname(target);
    while (cursor.length >= staging.length && !directories.has(cursor)) {
      directories.add(cursor);
      cursor = path11.dirname(cursor);
    }
    await writeFile6(target, await readFile9(source));
    await chmod7(target, READONLY_FILE2);
  }
  const ordered = [...directories].sort((a, b) => b.length - a.length);
  for (const directory of ordered) {
    if (directory === staging) continue;
    await chmod7(directory, READONLY_DIR);
  }
  await rename3(staging, root);
  await chmod7(root, READONLY_DIR);
}
function checkQualificationFlag(manifestProfile, qualification) {
  if (manifestProfile === "confirmation-fixture") {
    if (qualification === void 0) {
      return fail3(
        "qualification_flag_required",
        "the manifest declares the confirmation-fixture profile; activating it requires the explicit operator-supplied qualification flag with its disposable repository identities"
      );
    }
    const ids = qualification.disposableRepositoryIds;
    if (ids.length === 0 || !ids.every((id) => SPINE_ID.test(id))) {
      return fail3(
        "disposable_repository_required",
        "the qualification flag names the disposable repository identities the installation may serve; an empty or malformed set is refused"
      );
    }
    return void 0;
  }
  if (qualification !== void 0) {
    return fail3(
      "qualification_flag_refused",
      "the qualification flag is valid only for a fixture-declaring manifest; a flagged installation activates only fixture-declaring compositions"
    );
  }
  return void 0;
}
async function runActivationPreflight(manifest, source, overrides) {
  const live = await livePreflightProbes();
  const probes = {
    nodeVersion: overrides?.nodeVersion ?? live.nodeVersion,
    pythonVersion: overrides !== void 0 && "pythonVersion" in overrides ? overrides.pythonVersion : live.pythonVersion,
    platform: overrides?.platform ?? live.platform
  };
  const failures = [
    ...checkRuntimePreflight(probes),
    ...checkLicenseProvenancePreflight(manifest),
    ...await checkAssertionSourcePreflight(source)
  ];
  if (failures.length === 0) return void 0;
  return {
    ok: false,
    blockers: failures.map((failure) => ({
      code: "preflight_failed",
      message: `${failure.requirement}: ${failure.message}`
    }))
  };
}
async function installComposition(input) {
  const trust = input.trust ?? localDigestTrustPredicate;
  const closure = await verifyGenerationClosure(input.packedDir);
  if (!closure.ok) return closure;
  const generationDigest = closure.generationDigest;
  const manifestProfile = closure.manifest["compositionProfile"];
  const compositionSequence = closure.manifest["compositionSequence"];
  const flagVerdict = checkQualificationFlag(manifestProfile, input.qualification);
  if (flagVerdict !== void 0) return flagVerdict;
  const observed = await observePresence(input);
  const discrimination = discriminateInstall(observed.presence);
  if (discrimination.kind === "fail_closed") {
    return fail3(discrimination.code, discrimination.message);
  }
  let installationId;
  let state;
  const firstInstall = discrimination.kind === "first_install";
  if (firstInstall) {
    installationId = `install-${randomBytes2(16).toString("hex")}`;
    state = {
      spec: "product-trust-state/1",
      installationId,
      pinnedManifestDigest: generationDigest,
      acceptedGenerationDigests: [generationDigest],
      revokedGenerationDigests: [],
      revocationEpoch: 0,
      highWaterMark: compositionSequence
    };
  } else {
    const adopted = observed.state;
    const receipt = observed.receipt;
    installationId = adopted.installationId;
    if (receipt.installationProfile !== manifestProfile) {
      return fail3(
        "composition_profile_mismatch",
        `the manifest declares the ${manifestProfile} profile but this installation's receipt records ${receipt.installationProfile}; the confirmation-fixture profile is valid only in disposable-repository qualification runs and is production-rejected`
      );
    }
    if (generationDigest !== adopted.pinnedManifestDigest) {
      return fail3(
        "update_lane_required",
        `this installation pins ${adopted.pinnedManifestDigest}; activating ${generationDigest} is an update or rollback \u2014 a maintenance-lane operation under the sensitive-approval assertion, not a reinstall`
      );
    }
    const decision = trust.evaluate(generationDigest, adopted);
    if (!decision.eligible) {
      return fail3(
        "generation_revoked",
        `generation ${generationDigest} is not execution-eligible under current local trust state (${decision.reason})`
      );
    }
    state = adopted;
  }
  const requestedSourceKind = input.assertionProvider?.sourceKind ?? "os-native";
  const source = input.assertionSource ?? assertionSourceForKind(requestedSourceKind);
  const preflight = await runActivationPreflight(closure.manifest, source, input.preflight);
  if (preflight !== void 0) return preflight;
  const root = generationRootFor(input.installationPath, generationDigest);
  if (!await exists2(root)) {
    await materializeRoot(input.packedDir, root);
  }
  await writeOwnerFile(trustStorePathFor(input.installationPath), JSON.stringify(state));
  await writeOwnerFile(
    activePointerPathFor(input.installationPath),
    JSON.stringify({ spec: ACTIVE_POINTER_SPEC, generationDigest })
  );
  if (firstInstall) {
    const receipt = {
      spec: INSTALL_RECEIPT_SPEC,
      installationPath: input.installationPath,
      installationId,
      installationProfile: manifestProfile,
      ...input.qualification === void 0 ? {} : { disposableRepositoryIds: [...input.qualification.disposableRepositoryIds] }
    };
    await writeOwnerFile(receiptPathFor(input.receiptDir, input.installationPath), JSON.stringify(receipt));
    await writeAssertionProviderConfig(input.installationPath, requestedSourceKind);
    const journaled = await appendMaintenanceAction(input.installationPath, installationId, {
      action: "first-install",
      phase: "completed",
      generationDigest,
      highWaterMark: "absent-by-state",
      assertion: "absent-by-state"
    });
    if (!journaled.ok) return fail3("maintenance_journal_corrupt", journaled.message);
  }
  return { ok: true, installationId, generationDigest, firstInstall, root };
}
async function checkMutationLane(input) {
  const loaded = await loadTrustState(input.installationPath);
  if (!loaded.ok) return loaded;
  const trust = input.trust ?? localDigestTrustPredicate;
  const decision = trust.evaluate(input.generationDigest, loaded.state);
  if (!decision.eligible) {
    return decision.reason === "revoked" ? fail3(
      "generation_revoked",
      `generation ${input.generationDigest} is revoked; revoked bytes remain retained for audit but are never execution-eligible`
    ) : fail3(
      "generation_not_pinned",
      `generation ${input.generationDigest} is not the operator-pinned manifest digest`
    );
  }
  return { ok: true };
}
async function loadPinnedGeneration(input) {
  const loaded = await loadTrustState(input.installationPath);
  if (!loaded.ok) return loaded;
  const root = generationRootFor(input.installationPath, input.generationDigest);
  const closure = await verifyGenerationClosure(root, input.generationDigest);
  if (!closure.ok) return closure;
  const lane = await checkMutationLane(input);
  if (!lane.ok) return lane;
  return { ok: true, root, manifest: closure.manifest };
}
async function resolveActiveGeneration(installationPath) {
  const pointerPath = activePointerPathFor(installationPath);
  let bytes;
  try {
    bytes = await readFile9(pointerPath, "utf8");
  } catch {
    return fail3("active_pointer_missing", `no active pointer at ${pointerPath}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(bytes);
  } catch {
    return fail3("active_pointer_corrupt", "the active pointer is not JSON");
  }
  const record2 = typeof parsed === "object" && parsed !== null ? parsed : void 0;
  const digest2 = record2?.["generationDigest"];
  if (record2?.["spec"] !== ACTIVE_POINTER_SPEC || typeof digest2 !== "string" || !/^[0-9a-f]{64}$/.test(digest2)) {
    return fail3("active_pointer_corrupt", "the active pointer is outside its grammar");
  }
  return { ok: true, generationDigest: digest2 };
}
async function registrationBinding(input) {
  const receiptRead = await readInstallReceipt(input.receiptDir, input.installationPath);
  if (receiptRead.presence === "absent") {
    return fail3(
      "install_receipt_absent",
      "no install receipt for this installation path; registration resolves no identity or profile"
    );
  }
  if (receiptRead.presence === "corrupt") {
    return fail3("install_receipt_corrupt", receiptRead.message);
  }
  return {
    ok: true,
    registeringInstallationId: receiptRead.receipt.installationId,
    activeCompositionProfile: receiptRead.receipt.installationProfile,
    ...receiptRead.receipt.disposableRepositoryIds === void 0 ? {} : { disposableRepositoryIds: receiptRead.receipt.disposableRepositoryIds }
  };
}

// packages/kernel/src/index.ts
init_assertion_source();

// packages/kernel/src/substrate/lifecycle.ts
import { readdir as readdir3, readFile as readFile10, rm as rm5 } from "node:fs/promises";
import path12 from "node:path";
init_assertion_source();
var fail4 = (code, message) => ({
  ok: false,
  blockers: [{ code, message }]
});
async function adoptInstallation(installationPath, receiptDir) {
  const loaded = await loadTrustState(installationPath);
  if (!loaded.ok) return loaded;
  const receiptRead = await readInstallReceipt(receiptDir, installationPath);
  if (receiptRead.presence === "absent") {
    return fail4("install_receipt_absent", "no install receipt resolves this installation; maintenance adopts, it never re-initializes");
  }
  if (receiptRead.presence === "corrupt") return fail4("install_receipt_corrupt", receiptRead.message);
  const journal = await readMaintenanceJournal(installationPath);
  if (!journal.ok) return fail4("maintenance_journal_corrupt", journal.message);
  const interrupted = interruptedMaintenanceOf(journal.entries);
  if (interrupted !== void 0) {
    return fail4(
      "maintenance_in_progress",
      `an interrupted ${interrupted.action} targeting generation ${interrupted.generationDigest} is unrecovered; run maintenance recovery before any further operation`
    );
  }
  return { state: loaded.state, receipt: receiptRead.receipt, journal: journal.entries };
}
async function consumeMaintenanceAssertion(input, adopted, action, target) {
  const config = await loadAssertionProviderConfig(input.installationPath);
  if (!config.ok) {
    return fail4(
      "assertion_source_unavailable",
      `the assertion provider configuration is ${config.reason}; sensitive operations fail closed until an operator-performed installer repair re-establishes the source`
    );
  }
  if (config.config.sourceKind === "qualification-fixture" && adopted.receipt.installationProfile !== "confirmation-fixture") {
    return fail4(
      "assertion_source_mismatch",
      "the qualification-fixture assertion source is valid only on a confirmation-fixture installation"
    );
  }
  const source = input.assertionSource ?? assertionSourceForKind(config.config.sourceKind);
  const availability = await source.probe();
  if (!availability.available) {
    return fail4(
      "assertion_source_unavailable",
      `the configured assertion source is unavailable (${availability.detail}); sensitive operations fail closed until an operator-performed installer repair restores it`
    );
  }
  const targetText = target.generationDigest !== void 0 ? `generation ${target.generationDigest}` : `high-water mark ${target.highWaterMark}`;
  const request = {
    action,
    disclosure: `Approve ${action} of ${targetText} on installation ${adopted.state.installationId}`
  };
  const evaluation = await source.evaluate(request);
  if (!evaluation.ok) {
    return fail4("assertion_refused", `the interactive evaluation was not granted: ${evaluation.reason}`);
  }
  if (evaluation.sourceKind === "qualification-fixture" && adopted.receipt.installationProfile !== "confirmation-fixture") {
    return fail4(
      "assertion_source_mismatch",
      "a fixture-sourced assertion can never approve a sensitive operation on a production installation"
    );
  }
  if (evaluation.expiry < input.now) {
    return fail4(
      "assertion_stale",
      `the evaluation expired at ${evaluation.expiry}; an expired assertion is a cached credential and is treated as invalid`
    );
  }
  if (consumedNoncesOf(adopted.journal).has(evaluation.nonce)) {
    return fail4(
      "assertion_replayed",
      `nonce ${evaluation.nonce} was already consumed; a sensitive approval requires one fresh interactive evaluation per single-use nonce`
    );
  }
  const record2 = {
    spec: "sensitive-approval-assertion/1",
    assertionClass: "maintenance-lane",
    origin: "installer.maintenance",
    action,
    expiry: evaluation.expiry,
    nonce: evaluation.nonce,
    assertionSource: evaluation.sourceKind,
    productTrustRevocationEpoch: adopted.state.revocationEpoch,
    repositoryAuthorityRevocationEpoch: "absent-by-state",
    deliveryId: "absent-by-state",
    candidateTreeSha: "absent-by-state",
    policyDigest: "absent-by-state",
    invocationFence: "absent-by-state",
    targetInstallationId: adopted.state.installationId,
    targetGenerationDigest: target.generationDigest ?? "absent-by-state",
    targetHighWaterMark: target.highWaterMark ?? "absent-by-state",
    expectedJournalRevision: "absent-by-state"
  };
  const verdict = validateSensitiveApprovalAssertion(record2);
  if (!verdict.ok) {
    return fail4(
      "assertion_refused",
      `the minted assertion is outside its frozen contract: ${verdict.rejections.map((rejection) => rejection.message).join("; ")}`
    );
  }
  return { record: record2 };
}
var writeTrustState = async (installationPath, state) => {
  await writeOwnerFile(trustStorePathFor(installationPath), JSON.stringify(state));
};
var writePointer = async (pointerPath, spec, generationDigest) => {
  await writeOwnerFile(pointerPath, JSON.stringify({ spec, generationDigest }));
};
async function updateComposition(input) {
  const trust = input.trust ?? localDigestTrustPredicate;
  const closure = await verifyGenerationClosure(input.packedDir);
  if (!closure.ok) return closure;
  const generationDigest = closure.generationDigest;
  const manifestProfile = closure.manifest["compositionProfile"];
  const compositionSequence = closure.manifest["compositionSequence"];
  const flagVerdict = checkQualificationFlag(manifestProfile, input.qualification);
  if (flagVerdict !== void 0) return flagVerdict;
  const adopted = await adoptInstallation(input.installationPath, input.receiptDir);
  if ("ok" in adopted) return adopted;
  if (adopted.receipt.installationProfile !== manifestProfile) {
    return fail4(
      "composition_profile_mismatch",
      `the manifest declares the ${manifestProfile} profile but this installation's receipt records ${adopted.receipt.installationProfile}`
    );
  }
  const prior = adopted.state.pinnedManifestDigest;
  if (generationDigest === prior) {
    return {
      ok: true,
      generationDigest,
      priorGenerationDigest: prior,
      root: generationRootFor(input.installationPath, generationDigest),
      noOp: true
    };
  }
  if (compositionSequence < adopted.state.highWaterMark) {
    return fail4(
      "downgrade_rejected",
      `composition sequence ${compositionSequence} is below the persisted high-water mark ${adopted.state.highWaterMark}; an older archive can never silently replace the active generation \u2014 explicit rollback to a retained accepted generation is the sanctioned path`
    );
  }
  const decision = trust.evaluate(generationDigest, { ...adopted.state, pinnedManifestDigest: generationDigest });
  if (!decision.eligible) {
    return fail4("generation_revoked", `generation ${generationDigest} is revoked and can never activate`);
  }
  const config = await loadAssertionProviderConfig(input.installationPath);
  if (!config.ok) {
    return fail4(
      "assertion_source_unavailable",
      `the assertion provider configuration is ${config.reason}; sensitive operations fail closed until an operator-performed installer repair re-establishes the source`
    );
  }
  const source = input.assertionSource ?? assertionSourceForKind(config.config.sourceKind);
  const preflight = await runActivationPreflight(closure.manifest, source, input.preflight);
  if (preflight !== void 0) return preflight;
  const consumed = await consumeMaintenanceAssertion(input, adopted, "update", { generationDigest });
  if ("ok" in consumed) return consumed;
  const journalStarted = await appendMaintenanceAction(input.installationPath, adopted.state.installationId, {
    action: "update",
    phase: "started",
    generationDigest,
    highWaterMark: "absent-by-state",
    assertion: consumed.record
  });
  if (!journalStarted.ok) return fail4("maintenance_journal_corrupt", journalStarted.message);
  await input.hooks?.onPhase?.("started");
  const root = generationRootFor(input.installationPath, generationDigest);
  const rootPresent = await verifyGenerationClosure(root, generationDigest);
  if (!rootPresent.ok) {
    await materializeRoot(input.packedDir, root);
  }
  await input.hooks?.onPhase?.("root-materialized");
  const accepted = adopted.state.acceptedGenerationDigests.includes(generationDigest) ? adopted.state.acceptedGenerationDigests : [...adopted.state.acceptedGenerationDigests, generationDigest];
  await writeTrustState(input.installationPath, {
    ...adopted.state,
    pinnedManifestDigest: generationDigest,
    acceptedGenerationDigests: accepted,
    highWaterMark: Math.max(adopted.state.highWaterMark, compositionSequence)
  });
  await input.hooks?.onPhase?.("trust-state-written");
  await writePointer(rollbackPointerPathFor(input.installationPath), ROLLBACK_POINTER_SPEC, prior);
  await input.hooks?.onPhase?.("rollback-pointer-written");
  await writePointer(activePointerPathFor(input.installationPath), ACTIVE_POINTER_SPEC, generationDigest);
  await input.hooks?.onPhase?.("active-pointer-written");
  const journalCompleted = await appendMaintenanceAction(input.installationPath, adopted.state.installationId, {
    action: "update",
    phase: "completed",
    generationDigest,
    highWaterMark: "absent-by-state",
    assertion: "absent-by-state"
  });
  if (!journalCompleted.ok) return fail4("maintenance_journal_corrupt", journalCompleted.message);
  return { ok: true, generationDigest, priorGenerationDigest: prior, root, noOp: false };
}
async function rollbackComposition(input) {
  const adopted = await adoptInstallation(input.installationPath, input.receiptDir);
  if ("ok" in adopted) return adopted;
  const target = input.targetGenerationDigest;
  const trust = input.trust ?? localDigestTrustPredicate;
  if (!adopted.state.acceptedGenerationDigests.includes(target)) {
    return fail4(
      "rollback_target_not_accepted",
      `generation ${target} was never accepted under this installation's local trust policy; rollback can never adopt an arbitrary archive`
    );
  }
  const decision = trust.evaluate(target, adopted.state);
  if (!decision.eligible) {
    return decision.reason === "revoked" ? fail4("generation_revoked", `generation ${target} is revoked; a formerly valid rollback target stops being one`) : fail4("rollback_target_not_accepted", `generation ${target} is not execution-eligible under current local trust state`);
  }
  const root = generationRootFor(input.installationPath, target);
  const retained = await verifyGenerationClosure(root, target);
  if (!retained.ok) return retained;
  const prior = adopted.state.pinnedManifestDigest;
  if (target === prior) return { ok: true, generationDigest: target };
  const consumed = await consumeMaintenanceAssertion(input, adopted, "rollback", { generationDigest: target });
  if ("ok" in consumed) return consumed;
  const journalStarted = await appendMaintenanceAction(input.installationPath, adopted.state.installationId, {
    action: "rollback",
    phase: "started",
    generationDigest: target,
    highWaterMark: "absent-by-state",
    assertion: consumed.record
  });
  if (!journalStarted.ok) return fail4("maintenance_journal_corrupt", journalStarted.message);
  await writeTrustState(input.installationPath, { ...adopted.state, pinnedManifestDigest: target });
  await writePointer(rollbackPointerPathFor(input.installationPath), ROLLBACK_POINTER_SPEC, prior);
  await writePointer(activePointerPathFor(input.installationPath), ACTIVE_POINTER_SPEC, target);
  const journalCompleted = await appendMaintenanceAction(input.installationPath, adopted.state.installationId, {
    action: "rollback",
    phase: "completed",
    generationDigest: target,
    highWaterMark: "absent-by-state",
    assertion: "absent-by-state"
  });
  if (!journalCompleted.ok) return fail4("maintenance_journal_corrupt", journalCompleted.message);
  return { ok: true, generationDigest: target };
}
async function maintainTrustState(input) {
  const adopted = await adoptInstallation(input.installationPath, input.receiptDir);
  if ("ok" in adopted) return adopted;
  const state = adopted.state;
  let next;
  if (input.operation === "advance-high-water-mark") {
    if (input.highWaterMark <= state.highWaterMark) {
      return fail4(
        "epoch_rollback_rejected",
        `the high-water mark is ${state.highWaterMark} and only advances; ${input.highWaterMark} would rewind the no-downgrade policy`
      );
    }
    next = { ...state, highWaterMark: input.highWaterMark };
  } else if (input.operation === "pin") {
    if (!state.acceptedGenerationDigests.includes(input.generationDigest)) {
      return fail4(
        "rollback_target_not_accepted",
        `generation ${input.generationDigest} was never accepted under this installation's local trust policy`
      );
    }
    if (state.revokedGenerationDigests.includes(input.generationDigest)) {
      return fail4("generation_revoked", `generation ${input.generationDigest} is revoked and can never be pinned`);
    }
    const retained = await verifyGenerationClosure(
      generationRootFor(input.installationPath, input.generationDigest),
      input.generationDigest
    );
    if (!retained.ok) return retained;
    next = { ...state, pinnedManifestDigest: input.generationDigest };
  } else if (input.operation === "revoke") {
    if (state.revokedGenerationDigests.includes(input.generationDigest)) {
      return fail4("generation_revoked", `generation ${input.generationDigest} is already revoked`);
    }
    next = {
      ...state,
      revokedGenerationDigests: [...state.revokedGenerationDigests, input.generationDigest],
      revocationEpoch: state.revocationEpoch + 1
    };
  } else {
    next = {
      ...state,
      revokedGenerationDigests: state.revokedGenerationDigests.filter((digest2) => digest2 !== input.generationDigest),
      // Un-revocation is also a revocation-list change: the epoch counts
      // changes and never rewinds, so stale epoch-bound authority stays stale.
      revocationEpoch: state.revocationEpoch + 1
    };
  }
  const target = input.operation === "advance-high-water-mark" ? { highWaterMark: input.highWaterMark } : { generationDigest: input.generationDigest };
  const consumed = await consumeMaintenanceAssertion(input, adopted, input.operation, target);
  if ("ok" in consumed) return consumed;
  const journaled = await appendMaintenanceAction(input.installationPath, state.installationId, {
    action: input.operation,
    phase: "completed",
    generationDigest: input.operation === "advance-high-water-mark" ? "absent-by-state" : input.generationDigest,
    highWaterMark: input.operation === "advance-high-water-mark" ? input.highWaterMark : "absent-by-state",
    assertion: consumed.record
  });
  if (!journaled.ok) return fail4("maintenance_journal_corrupt", journaled.message);
  await writeTrustState(input.installationPath, next);
  return { ok: true, state: next };
}
var readPointerDigest = async (pointerPath) => {
  try {
    const parsed = JSON.parse(await readFile10(pointerPath, "utf8"));
    const digest2 = parsed["generationDigest"];
    return typeof digest2 === "string" ? digest2 : void 0;
  } catch {
    return void 0;
  }
};
async function removeReadonlyTree(root) {
  const { chmod: chmod11 } = await import("node:fs/promises");
  const restore = async (dir) => {
    await chmod11(dir, 448).catch(() => void 0);
    let entries;
    try {
      entries = await readdir3(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry3 of entries) {
      if (entry3.isDirectory()) await restore(path12.join(dir, entry3.name));
    }
  };
  await restore(root);
  await rm5(root, { recursive: true, force: true });
}
async function garbageCollectGenerations(input) {
  const loaded = await loadTrustState(input.installationPath);
  if (!loaded.ok) return loaded;
  const journal = await readMaintenanceJournal(input.installationPath);
  if (!journal.ok) return fail4("maintenance_journal_corrupt", journal.message);
  if (interruptedMaintenanceOf(journal.entries) !== void 0) {
    return fail4("maintenance_in_progress", "an interrupted maintenance operation is unrecovered; nothing is collected");
  }
  const retained = /* @__PURE__ */ new Set([
    loaded.state.pinnedManifestDigest,
    ...loaded.state.revokedGenerationDigests,
    // revoked bytes are retained for audit
    ...input.referencedGenerationDigests
  ]);
  const active = await readPointerDigest(activePointerPathFor(input.installationPath));
  if (active !== void 0) retained.add(active);
  const rollback = await readPointerDigest(rollbackPointerPathFor(input.installationPath));
  if (rollback !== void 0) retained.add(rollback);
  let present;
  try {
    present = await readdir3(generationsDirFor(input.installationPath));
  } catch {
    return { ok: true, removed: [] };
  }
  const removed = [];
  for (const name of present.sort()) {
    if (!/^[0-9a-f]{64}$/.test(name) || retained.has(name)) continue;
    await removeReadonlyTree(generationRootFor(input.installationPath, name));
    removed.push(name);
    const journaled = await appendMaintenanceAction(input.installationPath, loaded.state.installationId, {
      action: "garbage-collection",
      phase: "completed",
      generationDigest: name,
      highWaterMark: "absent-by-state",
      assertion: "absent-by-state"
    });
    if (!journaled.ok) return fail4("maintenance_journal_corrupt", journaled.message);
  }
  return { ok: true, removed };
}
async function recoverInterruptedMaintenance(input) {
  const journal = await readMaintenanceJournal(input.installationPath);
  if (!journal.ok) return fail4("maintenance_journal_corrupt", journal.message);
  const interrupted = interruptedMaintenanceOf(journal.entries);
  if (interrupted === void 0) return { ok: true, recovered: false };
  const loaded = await loadTrustState(input.installationPath);
  if (!loaded.ok) return loaded;
  const state = loaded.state;
  const target = interrupted.generationDigest;
  const installationId = state.installationId;
  if (state.pinnedManifestDigest === target) {
    const root = generationRootFor(input.installationPath, target);
    const closure = await verifyGenerationClosure(root, target);
    if (!closure.ok) return closure;
    const prior = lastActivatedGenerationOf(journal.entries);
    if (prior !== void 0 && prior !== target) {
      await writePointer(rollbackPointerPathFor(input.installationPath), ROLLBACK_POINTER_SPEC, prior);
    }
    await writePointer(activePointerPathFor(input.installationPath), ACTIVE_POINTER_SPEC, target);
  } else {
    await writePointer(activePointerPathFor(input.installationPath), ACTIVE_POINTER_SPEC, state.pinnedManifestDigest);
    const generationsDir = generationsDirFor(input.installationPath);
    let entries = [];
    try {
      entries = await readdir3(generationsDir);
    } catch {
    }
    for (const name of entries) {
      if (name.includes(".staging-")) await removeReadonlyTree(path12.join(generationsDir, name));
    }
    const targetRoot = generationRootFor(input.installationPath, target);
    const closure = await verifyGenerationClosure(targetRoot, target);
    if (!closure.ok) {
      await removeReadonlyTree(targetRoot);
    }
  }
  const journaled = await appendMaintenanceAction(input.installationPath, installationId, {
    action: interrupted.action,
    phase: "recovered",
    generationDigest: target,
    highWaterMark: "absent-by-state",
    assertion: "absent-by-state"
  });
  if (!journaled.ok) return fail4("maintenance_journal_corrupt", journaled.message);
  return { ok: true, recovered: true };
}
async function repairInstallation(input) {
  if (!input.interactive) {
    return fail4("non_interactive_refused", "the installer repair is an interactive operator act; non-interactive, piped, or inherited input is refused");
  }
  const receiptRead = await readInstallReceipt(input.receiptDir, input.installationPath);
  if (receiptRead.presence === "absent") {
    return fail4("install_receipt_absent", "no install receipt resolves this installation; a repair adopts an installation, it never creates one");
  }
  if (receiptRead.presence === "corrupt") return fail4("install_receipt_corrupt", receiptRead.message);
  const loaded = await loadTrustState(input.installationPath);
  if (!loaded.ok) return loaded;
  const existing = await loadAssertionProviderConfig(input.installationPath);
  if (existing.ok) {
    const existingPort = assertionSourceForKind(existing.config.sourceKind);
    const availability2 = await existingPort.probe();
    if (availability2.available) {
      return fail4("repair_not_needed", "a working assertion source exists; the repair is refused while the sensitive set is serviceable");
    }
  }
  if (input.source.sourceKind === "qualification-fixture" && receiptRead.receipt.installationProfile !== "confirmation-fixture") {
    return fail4("assertion_source_mismatch", "the qualification-fixture source is valid only on a confirmation-fixture installation");
  }
  const port = input.source.port ?? assertionSourceForKind(input.source.sourceKind);
  const availability = await port.probe();
  if (!availability.available) {
    return fail4("assertion_source_unavailable", `the replacement assertion source is unavailable: ${availability.detail}`);
  }
  const { writeAssertionProviderConfig: writeAssertionProviderConfig2 } = await Promise.resolve().then(() => (init_assertion_source(), assertion_source_exports));
  await writeAssertionProviderConfig2(input.installationPath, input.source.sourceKind);
  const journaled = await appendMaintenanceAction(input.installationPath, loaded.state.installationId, {
    action: "installer-repair",
    phase: "completed",
    generationDigest: "absent-by-state",
    highWaterMark: "absent-by-state",
    assertion: "absent-by-state"
  });
  if (!journaled.ok) return fail4("maintenance_journal_corrupt", journaled.message);
  return { ok: true };
}
async function inspectInstallation(input) {
  const loaded = await loadTrustState(input.installationPath);
  if (!loaded.ok) return loaded;
  const receiptRead = await readInstallReceipt(input.receiptDir, input.installationPath);
  if (receiptRead.presence === "absent") return fail4("install_receipt_absent", "no install receipt resolves this installation");
  if (receiptRead.presence === "corrupt") return fail4("install_receipt_corrupt", receiptRead.message);
  let present = [];
  try {
    present = (await readdir3(generationsDirFor(input.installationPath))).filter((name) => /^[0-9a-f]{64}$/.test(name));
  } catch {
  }
  const config = await loadAssertionProviderConfig(input.installationPath);
  return {
    ok: true,
    installationId: loaded.state.installationId,
    profile: receiptRead.receipt.installationProfile,
    pinnedGenerationDigest: loaded.state.pinnedManifestDigest,
    activeGenerationDigest: await readPointerDigest(activePointerPathFor(input.installationPath)),
    rollbackGenerationDigest: await readPointerDigest(rollbackPointerPathFor(input.installationPath)),
    highWaterMark: loaded.state.highWaterMark,
    revocationEpoch: loaded.state.revocationEpoch,
    assertionSourceKind: config.ok ? config.config.sourceKind : void 0,
    generations: present.sort().map((digest2) => ({
      digest: digest2,
      accepted: loaded.state.acceptedGenerationDigests.includes(digest2),
      revoked: loaded.state.revokedGenerationDigests.includes(digest2)
    }))
  };
}

// packages/kernel/src/policy/capabilities.ts
function createPolicyCollector() {
  const rejections = [];
  return {
    emit(code, pointer2, message) {
      rejections.push({ code, pointer: pointer2, message });
    },
    verdict() {
      return rejections.length === 0 ? { ok: true } : { ok: false, rejections };
    }
  };
}
var spineView = (collector) => ({
  emit(code, pointer2, message) {
    collector.emit(code, pointer2, message);
  },
  verdict: () => ({ ok: true })
});
function checkClosedWithOptionals(value, at, required, optional, collector) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    collector.emit("not_an_object", at, "expected a JSON object");
    return void 0;
  }
  const record2 = value;
  const defined = new Set([...required, ...optional].map((rule) => rule.name));
  for (const name of Object.keys(record2)) {
    if (!defined.has(name)) {
      collector.emit("unknown_member", spinePointer(at, name), "member is not defined by this grammar");
    }
  }
  const view = spineView(collector);
  for (const rule of required) {
    if (!Object.prototype.hasOwnProperty.call(record2, rule.name) || record2[rule.name] === void 0) {
      collector.emit("missing_member", spinePointer(at, rule.name), "required member is absent");
      continue;
    }
    rule.check(record2[rule.name], spinePointer(at, rule.name), view);
  }
  for (const rule of optional) {
    if (Object.prototype.hasOwnProperty.call(record2, rule.name) && record2[rule.name] !== void 0) {
      rule.check(record2[rule.name], spinePointer(at, rule.name), view);
    }
  }
  return record2;
}
var ADAPTER_CAPABILITY_SPEC = "adapter-capability/1";
var OPERATION_RESULT_SPEC = "operation-result/1";
var POLICY_CAPABILITY_KINDS = Object.freeze([
  "sensor",
  "mutation-stage",
  "pr-creation",
  "merge",
  "deploy",
  "approval-request",
  "tracker",
  "status-reconciliation"
]);
var READ_ONLY_CAPABILITY_KINDS = Object.freeze(["sensor", "status-reconciliation"]);
var PRIVILEGED_CAPABILITY_KINDS = Object.freeze(["pr-creation", "merge", "deploy", "approval-request"]);
var PRIVILEGED_ACTIONS = EXTERNAL_ACTIONS;
var CAPABILITY_RESULT_SPECS = Object.freeze({
  sensor: SENSOR_RESULT_SPEC,
  "mutation-stage": OPERATION_RESULT_SPEC,
  "pr-creation": OPERATION_RESULT_SPEC,
  merge: OPERATION_RESULT_SPEC,
  deploy: OPERATION_RESULT_SPEC,
  "approval-request": OPERATION_RESULT_SPEC,
  tracker: OPERATION_RESULT_SPEC,
  "status-reconciliation": OPERATION_RESULT_SPEC
});
var ADAPTER_REQUIRED = [
  { name: "spec", check: specLiteral(ADAPTER_CAPABILITY_SPEC) },
  { name: "capabilityId", check: spineId },
  { name: "kind", check: oneOf(POLICY_CAPABILITY_KINDS) },
  { name: "version", check: text },
  { name: "resultSpec", check: text }
];
var ADAPTER_OPTIONAL = [{ name: "credentialId", check: spineId }];
function validateAdapterCapability(value) {
  const collector = createPolicyCollector();
  const record2 = checkClosedWithOptionals(value, "", ADAPTER_REQUIRED, ADAPTER_OPTIONAL, collector);
  if (record2 !== void 0) {
    const kind = record2["kind"];
    const resultSpec = record2["resultSpec"];
    if (typeof kind === "string" && POLICY_CAPABILITY_KINDS.includes(kind) && typeof resultSpec === "string") {
      const expected = CAPABILITY_RESULT_SPECS[kind];
      if (resultSpec !== expected) {
        collector.emit(
          "capability_contract_mismatch",
          "/resultSpec",
          `a ${kind} capability contracts ${expected}; ${JSON.stringify(resultSpec)} is a different integration`
        );
      }
    }
  }
  return collector.verdict();
}
function validateAdapterSet(values) {
  const collector = createPolicyCollector();
  const seen = /* @__PURE__ */ new Set();
  values.forEach((value, index) => {
    const at = `/${index}`;
    const verdict = validateAdapterCapability(value);
    if (!verdict.ok) {
      for (const rejection of verdict.rejections) collector.emit(rejection.code, `${at}${rejection.pointer}`, rejection.message);
      return;
    }
    const capability = value;
    if (seen.has(capability.capabilityId)) {
      collector.emit("duplicate_capability", `${at}/capabilityId`, `capability ${capability.capabilityId} is declared more than once`);
      return;
    }
    seen.add(capability.capabilityId);
  });
  return collector.verdict();
}
var OPERATION_CLAIM_SPEC = "operation-claim/1";
var CLAIM_RULES = [
  { name: "spec", check: specLiteral(OPERATION_CLAIM_SPEC) },
  { name: "capabilityId", check: spineId },
  { name: "action", check: oneOf(POLICY_CAPABILITY_KINDS) }
];
function checkClaimAuthorized(claim, compiled) {
  const collector = createPolicyCollector();
  const record2 = checkClosedWithOptionals(claim, "", CLAIM_RULES, [], collector);
  const early = collector.verdict();
  if (record2 === void 0 || !early.ok) return early;
  const capabilityId = record2["capabilityId"];
  const action = record2["action"];
  const capability = compiled.capabilities.find((entry3) => entry3.capabilityId === capabilityId);
  if (capability === void 0) {
    collector.emit("capability_unavailable", "/capabilityId", `no capability ${capabilityId} is bound in the compiled policy`);
    return collector.verdict();
  }
  if (capability.kind !== action) {
    collector.emit(
      "capability_contract_mismatch",
      "/action",
      `capability ${capabilityId} is bound as ${capability.kind}; it cannot substantiate a ${action} claim`
    );
  }
  if (PRIVILEGED_ACTIONS.includes(action) && !compiled.snapshot.grantedAuthority.includes(action)) {
    collector.emit(
      "authority_not_granted",
      "/action",
      `the compiled policy grants no ${action} authority; an adapter output cannot claim an ungranted action`
    );
  }
  return collector.verdict();
}

// packages/kernel/src/policy/document.ts
var REPOSITORY_POLICY_DOCUMENT_SPEC = "repository-policy-document/1";
var PORTABLE_MODEL_DRIVEN_STAGES = Object.freeze(["plan", "implement", "compound"]);
var TRACKER_ABSENCE_FALLBACKS = Object.freeze(["proceed-without-tracker", "block"]);
var APPROVAL_REQUIREMENTS = Object.freeze(["operator-required", "none"]);
var LENS_RULES2 = [
  { name: "lensId", check: spineId },
  { name: "category", check: oneOf(REVIEW_LENS_CATEGORIES) },
  { name: "personaId", check: spineId }
];
var LENS_OPTIONAL_RULES = [{ name: "personaDigest", check: sha256 }];
var OBLIGATION_RULES2 = [{ name: "obligationId", check: spineId }];
var REQUIRED_CAPABILITY_RULES = [
  { name: "capabilityId", check: spineId },
  { name: "kind", check: oneOf(POLICY_CAPABILITY_KINDS) },
  { name: "version", check: text }
];
var APPROVAL_RULES = [
  { name: "action", check: oneOf(PRIVILEGED_ACTIONS) },
  { name: "approval", check: oneOf(APPROVAL_REQUIREMENTS) }
];
var CHECKPOINT_REQUIRED = [
  {
    name: "stageId",
    check: (value, at, collector) => {
      if (typeof value !== "string" || !PORTABLE_MODEL_DRIVEN_STAGES.includes(value)) {
        collector.emit(
          "unknown_checkpoint_stage",
          at,
          `no model-driven stage ${JSON.stringify(value)} exists; envelopes attach only to ${PORTABLE_MODEL_DRIVEN_STAGES.join(", ")}`
        );
      }
    }
  },
  { name: "allowedCapabilities", check: stringArray() },
  { name: "writablePaths", check: stringArray() },
  { name: "credentials", check: stringArray() },
  { name: "additionalProtectedPaths", check: stringArray() },
  { name: "additionalForbiddenOperations", check: stringArray() }
];
var closedArrayWithOptionals = (required, collectorRef, optional = []) => (value, at) => {
  if (!Array.isArray(value)) {
    collectorRef.emit("malformed_member", at, "expected an array");
    return;
  }
  value.forEach((entry3, index) => {
    checkClosedWithOptionals(entry3, spinePointer(at, index), required, optional, collectorRef);
  });
};
function validateRepositoryPolicyDocument(value) {
  const collector = createPolicyCollector();
  const view = spineView(collector);
  const nestedClosed = (rules, optional = []) => (nested, at) => closedArrayWithOptionals(rules, collector, optional)(nested, at);
  const REQUIRED2 = [
    { name: "spec", check: specLiteral(REPOSITORY_POLICY_DOCUMENT_SPEC) },
    { name: "repositoryId", check: spineId },
    { name: "policyGeneration", check: positiveInt },
    { name: "grantedFinishLines", check: stringArray({ minItems: 1, item: oneOf(FINISH_LINES) }) },
    { name: "grantedAuthority", check: stringArray({ item: oneOf(PRIVILEGED_ACTIONS) }) },
    { name: "forbiddenAuthority", check: stringArray({ item: oneOf(PRIVILEGED_ACTIONS) }) },
    { name: "reviewLenses", check: (nested, at) => nestedClosed(LENS_RULES2, LENS_OPTIONAL_RULES)(nested, at) },
    { name: "obligations", check: (nested, at) => nestedClosed(OBLIGATION_RULES2)(nested, at) },
    { name: "requiredCapabilities", check: (nested, at) => nestedClosed(REQUIRED_CAPABILITY_RULES)(nested, at) },
    { name: "approvals", check: (nested, at) => nestedClosed(APPROVAL_RULES)(nested, at) },
    { name: "trackerAbsenceFallback", check: oneOf(TRACKER_ABSENCE_FALLBACKS) }
  ];
  const OPTIONAL = [
    { name: "checkpoints", check: (nested, at) => nestedClosed(CHECKPOINT_REQUIRED)(nested, at) },
    {
      name: "admission",
      check: (nested, at) => {
        if (typeof nested !== "object" || nested === null || Array.isArray(nested)) {
          view.emit("not_an_object", at, "the admission gate is an object the harness config loader validates");
        }
      }
    }
  ];
  checkClosedWithOptionals(value, "", REQUIRED2, OPTIONAL, collector);
  return collector.verdict();
}

// packages/kernel/src/policy/compile.ts
var COMPILED_POLICY_SPEC = "compiled-repository-policy/1";
var POLICY_COMPILE_CODES = Object.freeze([
  "contradictory_authority",
  "contradictory_finish_line",
  "duplicate_obligation",
  "duplicate_review_lens",
  "duplicate_checkpoint",
  "mandatory_lens_missing",
  "persona_unresolvable",
  "capability_unavailable",
  "capability_version_mismatch",
  "capability_contract_mismatch",
  "prose_only_authority",
  "privileged_credential_in_model_grant",
  "tracker_unavailable",
  "admission_obligation_unactivated",
  "policy_tamper"
]);
var PORTABLE_PRIVILEGED_CREDENTIALS = Object.freeze([
  "credential.merge",
  "credential.deploy",
  "credential.pr-creation",
  "credential.approval-request"
]);
var MANDATORY_LENS_CATEGORIES = Object.freeze(["outcome-correctness", "testing-policy"]);
var PORTABLE_STAGE_GRANT = Object.freeze({
  spec: EXECUTION_GRANT_SPEC,
  profile: "checkpoint",
  allowedCapabilities: Object.freeze(["Bash", "Read", "Write", "Edit", "Glob", "Grep", "Task", "TodoWrite"]),
  writablePaths: Object.freeze(["src", "tests", "tools", "telemetry", "docs"]),
  protectedPaths: Object.freeze([".git", ".managed-projection", ".claude"]),
  forbiddenOperations: Object.freeze(["git.push", "merge", "deploy"])
});
var PORTABLE_INTAKE_GRANT = Object.freeze({
  spec: EXECUTION_GRANT_SPEC,
  profile: "intake",
  allowedCapabilities: Object.freeze(["Read", "Glob", "Grep"]),
  writablePaths: Object.freeze([]),
  protectedPaths: Object.freeze([".git", ".managed-projection", ".claude"]),
  forbiddenOperations: Object.freeze(["git.push", "merge", "deploy"])
});
var union = (base, extra) => [
  ...base,
  ...extra.filter((entry3) => !base.includes(entry3))
];
function compileRepositoryPolicy(input) {
  const collector = createPolicyCollector();
  const documentVerdict = validateRepositoryPolicyDocument(input.document);
  if (!documentVerdict.ok) {
    for (const rejection of documentVerdict.rejections) {
      collector.emit(rejection.code, `/document${rejection.pointer}`, rejection.message);
    }
  }
  const adapterVerdict = validateAdapterSet(input.adapters);
  if (!adapterVerdict.ok) {
    for (const rejection of adapterVerdict.rejections) {
      collector.emit(rejection.code, `/adapters${rejection.pointer}`, rejection.message);
    }
  }
  const shape = collector.verdict();
  if (!shape.ok) return { ok: false, rejections: shape.rejections };
  const document = input.document;
  const adapters = input.adapters;
  const byId = new Map(adapters.map((adapter) => [adapter.capabilityId, adapter]));
  document.grantedAuthority.forEach((authority, index) => {
    if (document.forbiddenAuthority.includes(authority)) {
      collector.emit(
        "contradictory_authority",
        `/document/grantedAuthority/${index}`,
        `${authority} is granted and forbidden by the same document; a contradiction rejects rather than resolving silently`
      );
    }
    if (!adapters.some((adapter) => adapter.kind === authority)) {
      collector.emit(
        "prose_only_authority",
        `/document/grantedAuthority/${index}`,
        `${authority} authority is declared with no executable ${authority} adapter; repository prose never satisfies a capability`
      );
    }
  });
  document.grantedFinishLines.forEach((finishLine, index) => {
    if (PRIVILEGED_ACTIONS.includes(finishLine) && !document.grantedAuthority.includes(finishLine)) {
      collector.emit(
        "contradictory_finish_line",
        `/document/grantedFinishLines/${index}`,
        `finish line ${finishLine} requires ${finishLine} authority, which this document does not grant`
      );
    }
  });
  const obligationIds = /* @__PURE__ */ new Set();
  document.obligations.forEach((obligation, index) => {
    if (obligationIds.has(obligation.obligationId)) {
      collector.emit("duplicate_obligation", `/document/obligations/${index}`, `obligation ${obligation.obligationId} is activated more than once`);
    }
    obligationIds.add(obligation.obligationId);
  });
  const lensIds = /* @__PURE__ */ new Set();
  document.reviewLenses.forEach((lens, index) => {
    if (lensIds.has(lens.lensId)) {
      collector.emit("duplicate_review_lens", `/document/reviewLenses/${index}`, `review lens ${lens.lensId} is activated more than once`);
    }
    lensIds.add(lens.lensId);
  });
  const personas = input.personas ?? [];
  const resolvedLenses = [];
  document.reviewLenses.forEach((lens, index) => {
    const at = `/document/reviewLenses/${index}`;
    const resolved = lens.personaDigest === void 0 ? personas.find((persona) => persona.origin === "composition" && persona.personaId === lens.personaId) : personas.find(
      (persona) => persona.origin === "adopter" && persona.personaId === lens.personaId && persona.digest === lens.personaDigest
    );
    if (resolved === void 0) {
      collector.emit(
        "persona_unresolvable",
        at,
        lens.personaDigest === void 0 ? `lens ${lens.lensId} references reviewer charter ${lens.personaId} by identity, and the pinned composition ships no such charter` : `lens ${lens.lensId} references repository-owned reviewer charter ${lens.personaId} at ${lens.personaDigest}, and no charter at the repository's protected path carries those bytes`
      );
      return;
    }
    resolvedLenses.push({
      lensId: lens.lensId,
      category: lens.category,
      personaId: resolved.personaId,
      personaDigest: resolved.digest
    });
  });
  const categories = new Set(document.reviewLenses.map((lens) => lens.category));
  for (const category of MANDATORY_LENS_CATEGORIES) {
    if (!categories.has(category)) {
      collector.emit(
        "mandatory_lens_missing",
        "/document/reviewLenses",
        `no lens activates the mandatory ${category} category; the review floor is not lowered by omission`
      );
    }
  }
  document.requiredCapabilities.forEach((required, index) => {
    const at = `/document/requiredCapabilities/${index}`;
    const bound2 = byId.get(required.capabilityId);
    if (bound2 === void 0) {
      collector.emit(
        "capability_unavailable",
        at,
        `required capability ${required.capabilityId} has no executable adapter; the delivery is rejected before mutation`
      );
      return;
    }
    if (bound2.kind !== required.kind) {
      collector.emit(
        "capability_contract_mismatch",
        at,
        `required capability ${required.capabilityId} is declared ${required.kind}; the adapter binds it as ${bound2.kind}`
      );
    }
    if (bound2.version !== required.version) {
      collector.emit(
        "capability_version_mismatch",
        at,
        `required capability ${required.capabilityId} requires version ${required.version}; the adapter provides ${bound2.version}`
      );
    }
  });
  const trackerBound = adapters.some((adapter) => adapter.kind === "tracker");
  if (!trackerBound && document.trackerAbsenceFallback === "block") {
    collector.emit(
      "tracker_unavailable",
      "/document/trackerAbsenceFallback",
      "the document blocks on tracker absence and no tracker capability is bound"
    );
  }
  const privilegedCredentialIds = new Set(PORTABLE_PRIVILEGED_CREDENTIALS);
  for (const adapter of adapters) {
    if (PRIVILEGED_CAPABILITY_KINDS.includes(adapter.kind) && adapter.credentialId !== void 0) {
      privilegedCredentialIds.add(adapter.credentialId);
    }
  }
  const seenStages = /* @__PURE__ */ new Set();
  (document.checkpoints ?? []).forEach((override, index) => {
    if (seenStages.has(override.stageId)) {
      collector.emit(
        "duplicate_checkpoint",
        `/document/checkpoints/${index}/stageId`,
        `stage ${override.stageId} carries more than one envelope; a duplicate rejects rather than resolving last-write-wins`
      );
    }
    seenStages.add(override.stageId);
    override.credentials.forEach((credential, credentialIndex) => {
      if (privilegedCredentialIds.has(credential)) {
        collector.emit(
          "privileged_credential_in_model_grant",
          `/document/checkpoints/${index}/credentials/${credentialIndex}`,
          `${credential} is a privileged-action credential; it is excluded from every model-driven execution grant`
        );
      }
    });
  });
  const overrides = new Map((document.checkpoints ?? []).map((entry3) => [entry3.stageId, entry3]));
  const checkpointGrants = PORTABLE_MODEL_DRIVEN_STAGES.map((stageId) => {
    const override = overrides.get(stageId);
    return {
      stageId,
      grant: {
        spec: EXECUTION_GRANT_SPEC,
        profile: "checkpoint",
        allowedCapabilities: override?.allowedCapabilities ?? PORTABLE_STAGE_GRANT.allowedCapabilities,
        writablePaths: override?.writablePaths ?? PORTABLE_STAGE_GRANT.writablePaths,
        protectedPaths: union(PORTABLE_STAGE_GRANT.protectedPaths, override?.additionalProtectedPaths ?? []),
        forbiddenOperations: union(PORTABLE_STAGE_GRANT.forbiddenOperations, override?.additionalForbiddenOperations ?? [])
      },
      credentials: override?.credentials ?? []
    };
  });
  let admission;
  if (document.admission !== void 0) {
    const verdict = validateHarnessConfig(document.admission);
    if (!verdict.ok) {
      for (const blocker of verdict.blockers) {
        collector.emit(blocker.code, "/document/admission", blocker.summary);
      }
    } else {
      admission = verdict.config;
      verdict.config.obligations.forEach((obligation, index) => {
        if (!obligationIds.has(obligation.id)) {
          collector.emit(
            "admission_obligation_unactivated",
            `/document/admission/obligations/${index}`,
            `the admission gate enforces ${obligation.id}, which the declarative policy never activates`
          );
        }
      });
    }
  }
  const semantic = collector.verdict();
  if (!semantic.ok) return { ok: false, rejections: semantic.rejections };
  const snapshotBody = {
    spec: POLICY_SNAPSHOT_SPEC,
    repositoryId: document.repositoryId,
    productTrustRevocationEpoch: input.productTrustRevocationEpoch,
    repositoryAuthorityRevocationEpoch: input.repositoryAuthorityRevocationEpoch,
    grantedFinishLines: [...document.grantedFinishLines],
    grantedAuthority: [...document.grantedAuthority],
    reviewLenses: resolvedLenses.map((lens) => ({ ...lens })),
    obligations: document.obligations.map((obligation) => ({ ...obligation }))
  };
  const snapshot = { ...snapshotBody, policyDigest: digestCanonical(snapshotBody) };
  const spineVerdict = validatePolicySnapshot(snapshot);
  if (!spineVerdict.ok) return { ok: false, rejections: spineVerdict.rejections };
  const compiledBody = {
    spec: COMPILED_POLICY_SPEC,
    policyGeneration: document.policyGeneration,
    snapshot,
    capabilities: adapters.map((adapter) => ({ ...adapter })),
    checkpointGrants,
    approvals: document.approvals.map((approval) => ({ ...approval })),
    tracker: trackerBound ? "available" : "absent",
    trackerAbsenceFallback: document.trackerAbsenceFallback,
    ...admission === void 0 ? {} : { admission }
  };
  const compiled = { ...compiledBody, compiledDigest: digestCanonical(compiledBody) };
  return { ok: true, compiled };
}
function verifyCompiledPolicy(value) {
  const collector = createPolicyCollector();
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    collector.emit("not_an_object", "", "expected a compiled policy object");
    return collector.verdict();
  }
  const record2 = value;
  const { compiledDigest, ...body } = record2;
  let recomputed;
  try {
    recomputed = digestCanonical(body);
  } catch {
    recomputed = void 0;
  }
  if (typeof compiledDigest !== "string" || recomputed === void 0 || recomputed !== compiledDigest) {
    collector.emit("digest_mismatch", "/compiledDigest", "the compiled digest does not recompute from the compiled body");
  }
  const snapshot = record2["snapshot"];
  const snapshotVerdict = validatePolicySnapshot(snapshot);
  if (!snapshotVerdict.ok) {
    for (const rejection of snapshotVerdict.rejections) collector.emit(rejection.code, `/snapshot${rejection.pointer}`, rejection.message);
  }
  return collector.verdict();
}
function checkBoundPolicy(boundCompiledDigest, presented) {
  const collector = createPolicyCollector();
  const structural = verifyCompiledPolicy(presented);
  if (!structural.ok) return structural;
  const presentedDigest = presented["compiledDigest"];
  if (presentedDigest !== boundCompiledDigest) {
    collector.emit(
      "policy_tamper",
      "/compiledDigest",
      "the presented policy is not the trusted pre-run copy this delivery bound; a candidate edit is a proposal for a future delivery"
    );
  }
  return collector.verdict();
}

// packages/kernel/src/policy/disposable.ts
var DISPOSABLE_OUTCOME_AUTHORITIES = Object.freeze(["operator"]);
var DISPOSABLE_REVIEW_LENSES = Object.freeze([
  { lensId: "lens.outcome-correctness", category: "outcome-correctness", personaId: "persona.outcome-correctness" },
  { lensId: "lens.testing-policy", category: "testing-policy", personaId: "persona.testing-policy" }
]);
var DISPOSABLE_PERSONA_TRUSTED_BASE_PATHS = Object.freeze({
  "persona.outcome-correctness": "delivery/personas/outcome-correctness.md",
  "persona.testing-policy": "delivery/personas/testing-policy.md"
});
var DISPOSABLE_SENSOR_CAPABILITY = Object.freeze({
  descriptor: Object.freeze({
    spec: "capability-descriptor/1",
    capabilityId: "sensor.acceptance",
    kind: "sensor",
    version: "1",
    resultSpec: "sensor-result/1"
  }),
  /** Where the sensor lives in the repository tree, resolved from the base commit. */
  trustedBasePath: "tools/sensor.mjs"
});
function compileDisposableCompiledPolicy(input) {
  const personas = DISPOSABLE_REVIEW_LENSES.flatMap((lens) => {
    const bytes = input.personaBytes[lens.personaId];
    return bytes === void 0 ? [] : [{ personaId: lens.personaId, digest: sha256Hex(bytes), origin: "adopter" }];
  });
  const digestOf = (personaId) => personas.find((persona) => persona.personaId === personaId)?.digest;
  const result2 = compileRepositoryPolicy({
    document: {
      spec: REPOSITORY_POLICY_DOCUMENT_SPEC,
      repositoryId: input.repositoryId,
      policyGeneration: 1,
      grantedFinishLines: ["merge-ready"],
      grantedAuthority: [],
      forbiddenAuthority: [],
      reviewLenses: DISPOSABLE_REVIEW_LENSES.map((lens) => {
        const personaDigest = digestOf(lens.personaId);
        return { ...lens, ...personaDigest === void 0 ? {} : { personaDigest } };
      }),
      obligations: [{ obligationId: "outcome.verification" }, { obligationId: "review.green" }],
      requiredCapabilities: [
        {
          capabilityId: DISPOSABLE_SENSOR_CAPABILITY.descriptor.capabilityId,
          kind: "sensor",
          version: DISPOSABLE_SENSOR_CAPABILITY.descriptor.version
        }
      ],
      approvals: [],
      trackerAbsenceFallback: "proceed-without-tracker",
      ...input.admission === void 0 ? {} : { admission: input.admission }
    },
    adapters: [
      {
        spec: "adapter-capability/1",
        capabilityId: DISPOSABLE_SENSOR_CAPABILITY.descriptor.capabilityId,
        kind: "sensor",
        version: DISPOSABLE_SENSOR_CAPABILITY.descriptor.version,
        resultSpec: DISPOSABLE_SENSOR_CAPABILITY.descriptor.resultSpec
      }
    ],
    personas,
    productTrustRevocationEpoch: input.productTrustRevocationEpoch,
    repositoryAuthorityRevocationEpoch: input.repositoryAuthorityRevocationEpoch
  });
  if (!result2.ok) {
    throw new Error(`the disposable policy no longer compiles: ${JSON.stringify(result2.rejections)}`);
  }
  return result2.compiled;
}
function compileDisposablePolicy(input) {
  return compileDisposableCompiledPolicy(input).snapshot;
}
var DISPOSABLE_STAGE_GRANT = PORTABLE_STAGE_GRANT;

// packages/kernel/src/policy/authority.ts
var AUTHORITY_REVOCATION_SPEC = "authority-revocation/1";
var REVOCATION_RULES = [
  { name: "spec", check: specLiteral(AUTHORITY_REVOCATION_SPEC) },
  { name: "epoch", check: nonNegativeInt },
  { name: "revokedAuthority", check: stringArray() },
  { name: "revokedFinishLines", check: stringArray() }
];
function validateAuthorityRevocation(value) {
  const collector = createPolicyCollector();
  checkClosedWithOptionals(value, "", REVOCATION_RULES, [], collector);
  return collector.verdict();
}
function observeAuthorityEpoch(highestObservedEpoch, presented) {
  const shape = validateAuthorityRevocation(presented);
  if (!shape.ok) return shape;
  const revocation = presented;
  if (revocation.epoch < highestObservedEpoch) {
    return {
      ok: false,
      rejections: [
        {
          code: "epoch_rollback",
          pointer: "/epoch",
          message: `the store presents epoch ${revocation.epoch} below the observed floor ${highestObservedEpoch}; the epoch is monotonic and a rollback restores nothing`
        }
      ]
    };
  }
  return { ok: true, highestObservedEpoch: revocation.epoch };
}
function effectiveDeliveryAuthority(input) {
  const withinCurrent = (kind, entry3) => input.currentGeneration === void 0 || input.currentGeneration[kind].includes(entry3);
  return {
    grantedFinishLines: input.bound.grantedFinishLines.filter(
      (entry3) => !input.revocation.revokedFinishLines.includes(entry3) && withinCurrent("grantedFinishLines", entry3)
    ),
    grantedAuthority: input.bound.grantedAuthority.filter(
      (entry3) => !input.revocation.revokedAuthority.includes(entry3) && withinCurrent("grantedAuthority", entry3)
    )
  };
}
function checkActionAuthorization(input) {
  const collector = createPolicyCollector();
  const observed = observeAuthorityEpoch(input.highestObservedEpoch, input.revocation);
  if (!observed.ok) {
    for (const rejection of observed.rejections) collector.emit(rejection.code, rejection.pointer, rejection.message);
    return collector.verdict();
  }
  const revocation = input.revocation;
  if (revocation.revokedAuthority.includes(input.action)) {
    collector.emit(
      "authority_revoked",
      "/action",
      `${input.action} authority is revoked at epoch ${revocation.epoch}; a revocation narrows immediately, including after ready`
    );
    return collector.verdict();
  }
  if (!input.bound.grantedAuthority.includes(input.action)) {
    collector.emit(
      "authority_not_granted",
      "/action",
      `the bound snapshot grants no ${input.action} authority; absence of a grant is denial`
    );
  }
  return collector.verdict();
}

// packages/kernel/src/checkpoint/append-only-file.ts
import { constants as fsConstants } from "node:fs";
import { chmod as chmod8, mkdir as mkdir8, open as open5, truncate } from "node:fs/promises";
import path13 from "node:path";
var OWNER_DIR5 = 448;
var OWNER_FILE5 = 384;
var JournalAccessRefused = class extends Error {
  journalPath;
  reason;
  constructor(journalPath, reason) {
    super(`${journalPath}: ${reason}`);
    this.name = "JournalAccessRefused";
    this.journalPath = journalPath;
    this.reason = reason;
  }
};
var EMPTY_RAW = { lines: [], terminatedByteLength: 0, interruptedTail: false };
function splitTerminated(text4) {
  const lastNewline = text4.lastIndexOf("\n");
  const terminated = lastNewline === -1 ? "" : text4.slice(0, lastNewline + 1);
  return {
    lines: terminated.split("\n").filter((line) => line.length > 0),
    terminatedByteLength: Buffer.byteLength(terminated, "utf8"),
    interruptedTail: text4.length > terminated.length
  };
}
var isMissing = (error) => error?.code === "ENOENT";
async function readRawJournal(journalPath, discipline = {}) {
  const flags = fsConstants.O_RDONLY | (discipline.extraFlags ?? 0);
  let handle;
  try {
    handle = await open5(journalPath, flags);
  } catch (error) {
    if (isMissing(error)) return EMPTY_RAW;
    if (discipline.refuseOnError === true) throw new JournalAccessRefused(journalPath, describe4(error));
    return EMPTY_RAW;
  }
  try {
    const refusal2 = discipline.verify?.(await handle.stat());
    if (refusal2 !== void 0) throw new JournalAccessRefused(journalPath, refusal2);
    return splitTerminated(await handle.readFile("utf8"));
  } catch (error) {
    if (error instanceof JournalAccessRefused) throw error;
    if (discipline.refuseOnError === true) throw new JournalAccessRefused(journalPath, describe4(error));
    return EMPTY_RAW;
  } finally {
    await handle.close().catch(() => void 0);
  }
}
function describe4(error) {
  const code = error?.code;
  return code ?? (error instanceof Error ? error.message : String(error));
}
function parseJournalLines(lines) {
  const entries = [];
  for (const [index, line] of lines.entries()) {
    try {
      entries.push(JSON.parse(line));
    } catch {
      return { ok: false, unparsableLineIndex: index };
    }
  }
  return { ok: true, entries };
}
var appendQueues = /* @__PURE__ */ new Map();
function serializedOnPath(key, operation) {
  const previous = appendQueues.get(key) ?? Promise.resolve();
  const current = previous.then(operation, operation);
  appendQueues.set(
    key,
    current.then(
      () => void 0,
      () => void 0
    )
  );
  return current;
}
function appendDecided(options) {
  const { journalPath, discipline } = options;
  return serializedOnPath(journalPath, async () => {
    let raw;
    const read = async () => {
      raw = await readRawJournal(journalPath, discipline);
      return parseJournalLines(raw.lines);
    };
    const decision = await options.decide(read);
    if (!decision.ok) return { ok: false, rejected: decision.rejected };
    await mkdir8(path13.dirname(journalPath), { recursive: true, mode: OWNER_DIR5 });
    if (raw?.interruptedTail === true) {
      await truncate(journalPath, raw.terminatedByteLength);
    }
    const flags = fsConstants.O_WRONLY | fsConstants.O_CREAT | fsConstants.O_APPEND | (discipline?.extraFlags ?? 0);
    const handle = await open5(journalPath, flags, OWNER_FILE5);
    try {
      const refusal2 = discipline?.verify?.(await handle.stat());
      if (refusal2 !== void 0) throw new JournalAccessRefused(journalPath, refusal2);
      await handle.writeFile(`${JSON.stringify(decision.entry)}
`, "utf8");
    } finally {
      await handle.close().catch(() => void 0);
    }
    await chmod8(journalPath, OWNER_FILE5);
    return { ok: true, accepted: decision.accepted };
  });
}
function ownerOnlyRegularFile(stats) {
  if (!stats.isFile()) return "not a regular file";
  if ((stats.mode & 63) !== 0) return "not owner-only";
  const uid = process.getuid?.();
  if (uid !== void 0 && stats.uid !== uid) return "not owned by this user";
  return void 0;
}

// packages/kernel/src/checkpoint/redaction.ts
var SECRET_PATTERNS = Object.freeze([
  { id: "private-key-block", source: String.raw`-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----[\s\S]*?(?:-----END [A-Z0-9 ]*PRIVATE KEY-----|$)` },
  { id: "aws-access-key-id", source: String.raw`\bAKIA[0-9A-Z]{16}\b` },
  { id: "github-token", source: String.raw`\bgh[pousr]_[A-Za-z0-9]{20,}\b` },
  { id: "github-fine-grained-token", source: String.raw`\bgithub_pat_[A-Za-z0-9_]{20,}\b` },
  { id: "slack-token", source: String.raw`\bxox[baprs]-[A-Za-z0-9-]{10,}\b` },
  { id: "openai-key", source: String.raw`\bsk-[A-Za-z0-9_-]{20,}\b` },
  { id: "google-api-key", source: String.raw`\bAIza[0-9A-Za-z_-]{30,}\b` },
  { id: "jwt", source: String.raw`\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{5,}\b` },
  { id: "bearer-credential", source: String.raw`\bBearer\s+[A-Za-z0-9._~+/=-]{20,}` }
]);
var FREE_TEXT_MEMBERS = /* @__PURE__ */ new Set(["summary", "reason"]);
function redactSecretText(text4) {
  let result2 = text4;
  const redacted = [];
  for (const pattern of SECRET_PATTERNS) {
    const matcher = new RegExp(pattern.source, "g");
    if (!matcher.test(result2)) continue;
    redacted.push(pattern.id);
    result2 = result2.replace(new RegExp(pattern.source, "g"), `[redacted:${pattern.id}]`);
  }
  return { text: result2, redacted };
}
function firstSecretIn(text4) {
  for (const pattern of SECRET_PATTERNS) {
    if (new RegExp(pattern.source, "g").test(text4)) return pattern.id;
  }
  return void 0;
}
function applySecretDiscipline(entry3, freeTextMembers = FREE_TEXT_MEMBERS) {
  const matches = [];
  const redactions = [];
  const walk = (value, pointer2, member2) => {
    if (typeof value === "string") {
      if (member2 !== void 0 && freeTextMembers.has(member2)) {
        const outcome = redactSecretText(value);
        for (const id2 of outcome.redacted) if (!redactions.includes(id2)) redactions.push(id2);
        return outcome.redacted.length > 0 && outcome.text.length > MAX_FREE_TEXT ? outcome.text.slice(0, MAX_FREE_TEXT) : outcome.text;
      }
      const id = firstSecretIn(value);
      if (id !== void 0) matches.push({ pointer: pointer2, id });
      return value;
    }
    if (Array.isArray(value)) {
      return value.map((item, index) => walk(item, `${pointer2}/${index}`, void 0));
    }
    if (typeof value === "object" && value !== null) {
      const copy = {};
      for (const [name, item] of Object.entries(value)) {
        copy[name] = walk(item, `${pointer2}/${name}`, name);
      }
      return copy;
    }
    return value;
  };
  const disciplined = walk(entry3, "", void 0);
  if (matches.length > 0) return { ok: false, matches };
  return { ok: true, entry: disciplined, redactions };
}

// packages/kernel/src/checkpoint/journal-store.ts
var parseRejections = (index) => [
  {
    code: "not_an_object",
    pointer: `/${index}`,
    message: "a terminated journal line is not JSON; the journal fails closed rather than skipping it"
  }
];
function parseEntries(lines) {
  const parsed = parseJournalLines(lines);
  return parsed.ok ? { ok: true, entries: [...parsed.entries] } : { ok: false, rejections: parseRejections(parsed.unparsableLineIndex) };
}
function revisionOf(state) {
  return state.expectedRevision;
}
function createStore(journalPath, reduce) {
  return {
    journalPath,
    async read() {
      const raw = await readRawJournal(journalPath);
      const parsed = parseEntries(raw.lines);
      if (!parsed.ok) return { ok: false, rejections: parsed.rejections };
      return raw.interruptedTail ? { ok: true, entries: parsed.entries, interruptedTail: true } : { ok: true, entries: parsed.entries };
    },
    async state() {
      const raw = await readRawJournal(journalPath);
      const parsed = parseEntries(raw.lines);
      if (!parsed.ok) return { ok: false, rejections: parsed.rejections };
      return reduce(parsed.entries);
    },
    async append(entry3) {
      const outcome = await appendDecided({
        journalPath,
        async decide(read) {
          const disciplined = applySecretDiscipline(entry3);
          if (!disciplined.ok) {
            return {
              ok: false,
              rejected: disciplined.matches.map((match) => ({
                code: "secret_rejected",
                pointer: match.pointer,
                message: `a ${match.id}-shaped secret has no place in this member; the append is refused before any byte is durable`
              }))
            };
          }
          const parsed = await read();
          if (!parsed.ok) return { ok: false, rejected: parseRejections(parsed.unparsableLineIndex) };
          const reduced = reduce([...parsed.entries, disciplined.entry]);
          if (!reduced.ok) return { ok: false, rejected: reduced.rejections };
          return { ok: true, entry: disciplined.entry, accepted: revisionOf(reduced.state) };
        }
      });
      return outcome.ok ? { ok: true, expectedRevision: outcome.accepted } : { ok: false, rejections: outcome.rejected };
    }
  };
}
function createJournalStore(journalPath) {
  return createStore(journalPath, reduceDeliveryJournal);
}
function createIntakeJournalStore(journalPath) {
  return createStore(journalPath, reduceIntakeJournal);
}
function createMaintenanceJournalStore(journalPath) {
  return createStore(journalPath, reduceMaintenanceJournal);
}

// packages/kernel/src/checkpoint/recheck.ts
var RECHECKED_VALUES = Object.freeze([
  "product-trust",
  "repository-authority-epoch",
  "invocation-fence",
  "registering-installation-id",
  "active-profile",
  "projection-digest",
  "discovery-configuration-digest"
]);
var SUBSTITUTED = Object.freeze({
  standard: [],
  takeover: ["invocation-fence", "projection-digest", "discovery-configuration-digest"],
  "rebinding-migration": [
    "registering-installation-id",
    "active-profile",
    "invocation-fence",
    "projection-digest",
    "discovery-configuration-digest"
  ],
  "generation-migration": ["product-trust", "invocation-fence", "projection-digest", "discovery-configuration-digest"]
});
var evaluateCheck = (value, check, failures) => {
  if (check.kind === "eligible") {
    if (!check.ok) {
      failures.push({
        value,
        code: "trust_ineligible",
        message: check.detail ?? `${value} is not execution-eligible under current local trust state`
      });
    }
    return;
  }
  if (check.expected !== check.observed) {
    failures.push({
      value,
      code: "value_mismatch",
      message: `${value} changed: bound ${String(check.expected)}, observed ${String(check.observed)}`
    });
  }
};
function evaluateCanonicalRecheck(input) {
  const failures = [];
  const substituted = SUBSTITUTED[input.consumption.kind];
  for (const value of RECHECKED_VALUES) {
    const check = input.values[value];
    if (check === void 0) {
      failures.push({
        value,
        code: "recheck_incomplete",
        message: `the canonical recheck evaluates every frozen value; ${value} was not supplied`
      });
      continue;
    }
    if (substituted.includes(value)) {
      if (check !== "absent-by-state") {
        failures.push({
          value,
          code: "substitution_violation",
          message: `${input.consumption.kind} consumption replaces ${value}; a real value here rechecks the wrong axis`
        });
      }
      continue;
    }
    if (check === "absent-by-state") continue;
    evaluateCheck(value, check, failures);
  }
  switch (input.consumption.kind) {
    case "takeover":
      evaluateCheck("superseded-fence", input.consumption.supersededFence, failures);
      evaluateCheck("expected-journal-revision", input.consumption.expectedJournalRevision, failures);
      evaluateCheck("target-base-commit", input.consumption.targetBaseCommit, failures);
      break;
    case "rebinding-migration":
      evaluateCheck("target-installation-id", input.consumption.targetInstallationId, failures);
      evaluateCheck("recorded-profile", input.consumption.recordedProfile, failures);
      break;
    case "generation-migration":
      evaluateCheck("target-generation-trust", input.consumption.targetGenerationTrust, failures);
      break;
    default:
      break;
  }
  return failures.length === 0 ? { ok: true } : { ok: false, failures };
}

// packages/kernel/src/checkpoint/run-event.ts
var RUN_EVENT_SPEC = "run-event/1";
var RUN_STORE_ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;
var RUN_TICKET = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
var RUN_CANDIDATE_TREE_SHA = /^(?:[0-9a-f]{40}|[0-9a-f]{64})$/;
var RUN_PROVIDER_ID = /^[a-z0-9]+([._-][a-z0-9]+)*$/;
var MAX_RUN_PROVIDER_ID = 128;
var MAX_RUN_LABEL = 128;
var MAX_RUN_PATH = 4096;
var MAX_RUN_URL = 2048;
var MAX_RUN_LENSES = 32;
var RUN_FREE_TEXT_MEMBERS = /* @__PURE__ */ new Set(["rationale", "summary", "choice", "cited", "fork"]);
var RUN_ACTOR_ROLES = Object.freeze(["cli", "executor"]);
var RUN_COMMAND_OUTCOMES = Object.freeze(["ok", "policy", "usage", "interrupted"]);
var RUN_GATE_REPORTED_OUTCOMES = Object.freeze(["pass", "fail", "blocked", "interrupted"]);
var RUN_ENDED_RESULTS = Object.freeze(["complete", "partial", "blocked"]);
var RUN_EVENT_KINDS = Object.freeze([
  "run.started",
  "run.ended",
  "ticket.read",
  "posture.declared",
  "lens.selected",
  "review.round.opened",
  "review.round.closed",
  "command.completed",
  "gate.reported",
  "pr.opened",
  "blocker.recorded",
  "decision.recorded",
  "compounding.recorded",
  "context.saved",
  "action.intent",
  "action.observed"
]);
var KIND_SET = new Set(RUN_EVENT_KINDS);
function isRunEventKind(value) {
  return typeof value === "string" && KIND_SET.has(value);
}
var malformed3 = (collector, at, message) => {
  collector.emit("malformed_member", at, message);
};
var boundedString = (maximum, what) => (value, at, collector) => {
  if (typeof value !== "string" || value.length === 0 || value.length > maximum) {
    malformed3(collector, at, `expected ${what}: a non-empty string of at most ${maximum} characters`);
  }
};
var patterned = (pattern, maximum, what) => (value, at, collector) => {
  if (typeof value !== "string" || value.length > maximum || !pattern.test(value)) {
    malformed3(collector, at, `expected ${what}`);
  }
};
var oneOf2 = (values) => (value, at, collector) => {
  if (typeof value !== "string" || !values.includes(value)) {
    malformed3(collector, at, `expected one of ${values.join(", ")}`);
  }
};
var runStoreId = patterned(RUN_STORE_ID, 128, "a run id matching the run-store charset");
var ticketId = patterned(RUN_TICKET, 128, "a ticket identity matching the kernel run-id charset");
var treeSha = patterned(RUN_CANDIDATE_TREE_SHA, 64, "a lowercase-hex git object id of 40 or 64 characters");
var providerId = patterned(RUN_PROVIDER_ID, MAX_RUN_PROVIDER_ID, "a bounded provider-id-shaped identity");
var label = boundedString(MAX_RUN_LABEL, "a bounded label");
var freeText = boundedString(MAX_FREE_TEXT, "bounded free text");
var RUN_INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;
var instant2 = patterned(RUN_INSTANT, 20, "a UTC instant of the form YYYY-MM-DDTHH:MM:SSZ");
function isRunInstant(value) {
  return typeof value === "string" && RUN_INSTANT.test(value);
}
var nonNegativeInt2 = (value, at, collector) => {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) {
    malformed3(collector, at, "expected a non-negative safe integer");
  }
};
var positiveInt2 = (value, at, collector) => {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1) {
    malformed3(collector, at, "expected a positive safe integer");
  }
};
var idList = (maximum) => (value, at, collector) => {
  if (!Array.isArray(value) || value.length > maximum) {
    malformed3(collector, at, `expected an array of at most ${maximum} bounded ids`);
    return;
  }
  for (const [index, item] of value.entries()) providerId(item, spinePointer(at, index), collector);
};
var httpUrl = (value, at, collector) => {
  if (typeof value !== "string" || value.length === 0 || value.length > MAX_RUN_URL) {
    malformed3(collector, at, `expected a non-empty URL of at most ${MAX_RUN_URL} characters`);
    return;
  }
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    malformed3(collector, at, "expected an absolute URL");
    return;
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    malformed3(collector, at, "expected an http or https URL");
  }
};
var COST_MEMBERS2 = [
  { name: "unit", check: label },
  { name: "total", check: (value, at, collector) => {
    if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
      malformed3(collector, at, "expected a finite non-negative number");
    }
  } },
  { name: "reportedBy", check: label }
];
var cost = (value, at, collector) => {
  if (isSpineRecord(value) && value["coverage"] === "unreported") {
    checkClosed2(value, at, [
      { name: "coverage", check: oneOf2(["unreported"]) },
      { name: "reportedBy", check: label }
    ], collector);
  } else {
    checkClosed2(value, at, [...COST_MEMBERS2, { name: "coverage", check: oneOf2(["complete", "partial"]), required: false }], collector);
  }
};
var digest = patterned(/^[0-9a-f]{64}$/, 64, "a sha256 digest");
var contract = (value, at, collector) => {
  checkClosed2(value, at, [
    { name: "objective", check: freeText },
    { name: "finishLine", check: label },
    { name: "acceptanceCriteria", check: (items, pointer2, c) => {
      if (!Array.isArray(items) || items.length === 0 || items.length > 32) {
        malformed3(c, pointer2, "expected 1 to 32 bounded acceptance criteria");
        return;
      }
      items.forEach((item, index) => freeText(item, spinePointer(pointer2, index), c));
    } }
  ], collector);
};
var FINDINGS_MEMBERS = [
  { name: "P0", check: nonNegativeInt2 },
  { name: "P1", check: nonNegativeInt2 },
  { name: "P2", check: nonNegativeInt2 },
  { name: "P3", check: nonNegativeInt2 }
];
var findings = (value, at, collector) => {
  checkClosed2(value, at, FINDINGS_MEMBERS, collector);
};
var WORKFLOW_MEMBERS = [
  { name: "releaseId", check: label },
  { name: "profile", check: label }
];
var workflow = (value, at, collector) => {
  checkClosed2(value, at, WORKFLOW_MEMBERS, collector);
};
var PAYLOAD_MEMBERS2 = Object.freeze({
  "context.saved": [
    { name: "spec", check: oneOf2(["ordinary-run-context/1"]) },
    { name: "contract", check: contract },
    { name: "stage", check: label },
    { name: "candidateTreeSha", check: treeSha },
    { name: "candidateBinding", check: (value, at, c) => void checkClosed2(value, at, [
      { name: "deliverableDigest", check: digest },
      { name: "identity", check: label },
      { name: "baseRef", check: label },
      { name: "baseTipSha", check: treeSha },
      { name: "mergeBaseSha", check: treeSha },
      { name: "workspaceId", check: label }
    ], c) },
    { name: "policyDigest", check: digest },
    { name: "release", check: (value, at, c) => void checkClosed2(value, at, [
      { name: "runtimeVersion", check: label },
      { name: "releaseId", check: label },
      { name: "profile", check: label },
      { name: "archiveSha256", check: digest }
    ], c) }
  ],
  "action.intent": [
    { name: "actionId", check: runStoreId },
    { name: "operation", check: label },
    { name: "reference", check: boundedString(MAX_RUN_URL, "a reconciliation reference without credentials") }
  ],
  "action.observed": [
    { name: "actionId", check: runStoreId },
    { name: "outcome", check: oneOf2(["succeeded", "failed", "not-performed", "unknown"]) },
    { name: "reference", check: boundedString(MAX_RUN_URL, "an observed reconciliation reference without credentials") }
  ],
  "run.started": [
    { name: "ticket", check: ticketId, required: false },
    { name: "host", check: label },
    { name: "workflow", check: workflow },
    { name: "displacedRunId", check: runStoreId, required: false }
  ],
  "run.ended": [
    { name: "result", check: oneOf2(RUN_ENDED_RESULTS) },
    { name: "cost", check: cost }
  ],
  "ticket.read": [
    { name: "ticket", check: ticketId },
    { name: "posture", check: label, required: false },
    { name: "tracker", check: label }
  ],
  "posture.declared": [
    { name: "posture", check: label },
    { name: "ticket", check: ticketId, required: false }
  ],
  "lens.selected": [
    // Arity is deliberately NOT checked here: `mandated-pair-mismatch` is the
    // evaluator's finding, and a pair the validator refused to store could
    // never be found.
    { name: "mandated", check: idList(MAX_RUN_LENSES) },
    { name: "selected", check: idList(MAX_RUN_LENSES) },
    { name: "rationale", check: freeText }
  ],
  "review.round.opened": [
    { name: "round", check: positiveInt2 },
    { name: "candidateTreeSha", check: treeSha },
    { name: "lenses", check: idList(MAX_RUN_LENSES) }
  ],
  "review.round.closed": [
    { name: "round", check: positiveInt2 },
    { name: "candidateTreeSha", check: treeSha },
    { name: "outcome", check: label },
    { name: "findings", check: findings },
    { name: "cost", check: cost }
  ],
  "command.completed": [
    { name: "command", check: providerId },
    { name: "outcome", check: oneOf2(RUN_COMMAND_OUTCOMES) },
    { name: "durationMs", check: nonNegativeInt2 },
    { name: "digest", check: patterned(/^[0-9a-f]{64}$/, 64, "a lowercase-hex sha256 digest"), required: false }
  ],
  "gate.reported": [
    { name: "command", check: label },
    { name: "outcome", check: oneOf2(RUN_GATE_REPORTED_OUTCOMES) },
    { name: "durationMs", check: nonNegativeInt2 },
    { name: "ticket", check: ticketId, required: false }
  ],
  "pr.opened": [
    { name: "url", check: httpUrl },
    { name: "candidateTreeSha", check: treeSha },
    { name: "ticket", check: ticketId, required: false }
  ],
  "blocker.recorded": [
    { name: "code", check: label },
    { name: "summary", check: freeText }
  ],
  "decision.recorded": [
    { name: "fork", check: freeText },
    { name: "choice", check: freeText },
    { name: "cited", check: freeText, required: false }
  ],
  "compounding.recorded": [
    { name: "outcome", check: label },
    { name: "reference", check: label, required: false }
  ]
});
var MIRRORED_MEMBERS = Object.freeze(["ticket", "candidateTreeSha"]);
var REPO_MEMBERS = [
  { name: "commonDir", check: boundedString(MAX_RUN_PATH, "an absolute common-directory path") },
  { name: "remote", check: boundedString(MAX_RUN_URL, "a remote locator"), required: false }
];
var ACTOR_MEMBERS = [
  { name: "role", check: oneOf2(RUN_ACTOR_ROLES) },
  { name: "id", check: providerId, required: false }
];
function envelopeMembers(withSeq) {
  return [
    { name: "version", check: oneOf2([RUN_EVENT_SPEC]) },
    { name: "runId", check: runStoreId },
    ...withSeq ? [{ name: "seq", check: positiveInt2 }] : [],
    { name: "at", check: instant2 },
    { name: "repo", check: (value, at, collector) => void checkClosed2(value, at, REPO_MEMBERS, collector) },
    { name: "kind", check: oneOf2(RUN_EVENT_KINDS) },
    { name: "actor", check: (value, at, collector) => void checkClosed2(value, at, ACTOR_MEMBERS, collector) },
    { name: "ticket", check: ticketId, required: false },
    { name: "candidateTreeSha", check: treeSha, required: false },
    { name: "attestation", check: oneOf2(["self"]) },
    { name: "payload", check: () => void 0 }
  ];
}
function validateRunEvent(value, options = {}) {
  const collector = createSpineCollector();
  const withSeq = options.seqAssigned !== false;
  if (!isSpineRecord(value)) {
    collector.emit("not_an_object", "", "expected a JSON object");
    return collector.verdict();
  }
  if (value["version"] !== RUN_EVENT_SPEC) {
    collector.emit("unsupported_spec", "/version", `expected exactly ${JSON.stringify(RUN_EVENT_SPEC)}`);
    return collector.verdict();
  }
  const kind = value["kind"];
  if (!isRunEventKind(kind)) {
    collector.emit("unknown_kind", "/kind", "kind is not defined by the run-event/1 vocabulary");
    return collector.verdict();
  }
  checkClosed2(value, "", envelopeMembers(withSeq), collector);
  const payload = value["payload"];
  checkClosed2(payload, "/payload", PAYLOAD_MEMBERS2[kind], collector);
  if (isSpineRecord(payload)) {
    for (const member2 of MIRRORED_MEMBERS) {
      const inPayload = Object.prototype.hasOwnProperty.call(payload, member2) ? payload[member2] : void 0;
      const inEnvelope = Object.prototype.hasOwnProperty.call(value, member2) ? value[member2] : void 0;
      if (inPayload === void 0 && inEnvelope === void 0) continue;
      if (inPayload === void 0) {
        collector.emit(
          "unsupported_combination",
          spinePointer("", member2),
          `the envelope carries ${member2} but this kind's payload does not; the two must agree exactly`
        );
        continue;
      }
      if (inEnvelope === void 0) {
        collector.emit(
          "unsupported_combination",
          spinePointer("", member2),
          `the payload carries ${member2} but the envelope does not; the two must agree exactly`
        );
        continue;
      }
      if (inEnvelope !== inPayload) {
        collector.emit(
          "unsupported_combination",
          spinePointer("", member2),
          `the envelope's ${member2} differs from the payload's; the two must agree exactly`
        );
      }
    }
  }
  return collector.verdict();
}
function runPrimaryTicket(events) {
  for (const event of events) {
    if (event.ticket !== void 0) return event.ticket;
  }
  return void 0;
}
function validateRunEventInput(value) {
  return validateRunEvent(value, { seqAssigned: false });
}
function reduceToProviderId(value) {
  const reduced = value.toLowerCase().replaceAll(/[^a-z0-9._-]+/g, "-").replaceAll(/[._-]{2,}/g, "-").replace(/^[._-]+/, "").slice(0, MAX_RUN_PROVIDER_ID).replace(/[._-]+$/, "");
  return reduced.length > 0 ? reduced : "unknown";
}

// packages/kernel/src/checkpoint/run-journal-completeness.ts
var VIOLATION = Object.freeze({
  runStartedNotFirst: "run-started-not-first",
  prerequisitesAfterFirstRound: "prerequisites-after-first-round",
  roundClosedBeforeOpened: "round-closed-before-opened",
  gateBeforeClosedRound: "gate-before-closed-round",
  recordBeforeGate: "record-before-gate",
  prBeforeGate: "pr-before-gate",
  runEndedNotLast: "run-ended-not-last",
  gateReportedBeforeClosedRound: "gate-reported-before-closed-round",
  prBeforeGateReported: "pr-before-gate-reported",
  mandatedPairMismatch: "mandated-pair-mismatch",
  roundNotBoundToRecord: "round-not-bound-to-record"
});
var REQUIRED = Object.freeze({
  runStarted: "run.started",
  ticketRead: "ticket.read",
  postureDeclared: "posture.declared",
  lensSelected: "lens.selected",
  roundOpened: "review.round.opened",
  roundClosed: "review.round.closed",
  gateCompletion: "command.completed:gate",
  recordCompletion: "command.completed:record",
  prOpened: "pr.opened",
  runEnded: "run.ended",
  gateReported: "gate.reported"
});
var RUN_JOURNAL_VIOLATIONS = Object.freeze([
  VIOLATION.runStartedNotFirst,
  VIOLATION.prerequisitesAfterFirstRound,
  VIOLATION.roundClosedBeforeOpened,
  VIOLATION.gateBeforeClosedRound,
  VIOLATION.recordBeforeGate,
  VIOLATION.prBeforeGate,
  VIOLATION.runEndedNotLast,
  VIOLATION.gateReportedBeforeClosedRound,
  VIOLATION.prBeforeGateReported,
  VIOLATION.mandatedPairMismatch,
  VIOLATION.roundNotBoundToRecord
]);
var RUN_JOURNAL_REQUIRED_ENTRIES = Object.freeze([
  REQUIRED.runStarted,
  REQUIRED.ticketRead,
  REQUIRED.postureDeclared,
  REQUIRED.lensSelected,
  REQUIRED.roundOpened,
  REQUIRED.roundClosed,
  REQUIRED.gateCompletion,
  REQUIRED.recordCompletion,
  REQUIRED.prOpened,
  REQUIRED.runEnded,
  REQUIRED.gateReported
]);
var RUN_JOURNAL_STATUSES = Object.freeze(["complete", "complete-executor-only", "incomplete", "absent"]);
var payloadOf = (event) => typeof event.payload === "object" && event.payload !== null ? event.payload : {};
var first = (events) => events[0];
var last = (events) => events[events.length - 1];
function indexBy(events, kind) {
  return events.flatMap((event, at) => event.kind === kind ? [{ at, event }] : []);
}
function cliCompletion(events, command, pick = last) {
  return pick(
    indexBy(events, "command.completed").filter(
      (entry3) => entry3.event.actor.role === "cli" && payloadOf(entry3.event)["command"] === command
    )
  );
}
function pairRounds(events) {
  const opened = indexBy(events, "review.round.opened");
  const closed2 = indexBy(events, "review.round.closed");
  const rounds = new Set([...opened, ...closed2].map((entry3) => payloadOf(entry3.event)["round"]));
  const paired = [];
  let inverted = false;
  for (const round of rounds) {
    const firstOpened = first(opened.filter((entry3) => payloadOf(entry3.event)["round"] === round));
    const firstClosed = first(closed2.filter((entry3) => payloadOf(entry3.event)["round"] === round));
    if (firstOpened === void 0 || firstClosed === void 0) continue;
    if (firstClosed.at < firstOpened.at) {
      inverted = true;
      continue;
    }
    paired.push({ round, openedAt: firstOpened.at, closedAt: firstClosed.at, closed: firstClosed.event });
  }
  return { paired, inverted };
}
function runJournalCarries(events, entry3) {
  switch (entry3) {
    case REQUIRED.gateCompletion:
      return cliCompletion(events, "gate") !== void 0;
    case REQUIRED.recordCompletion:
      return cliCompletion(events, "record") !== void 0;
    case REQUIRED.roundClosed:
      return pairRounds(events).paired.length > 0;
    default:
      return indexBy(events, entry3).length > 0;
  }
}
function evaluateRunJournal(events, treeSha2, mandatedLensIds) {
  const missing = [];
  const violations = [];
  const boundToRecord = treeSha2 !== void 0;
  const runStarted = first(indexBy(events, "run.started"));
  const ticketRead = first(indexBy(events, "ticket.read"));
  const postureDeclared = first(indexBy(events, "posture.declared"));
  const lensSelected = first(indexBy(events, "lens.selected"));
  const roundsOpened = indexBy(events, "review.round.opened");
  const prOpened = first(indexBy(events, "pr.opened"));
  const runEnded = first(indexBy(events, "run.ended"));
  const gateReported = first(indexBy(events, "gate.reported"));
  const completions = indexBy(events, "command.completed");
  const gateCompletion = cliCompletion(events, "gate");
  const recordCompletion = cliCompletion(events, "record");
  const openingGateCompletion = cliCompletion(events, "gate", first);
  const executorOnly = completions.length === 0;
  const { paired, inverted } = pairRounds(events);
  const qualifying = paired.filter((entry3) => treeSha2 === void 0 || payloadOf(entry3.closed)["candidateTreeSha"] === treeSha2);
  const requiredRound = first(
    qualifying.map((entry3) => ({ at: entry3.closedAt, event: entry3.closed })).sort((left, right) => left.at - right.at)
  );
  for (const entry3 of RUN_JOURNAL_REQUIRED_ENTRIES) {
    if (entry3 === REQUIRED.gateReported && !executorOnly) continue;
    if (!runJournalCarries(events, entry3)) missing.push(entry3);
  }
  if (runStarted !== void 0 && (runStarted.at !== 0 || indexBy(events, "run.started").length > 1)) {
    violations.push(VIOLATION.runStartedNotFirst);
  }
  const firstRound = first(roundsOpened);
  if (firstRound !== void 0) {
    const late = [ticketRead, postureDeclared, lensSelected].some((entry3) => entry3 !== void 0 && entry3.at > firstRound.at);
    if (late) violations.push(VIOLATION.prerequisitesAfterFirstRound);
  }
  if (inverted) violations.push(VIOLATION.roundClosedBeforeOpened);
  if (gateCompletion !== void 0) {
    const closedFirst = qualifying.some((entry3) => entry3.closedAt < gateCompletion.at);
    if (!closedFirst) violations.push(VIOLATION.gateBeforeClosedRound);
    if (recordCompletion !== void 0 && recordCompletion.at < gateCompletion.at) violations.push(VIOLATION.recordBeforeGate);
  }
  if (openingGateCompletion !== void 0 && prOpened !== void 0 && prOpened.at < openingGateCompletion.at) {
    violations.push(VIOLATION.prBeforeGate);
  }
  if (runEnded !== void 0 && runEnded.at !== events.length - 1) violations.push(VIOLATION.runEndedNotLast);
  if (executorOnly && gateReported !== void 0) {
    const closedFirst = qualifying.some((entry3) => entry3.closedAt < gateReported.at);
    if (!closedFirst) violations.push(VIOLATION.gateReportedBeforeClosedRound);
    if (prOpened !== void 0 && prOpened.at < gateReported.at) violations.push(VIOLATION.prBeforeGateReported);
  }
  if (lensSelected !== void 0) {
    const mandated = payloadOf(lensSelected.event)["mandated"];
    const ids = Array.isArray(mandated) ? mandated : void 0;
    const wellFormed = ids !== void 0 && ids.length === 2 && ids.every((id) => typeof id === "string" && id.length > 0);
    const agreed = mandatedLensIds === void 0 || ids !== void 0 && [...ids].map(String).sort().join("\0") === [...mandatedLensIds].sort().join("\0");
    if (!wellFormed || !agreed) violations.push(VIOLATION.mandatedPairMismatch);
  }
  if (treeSha2 !== void 0 && requiredRound === void 0) violations.push(VIOLATION.roundNotBoundToRecord);
  const outstanding = new Set(missing);
  if (executorOnly) {
    outstanding.delete(REQUIRED.gateCompletion);
    outstanding.delete(REQUIRED.recordCompletion);
  } else {
    outstanding.delete(REQUIRED.gateReported);
  }
  const status = violations.length > 0 || outstanding.size > 0 ? "incomplete" : executorOnly ? "complete-executor-only" : "complete";
  return { status, missing, violations, boundToRecord };
}

// packages/kernel/src/checkpoint/run-namespace.ts
import { spawn as spawn3 } from "node:child_process";
import path14 from "node:path";
var MANAGED_DELIVERY_NAMESPACE = "managed-delivery";
var RUN_STORE_DIRECTORY = "runs";
async function resolveCommonDirectoryNamespace(input) {
  const outcome = await input.run({
    cwd: input.cwd,
    args: ["rev-parse", "--path-format=absolute", "--git-common-dir"],
    ...input.env === void 0 ? {} : { env: input.env }
  });
  const commonDir = outcome.stdout.trim();
  if (outcome.code !== 0 || commonDir.length === 0) {
    return { ok: false, reason: `not a git repository: ${input.cwd}` };
  }
  return { ok: true, commonDir, namespaceDir: path14.join(commonDir, MANAGED_DELIVERY_NAMESPACE) };
}
async function resolveRunStoreLocation(input) {
  const outcome = await input.run({
    cwd: input.cwd,
    args: ["rev-parse", "--path-format=absolute", "--git-dir", "--git-common-dir"],
    ...input.env === void 0 ? {} : { env: input.env }
  });
  const lines = outcome.stdout.split("\n").map((line) => line.trim()).filter((line) => line.length > 0);
  const gitDir = lines[0];
  const commonDir = lines[1];
  if (outcome.code !== 0 || gitDir === void 0 || commonDir === void 0) {
    return { ok: false, reason: `not a git repository: ${input.cwd}` };
  }
  const namespaceDir = path14.join(commonDir, MANAGED_DELIVERY_NAMESPACE);
  return {
    ok: true,
    gitDir,
    commonDir,
    namespaceDir,
    runsDir: path14.join(namespaceDir, RUN_STORE_DIRECTORY),
    worktreeKey: sha256Hex(gitDir)
  };
}
function gitNamespaceClearedEnvironment() {
  const environment = {};
  for (const [name, value] of Object.entries(process.env)) {
    if (name.startsWith("GIT_") || value === void 0) continue;
    environment[name] = value;
  }
  return { ...environment, GIT_TERMINAL_PROMPT: "0", GIT_OPTIONAL_LOCKS: "0" };
}
var runGitDirect = (launch) => new Promise((resolve) => {
  const child = spawn3("git", [...launch.args], {
    cwd: launch.cwd,
    ...launch.env === void 0 ? {} : { env: launch.env },
    stdio: ["ignore", "pipe", "ignore"],
    windowsHide: true
  });
  let stdout = "";
  child.stdout.setEncoding("utf8");
  child.stdout.on("data", (chunk) => {
    stdout += chunk;
  });
  child.once("error", () => resolve({ code: -1, stdout }));
  child.once("close", (code) => resolve({ code: code ?? -1, stdout }));
});

// packages/kernel/src/checkpoint/run-store.ts
import { constants as fsConstants2 } from "node:fs";
import { mkdir as mkdir9, open as open6, readdir as readdir4, unlink } from "node:fs/promises";
import { randomBytes as randomBytes3 } from "node:crypto";
import path15 from "node:path";
var JOURNAL_SUFFIX = ".jsonl";
var NOTES_DIRECTORY = "notes";
var CURRENT_DIRECTORY = "current";
var MAX_POINTER_BYTES = 256;
var WORKTREE_KEY = /^[0-9a-f]{64}$/;
var NOFOLLOW = {
  extraFlags: fsConstants2.O_NOFOLLOW,
  verify: ownerOnlyRegularFile,
  refuseOnError: true
};
var reject = (code, pointer2, message) => [
  { code, pointer: pointer2, message }
];
var refusalOf = (error, pointer2) => error instanceof JournalAccessRefused ? reject("access_refused", pointer2, `the store refuses this path: ${error.reason}`) : void 0;
function isLegalRunId(runId) {
  return typeof runId === "string" && runId.length <= 128 && RUN_STORE_ID.test(runId);
}
function createRunStore(commonDir) {
  const runsDir = path15.join(commonDir, MANAGED_DELIVERY_NAMESPACE, RUN_STORE_DIRECTORY);
  const notesDir = path15.join(runsDir, NOTES_DIRECTORY);
  const currentDir = path15.join(runsDir, CURRENT_DIRECTORY);
  const journalPathFor = (runId) => {
    if (!isLegalRunId(runId)) return void 0;
    const resolved = path15.join(runsDir, `${runId}${JOURNAL_SUFFIX}`);
    return path15.dirname(resolved) === runsDir ? resolved : void 0;
  };
  const notePathFor = (runId) => {
    if (!isLegalRunId(runId)) return void 0;
    const resolved = path15.join(notesDir, `${runId}${JOURNAL_SUFFIX}`);
    return path15.dirname(resolved) === notesDir ? resolved : void 0;
  };
  const pointerPathFor = (worktreeKey) => {
    if (!WORKTREE_KEY.test(worktreeKey)) return void 0;
    const resolved = path15.join(currentDir, worktreeKey);
    return path15.dirname(resolved) === currentDir ? resolved : void 0;
  };
  const journalExists = async (journalPath) => {
    let handle;
    try {
      handle = await open6(journalPath, fsConstants2.O_RDONLY | fsConstants2.O_NOFOLLOW);
    } catch (error) {
      if (error.code === "ENOENT") return false;
      throw new JournalAccessRefused(journalPath, error.code ?? "unreadable");
    }
    try {
      const refusal2 = ownerOnlyRegularFile(await handle.stat());
      if (refusal2 !== void 0) throw new JournalAccessRefused(journalPath, refusal2);
      return true;
    } finally {
      await handle.close().catch(() => void 0);
    }
  };
  const note = async (runId, event, rejection, pattern) => {
    const notePath = notePathFor(runId);
    if (notePath === void 0) return;
    const kindLike = typeof event.kind === "string" ? event.kind : "";
    const line = {
      kind: reduceToProviderId(kindLike),
      code: rejection.code,
      ...pattern === void 0 ? {} : { pattern },
      ...isRunInstant(event.at) ? { at: event.at } : {}
    };
    try {
      await mkdir9(notesDir, { recursive: true, mode: OWNER_DIR5 });
      const handle = await open6(
        notePath,
        fsConstants2.O_WRONLY | fsConstants2.O_CREAT | fsConstants2.O_APPEND | fsConstants2.O_NOFOLLOW,
        OWNER_FILE5
      );
      try {
        if (ownerOnlyRegularFile(await handle.stat()) !== void 0) return;
        await handle.writeFile(`${JSON.stringify(line)}
`, "utf8");
      } finally {
        await handle.close().catch(() => void 0);
      }
    } catch {
    }
  };
  const readJournalFile = async (journalPath) => {
    let raw;
    try {
      raw = await readRawJournal(journalPath, NOFOLLOW);
    } catch (error) {
      return { ok: false, rejections: refusalOf(error, "") ?? reject("access_refused", "", "the journal could not be read") };
    }
    const parsed = parseJournalLines(raw.lines);
    if (!parsed.ok) {
      return {
        ok: false,
        rejections: reject(
          "not_an_object",
          `/${parsed.unparsableLineIndex}`,
          "a terminated journal line is not JSON; the journal fails closed rather than skipping it"
        )
      };
    }
    const events = [];
    for (const [index, entry3] of parsed.entries.entries()) {
      const verdict = validateRunEvent(entry3);
      if (!verdict.ok) {
        return {
          ok: false,
          rejections: verdict.rejections.map((rejection) => ({ ...rejection, pointer: `/${index}${rejection.pointer}` }))
        };
      }
      events.push(entry3);
    }
    return { ok: true, events };
  };
  return {
    runsDir,
    async allocate() {
      await mkdir9(runsDir, { recursive: true, mode: OWNER_DIR5 });
      for (let attempt = 0; attempt < 8; attempt += 1) {
        const runId = `run-${randomBytes3(8).toString("hex")}`;
        const journalPath = journalPathFor(runId);
        if (journalPath === void 0) continue;
        try {
          const handle = await open6(
            journalPath,
            fsConstants2.O_WRONLY | fsConstants2.O_CREAT | fsConstants2.O_EXCL | fsConstants2.O_NOFOLLOW,
            OWNER_FILE5
          );
          await handle.close();
          return { ok: true, runId };
        } catch (error) {
          if (error.code === "EEXIST") continue;
          return { ok: false, rejections: reject("access_refused", "", `the run journal could not be created: ${error.code ?? "unknown"}`) };
        }
      }
      return { ok: false, rejections: reject("access_refused", "", "no unused run id was available after eight attempts") };
    },
    async discard(runId) {
      const journalPath = journalPathFor(runId);
      if (journalPath === void 0) {
        return { ok: false, rejections: reject("malformed_member", "/runId", "the run id is not admissible to this store") };
      }
      const read = await this.read(runId);
      if (!read.ok) return { ok: false, rejections: read.rejections };
      const [first2, ...rest] = read.events;
      if (rest.length > 0) {
        return {
          ok: false,
          rejections: reject("invalid_transition", "/seq", "this run carries history beyond its start; a journal with history is never discarded")
        };
      }
      if (first2 !== void 0 && first2.kind !== "run.started") {
        return {
          ok: false,
          rejections: reject("invalid_transition", "/kind", `this journal's one event is ${first2.kind}, not the start it was allocated for; it is never discarded`)
        };
      }
      try {
        await unlink(journalPath);
      } catch (error) {
        return {
          ok: false,
          rejections: reject("access_refused", "", `the run journal could not be removed: ${error.code ?? "unknown"}`)
        };
      }
      const notePath = notePathFor(runId);
      if (notePath !== void 0) await unlink(notePath).catch(() => void 0);
      return { ok: true };
    },
    async append(runId, event) {
      const journalPath = journalPathFor(runId);
      if (journalPath === void 0) {
        return { ok: false, rejections: reject("malformed_member", "/runId", "the run id is not admissible to this store") };
      }
      let pattern;
      let outcome;
      try {
        outcome = await appendDecided({
          journalPath,
          discipline: NOFOLLOW,
          async decide(read) {
            const disciplined = applySecretDiscipline(event, RUN_FREE_TEXT_MEMBERS);
            if (!disciplined.ok) {
              pattern = disciplined.matches[0]?.id;
              return {
                ok: false,
                rejected: disciplined.matches.map((match) => ({
                  code: "secret_rejected",
                  pointer: match.pointer,
                  message: `a ${match.id}-shaped secret has no place in this member; the append is refused before any byte is durable`
                }))
              };
            }
            if (!await journalExists(journalPath)) {
              return {
                ok: false,
                rejected: reject("unresolvable_run", "/runId", "no journal exists for this run; only allocate() creates one")
              };
            }
            const parsed = await read();
            if (!parsed.ok) {
              return {
                ok: false,
                rejected: reject(
                  "not_an_object",
                  `/${parsed.unparsableLineIndex}`,
                  "a terminated journal line is not JSON; the journal fails closed rather than skipping it"
                )
              };
            }
            const kinds = parsed.entries.map((entry3) => entry3.kind);
            const candidate2 = disciplined.entry;
            const kind = candidate2["kind"];
            const role = candidate2["actor"]?.role;
            if (kinds.includes("run.ended")) {
              return { ok: false, rejected: reject("journal_terminal", "/kind", "this run has ended; nothing may be appended after run.ended") };
            }
            if (kind === "run.started" && kinds.includes("run.started")) {
              return { ok: false, rejected: reject("invalid_transition", "/kind", "this run has already started; a run starts exactly once") };
            }
            if (role === "cli" && kind !== "command.completed") {
              return {
                ok: false,
                rejected: reject(
                  "unsupported_combination",
                  "/actor/role",
                  "only command.completed may be written by the CLI; every other kind is the executor's"
                )
              };
            }
            if (candidate2["runId"] !== runId) {
              return { ok: false, rejected: reject("subject_mismatch", "/runId", "the event names a different run than the journal it is being appended to") };
            }
            const admitted = validateRunEventInput(candidate2);
            if (!admitted.ok) return { ok: false, rejected: admitted.rejections };
            const durable = {};
            for (const [name, value] of Object.entries(candidate2)) {
              durable[name] = value;
              if (name === "runId") durable["seq"] = parsed.entries.length + 1;
            }
            const verdict = validateRunEvent(durable);
            if (!verdict.ok) return { ok: false, rejected: verdict.rejections };
            return { ok: true, entry: durable, accepted: durable };
          }
        });
      } catch (error) {
        const refusal2 = refusalOf(error, "");
        if (refusal2 === void 0) throw error;
        await note(runId, event, refusal2[0]);
        return { ok: false, rejections: refusal2 };
      }
      if (outcome.ok) return { ok: true, event: outcome.accepted };
      const first2 = outcome.rejected[0];
      if (first2 !== void 0 && first2.code !== "unresolvable_run") await note(runId, event, first2, pattern);
      return { ok: false, rejections: outcome.rejected };
    },
    async noteRefusal(runId, event, rejection) {
      await note(runId, event, rejection);
    },
    async read(runId) {
      const journalPath = journalPathFor(runId);
      if (journalPath === void 0) {
        return { ok: false, rejections: reject("malformed_member", "/runId", "the run id is not admissible to this store") };
      }
      try {
        if (!await journalExists(journalPath)) {
          return { ok: false, rejections: reject("unresolvable_run", "/runId", "no journal exists for this run") };
        }
      } catch (error) {
        const refusal2 = refusalOf(error, "");
        if (refusal2 === void 0) throw error;
        return { ok: false, rejections: refusal2 };
      }
      return readJournalFile(journalPath);
    },
    async readNotes(runId) {
      const notePath = notePathFor(runId);
      if (notePath === void 0) return [];
      try {
        const raw = await readRawJournal(notePath, NOFOLLOW);
        const parsed = parseJournalLines(raw.lines);
        return parsed.ok ? parsed.entries : [];
      } catch {
        return [];
      }
    },
    async list() {
      let entries;
      try {
        entries = await readdir4(runsDir);
      } catch {
        return [];
      }
      return entries.filter((entry3) => entry3.endsWith(JOURNAL_SUFFIX)).map((entry3) => entry3.slice(0, -JOURNAL_SUFFIX.length)).filter((runId) => isLegalRunId(runId)).sort();
    },
    async current(worktreeKey) {
      const pointerPath = pointerPathFor(worktreeKey);
      if (pointerPath === void 0) {
        return { ok: false, rejections: reject("malformed_member", "/worktreeKey", "the worktree key is not a sha256 digest") };
      }
      let handle;
      try {
        handle = await open6(pointerPath, fsConstants2.O_RDONLY | fsConstants2.O_NOFOLLOW);
      } catch (error) {
        if (error.code === "ENOENT") return { ok: true, runId: void 0 };
        return { ok: false, rejections: reject("access_refused", "", `the pointer refuses to be read: ${error.code ?? "unreadable"}`) };
      }
      try {
        const refusal2 = ownerOnlyRegularFile(await handle.stat());
        if (refusal2 !== void 0) return { ok: false, rejections: reject("access_refused", "", `the pointer refuses to be read: ${refusal2}`) };
        const buffer = Buffer.alloc(MAX_POINTER_BYTES + 1);
        const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
        if (bytesRead > MAX_POINTER_BYTES) return { ok: true, runId: void 0 };
        const named = buffer.subarray(0, bytesRead).toString("utf8").trim();
        if (!isLegalRunId(named)) return { ok: true, runId: void 0 };
        const journalPath = journalPathFor(named);
        if (journalPath === void 0) return { ok: true, runId: void 0 };
        try {
          return await journalExists(journalPath) ? { ok: true, runId: named } : { ok: true, runId: void 0 };
        } catch {
          return { ok: true, runId: void 0 };
        }
      } finally {
        await handle.close().catch(() => void 0);
      }
    },
    async setCurrent(worktreeKey, runId, options) {
      const pointerPath = pointerPathFor(worktreeKey);
      if (pointerPath === void 0) {
        return { ok: false, rejections: reject("malformed_member", "/worktreeKey", "the worktree key is not a sha256 digest") };
      }
      if (!isLegalRunId(runId)) {
        return { ok: false, rejections: reject("malformed_member", "/runId", "the run id is not admissible to this store") };
      }
      return serializedOnPath(pointerPath, async () => {
        await mkdir9(currentDir, { recursive: true, mode: OWNER_DIR5 });
        const write = async () => {
          try {
            const handle = await open6(
              pointerPath,
              fsConstants2.O_WRONLY | fsConstants2.O_CREAT | fsConstants2.O_EXCL | fsConstants2.O_NOFOLLOW,
              OWNER_FILE5
            );
            try {
              await handle.writeFile(runId, "utf8");
            } finally {
              await handle.close().catch(() => void 0);
            }
            return { ok: true };
          } catch (error) {
            if (error.code === "EEXIST") return void 0;
            return {
              ok: false,
              rejections: reject("invalid_transition", "", `the pointer could not be created: ${error.code ?? "unknown"}`)
            };
          }
        };
        const created = await write();
        if (created !== void 0) return created;
        if (options?.force !== true) {
          return {
            ok: false,
            rejections: reject("invalid_transition", "", "a run is already current for this worktree; --force displaces it")
          };
        }
        const displaced = await this.current(worktreeKey);
        await unlink(pointerPath).catch(() => void 0);
        const forced = await write();
        if (forced === void 0) {
          return { ok: false, rejections: reject("invalid_transition", "", "the pointer could not be displaced") };
        }
        if (!forced.ok) return forced;
        const previous = displaced.ok ? displaced.runId : void 0;
        return previous === void 0 ? { ok: true } : { ok: true, displaced: previous };
      });
    },
    async clearCurrent(worktreeKey, runId) {
      const pointerPath = pointerPathFor(worktreeKey);
      if (pointerPath === void 0) return false;
      return serializedOnPath(pointerPath, async () => {
        const named = await this.current(worktreeKey);
        if (!named.ok || named.runId !== runId) return false;
        await unlink(pointerPath).catch(() => void 0);
        return true;
      });
    },
    async findByCandidateTreeSha(treeSha2) {
      const matches = [];
      for (const runId of await this.list()) {
        const read = await this.read(runId);
        if (!read.ok) continue;
        if (!read.events.some((entry3) => entry3.candidateTreeSha === treeSha2)) continue;
        const started = read.events.find((entry3) => entry3.kind === "run.started");
        matches.push({ runId, startedAt: isRunInstant(started?.at) ? started.at : void 0 });
      }
      matches.sort((left, right) => {
        if (left.startedAt !== right.startedAt) {
          if (left.startedAt === void 0) return 1;
          if (right.startedAt === void 0) return -1;
          return left.startedAt < right.startedAt ? 1 : -1;
        }
        return left.runId < right.runId ? 1 : -1;
      });
      const [selected, ...rest] = matches;
      return selected === void 0 ? void 0 : { runId: selected.runId, alsoMatching: rest.map((entry3) => entry3.runId) };
    }
  };
}

// packages/kernel/src/checkpoint/retention.ts
import { chmod as chmod9, mkdir as mkdir10, readFile as readFile11, rm as rm6, writeFile as writeFile7 } from "node:fs/promises";
import path16 from "node:path";
var OWNER_DIR6 = 448;
var OWNER_FILE6 = 384;
var refuse2 = (code, summary, remediation) => ({ ok: false, code, summary, remediation });
async function writeOwned(target, contents) {
  await mkdir10(path16.dirname(target), { recursive: true, mode: OWNER_DIR6 });
  await writeFile7(target, contents, { mode: OWNER_FILE6 });
  await chmod9(target, OWNER_FILE6);
}
async function appendRetentionRecord(context, action, deliveryId, artifactDigest, preservedAuditRecords) {
  const store = createMaintenanceJournalStore(context.maintenanceJournalPath);
  const read = await store.read();
  if (!read.ok) {
    return refuse2("maintenance_journal_unreadable", "The maintenance journal is unreadable.", "Inspect the installation's maintenance journal file.");
  }
  let expectedRevision = 0;
  if (read.entries.length > 0) {
    const reduced = await store.state();
    if (!reduced.ok) {
      return refuse2("maintenance_journal_rejected", "The maintenance journal does not reduce.", "Inspect the installation's maintenance journal file.");
    }
    expectedRevision = reduced.state.expectedRevision;
  }
  const appended = await store.append({
    spec: "journal-entry/1",
    journal: "maintenance",
    subjectId: context.installationId,
    expectedRevision,
    idempotencyKey: `m${read.entries.length}-${action}-${deliveryId}`,
    kind: "retention.action.recorded",
    payload: { action, subjectDeliveryId: deliveryId, artifactDigest, preservedAuditRecords: [...preservedAuditRecords] }
  });
  if (!appended.ok) {
    return refuse2(
      "maintenance_journal_rejected",
      `The maintenance journal refused the retention record: ${appended.rejections.map((rejection) => rejection.message).join("; ")}`,
      "The retention action is not performed without its durable record."
    );
  }
  return { ok: true };
}
var lastOf = (views, kind) => [...views].reverse().find((view) => view.kind === kind);
async function exportDelivery(context, deliveryId) {
  const deliveryDir = path16.join(context.namespaceDir, "deliveries", deliveryId);
  const store = createJournalStore(path16.join(deliveryDir, "journal.jsonl"));
  const read = await store.read();
  if (!read.ok || read.entries.length === 0) {
    return refuse2("unknown_delivery", `No registered delivery ${deliveryId} to export.`, "Name a registered delivery.");
  }
  let meta;
  try {
    meta = JSON.parse(await readFile11(path16.join(deliveryDir, "delivery.json"), "utf8"));
  } catch {
    meta = void 0;
  }
  const bundle = `${JSON.stringify({
    spec: "delivery-export/1",
    deliveryId,
    installationId: context.installationId,
    journal: read.entries,
    ...meta === void 0 ? {} : { meta }
  })}
`;
  const artifactDigest = sha256Hex(bundle);
  const exportPath = path16.join(context.namespaceDir, "exports", `${deliveryId}.json`);
  await writeOwned(exportPath, bundle);
  const recorded = await appendRetentionRecord(context, "export", deliveryId, artifactDigest, []);
  if (!recorded.ok) return recorded;
  return { ok: true, exportPath, artifactDigest };
}
async function deleteDelivery(context, deliveryId) {
  const deliveryDir = path16.join(context.namespaceDir, "deliveries", deliveryId);
  const store = createJournalStore(path16.join(deliveryDir, "journal.jsonl"));
  const read = await store.read();
  if (!read.ok || read.entries.length === 0) {
    return refuse2("unknown_delivery", `No registered delivery ${deliveryId} to delete.`, "Name a registered delivery.");
  }
  const reduced = await store.state();
  if (!reduced.ok) {
    return refuse2("journal_rejected", "The delivery journal does not reduce; nothing is deleted over a journal that fails closed.", "Inspect the durable journal file.");
  }
  const finalState = reduced.state.state;
  if (finalState !== "completed" && finalState !== "cancelled" && finalState !== "failed") {
    return refuse2(
      "delivery_not_terminal",
      `Delivery ${deliveryId} is ${finalState}; only terminal-delivery detail is deletable.`,
      "Finish or cancel the delivery first; retention bounds apply to terminal detail only."
    );
  }
  const views = read.entries.map((entry3) => {
    const record2 = entry3;
    return { kind: record2["kind"], payload: record2["payload"] };
  });
  const registered = lastOf(views, "delivery.registered");
  const candidate2 = lastOf(views, "candidate.recaptured") ?? lastOf(views, "invocation.fenced");
  const finishLine = lastOf(views, "finish.line.recorded");
  const audit = `${JSON.stringify({
    spec: "delivery-audit/1",
    deliveryId,
    finalState,
    contractDigest: registered?.payload["contractDigest"],
    ...reduced.state.policyDigest === void 0 ? {} : { policyDigest: reduced.state.policyDigest },
    ...reduced.state.generationDigest === void 0 ? {} : { generationDigest: reduced.state.generationDigest },
    ...candidate2 === void 0 ? {} : { candidate: candidate2.payload },
    evidenceReferences: views.filter((view) => view.kind === "evidence.reference.recorded").map((view) => view.payload),
    actions: views.filter((view) => view.kind === "finish.line.recorded").length,
    ...finishLine === void 0 ? {} : { finishLine: finishLine.payload }
  })}
`;
  const auditRelative = path16.join("audit", `${deliveryId}.json`);
  const auditPath = path16.join(context.namespaceDir, auditRelative);
  await writeOwned(auditPath, audit);
  const preservedAuditRecords = [auditRelative];
  const recorded = await appendRetentionRecord(context, "delete", deliveryId, sha256Hex(audit), preservedAuditRecords);
  if (!recorded.ok) return recorded;
  await rm6(deliveryDir, { recursive: true, force: true });
  return { ok: true, auditPath, preservedAuditRecords, artifactDigest: sha256Hex(audit) };
}

// packages/kernel/src/workflow/graph.ts
var WORKFLOW_GRAPH_ENTRY = "workflows/delivery-v1.json";
function loadBundledWorkflowGraph(archiveBytes, options = {}) {
  const readEntry = options.readEntry ?? readArchiveEntry;
  let bytes;
  try {
    bytes = readEntry(archiveBytes, WORKFLOW_GRAPH_ENTRY);
  } catch (error) {
    return {
      ok: false,
      blockers: [
        {
          code: "workflow_graph_malformed",
          message: `the bundled workflow graph could not be read: ${error instanceof Error ? error.message : String(error)}`
        }
      ]
    };
  }
  const digest2 = sha256Hex(bytes);
  if (digest2 !== PINNED_AGENT_SKILLS.workflowGraphSha256) {
    return {
      ok: false,
      blockers: [
        {
          code: "workflow_graph_digest_mismatch",
          message: `the bundled graph hashes to ${digest2}, not the pinned ${PINNED_AGENT_SKILLS.workflowGraphSha256}; the pin governs`
        }
      ]
    };
  }
  let parsed;
  try {
    parsed = JSON.parse(Buffer.from(bytes).toString("utf8"));
  } catch {
    return { ok: false, blockers: [{ code: "workflow_graph_malformed", message: "the bundled graph is not JSON" }] };
  }
  const record2 = typeof parsed === "object" && parsed !== null ? parsed : void 0;
  const stages = record2?.["stages"];
  if (record2?.["schemaVersion"] !== "workflow-graph/1" || typeof record2["graphId"] !== "string" || !Array.isArray(stages)) {
    return {
      ok: false,
      blockers: [{ code: "workflow_graph_malformed", message: "the bundled graph is outside the workflow-graph/1 shape" }]
    };
  }
  const parsedStages = [];
  for (const stage of stages) {
    const parsedStage = parseStage(stage);
    if (parsedStage === void 0) {
      return {
        ok: false,
        blockers: [{ code: "workflow_graph_malformed", message: "a bundled graph stage is outside its declared shape" }]
      };
    }
    parsedStages.push(parsedStage);
  }
  return {
    ok: true,
    graph: { schemaVersion: "workflow-graph/1", graphId: record2["graphId"], stages: parsedStages },
    graphSha256: digest2,
    bytes
  };
}
var STAGE_MEMBERS = /* @__PURE__ */ new Set([
  "id",
  "semanticKind",
  "prerequisites",
  "mutationClass",
  "requiredness",
  "candidateBinding",
  "requiredInputs",
  "optionalInputs",
  "successOutputs",
  "statuses",
  "evidenceAdapter",
  "edges"
]);
var asRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value) ? value : void 0;
var stringArrayOf = (value) => Array.isArray(value) && value.every((item) => typeof item === "string") ? value : void 0;
function parseStage(value) {
  const entry3 = asRecord(value);
  if (entry3 === void 0) return void 0;
  for (const member2 of Object.keys(entry3)) {
    if (!STAGE_MEMBERS.has(member2)) return void 0;
  }
  if (typeof entry3["id"] !== "string" || typeof entry3["semanticKind"] !== "string" || typeof entry3["mutationClass"] !== "string" || typeof entry3["requiredness"] !== "string" || typeof entry3["candidateBinding"] !== "string") {
    return void 0;
  }
  const requiredInputs = stringArrayOf(entry3["requiredInputs"]);
  const optionalInputs = stringArrayOf(entry3["optionalInputs"]);
  const successOutputs = stringArrayOf(entry3["successOutputs"]);
  const statuses = stringArrayOf(entry3["statuses"]);
  if (requiredInputs === void 0 || optionalInputs === void 0 || successOutputs === void 0 || statuses === void 0) {
    return void 0;
  }
  const adapterRecord = asRecord(entry3["evidenceAdapter"]);
  if (adapterRecord === void 0 || typeof adapterRecord["requirement"] !== "string") return void 0;
  const adapterRef = adapterRecord["ref"];
  if (adapterRef !== void 0 && typeof adapterRef !== "string") return void 0;
  const evidenceAdapter = {
    requirement: adapterRecord["requirement"],
    ...adapterRef === void 0 ? {} : { ref: adapterRef }
  };
  if (!Array.isArray(entry3["prerequisites"]) || !Array.isArray(entry3["edges"])) return void 0;
  const prerequisites = [];
  for (const raw of entry3["prerequisites"]) {
    const prerequisite = asRecord(raw);
    const outputs = stringArrayOf(prerequisite?.["outputs"]);
    if (prerequisite === void 0 || typeof prerequisite["stageId"] !== "string" || typeof prerequisite["when"] !== "string" || outputs === void 0 || typeof prerequisite["allowOmitted"] !== "boolean") {
      return void 0;
    }
    prerequisites.push({
      stageId: prerequisite["stageId"],
      when: prerequisite["when"],
      outputs,
      allowOmitted: prerequisite["allowOmitted"]
    });
  }
  const edges = [];
  for (const raw of entry3["edges"]) {
    const edge = asRecord(raw);
    if (edge === void 0 || typeof edge["to"] !== "string" || typeof edge["when"] !== "string") return void 0;
    edges.push({ to: edge["to"], when: edge["when"] });
  }
  return {
    id: entry3["id"],
    semanticKind: entry3["semanticKind"],
    prerequisites,
    mutationClass: entry3["mutationClass"],
    requiredness: entry3["requiredness"],
    candidateBinding: entry3["candidateBinding"],
    requiredInputs,
    optionalInputs,
    successOutputs,
    statuses,
    evidenceAdapter,
    edges
  };
}
function workflowStageOf(graph, stageId) {
  return graph.stages.find((stage) => stage.id === stageId);
}
var WORKFLOW_CHECKPOINT_BINDINGS = Object.freeze([
  { deliveryState: "planning", stageId: "plan", productRealizedPrerequisites: [] },
  { deliveryState: "implementing", stageId: "implement", productRealizedPrerequisites: [] },
  { deliveryState: "remediating", stageId: "implement", productRealizedPrerequisites: [] },
  { deliveryState: "reviewing", stageId: "review.acquire", productRealizedPrerequisites: [] },
  { deliveryState: "compounding", stageId: "compound", productRealizedPrerequisites: ["finish.verify"] }
]);
function workflowStageBindingFor(state) {
  return WORKFLOW_CHECKPOINT_BINDINGS.find((binding) => binding.deliveryState === state);
}

// packages/kernel/src/host/consumption-gate-record.ts
import { lstat, open as open7, readFile as readFile12, realpath as realpath4, rename as rename5, rm as rm7, stat as stat5, writeFile as writeFile8 } from "node:fs/promises";
import path18 from "node:path";

// packages/kernel/src/projection-consumption-observation.ts
import path17 from "node:path";
var PROJECTION_CONSUMPTION_OBSERVATION_SPEC = "projection-consumption-observation/1";
var OBSERVATION_KEYS = Object.freeze([
  "canonicalProjectionPath",
  "deliveryId",
  "entry",
  "fence",
  "hostInvocationId",
  "observedAt",
  "projectionDigest",
  "spec"
]);
var nonempty = (value) => typeof value === "string" && value.length > 0;
function parseProjectionConsumptionObservation(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return void 0;
  const observation = value;
  const keys = Object.keys(observation).sort();
  if (keys.length !== OBSERVATION_KEYS.length || keys.some((key, index) => key !== OBSERVATION_KEYS[index])) {
    return void 0;
  }
  if (observation["spec"] !== PROJECTION_CONSUMPTION_OBSERVATION_SPEC || !nonempty(observation["deliveryId"]) || !Number.isSafeInteger(observation["fence"]) || observation["fence"] <= 0 || observation["entry"] !== WORKFLOW_GRAPH_ENTRY || !nonempty(observation["canonicalProjectionPath"]) || !path17.isAbsolute(observation["canonicalProjectionPath"]) || typeof observation["projectionDigest"] !== "string" || !SPINE_SHA256.test(observation["projectionDigest"]) || !nonempty(observation["hostInvocationId"]) || typeof observation["observedAt"] !== "string" || !SPINE_INSTANT.test(observation["observedAt"])) {
    return void 0;
  }
  return observation;
}
var projectionConsumptionObservationFile = (fence) => `projection-consumption-${fence}.json`;

// packages/kernel/src/host/consumption-gate-record.ts
var SHADOW_MILESTONE_GATE_RECORD_SPEC_SUFFIX = "shadow-milestone-gate-record/1";
var SHADOW_MILESTONE_GATE_RECORD_SPEC = `athena-${SHADOW_MILESTONE_GATE_RECORD_SPEC_SUFFIX}`;
var SHADOW_MILESTONE_GATE_RECORD_PATH = ".agents/policy/shadow-milestone-gate-record.json";
var isGateRecordSpec = (value) => typeof value === "string" && value.endsWith(SHADOW_MILESTONE_GATE_RECORD_SPEC_SUFFIX) && value.length > SHADOW_MILESTONE_GATE_RECORD_SPEC_SUFFIX.length;
var CONSUMPTION_GATE_RECORD_BLOCKER_CODES = Object.freeze([
  "gate_record_unreadable",
  "gate_record_unrecognized",
  "gate_record_repository_mismatch",
  "gate_record_locked",
  "gate_record_write_failed"
]);
var fail5 = (code, message) => ({ ok: false, blockers: [{ code, message }] });
var unobserved = (reason) => ({
  ok: true,
  emitted: false,
  reason
});
async function emitProjectionConsumptionRecord(input) {
  const projection = await verifyProjection({
    worktreeDir: input.worktreeDir,
    bindingDir: input.bindingDir
  });
  if (!projection.ok) return unobserved("projection-unverified");
  const marker = await readConsumptionMarker({ worktreeDir: input.worktreeDir });
  if (!marker.ok) return unobserved("marker-unreadable");
  if (marker.deliveryId !== input.deliveryId || marker.fence !== input.fence) {
    return unobserved("marker-names-another-run");
  }
  let observation;
  try {
    observation = parseProjectionConsumptionObservation(JSON.parse(
      await readFile12(
        path18.join(input.bindingDir, projectionConsumptionObservationFile(input.fence)),
        "utf8"
      )
    ));
  } catch {
    return unobserved("projection-not-consumed");
  }
  if (observation === void 0) return unobserved("projection-not-consumed");
  let canonicalWorkflowPath;
  try {
    canonicalWorkflowPath = await realpath4(
      path18.join(input.worktreeDir, PROJECTION_DIR, ...WORKFLOW_GRAPH_ENTRY.split("/"))
    );
  } catch {
    return unobserved("projection-not-consumed");
  }
  if (observation.deliveryId !== input.deliveryId || observation.fence !== input.fence || observation.entry !== WORKFLOW_GRAPH_ENTRY || observation.canonicalProjectionPath !== canonicalWorkflowPath || observation.projectionDigest !== projection.projectionDigest || typeof observation.hostInvocationId !== "string" || observation.hostInvocationId.length === 0 || // CONTAINMENT. DO NOT DELETE THIS AS A DUPLICATE OF THE BINDING'S CHECK —
  // it is the same question asked of differently trusted state.
  //
  // The binding checks containment before recording, and must: the
  // observation is one-shot per fence, so an unadmissible name would lock
  // out the honest read that follows. But it reads the receipt as plain
  // JSON — no self-binding digest check, no byte verification — because at
  // interception time that is all it can afford. The check HERE runs
  // against `verifyProjection`'s entries, which come from a receipt that
  // binds its own digest and whose every byte was re-hashed against the
  // worktree moments ago.
  //
  // So the binding's check is about slot economy against an unvalidated
  // receipt; this one is the admissibility rule, against a validated one.
  // Removing either brings back a defect the other does not cover.
  //
  // The gap between interception and this check is real but cannot make the
  // record false: every projection byte is re-verified above, so a run whose
  // worktree changed after the observation fails verification rather than
  // emitting. The most a delay can cost is a stale provenance, never a
  // claim about bytes that are no longer there.
  !projection.entries.includes(WORKFLOW_GRAPH_ENTRY)) {
    return unobserved("projection-not-consumed");
  }
  const record2 = {
    source: "binding",
    affirmative: true,
    projectionDigest: projection.projectionDigest,
    marker: { deliveryId: marker.deliveryId, fence: marker.fence, consumed: marker.consumed }
  };
  const target = await resolveGateRecordTarget(input);
  if ("ok" in target) return target;
  const scopedInput = {
    ...input,
    gateRecordPath: target.gateRecordPath,
    repositoryRoot: target.repositoryRoot
  };
  const preflight = await readGateRecord(scopedInput);
  if ("ok" in preflight) return preflight;
  const lockPath = `${scopedInput.gateRecordPath}.lock`;
  let lock;
  try {
    lock = await open7(lockPath, "wx");
  } catch (error) {
    return fail5(
      "gate_record_locked",
      `another writer holds ${lockPath}; the milestone gate record takes one writer at a time (remove the lock only if no writer is running): ${error instanceof Error ? error.message : String(error)}`
    );
  }
  try {
    return await writeEntry(scopedInput, record2, lockPath);
  } finally {
    await lock.close().catch(() => void 0);
    await rm7(lockPath, { force: true }).catch(() => void 0);
  }
}
async function resolveGateRecordTarget(input) {
  let repositoryRoot;
  let gateRecordParent;
  let gateRecordPath;
  let recordLink;
  let recordStat;
  try {
    repositoryRoot = await realpath4(input.repositoryRoot);
    const expectedParent = path18.join(repositoryRoot, ".agents", "policy");
    const expectedRecord = path18.join(expectedParent, SHADOW_MILESTONE_GATE_RECORD_PATH.split("/").at(-1));
    [gateRecordParent, gateRecordPath, recordLink, recordStat] = await Promise.all([
      realpath4(path18.dirname(input.gateRecordPath)),
      realpath4(input.gateRecordPath),
      lstat(expectedRecord),
      stat5(expectedRecord)
    ]);
    if (gateRecordParent !== expectedParent || gateRecordPath !== expectedRecord || !recordLink.isFile() || recordLink.isSymbolicLink() || recordStat.nlink !== 1) {
      return fail5(
        "gate_record_repository_mismatch",
        `${input.gateRecordPath} is not the single-link protected gate record at ${expectedRecord}; the writer refuses a same-repository alias before changing either record`
      );
    }
  } catch (error) {
    return fail5(
      "gate_record_unreadable",
      `${input.gateRecordPath} cannot be resolved inside its repository: ${error instanceof Error ? error.message : String(error)}`
    );
  }
  return { repositoryRoot, gateRecordPath };
}
async function writeEntry(input, record2, lockPath) {
  const beforeRead = await resolveGateRecordTarget(input);
  if ("ok" in beforeRead) return beforeRead;
  const loaded = await readGateRecord(input);
  if ("ok" in loaded) return loaded;
  const document = loaded.document;
  const deliveries = [...document["deliveries"]];
  const index = deliveries.findIndex(
    (entry4) => typeof entry4 === "object" && entry4 !== null && entry4["id"] === input.deliveryId
  );
  const existing = index >= 0 ? deliveries[index] : {};
  const excluded = existing["countedInComparisonSet"] === false;
  const entry3 = {
    ...existing,
    id: input.deliveryId,
    category: input.category,
    countedInComparisonSet: !excluded,
    projectionConsumption: record2
  };
  if (index >= 0) deliveries[index] = entry3;
  else deliveries.push(entry3);
  const tempPath = `${input.gateRecordPath}.${path18.basename(lockPath)}.tmp`;
  try {
    const beforePublish = await resolveGateRecordTarget(input);
    if ("ok" in beforePublish) return beforePublish;
    await writeFile8(tempPath, `${JSON.stringify({ ...document, deliveries }, null, 2)}
`);
    await rename5(tempPath, input.gateRecordPath);
  } catch (error) {
    await rm7(tempPath, { force: true }).catch(() => void 0);
    return fail5(
      "gate_record_write_failed",
      `writing ${input.gateRecordPath} failed: ${error instanceof Error ? error.message : String(error)}`
    );
  }
  return { ok: true, emitted: true, record: record2 };
}
async function readGateRecord(input) {
  let text4;
  try {
    text4 = await readFile12(input.gateRecordPath, "utf8");
  } catch (error) {
    return fail5(
      "gate_record_unreadable",
      `${input.gateRecordPath} is not readable, so no consumption record can be added to it: ${error instanceof Error ? error.message : String(error)}`
    );
  }
  let document;
  try {
    document = JSON.parse(text4);
  } catch (error) {
    return fail5("gate_record_unreadable", `${input.gateRecordPath} is not valid JSON: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (typeof document !== "object" || document === null || !isGateRecordSpec(document["spec"]) || !Array.isArray(document["deliveries"])) {
    return fail5(
      "gate_record_unrecognized",
      `${input.gateRecordPath} does not declare a <consumer>-${SHADOW_MILESTONE_GATE_RECORD_SPEC_SUFFIX} spec with a deliveries list; the writer edits a milestone gate record and nothing else`
    );
  }
  if (document["repositoryId"] !== input.expectedRepositoryId) {
    return fail5(
      "gate_record_repository_mismatch",
      `${input.gateRecordPath} declares repositoryId ${JSON.stringify(document["repositoryId"])}, but this delivery is bound to ${JSON.stringify(input.expectedRepositoryId)}; the writer refuses a cross-repository gate target before changing either record`
    );
  }
  return { document };
}

// packages/kernel/src/host/exec-port.ts
import { execFile as execFile3 } from "node:child_process";
function createExecPort() {
  return {
    run(invocation) {
      return new Promise((resolve) => {
        execFile3(
          invocation.command,
          [...invocation.args],
          {
            cwd: invocation.cwd,
            ...invocation.env === void 0 ? {} : { env: { ...invocation.env } },
            encoding: "utf8",
            maxBuffer: invocation.maxBuffer ?? 16 * 1024 * 1024,
            ...invocation.timeoutMs === void 0 ? {} : { timeout: invocation.timeoutMs, killSignal: "SIGKILL" },
            ...invocation.signal === void 0 ? {} : { signal: invocation.signal }
          },
          (error, stdout, stderr) => {
            const code = error === null ? 0 : typeof error.code === "number" ? error.code : 1;
            resolve({
              code,
              stdout,
              stderr,
              ...error === null ? {} : { errorCode: String(error.code ?? error.signal ?? "execution_failed") }
            });
          }
        );
      });
    }
  };
}

// packages/kernel/src/evidence/review.ts
function qualifyReviewAttempts(attempts, candidateTreeSha) {
  const qualified = [];
  const disqualified = [];
  const holders = /* @__PURE__ */ new Map();
  for (const attempt of attempts) {
    if (attempt.candidateTreeSha !== candidateTreeSha) continue;
    const holder = holders.get(attempt.contextDigest);
    if (holder !== void 0) {
      disqualified.push({ attempt, collidesWith: holder });
      continue;
    }
    holders.set(attempt.contextDigest, attempt.attemptId);
    qualified.push(attempt);
  }
  return { qualified, disqualified };
}
function checkReviewFloor(input) {
  const rejections = [];
  const emit = (code, pointer2, message) => {
    rejections.push({ code, pointer: pointer2, message });
  };
  const current = input.attempts.filter((attempt) => attempt.candidateTreeSha === input.candidateTreeSha);
  if (current.length === 0) {
    emit(
      "zero_review_attempts",
      "/attempts",
      "no completed review attempt is bound to the current candidate; an aligned final review is mandatory after every mutation"
    );
    return { ok: false, rejections };
  }
  const seenAttemptIds = /* @__PURE__ */ new Set();
  current.forEach((attempt, index) => {
    if (seenAttemptIds.has(attempt.attemptId)) {
      emit(
        "duplicate_review_attempt",
        spinePointer("/attempts", index, "attemptId"),
        `attempt ${attempt.attemptId} appears twice; review attempts complete under distinct attempt identities`
      );
    }
    seenAttemptIds.add(attempt.attemptId);
  });
  const { qualified, disqualified } = qualifyReviewAttempts(input.attempts, input.candidateTreeSha);
  for (const lens of input.lenses) {
    if (qualified.some((attempt) => attempt.lensId === lens.lensId && attempt.personaDigest === lens.personaDigest)) continue;
    const misbound = qualified.find((attempt) => attempt.lensId === lens.lensId);
    if (misbound !== void 0) {
      emit(
        "persona_digest_mismatch",
        "/attempts",
        `attempt ${misbound.attemptId} is bound to reviewer charter ${misbound.personaDigest}, which is not the charter lens ${lens.lensId} references (${lens.personaDigest}); the lens is unsatisfied whatever the attempt claims`
      );
      continue;
    }
    const collision = disqualified.find((entry3) => entry3.attempt.lensId === lens.lensId);
    if (collision !== void 0) {
      emit(
        "duplicate_review_context",
        "/attempts",
        `mandatory lens ${lens.lensId} is covered only by attempt ${collision.attempt.attemptId}, which carries the same context digest as ${collision.collidesWith}; same-context re-invocation under a fresh attempt identity does not qualify as independence`
      );
      continue;
    }
    emit(
      "criterion_unverified",
      "/attempts",
      `mandatory lens ${lens.lensId} (${lens.category}) has no completed attempt on the current candidate`
    );
  }
  return rejections.length === 0 ? { ok: true } : { ok: false, rejections };
}
function composeOutcomeVerification(input) {
  const waived = new Map((input.waivedCriteria ?? []).map((entry3) => [entry3.criterionId, entry3.reference]));
  const criteria = input.contract.acceptanceCriteria.map((criterion) => {
    const latest = [...input.sensorResults].reverse().find((result2) => result2.candidateTreeSha === input.candidate.treeSha);
    const passed = latest !== void 0 && latest.outcome === "passed";
    const waiver = waived.get(criterion.criterionId);
    if (!passed && waiver !== void 0) {
      return {
        criterionId: criterion.criterionId,
        disposition: "amended-waived",
        evidence: { kind: "review", reference: waiver }
      };
    }
    return {
      criterionId: criterion.criterionId,
      disposition: passed ? "passed" : "blocked",
      evidence: {
        kind: "sensor",
        reference: latest === void 0 ? "sensor.acceptance: no exact-candidate result" : `${latest.capabilityId}@${latest.candidateTreeSha}: ${latest.outcome}`
      }
    };
  });
  return {
    spec: "outcome-verification/1",
    contractId: input.contract.contractId,
    candidate: { ...input.candidate },
    criteria,
    reviewAttempts: qualifyReviewAttempts(input.attempts, input.candidate.treeSha).qualified.map((attempt) => ({
      attemptId: attempt.attemptId,
      lensId: attempt.lensId,
      contextDigest: attempt.contextDigest,
      personaDigest: attempt.personaDigest,
      verdict: attempt.verdict
    }))
  };
}

// packages/kernel/src/evidence/waiver.ts
var WAIVER_ACTIONS = Object.freeze(["waive-criterion", "confirm-outcome-amendment"]);
var WAIVER_APPROVAL_ORIGIN_PREFIX = "waiver-approval:";
var CONSUMABLE_STATES = ["reviewing", "remediating", "admitting"];
function approverOf(origin) {
  if (typeof origin !== "string" || !origin.startsWith(WAIVER_APPROVAL_ORIGIN_PREFIX)) return void 0;
  const approver = origin.slice(WAIVER_APPROVAL_ORIGIN_PREFIX.length).trim();
  return approver.length > 0 ? approver : void 0;
}
function evaluateWaiverConsumption(assertion, context) {
  const blockers = [];
  const refuse4 = (code, message) => {
    blockers.push({ code, message });
  };
  const shape = validateSensitiveApprovalAssertion(assertion);
  if (!shape.ok || assertion["assertionClass"] !== "delivery-bound") {
    refuse4("assertion_malformed", "the presented value is not a well-formed delivery-bound sensitive-approval assertion");
    return { ok: false, blockers };
  }
  const action = assertion["action"];
  if (typeof action !== "string" || !WAIVER_ACTIONS.includes(action)) {
    refuse4("assertion_mismatch", `the assertion approves ${String(action)}, which is not a waiver action`);
    return { ok: false, blockers };
  }
  if (assertion["deliveryId"] !== context.deliveryId) {
    refuse4("assertion_mismatch", "the assertion binds a different delivery");
  }
  if (assertion["candidateTreeSha"] !== context.candidateTreeSha) {
    refuse4("assertion_mismatch", "the assertion binds a different candidate; a waiver is candidate-bound evidence");
  }
  if (assertion["policyDigest"] !== context.policyDigest) {
    refuse4("assertion_mismatch", "the assertion binds a different compiled policy snapshot");
  }
  if (assertion["invocationFence"] !== context.invocationFence) {
    refuse4("assertion_mismatch", "the assertion binds a superseded invocation fence");
  }
  if (assertion["productTrustRevocationEpoch"] !== context.productTrustRevocationEpoch) {
    refuse4("assertion_stale", "the assertion was evaluated under a superseded product-trust revocation epoch");
  }
  if (assertion["repositoryAuthorityRevocationEpoch"] !== context.repositoryAuthorityRevocationEpoch) {
    refuse4("assertion_stale", "the assertion was evaluated under a superseded repository authority-revocation epoch");
  }
  const expiry = assertion["expiry"];
  if (typeof expiry !== "string" || expiry < context.now) {
    refuse4("assertion_stale", "the assertion expired; an expired evaluation is a cached credential, treated as invalid");
  }
  const nonce = assertion["nonce"];
  if (typeof nonce === "string" && context.consumedNonces.has(nonce)) {
    refuse4("assertion_replayed", `nonce ${nonce} was already consumed by this delivery journal`);
  }
  if (assertion["assertionSource"] === "qualification-fixture" && context.currentProfile !== "confirmation-fixture") {
    refuse4("assertion_source_mismatch", "a fixture-sourced assertion can never approve a waiver on a production installation");
  }
  if (!CONSUMABLE_STATES.includes(context.deliveryState)) {
    refuse4(
      "waiver_after_admission",
      `a waiver is consumed within ${CONSUMABLE_STATES.join(", ")}; the delivery is in ${context.deliveryState}`
    );
  }
  const proposal = context.proposal;
  if (proposal === void 0) {
    refuse4("waiver_unproposed", "no pending proposal is journaled for this delivery; a waiver is never self-standing");
    return { ok: false, blockers };
  }
  if (!context.contractCriterionIds.includes(proposal.criterionId)) {
    refuse4("waiver_criterion_unknown", `criterion ${proposal.criterionId} is not an acceptance criterion of this contract`);
  }
  if (proposal.candidateTreeSha !== context.candidateTreeSha) {
    refuse4(
      "waiver_proposal_stale",
      "the candidate changed since the proposal was journaled; the criterion binding is re-evaluated and the stale proposal voids"
    );
  }
  const approver = approverOf(assertion["origin"]);
  if (approver === void 0) {
    refuse4("waiver_approver_unnamed", `the assertion origin does not name an approving identity (${WAIVER_APPROVAL_ORIGIN_PREFIX}<id>)`);
  } else if (approver === proposal.actorId) {
    refuse4("waiver_self_approved", `${approver} both proposed and approved this waiver; an agent cannot propose and approve`);
  }
  const outcomeChanging = action === "confirm-outcome-amendment";
  if (outcomeChanging && (approver === void 0 || !context.outcomeAuthorities.includes(approver))) {
    refuse4(
      "outcome_authority_missing",
      `confirming that the intended outcome changed requires a policy-declared outcome authority; ${String(approver)} is not one`
    );
  }
  return blockers.length === 0 ? { ok: true, outcomeChanging, criterionId: proposal.criterionId } : { ok: false, blockers };
}
function checkPositiveCriterion(criteria) {
  if (criteria.some((criterion) => criterion.disposition === "passed")) return { ok: true };
  return {
    ok: false,
    blockers: [
      {
        code: "blanket_waiver",
        message: "no acceptance criterion passed; a blanket waiver cannot produce delivery success, and an empty criterion set cannot pass by absence"
      }
    ]
  };
}

// packages/kernel/src/evidence/blocker-inventory.ts
var DELIVERY_BLOCKER_REMEDIATIONS = Object.freeze({
  "trust.generation-ineligible": "Restore local trust state through the operator maintenance lane, then leave security_blocked through full re-preparation.",
  "trust.installation-mismatch": "Rebinding a delivery to another installation is an explicit migration, not an ambient adoption; run the security-blocked migration.",
  "authority.epoch-changed": "The repository authority-revocation epoch moved; re-evaluate the delivery under the current compiled policy before continuing.",
  "discovery.configuration-tampered": "Quarantine the workspace and resume through an operator-authorized takeover into a fresh worktree.",
  "projection.tampered": "Quarantine the workspace and resume through an operator-authorized takeover into a fresh worktree.",
  "projection.consumption-marker-mismatch": "Only the projection this invocation materialized may carry its outputs; quarantine the workspace and take over into a fresh worktree.",
  "workflow.stage-blocked": "The workflow stage reported a typed blocker; read its recorded next step, resolve it, and re-submit the stage result.",
  "workflow.stage-failed": "The workflow stage failed; read its recorded next step, resolve it, and re-submit the stage result.",
  "workflow.stage-indeterminate": "The workflow stage could not decide; read its recorded next step, resolve the ambiguity, and re-submit the stage result.",
  "workspace.branch-collision": "Create the host worktree on the branch the delivery is bound to, or take over onto a fresh takeover branch.",
  "approval.proposal-voided": "The candidate changed since the proposal; re-propose the waiver against the current candidate if it still applies.",
  "review.loop-bound-reached": "Findings keep recurring; resolve them outside the loop \u2014 the bounded blocker exists so the loop cannot spin unobserved.",
  "review.floor-unmet": "Complete both mandatory lenses as distinct attempts with independently constructed contexts on the exact candidate.",
  "review.provider-result-invalid": "Have the qualified host binding emit a complete provider-review-result/1 envelope, then ingest a fresh native run.",
  "review.result-replay-conflict": "Treat the native run as conflicted and complete a fresh review under a new binding-owned handoff.",
  "review.provider-result-unqualified": "Complete one binding-owned native provider run over every mandatory lens on the exact current candidate.",
  "outcome.criterion-unverified": "Satisfy the criterion's sensor on the exact candidate, or carry an approved waiver for it, then re-validate.",
  "outcome.blanket-waiver": "At least one acceptance criterion must actually pass; rescope or cancel rather than waiving the whole outcome.",
  "evidence.rejected": "Read the manifest rejection codes verbatim and resubmit corrected evidence for the exact candidate.",
  "admission.refused": "Read the gate's blockers verbatim, satisfy the named obligations, and re-admit.",
  "record.non-neutral-change": "The recording commit may carry only review-neutral and record-neutral bytes; drop the non-neutral change and return through validation and a fresh aligned review.",
  "record.protected-authority-path": "Remove the projection or discovery-configuration path from the candidate tree; delivery-owned paths are never committed."
});
var FALLBACK_REMEDIATION = "No remediation is declared for this code; read the blocker summary verbatim and resolve it before continuing.";
function remediationFor(code) {
  return DELIVERY_BLOCKER_REMEDIATIONS[code] ?? FALLBACK_REMEDIATION;
}
var isSuspended2 = (state) => typeof state === "string" && SUSPENDED_DELIVERY_STATES.includes(state);
function composeBlockerInventory(views) {
  const entries = [];
  let pending = [];
  let attached = [];
  const resolve = (indices) => {
    for (const index of indices) {
      entries[index] = { ...entries[index], resolved: true };
    }
  };
  for (const view of views) {
    if (view.kind === "blocker.recorded") {
      const code = String(view.payload["code"] ?? "blocked");
      pending.push(entries.length);
      entries.push({
        code,
        summary: String(view.payload["summary"] ?? ""),
        remediation: remediationFor(code),
        resolved: false
      });
      continue;
    }
    if (view.kind !== "transition.committed") continue;
    if (isSuspended2(view.payload["to"])) {
      attached = [...attached, ...pending];
      pending = [];
      continue;
    }
    resolve(attached);
    resolve(pending);
    attached = [];
    pending = [];
  }
  resolve(pending);
  return entries;
}

// packages/kernel/src/finish-line/merge-ready.ts
var EXTERNAL_VERIFICATIONS = Object.freeze(["passed", "failed", "unavailable"]);
var FINISH_LINE_ACTIONS = Object.freeze({
  "merge-ready": void 0,
  merge: "merge",
  deploy: "deploy"
});
function authorizeFinishLineAction(input) {
  const refusals = [];
  const withinPolicy = checkContractWithinPolicy(input.contract, input.policy);
  if (!withinPolicy.ok) {
    for (const rejection of withinPolicy.rejections) {
      refusals.push({ code: rejection.code, pointer: rejection.pointer, message: rejection.message });
    }
  }
  if (input.contract.requestedFinishLine === "merge-ready") {
    refusals.push({
      code: "forbidden_action",
      pointer: "/requestedFinishLine",
      message: `a merge-ready finish line authorizes no ${input.action}; a green review alone never creates a pull request, merges, or deploys`
    });
  }
  if (!input.contract.requestedAuthority.includes(input.action)) {
    refusals.push({
      code: "authority_not_requested",
      pointer: "/requestedAuthority",
      message: `the contract requests no ${input.action} authority; an action nobody asked for is never taken`
    });
  }
  if (refusals.length > 0) return { ok: false, refusals };
  return {
    ok: true,
    nextState: (input.approvalRequiredActions ?? []).includes(input.action) ? "awaiting_approval" : "acting"
  };
}
var UNBOUND_EXTERNAL_ACTION_PORT = {
  invoke: (intent) => Promise.resolve({
    ok: false,
    refusals: [
      {
        code: "action_port_unbound",
        pointer: "/action",
        message: `no executable ${intent.action} adapter is bound; external actions are modelled here and invoked by no path in this product slice`
      }
    ]
  })
};
function decideFinishLine(input) {
  const refusals = [];
  const withinPolicy = checkContractWithinPolicy(input.contract, input.policy);
  if (!withinPolicy.ok) {
    for (const rejection of withinPolicy.rejections) {
      refusals.push({ code: rejection.code, pointer: rejection.pointer, message: rejection.message });
    }
  }
  if (!input.admission.admitted) {
    refusals.push({
      code: "admission_incomplete",
      pointer: "/admission",
      message: "the candidate was never admitted; merge-readiness is admission plus recording, never recording alone"
    });
  }
  if (input.observed.treeSha !== input.record.treeSha) {
    refusals.push({
      code: "candidate_moved",
      pointer: "/observed/treeSha",
      message: `the candidate is at ${input.observed.treeSha}; the recording transition bound ${input.record.treeSha}`
    });
  }
  if (input.observed.baseTipSha !== input.record.baseTipSha) {
    refusals.push({
      code: "base_moved",
      pointer: "/observed/baseTipSha",
      message: `the base tip is at ${input.observed.baseTipSha}; the tracked record binds ${input.record.baseTipSha}`
    });
  }
  const completed = new Set(input.admission.completedObligations);
  for (const obligation of input.policy.obligations) {
    if (!completed.has(obligation.obligationId)) {
      refusals.push({
        code: "obligation_unsatisfied",
        pointer: "/admission/completedObligations",
        message: `repository merge-ready obligation ${obligation.obligationId} carries no completed result`
      });
    }
  }
  if (input.admission.completedObligations.length === 0) {
    refusals.push({
      code: "obligation_unsatisfied",
      pointer: "/admission/completedObligations",
      message: "no obligation completed; merge-readiness cannot be passed by absence"
    });
  }
  if (input.externalVerification !== "passed") {
    refusals.push({
      code: "external_verification_missing",
      pointer: "/externalVerification",
      message: `the external verifier resolved ${input.externalVerification}; merge-readiness requires its passing result`
    });
  }
  if (refusals.length > 0) return { kind: "blocked", refusals };
  const result2 = {
    spec: "finish-line-result/1",
    finishLine: "merge-ready",
    deliveryId: input.deliveryId,
    candidate: { ...input.outcome.candidate },
    recordedCandidate: { treeSha: input.record.treeSha, baseTipSha: input.record.baseTipSha },
    policyDigest: input.policy.policyDigest,
    completedObligations: [...input.admission.completedObligations],
    trackedRecordDigest: input.record.digest,
    externalVerification: "passed",
    productTrustLabel: input.declaredProductTrustLabel,
    outcomeVerificationDigest: digestCanonical(input.outcome),
    mergeReadyObligationsSatisfied: true
  };
  const shape = validateFinishLineResult(result2);
  if (!shape.ok) {
    return { kind: "blocked", refusals: shape.rejections.map((rejection) => ({ ...rejection })) };
  }
  const cross = checkMergeReadyAgainstOutcome(result2, input.outcome);
  if (!cross.ok) {
    return { kind: "blocked", refusals: cross.rejections.map((rejection) => ({ ...rejection })) };
  }
  const action = FINISH_LINE_ACTIONS[input.contract.requestedFinishLine];
  if (action !== void 0) {
    const authorized = authorizeFinishLineAction({
      action,
      contract: input.contract,
      policy: input.policy,
      ...input.approvalRequiredActions === void 0 ? {} : { approvalRequiredActions: input.approvalRequiredActions }
    });
    return authorized.ok ? { kind: authorized.nextState, action } : { kind: "blocked", refusals: authorized.refusals };
  }
  return { kind: "completed", result: result2 };
}

// packages/kernel/src/portable-inputs.ts
import path19 from "node:path";
import { createHash as createHash4 } from "node:crypto";
async function candidateTreeEvidenceReader(rootDir, treeSha2, run = runGitCommand) {
  const refusal2 = (message) => {
    throw new BlockedError([portableBlocker("portable_tree_unreadable", message)]);
  };
  const listing = await run(["git", "ls-tree", "-r", "-z", "--full-tree", treeSha2], { cwd: rootDir });
  if (listing.exitCode !== 0) refusal2("The target candidate tree cannot be enumerated.");
  const entries = new Map(parseCandidateTreeListing(listing.stdout).map((entry3) => [entry3.path, entry3]));
  const readBlob = async (sha) => {
    const size = await run(["git", "cat-file", "-s", sha], { cwd: rootDir });
    if (size.exitCode !== 0 || !/^\d+\s*$/.test(size.stdout) || Number(size.stdout) > MAX_PORTABLE_ARTIFACT_BYTES) refusal2("A target-tree evidence input is missing or oversized.");
    const result2 = await run(["git", "cat-file", "blob", sha], { cwd: rootDir, captureBytes: true });
    if (result2.exitCode !== 0) refusal2("A target-tree evidence input cannot be read.");
    const bytes = result2.stdoutBase64 === void 0 ? Buffer.from(result2.stdout, "utf8") : Buffer.from(result2.stdoutBase64, "base64");
    const actual = createHash4(sha.length === 64 ? "sha256" : "sha1").update(`blob ${bytes.length}\0`).update(bytes).digest("hex");
    if (actual !== sha) refusal2("The target-tree reader did not preserve the exact blob bytes.");
    return bytes;
  };
  return async (requested) => {
    if (!isSafeRelativePath(requested)) refusal2("An evidence input is not a safe repository-relative path.");
    let current = requested;
    for (let depth = 0; depth < 32; depth += 1) {
      const segments = current.split("/");
      let redirected = false;
      for (let index = 0; index < segments.length; index += 1) {
        const prefix = segments.slice(0, index + 1).join("/");
        const entry4 = entries.get(prefix);
        if (entry4?.mode !== "120000") continue;
        const target = (await readBlob(entry4.objectSha)).toString("utf8");
        if (path19.posix.isAbsolute(target) || target.includes("\\") || target.includes("\0")) refusal2("An evidence input symlink escapes the repository.");
        current = path19.posix.normalize(path19.posix.join(path19.posix.dirname(prefix), target, ...segments.slice(index + 1)));
        if (!isSafeRelativePath(current)) refusal2("An evidence input symlink escapes the repository.");
        redirected = true;
        break;
      }
      if (redirected) continue;
      const entry3 = entries.get(current);
      if (entry3 === void 0) return null;
      if (!/^100(?:644|755)$/.test(entry3.mode)) refusal2("An evidence input is not a regular committed file.");
      return readBlob(entry3.objectSha);
    }
    return refusal2("An evidence input symlink chain is cyclic or too deep.");
  };
}
async function capturePortableVerificationInputs(rootDir, config, candidate2, record2, run = runGitCommand) {
  const read = await candidateTreeEvidenceReader(rootDir, candidate2.treeSha, run);
  const readWiring = async (repoPath) => {
    const bytes = await read(repoPath);
    if (bytes === null) throw new BlockedError([portableBlocker("portable_wiring_missing", "A target-tree preparation input is missing.")]);
    return bytes;
  };
  const preparationFingerprint = await computePreparationFingerprint(rootDir, config, { readWiring });
  const evidenceContext = await capturePortableEvidenceContext(config, read, preparationFingerprint);
  const checkBindings = await captureCheckBindings(rootDir, config, candidate2, {
    readWiring,
    readReleaseInputs: read,
    readOutput: async (repoPath, providerId2) => {
      const evidence = record2.claims.flatMap((claim) => [
        ...claim.evidence === void 0 ? [] : [claim.evidence],
        ...claim.supportingEvidence ?? []
      ]).find((entry3) => entry3.resolution.kind === "evidence" && entry3.resolution.providerId === providerId2);
      const portable = evidence?.resolution.kind === "evidence" ? evidence.resolution.portable : void 0;
      const contents = portableArtifactContents(portable?.artifacts);
      const index = config.providers.find((provider2) => provider2.id === providerId2)?.check?.outputs?.indexOf(repoPath) ?? -1;
      return retainedCheckOutput(contents.artifacts, repoPath, index);
    }
  });
  const projection = await evaluateCandidateActivation({ rootDir, config, candidate: candidate2, run });
  return { evidenceContext, checkBindings, projection };
}

// packages/kernel/src/facade/managed-delivery.ts
import { randomBytes as randomBytes4 } from "node:crypto";
import { chmod as chmod10, mkdir as mkdir11, readFile as readFile13, readdir as readdir5, realpath as realpath5, rm as rm8, stat as stat6, writeFile as writeFile9 } from "node:fs/promises";
import path20 from "node:path";
init_assertion_source();

// packages/kernel/src/facade/migration.ts
function evaluateMigrationConsumption(assertion, context) {
  const blockers = [];
  const refuse4 = (code, message) => {
    blockers.push({ code, message });
  };
  const shape = validateSensitiveApprovalAssertion(assertion);
  if (!shape.ok || assertion["assertionClass"] !== "security-blocked-migration") {
    refuse4("assertion_malformed", "the presented value is not a well-formed security-blocked migration assertion");
    return { ok: false, blockers };
  }
  if (assertion["action"] !== SECURITY_BLOCKED_MIGRATION_ACTION) {
    refuse4("assertion_mismatch", "the assertion approves a different action");
  }
  if (assertion["deliveryId"] !== context.deliveryId) {
    refuse4("assertion_mismatch", "the assertion binds a different target delivery");
  }
  if (assertion["expectedJournalRevision"] !== context.expectedJournalRevision) {
    refuse4(
      "assertion_mismatch",
      `the assertion binds journal revision ${String(assertion["expectedJournalRevision"])}; the delivery journal is at ${context.expectedJournalRevision}`
    );
  }
  if (assertion["targetInstallationId"] !== context.currentInstallationId) {
    refuse4("assertion_mismatch", "the assertion binds a different target installation");
  }
  if (assertion["productTrustRevocationEpoch"] !== context.trustState.revocationEpoch) {
    refuse4("assertion_stale", "the assertion was evaluated under a superseded product-trust revocation epoch");
  }
  const expiry = assertion["expiry"];
  if (typeof expiry !== "string" || expiry < context.now) {
    refuse4("assertion_stale", "the assertion expired; an expired evaluation is a cached credential, treated as invalid");
  }
  const nonce = assertion["nonce"];
  if (typeof nonce === "string" && context.consumedNonces.has(nonce)) {
    refuse4("assertion_replayed", `nonce ${nonce} was already consumed by this delivery journal`);
  }
  if (assertion["assertionSource"] === "qualification-fixture" && context.currentProfile !== "confirmation-fixture") {
    refuse4("assertion_source_mismatch", "a fixture-sourced assertion can never approve a migration on a production installation");
  }
  const target = assertion["targetGenerationDigest"];
  const trust = context.trust ?? localDigestTrustPredicate;
  if (typeof target === "string") {
    if (context.trustState.revokedGenerationDigests.includes(target)) {
      refuse4("generation_revoked", `target generation ${target} is revoked; a migration assertion naming a revoked target is refused`);
    } else if (!trust.evaluate(target, context.trustState).eligible) {
      refuse4(
        "generation_not_accepted",
        `target generation ${target} was never accepted under the target installation's local trust policy`
      );
    }
  }
  const rebinding = context.recordedInstallationId !== context.currentInstallationId;
  if (rebinding && context.recordedProfile !== context.currentProfile) {
    refuse4(
      "profile_mismatch",
      `a rebinding migration requires the target installation's active profile (${context.currentProfile}) to equal the delivery's recorded profile (${context.recordedProfile})`
    );
  }
  return blockers.length === 0 ? { ok: true, rebinding } : { ok: false, blockers };
}

// packages/kernel/src/facade/operations.ts
var FACADE_CAPABILITY_CLASSES = Object.freeze([
  "read",
  "control",
  "maintenance",
  "approval",
  "confirmation",
  "action"
]);
var FACADE_SURFACES = Object.freeze(["cli", "mcp", "binding-channel", "integration-event", "facade"]);
var entry2 = (operation, capability, fence, journalRevision, surfaces, summary) => Object.freeze({ operation, capability, fence, journalRevision, surfaces: Object.freeze([...surfaces]), summary });
var FACADE_OPERATIONS = Object.freeze([
  // Read.
  entry2("status", "read", "absent-by-state", "none", ["cli", "mcp"], "The one typed status model for a registered delivery."),
  entry2("nextCheckpoint", "read", "absent-by-state", "none", ["cli", "mcp"], "The next valid checkpoint the delivery will accept."),
  entry2("explainBlocker", "read", "absent-by-state", "none", ["cli", "mcp"], "The current blocker and its declared remediation."),
  entry2("blockerInventory", "read", "absent-by-state", "none", ["cli", "mcp"], "Every blocker this delivery journaled and whether it was left."),
  // Control — intake. These write the intake journal only; the delivery
  // journal does not exist until registration, so none of them moves the
  // revision this field names.
  entry2("openIntake", "control", "absent-by-state", "none", ["facade"], "Opens an iterative intake under the read-only intake grant."),
  entry2("recordClarification", "control", "absent-by-state", "none", ["facade"], "Retains one clarification exchange of the scope workflow."),
  entry2("recordDraft", "control", "absent-by-state", "none", ["facade"], "Retains the current draft contract, voiding any pending confirmation."),
  entry2("presentDraft", "control", "absent-by-state", "none", ["facade"], "Presents the retained draft for the one operator confirmation."),
  entry2("presentContract", "control", "absent-by-state", "none", ["facade"], "The already-scoped fallback lane into the same confirmation chain."),
  entry2("retryAcceptance", "control", "absent-by-state", "advances", ["facade"], "Re-runs acceptance validation on the standing confirmation."),
  // Control — delivery progression.
  entry2("bindWorkspace", "control", "absent-by-state", "advances", ["facade"], "Binds the host-supplied worktree and mints the invocation fence."),
  entry2("submitStageResult", "control", "required", "advances", ["cli"], "Submits a typed workflow-stage result for the current checkpoint."),
  entry2("checkpointCandidate", "control", "required", "advances", ["cli"], "Checkpoints the versioned candidate the workspace now stands on."),
  entry2("runSensor", "control", "required", "advances", ["cli"], "Runs the bound repository sensor and journals its typed result."),
  entry2(
    "prepareProviderReviewHandoff",
    "control",
    "absent-by-state",
    "none",
    ["facade"],
    "Pins one native provider invocation after checking the host-retained binding capability."
  ),
  entry2(
    "ingestProviderReviewResult",
    "control",
    "required",
    "advances",
    ["facade"],
    "Admits one native result after checking its invocation-scoped capability."
  ),
  entry2("reduceReview", "control", "required", "advances", ["cli"], "Reduces the recorded attempts to a review verdict."),
  entry2("admit", "control", "required", "advances", ["cli"], "Runs admission over the activated obligations."),
  entry2("prepareTrackedRecord", "control", "required", "advances", ["cli"], "Writes the tracked delivery record for native commit."),
  entry2("confirmTrackedRecord", "control", "required", "advances", ["cli"], "Verifies the committed record is both-neutral."),
  entry2("recordApprovalRequest", "control", "required", "advances", ["cli"], "Journals a waiver or amendment proposal and its pending marker."),
  entry2("requestCancellation", "control", "absent-by-state", "advances", ["cli"], "Revokes the fence and requests native host cancellation."),
  entry2("finalizeCancellation", "control", "absent-by-state", "advances", ["cli"], "Quarantines the prior workspace and reaches terminal cancelled."),
  entry2("presentTakeover", "control", "absent-by-state", "advances", ["facade"], "Presents a takeover for the one operator authorization."),
  entry2("tearDownWorkspaceProjection", "control", "absent-by-state", "none", ["facade"], "Tears the run-pinned projection down with the worktree."),
  // Writes no delivery-journal entry, so it does not bind the fence: the
  // run it records is fixed by the binding's own fence-scoped consumption
  // observation and workspace record, not by a fence the caller names.
  entry2(
    "recordProjectionConsumption",
    "control",
    "absent-by-state",
    "none",
    ["facade"],
    "Records the binding-observed projection consumption in the milestone gate record."
  ),
  entry2("sessionEnded", "control", "required", "observation-only", ["facade"], "Observes that the bound host task is no longer active."),
  // Action.
  entry2("completeFinishLine", "action", "required", "advances", ["cli"], "Actions the policy-selected finish line for the current candidate."),
  // Approval — the sensitive lane.
  entry2("consumeWaiver", "approval", "required", "advances", ["facade"], "Consumes one fresh assertion against the pending proposal."),
  // Confirmation — the binding's model-external channel, and nowhere else.
  entry2("confirmContract", "confirmation", "absent-by-state", "advances", ["binding-channel"], "Completes the contract confirmation by echoed challenge."),
  entry2("confirmTakeover", "confirmation", "absent-by-state", "advances", ["binding-channel"], "Completes the takeover authorization by echoed challenge."),
  // Trusted integration event — never a model-callable operation.
  entry2(
    "recordTerminationProvenance",
    "control",
    "required",
    "advances",
    ["integration-event"],
    "Admits graceful host-runtime termination provenance from the trusted lifecycle integration."
  ),
  // Maintenance — the installation-scoped lane.
  entry2("recoverSecurityBlocked", "maintenance", "absent-by-state", "advances", ["cli"], "Leaves security_blocked by re-preparation or a compatible migration."),
  entry2("exportDelivery", "maintenance", "absent-by-state", "none", ["cli"], "Exports the delivery's durable detail to an owned path."),
  entry2("deleteDelivery", "maintenance", "absent-by-state", "none", ["cli"], "Deletes a terminal delivery, preserving the required audit record."),
  entry2("updateComposition", "maintenance", "absent-by-state", "none", ["cli"], "Updates the installation to a newer product generation."),
  entry2("rollbackComposition", "maintenance", "absent-by-state", "none", ["cli"], "Restores a previously accepted product generation."),
  entry2("maintainTrustState", "maintenance", "absent-by-state", "none", ["cli"], "Pins, revokes, un-revokes, or advances the trust high-water mark.")
]);
function facadeOperation(operation) {
  return FACADE_OPERATIONS.find((candidate2) => candidate2.operation === operation);
}
function operationsOnSurface(surface) {
  return FACADE_OPERATIONS.filter((candidate2) => candidate2.surfaces.includes(surface));
}
var TERMINATION_PROVENANCE_OPERATION = "recordTerminationProvenance";
var MODEL_VISIBLE_SURFACES = Object.freeze(["cli", "mcp"]);
function checkFacadeSurfaceInvariants(operations) {
  const findings2 = [];
  const seen = /* @__PURE__ */ new Set();
  for (const operation of operations) {
    if (seen.has(operation.operation)) {
      findings2.push({
        rule: "duplicate-operation",
        operation: operation.operation,
        message: `operation ${operation.operation} is declared more than once`
      });
    }
    seen.add(operation.operation);
    if (operation.capability === "confirmation") {
      const offChannel = operation.surfaces.filter((surface) => surface !== "binding-channel");
      if (offChannel.length > 0) {
        findings2.push({
          rule: "confirmation-off-channel",
          operation: operation.operation,
          message: `an operator confirmation is served only by the binding-owned channel; ${operation.operation} also names ${offChannel.join(", ")}`
        });
      }
    }
    const modelVisible = operation.surfaces.filter((surface) => MODEL_VISIBLE_SURFACES.includes(surface));
    if (operation.operation === TERMINATION_PROVENANCE_OPERATION && modelVisible.length > 0) {
      findings2.push({
        rule: "termination-provenance-callable",
        operation: operation.operation,
        message: `termination provenance enters only through the trusted integration event; ${operation.operation} names ${modelVisible.join(", ")}`
      });
    }
    if (operation.surfaces.includes("mcp") && operation.capability !== "read") {
      findings2.push({
        rule: "mcp-not-read-only",
        operation: operation.operation,
        message: `the MCP surface inspects rather than orchestrates; ${operation.operation} is ${operation.capability}, not read`
      });
    }
    if (operation.fence === "required" && operation.journalRevision === "none") {
      findings2.push({
        rule: "fence-without-revision",
        operation: operation.operation,
        message: `${operation.operation} binds the invocation fence but writes nothing the fence could be checked against`
      });
    }
  }
  return findings2;
}

// packages/kernel/src/facade/status.ts
var TERMINAL_STATES = ["completed", "cancelled", "failed"];
var APPROVAL_PROPOSAL_STATES = ["reviewing", "remediating", "admitting"];
var READ_ACTIONS = ["status", "nextCheckpoint", "explainBlocker", "blockerInventory"];
var RETENTION_ACTIONS2 = ["exportDelivery", "deleteDelivery"];
function checkpointAction(checkpoint) {
  switch (checkpoint.kind) {
    case "bind-workspace":
      return "bindWorkspace";
    case "workflow-stage":
      return "submitStageResult";
    case "repository-sensor":
      return "runSensor";
    case "review":
      return "prepareProviderReviewHandoff";
    case "admission":
      return "admit";
    case "tracked-record":
      return "prepareTrackedRecord";
    case "finish-line":
      return "completeFinishLine";
    default:
      return void 0;
  }
}
function deriveMutationVerification(input) {
  if (!input.workspaceBound) return "not-applicable";
  if (input.hostActivity === "cancellation_pending") return "unverified";
  if (input.lastWorkspaceDisposition === "quarantined" || input.lastWorkspaceDisposition === "prior_host_termination_unverified") {
    return "unverified";
  }
  if (input.hostActivity === "active") return "not-applicable";
  if (input.lastWorkspaceDisposition === "reconciled" || input.terminationVerifiedAtCurrentFence) return "verified";
  return "unverified";
}
function deriveRetrySafety(input, mutation) {
  if (input.delivery.state === "action_succeeded_verification_failed") return "never-repeat-external-action";
  if (mutation === "unverified") return "unverified-prior-mutation";
  return "safe";
}
function deriveMigrationPath(input) {
  if (input.delivery.state !== "security_blocked") return "none";
  switch (input.registrationBinding.mismatch) {
    case "profile":
    case "unresolved":
      return "none";
    case "identity":
      return "rebinding-migration";
    default:
      return input.productTrust.generation === "eligible" ? "re-preparation" : "generation-change-migration";
  }
}
function deriveAuthorizedNextActions(input, mutation, migration) {
  const actions = [];
  const takeoverFirst = input.resume === "takeover-required" && input.hostActivity !== "active";
  const carriesFence = (action) => FACADE_OPERATIONS.find((operation) => operation.operation === action)?.fence === "required";
  const add = (action) => {
    if (action === void 0 || actions.includes(action)) return;
    if (takeoverFirst && carriesFence(action)) return;
    actions.push(action);
  };
  if (TERMINAL_STATES.includes(input.delivery.state)) {
    for (const action of READ_ACTIONS) add(action);
    for (const action of RETENTION_ACTIONS2) add(action);
    return actions;
  }
  if (input.delivery.state === "security_blocked") {
    if (migration !== "none") add("recoverSecurityBlocked");
    for (const action of READ_ACTIONS) add(action);
    add("requestCancellation");
    return actions;
  }
  if (input.delivery.state === "cancellation_requested") {
    add("finalizeCancellation");
    for (const action of READ_ACTIONS) add(action);
    return actions;
  }
  if (input.pendingDecision !== void 0 && input.assertionSource.lanes.sensitiveApprovals === "available") {
    add("consumeWaiver");
  }
  if (input.delivery.state !== "blocked" && input.delivery.state !== "action_succeeded_verification_failed") {
    add(checkpointAction(input.nextCheckpoint));
  }
  if (APPROVAL_PROPOSAL_STATES.includes(input.delivery.state)) add("recordApprovalRequest");
  if (takeoverFirst && input.workspaceBound && input.assertionSource.lanes.operatorConfirmations === "available") {
    add("presentTakeover");
  }
  if (mutation === "unverified") add("exportDelivery");
  for (const action of READ_ACTIONS) add(action);
  add("requestCancellation");
  return actions;
}
function composeManagedStatus(input) {
  const mutationVerification = deriveMutationVerification(input);
  const retrySafety = deriveRetrySafety(input, mutationVerification);
  const migrationPath = deriveMigrationPath(input);
  const authorizedNextActions = deriveAuthorizedNextActions(input, mutationVerification, migrationPath);
  const operationContracts = authorizedNextActions.map((action) => FACADE_OPERATIONS.find((operation) => operation.operation === action)).filter((operation) => operation !== void 0);
  return {
    deliveryId: input.deliveryId,
    intake: input.intake,
    delivery: input.delivery,
    hostActivity: input.hostActivity,
    completedObligations: input.completedObligations,
    productTrust: input.productTrust,
    assertionSource: input.assertionSource,
    quarantinedWorkspaces: input.quarantinedWorkspaces,
    candidate: input.candidate,
    pendingDecision: input.pendingDecision,
    registrationBinding: input.registrationBinding,
    mutationVerification,
    retrySafety,
    migrationPath,
    nextCheckpoint: input.nextCheckpoint,
    resume: input.resume,
    blockers: input.blockers,
    authorizedNextActions,
    operationContracts,
    policyRequiredInterruptions: input.policyRequiredInterruptions,
    operatorInterventions: input.operatorInterventions
  };
}

// packages/kernel/src/workflow/result.ts
var WORKFLOW_STAGE_RESULT_SPEC = "workflow-stage-result/1";
var WORKFLOW_SUBJECT_REF_SPEC = "workflow-subject-ref/1";
var WORKFLOW_CANDIDATE_REF_SPEC = "workflow-candidate-ref/1";
var RESULT_MEMBERS = /* @__PURE__ */ new Set([
  "schemaVersion",
  "release",
  "graphSha256",
  "stageId",
  "subjectRef",
  "candidateRef",
  "status",
  "output",
  "evidenceRefs",
  "limitations",
  "nextStep"
]);
var OUTPUT_MEMBERS = /* @__PURE__ */ new Set(["kind", "evidenceRef", "adapterRef", "trust", "preservationHandoffRef"]);
var ADAPTER_REF_STAGES = /* @__PURE__ */ new Set(["publish.handoff", "feedback.handoff"]);
var TRUST_STAGES = /* @__PURE__ */ new Set(["feedback.handoff"]);
var isRecord8 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var nonBlank = (value) => typeof value === "string" && value.trim().length > 0;
function validateWorkflowStageResult(value, context) {
  const rejections = [];
  const reject2 = (code, pointer2, message) => {
    rejections.push({ code, pointer: pointer2, message });
  };
  if (!isRecord8(value)) {
    return {
      ok: false,
      rejections: [
        {
          code: "result_malformed",
          pointer: "",
          message: "a stage result is a typed workflow-stage-result/1 object; prose cannot advance a checkpoint"
        }
      ]
    };
  }
  for (const member2 of Object.keys(value)) {
    if (!RESULT_MEMBERS.has(member2)) reject2("result_malformed", `/${member2}`, "member is not defined by the released result envelope");
  }
  for (const member2 of ["schemaVersion", "release", "graphSha256", "stageId", "subjectRef", "status", "evidenceRefs", "limitations"]) {
    if (value[member2] === void 0) reject2("result_malformed", `/${member2}`, "required member is absent");
  }
  if (rejections.length > 0) return { ok: false, rejections };
  if (value["schemaVersion"] !== WORKFLOW_STAGE_RESULT_SPEC) {
    reject2("result_malformed", "/schemaVersion", `expected ${WORKFLOW_STAGE_RESULT_SPEC}`);
  }
  const release = value["release"];
  if (!isRecord8(release)) {
    reject2("result_malformed", "/release", "expected the four-field verified release projection");
  } else {
    const expected = { ...context.release };
    for (const member2 of Object.keys(release)) {
      if (!Object.hasOwn(expected, member2)) reject2("result_malformed", `/release/${member2}`, "member is not part of the release projection");
    }
    for (const [member2, expectation] of Object.entries(expected)) {
      if (release[member2] !== expectation) {
        reject2("release_mismatch", `/release/${member2}`, "the result binds a release other than the pinned one");
      }
    }
  }
  if (value["graphSha256"] !== context.graphSha256) {
    reject2("graph_mismatch", "/graphSha256", "the result binds graph bytes other than the pinned graph");
  }
  const stageId = value["stageId"];
  if (typeof stageId !== "string" || workflowStageOf(context.graph, stageId) === void 0) {
    reject2("result_malformed", "/stageId", "the result names no stage the pinned graph declares");
    return { ok: false, rejections };
  }
  if (stageId !== context.expectedStageId) {
    reject2("stage_mismatch", "/stageId", `this checkpoint admits ${context.expectedStageId}, not ${stageId}`);
    return { ok: false, rejections };
  }
  const stage = workflowStageOf(context.graph, stageId);
  if (stage === void 0) return { ok: false, rejections };
  const subjectRef = value["subjectRef"];
  if (!isRecord8(subjectRef) || subjectRef["schemaVersion"] !== WORKFLOW_SUBJECT_REF_SPEC || !nonBlank(subjectRef["opaque"])) {
    reject2("result_malformed", "/subjectRef", "expected a workflow-subject-ref/1 with non-blank opaque text");
  } else {
    for (const member2 of Object.keys(subjectRef)) {
      if (member2 !== "schemaVersion" && member2 !== "opaque") reject2("result_malformed", `/subjectRef/${member2}`, "unknown member");
    }
    if (subjectRef["opaque"] !== context.expectedSubject) {
      reject2("subject_mismatch", "/subjectRef/opaque", "the result names a different subject; comparison is exact");
    }
  }
  const status = value["status"];
  if (typeof status !== "string" || !["succeeded", "blocked", "failed", "indeterminate"].includes(status)) {
    reject2("result_malformed", "/status", "expected succeeded, blocked, failed, or indeterminate");
    return { ok: false, rejections };
  }
  if (!stage.statuses.includes(status)) {
    reject2("status_undeclared", "/status", `the ${stageId} stage does not declare the ${status} status`);
  }
  let candidateOpaque;
  const candidateRef = value["candidateRef"];
  if (candidateRef !== void 0) {
    if (!isRecord8(candidateRef) || candidateRef["schemaVersion"] !== WORKFLOW_CANDIDATE_REF_SPEC || !nonBlank(candidateRef["opaque"])) {
      reject2("result_malformed", "/candidateRef", "expected a workflow-candidate-ref/1 with non-blank opaque text");
    } else {
      for (const member2 of Object.keys(candidateRef)) {
        if (member2 !== "schemaVersion" && member2 !== "opaque") reject2("result_malformed", `/candidateRef/${member2}`, "unknown member");
      }
      candidateOpaque = candidateRef["opaque"];
    }
  }
  const requireExact = (expected, description) => {
    if (expected === void 0) {
      reject2("candidate_binding_violation", "/candidateRef", `no ${description} exists for this checkpoint; the result cannot bind one`);
    } else if (candidateOpaque === void 0) {
      reject2("candidate_binding_violation", "/candidateRef", `the ${stageId} stage binds the ${description}; the result names none`);
    } else if (candidateOpaque !== expected) {
      reject2("candidate_binding_violation", "/candidateRef/opaque", `the result names a candidate other than the ${description}; a result cannot nominate its own trusted candidate`);
    }
  };
  switch (stage.candidateBinding) {
    case "forbidden": {
      if (candidateRef !== void 0) {
        reject2("candidate_binding_violation", "/candidateRef", `the ${stageId} stage forbids a candidate reference`);
      }
      break;
    }
    case "required": {
      requireExact(context.currentCandidate, "current checkpoint candidate");
      break;
    }
    case "checkpoint-contextual": {
      if (context.currentCandidate !== void 0) {
        requireExact(context.currentCandidate, "current checkpoint candidate");
      } else if (candidateRef !== void 0) {
        reject2("candidate_binding_violation", "/candidateRef", "no checkpoint candidate exists yet; the result must omit the reference");
      }
      break;
    }
    case "produced-on-success": {
      if (status === "succeeded") {
        requireExact(context.producedCandidate, "independently captured produced candidate");
      } else if (context.currentCandidate !== void 0) {
        requireExact(context.currentCandidate, "prior checkpoint candidate");
      } else if (candidateRef !== void 0) {
        reject2("candidate_binding_violation", "/candidateRef", "no prior candidate exists; a non-success result must omit the reference");
      }
      break;
    }
    default: {
      reject2("result_malformed", "/candidateRef", `the pinned graph declares an unknown candidate-binding policy ${stage.candidateBinding}`);
      break;
    }
  }
  const output = value["output"];
  const nextStep = value["nextStep"];
  let outputKind;
  let outputEvidenceRef;
  let preservationHandoffRef;
  if (status === "succeeded") {
    if (nextStep !== void 0) {
      reject2("unsupported_combination", "/nextStep", "a successful result carries its output, never a next step");
    }
    if (!isRecord8(output)) {
      reject2("result_malformed", "/output", "a successful result carries a closed output object");
    } else {
      for (const member2 of Object.keys(output)) {
        if (!OUTPUT_MEMBERS.has(member2)) reject2("result_malformed", `/output/${member2}`, "member is not defined by the released output shape");
      }
      const kind = output["kind"];
      if (typeof kind !== "string" || !nonBlank(output["evidenceRef"])) {
        reject2("result_malformed", "/output", "an output carries a kind and a non-blank retained evidence reference");
      } else {
        if (!stage.successOutputs.includes(kind)) {
          reject2("output_undeclared", "/output/kind", `the ${stageId} stage does not declare the ${kind} success output`);
        }
        outputKind = kind;
        outputEvidenceRef = output["evidenceRef"];
      }
      const adapterRef = output["adapterRef"];
      if (ADAPTER_REF_STAGES.has(stageId)) {
        if (!nonBlank(adapterRef) || stage.evidenceAdapter.ref !== void 0 && adapterRef !== stage.evidenceAdapter.ref) {
          reject2("unsupported_combination", "/output/adapterRef", `a successful ${stageId} output names the graph's declared adapter slot`);
        }
      } else if (adapterRef !== void 0) {
        reject2("unsupported_combination", "/output/adapterRef", `the ${stageId} stage carries no adapter reference`);
      }
      const trust = output["trust"];
      if (TRUST_STAGES.has(stageId)) {
        if (trust !== "untrusted") {
          reject2("unsupported_combination", "/output/trust", "normalized external feedback is consumed untrusted, and says so");
        }
      } else if (trust !== void 0) {
        reject2("unsupported_combination", "/output/trust", `the ${stageId} stage carries no trust marker`);
      }
      const preservation = output["preservationHandoffRef"];
      if (outputKind === "learning-required") {
        if (!nonBlank(preservation)) {
          reject2("unsupported_combination", "/output/preservationHandoffRef", "learning-required hands off to repository-owned preservation by reference");
        } else {
          preservationHandoffRef = preservation;
        }
      } else if (preservation !== void 0) {
        reject2("unsupported_combination", "/output/preservationHandoffRef", "only learning-required carries a preservation handoff");
      }
    }
  } else {
    if (output !== void 0) {
      reject2("unsupported_combination", "/output", "blocked, failed, and indeterminate are statuses, never outputs");
    }
    if (!nonBlank(nextStep)) {
      reject2("result_malformed", "/nextStep", "a non-success result carries exactly one non-blank actionable next step");
    }
  }
  const uniqueStrings = (member2) => {
    const list = value[member2];
    if (!Array.isArray(list) || !list.every(nonBlank)) {
      reject2("result_malformed", `/${member2}`, "expected an array of non-blank strings");
      return void 0;
    }
    if (new Set(list).size !== list.length) {
      reject2("result_malformed", `/${member2}`, "entries must be unique");
      return void 0;
    }
    return list;
  };
  const evidenceRefs = uniqueStrings("evidenceRefs");
  const limitations = uniqueStrings("limitations");
  if (rejections.length > 0) return { ok: false, rejections };
  return {
    ok: true,
    result: {
      stageId,
      status,
      ...outputKind === void 0 ? {} : { outputKind },
      ...outputEvidenceRef === void 0 ? {} : { outputEvidenceRef },
      ...preservationHandoffRef === void 0 ? {} : { preservationHandoffRef },
      ...nonBlank(nextStep) ? { nextStep } : {},
      ...candidateOpaque === void 0 ? {} : { candidateRef: candidateOpaque },
      evidenceRefs: evidenceRefs ?? [],
      limitations: limitations ?? []
    }
  };
}
function evaluateStagePrerequisites(stage, completed, options) {
  const rejections = [];
  for (const prerequisite of stage.prerequisites) {
    const applies = prerequisite.when === "always" || prerequisite.when === "effective" || // omission tolerance rides allowOmitted
    prerequisite.when === "diagnosis-invoked" && options.diagnosisInvoked === true || prerequisite.when === "repair-loop" && options.repairLoop === true;
    if (!applies) continue;
    if ((options.productRealized ?? []).includes(prerequisite.stageId)) continue;
    const satisfies = (summary2) => summary2 !== void 0 && summary2.status === "succeeded" && summary2.outputKind !== void 0 && prerequisite.outputs.includes(summary2.outputKind);
    if (prerequisite.stageId.startsWith("$")) {
      const anySatisfies = [...completed.values()].some((summary2) => satisfies(summary2));
      if (!anySatisfies) {
        rejections.push({
          code: "prerequisite_missing",
          pointer: `/prerequisites/${prerequisite.stageId}`,
          message: `no retained stage summary carries ${prerequisite.outputs.join(" or ")} for the ${prerequisite.when} prerequisite`
        });
      }
      continue;
    }
    const summary = completed.get(prerequisite.stageId);
    if (summary === void 0) {
      if (!prerequisite.allowOmitted) {
        rejections.push({
          code: "prerequisite_missing",
          pointer: `/prerequisites/${prerequisite.stageId}`,
          message: `the ${stage.id} stage requires admitted ${prerequisite.stageId} evidence and none is retained`
        });
      }
      continue;
    }
    if (!satisfies(summary)) {
      rejections.push({
        code: "prerequisite_unsatisfied",
        pointer: `/prerequisites/${prerequisite.stageId}`,
        message: `the retained ${prerequisite.stageId} summary (${summary.status}${summary.outputKind === void 0 ? "" : `, ${summary.outputKind}`}) does not satisfy ${prerequisite.outputs.join(" or ")}`
      });
    }
  }
  return rejections.length > 0 ? { ok: false, rejections } : { ok: true };
}

// packages/kernel/src/facade/managed-delivery.ts
var SOURCE = { kind: "command", id: "managed-delivery.facade" };
var refuse3 = (code, summary, remediation) => ({
  ok: false,
  blockers: [
    createBlocker({
      code,
      source: SOURCE,
      summary,
      remediations: [{ id: `${code.replaceAll("_", "-")}-remediation`, kind: "manual_action", summary: remediation }]
    })
  ]
});
var refuseWith = (blockers) => ({ ok: false, blockers });
var substrateRefusal = (blockers) => refuseWith(
  blockers.map(
    (blocker) => createBlocker({
      code: blocker.code,
      source: SOURCE,
      summary: blocker.message,
      remediations: [
        {
          id: "maintenance-lane-remediation",
          kind: "manual_action",
          summary: "Resolve the reported maintenance-lane condition and repeat the operation with a fresh assertion."
        }
      ]
    })
  )
);
var OWNER_DIR7 = 448;
var OWNER_FILE7 = 384;
var GENERATION_HOOK_ENTRY = "harness/packages/kernel/src/host/hook-main.ts";
var HOOK_RUNTIME_ARGS = Object.freeze(["--experimental-strip-types"]);
async function resolveStagedHookEntry(target) {
  try {
    return (await stat6(target)).isFile() ? await realpath5(target) : void 0;
  } catch {
    return void 0;
  }
}
var HOST_ID = "claude-code";
var compiledAdopterPolicyBindingDigest = (binding) => digestCanonical(binding);
var RELEASE_IDENTITY = Object.freeze({
  releaseId: PINNED_AGENT_SKILLS.releaseId,
  profile: PINNED_AGENT_SKILLS.profile,
  archiveSha256: PINNED_AGENT_SKILLS.archiveSha256,
  metadataSha256: PINNED_AGENT_SKILLS.metadataSha256
});
var REVIEW_ROUND_BOUND = 3;
var hex = (bytes) => randomBytes4(bytes).toString("hex");
var capabilityShape = (capability) => /^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$/.test(capability.id) && capability.secret.length >= 32 && capability.secret.length <= 1024;
var capabilityDigest = (input) => digestCanonical(input);
async function writeOwned2(target, contents) {
  await mkdir11(path20.dirname(target), { recursive: true, mode: OWNER_DIR7 });
  await writeFile9(target, contents, { mode: OWNER_FILE7 });
  await chmod10(target, OWNER_FILE7);
}
async function readJson(target) {
  try {
    return JSON.parse(await readFile13(target, "utf8"));
  } catch {
    return void 0;
  }
}
var viewsOf = (entries) => entries.map((entry3) => {
  const record2 = entry3;
  return { kind: record2["kind"], payload: record2["payload"] };
});
var lastOf2 = (views, kind) => [...views].reverse().find((view) => view.kind === kind);
function currentCandidateOf(views) {
  const recaptured = lastOf2(views, "candidate.recaptured");
  if (recaptured !== void 0) {
    return {
      treeSha: recaptured.payload["treeSha"],
      branchRefValue: recaptured.payload["branchRefValue"]
    };
  }
  const fenced = lastOf2(views, "invocation.fenced");
  if (fenced !== void 0) {
    return {
      treeSha: fenced.payload["candidateTreeSha"],
      branchRefValue: fenced.payload["candidateBranchRefValue"]
    };
  }
  return void 0;
}
function recordedBindingOf(views) {
  const registered = views.find((view) => view.kind === "delivery.registered");
  if (registered === void 0) return void 0;
  let registeringInstallationId = registered.payload["registeringInstallationId"];
  const activeCompositionProfile = registered.payload["activeCompositionProfile"];
  for (const view of views) {
    if (view.kind !== "approval.assertion.consumed") continue;
    const rebound = view.payload["newRegisteringInstallationId"];
    if (typeof rebound === "string" && rebound !== "absent-by-state") {
      registeringInstallationId = rebound;
    }
  }
  return { registeringInstallationId, activeCompositionProfile };
}
function consumedAssertionNoncesOf(views) {
  const nonces = /* @__PURE__ */ new Set();
  for (const view of views) {
    if (view.kind !== "approval.assertion.consumed") continue;
    const assertion = view.payload["assertion"];
    if (typeof assertion === "object" && assertion !== null) {
      const nonce = assertion["nonce"];
      if (typeof nonce === "string") nonces.add(nonce);
    }
  }
  return nonces;
}
function waiverLedgerOf(views) {
  const pendingStack = [];
  const consumed = [];
  let fencedCandidate = "";
  let recapturedCandidate;
  for (const view of views) {
    const candidate2 = recapturedCandidate ?? fencedCandidate;
    switch (view.kind) {
      case "invocation.fenced":
        fencedCandidate = view.payload["candidateTreeSha"];
        break;
      case "candidate.recaptured":
        recapturedCandidate = view.payload["treeSha"];
        break;
      case "approval.request.recorded":
        pendingStack.push({
          requestKind: view.payload["requestKind"],
          criterionId: view.payload["criterionId"],
          actorId: view.payload["actorId"],
          candidateTreeSha: recapturedCandidate ?? fencedCandidate
        });
        break;
      case "blocker.recorded":
        if (view.payload["code"] === "approval.proposal-voided") pendingStack.shift();
        break;
      case "approval.assertion.consumed": {
        const assertion = view.payload["assertion"];
        const origin = String(assertion?.["origin"] ?? "");
        if (!origin.startsWith(WAIVER_APPROVAL_ORIGIN_PREFIX)) break;
        const answered = pendingStack.shift();
        if (answered !== void 0) {
          consumed.push({
            candidateTreeSha: candidate2,
            criterionId: answered.criterionId,
            reference: `${String(assertion?.["action"])} by ${origin.slice(WAIVER_APPROVAL_ORIGIN_PREFIX.length)} (${String(assertion?.["nonce"])})`
          });
        }
        break;
      }
      default:
        break;
    }
  }
  return { pending: pendingStack, consumed };
}
function sensorResultsOf(views) {
  return views.filter((view) => view.kind === "operation.result.recorded").map((view) => view.payload["result"]);
}
async function voidSupersededBindingStates(bindingDir, currentFence) {
  let names;
  try {
    names = await readdir5(bindingDir);
  } catch {
    return;
  }
  for (const name of names) {
    const match = /^state-(\d+)\.json$/.exec(name);
    if (match === null) continue;
    if (Number.parseInt(match[1], 10) >= currentFence) continue;
    const statePath = path20.join(bindingDir, name);
    const state = await readJson(statePath);
    if (state === void 0 || state["attestation"] === null) continue;
    await writeOwned2(statePath, `${JSON.stringify({ ...state, attestation: null })}
`);
  }
}
function createManagedDeliveryFacade(input) {
  const policyBinding = input.policyBinding;
  const compiledPolicy = policyBinding.compiledPolicy;
  if (compiledPolicy.admission === void 0) {
    throw new Error("the adopter's compiled repository policy has no admission projection");
  }
  const policyVerdict = verifyCompiledPolicy(compiledPolicy);
  if (!policyVerdict.ok) {
    throw new Error(`the adopter's compiled repository policy is invalid: ${policyVerdict.rejections.map((rejection) => rejection.message).join("; ")}`);
  }
  const admissionVerdict = validateHarnessConfig(compiledPolicy.admission);
  if (!admissionVerdict.ok) {
    throw new Error(`the adopter's compiled admission projection is invalid: ${admissionVerdict.blockers.map((blocker) => blocker.summary).join("; ")}`);
  }
  const stageGrants = new Map(compiledPolicy.checkpointGrants.map((entry3) => [entry3.stageId, entry3.grant]));
  const stageGrant = stageGrants.get("plan");
  if (stageGrant === void 0 || !["implement", "compound"].every((stageId) => stageGrants.has(stageId))) {
    throw new Error("the adopter's compiled repository policy must grant plan, implement, and compound checkpoints");
  }
  const stageGrantDigest = digestCanonical(stageGrant);
  if (["implement", "compound"].some((stageId) => digestCanonical(stageGrants.get(stageId)) !== stageGrantDigest)) {
    throw new Error("the facade requires one shared checkpoint grant across model-driven stages");
  }
  const invalidGrant = ["plan", "implement", "compound"].find((stageId) => {
    const grant = stageGrants.get(stageId);
    const verdict = validateExecutionGrant(grant);
    return !verdict.ok || grant?.profile !== "checkpoint";
  });
  if (invalidGrant !== void 0) {
    throw new Error("the adopter's model-driven checkpoint grant is invalid");
  }
  const sensorCapability = compiledPolicy.capabilities.find(
    (capability) => capability.capabilityId === policyBinding.sensor.capabilityId && capability.kind === "sensor"
  );
  if (sensorCapability === void 0 || sensorCapability.resultSpec !== "sensor-result/1") {
    throw new Error("the adopter's trusted sensor binding is not present in the compiled policy");
  }
  if (path20.isAbsolute(policyBinding.sensor.trustedBasePath) || policyBinding.sensor.trustedBasePath.split("/").includes("..")) {
    throw new Error("the adopter's trusted sensor binding must be a repository-relative path");
  }
  for (const lens of compiledPolicy.snapshot.reviewLenses) {
    const source = policyBinding.personaSources[lens.personaId];
    if (source === void 0 || source.digest !== sha256Hex(source.bytes) || source.digest !== lens.personaDigest) {
      throw new Error(`the adopter's resolved persona bytes do not match ${lens.personaId}`);
    }
    if (source.origin === "repository" && (path20.isAbsolute(source.trustedBasePath) || source.trustedBasePath.split("/").includes(".."))) {
      throw new Error(`the repository persona source for ${lens.personaId} must be a repository-relative path`);
    }
  }
  const config = admissionVerdict.config;
  const policy = compiledPolicy.snapshot;
  const policyBindingDigest = compiledAdopterPolicyBindingDigest(policyBinding);
  const checkpointGrantFor = (stageId) => {
    const grant = stageGrants.get(stageId);
    if (grant === void 0) throw new Error(`the adopter's compiled repository policy has no ${stageId} checkpoint grant`);
    return grant;
  };
  const checkpointGrantDigestFor = (stageId) => digestCanonical(checkpointGrantFor(stageId));
  const exec = input.exec ?? createExecPort();
  const git = async (cwd, ...args) => {
    const outcome = await exec.run({ command: "git", args, cwd });
    return { code: outcome.code, out: outcome.stdout.trim() };
  };
  const candidateTreeEntries = async (cwd) => {
    const listed = await exec.run({ command: "git", args: ["ls-tree", "-r", "-z", "--full-tree", "HEAD"], cwd });
    if (listed.code !== 0) return void 0;
    const entries = [];
    for (const entry3 of parseCandidateTreeListing(listed.stdout)) {
      if (!needsCommittedSymlinkTarget(entry3)) {
        entries.push(entry3);
        continue;
      }
      const blob = await exec.run({ command: "git", args: ["cat-file", "blob", entry3.objectSha], cwd });
      entries.push(blob.code === 0 ? { ...entry3, symlinkTarget: blob.stdout } : entry3);
    }
    return entries;
  };
  const candidateRunner = async (command, options) => {
    const [executable, ...args] = command;
    if (executable === void 0) return { exitCode: -1, stdout: "", stderr: "no command was given" };
    const environment = {};
    for (const [name, value] of Object.entries(process.env)) {
      if (name.startsWith("GIT_") || value === void 0) continue;
      environment[name] = value;
    }
    const outcome = await exec.run({
      command: executable,
      args,
      cwd: options.cwd,
      env: { ...environment, GIT_TERMINAL_PROMPT: "0", GIT_OPTIONAL_LOCKS: "0" }
    });
    return { exitCode: outcome.code, stdout: outcome.stdout, stderr: outcome.stderr };
  };
  const storageGitRunner = async (cwd, args) => {
    const outcome = await exec.run({ command: "git", args: [...args], cwd });
    if (outcome.code !== 0) {
      throw new Error(`git ${args.join(" ")} failed (${outcome.code}): ${outcome.stderr.trim()}`);
    }
    return outcome.stdout.trim();
  };
  let providerCaptureQueue = Promise.resolve();
  const captureProviderPair = async (mutableRoot, reviewRoot) => {
    let release;
    const prior = providerCaptureQueue;
    providerCaptureQueue = new Promise((resolve) => {
      release = resolve;
    });
    await prior;
    try {
      const mutable = await captureFor(mutableRoot, config, candidateRunner, storageGitRunner);
      if (!mutable.ok) return { ok: false, failure: mutable.failure };
      const review = await captureFor(reviewRoot, config, candidateRunner, storageGitRunner);
      if (!review.ok) return { ok: false, failure: review.failure };
      return { ok: true, mutable: mutable.candidate, review: review.candidate };
    } finally {
      release();
    }
  };
  let namespaceDirCache;
  const namespaceDir = async () => {
    if (namespaceDirCache !== void 0) return namespaceDirCache;
    const resolved = await resolveCommonDirectoryNamespace({
      cwd: input.repoDir,
      run: async ({ cwd, args }) => {
        const outcome = await exec.run({ command: "git", args: [...args], cwd });
        return { code: outcome.code, stdout: outcome.stdout };
      }
    });
    if (!resolved.ok) throw new Error(resolved.reason);
    namespaceDirCache = resolved.namespaceDir;
    return namespaceDirCache;
  };
  const deliveryDir = async (deliveryId) => path20.join(await namespaceDir(), "deliveries", deliveryId);
  const providerAuthorityDir = (deliveryId) => path20.join(input.installation.installationPath, "provider-review-authority", "deliveries", deliveryId);
  const providerAuthorityStatePath = (deliveryId) => path20.join(providerAuthorityDir(deliveryId), "workspace.json");
  const providerHandoffAuthorityPath = (deliveryId, handoffId) => path20.join(providerAuthorityDir(deliveryId), "handoffs", `${handoffId}.json`);
  const journalStoreFor = async (deliveryId) => createJournalStore(path20.join(await deliveryDir(deliveryId), "journal.jsonl"));
  const confirmationPath = (nonce) => path20.join(input.installation.installationPath, "confirmations", `${nonce}.json`);
  const readTrust = async () => {
    try {
      const parsed = parseTrustState(await readFile13(trustStorePathFor(input.installation.installationPath), "utf8"));
      return parsed.ok ? parsed.state : void 0;
    } catch {
      return void 0;
    }
  };
  const appendEntry = async (store, deliveryId, kind, payload) => {
    const read = await store.read();
    if (!read.ok) return refuse3("journal_unreadable", "The delivery journal is unreadable.", "Inspect the durable journal file.");
    let expectedRevision = 0;
    if (read.entries.length > 0) {
      const reduced = await store.state();
      if (!reduced.ok) {
        return refuse3("journal_rejected", "The durable journal does not reduce.", "Inspect the durable journal file.");
      }
      expectedRevision = reduced.state.expectedRevision;
    }
    const appended = await store.append({
      spec: "journal-entry/1",
      journal: "delivery",
      subjectId: deliveryId,
      expectedRevision,
      idempotencyKey: `e${read.entries.length}-${kind}`,
      kind,
      payload
    });
    if (!appended.ok) {
      return refuse3(
        "journal_rejected",
        `The frozen journal reducer refused a ${kind} append: ${appended.rejections.map((rejection) => rejection.message).join("; ")}`,
        "The refused entry is reported verbatim; correct the calling state."
      );
    }
    return { ok: true };
  };
  const recordBlockerAndTransition = async (store, deliveryId, fromState, code, summary, to) => {
    await appendEntry(store, deliveryId, "blocker.recorded", { code, summary });
    await appendEntry(store, deliveryId, "transition.committed", { from: fromState, to });
  };
  const guard = async (deliveryId, options = {}) => {
    const dir = await deliveryDir(deliveryId);
    const meta = await readJson(path20.join(dir, "delivery.json"));
    if (meta === void 0) {
      return refuse3("unknown_delivery", `No registered delivery ${deliveryId}.`, "Register a delivery through the contract handoff first.");
    }
    if (options.allowPendingTakeover !== true && await readJson(path20.join(dir, "takeover.json")) !== void 0) {
      return refuse3(
        "takeover_pending",
        "A consumed takeover authorization is pending; the quarantined workspace accepts no further checkpoints.",
        "Bind the fresh worktree the takeover authorized, then continue from the last trustworthy checkpoint."
      );
    }
    const store = await journalStoreFor(deliveryId);
    const reduced = await store.state();
    if (!reduced.ok) {
      return refuse3("journal_rejected", "The durable journal does not reduce.", "Inspect the durable journal file.");
    }
    const read = await store.read();
    if (!read.ok) return refuse3("journal_unreadable", "The delivery journal is unreadable.", "Inspect the durable journal file.");
    const views = viewsOf(read.entries);
    const recordedPolicyBindingDigest = reduced.state.policyBindingDigest;
    if (meta.policyBindingDigest !== policyBindingDigest || recordedPolicyBindingDigest !== policyBindingDigest || meta.policyBindingDigest !== recordedPolicyBindingDigest) {
      return refuse3(
        "policy_binding_mismatch",
        "The current compiled adopter policy binding does not match this delivery's recorded binding.",
        "Use the exact binding captured at registration; drift requires a new owner-approved delivery."
      );
    }
    const workspace = await readJson(path20.join(dir, "workspace.json"));
    const pinned = reduced.state.generationDigest;
    if (pinned === void 0) {
      return refuse3("unregistered", "The delivery has no pinned generation.", "Register the delivery first.");
    }
    const generation = await loadPinnedGeneration({
      installationPath: input.installation.installationPath,
      generationDigest: pinned
    });
    const trustCheck = generation.ok ? { kind: "eligible", ok: true } : {
      kind: "eligible",
      ok: false,
      detail: generation.blockers.map((blocker) => blocker.message).join("; ").slice(0, 1900)
    };
    const recordedBinding = recordedBindingOf(views);
    const binding = await registrationBinding({
      installationPath: input.installation.installationPath,
      receiptDir: input.installation.receiptDir
    });
    const installationCheck = {
      kind: "compare",
      expected: recordedBinding?.registeringInstallationId ?? "recorded-installation",
      observed: binding.ok ? binding.registeringInstallationId : "unresolved-installation"
    };
    const profileCheck = {
      kind: "compare",
      expected: recordedBinding?.activeCompositionProfile ?? "recorded-profile",
      observed: binding.ok ? binding.activeCompositionProfile : "unresolved-profile"
    };
    const epochCheck = reduced.state.authorityEpoch === void 0 ? "absent-by-state" : { kind: "compare", expected: reduced.state.authorityEpoch, observed: meta.policy.repositoryAuthorityRevocationEpoch };
    if (options.fenceRequired === true && options.invokingFence === void 0) {
      return refuse3(
        "missing_fence",
        "This operation records host-task output and presented no invocation fence.",
        "Present the fence the invocation was bound under; only the currently fenced invocation may record outputs."
      );
    }
    const fenceCheck = {
      kind: "compare",
      expected: reduced.state.lastFence,
      observed: options.invokingFence ?? reduced.state.lastFence
    };
    let projectionCheck = "absent-by-state";
    let discoveryCheck = "absent-by-state";
    if (options.verifyWorkspace === true && workspace !== void 0) {
      try {
        await stat6(workspace.worktreeDir);
      } catch {
        return refuse3(
          "workspace_missing",
          "The bound worktree no longer exists on disk.",
          "Resume through an operator-authorized takeover into a fresh host-created worktree."
        );
      }
      const projection = await verifyProjection({
        worktreeDir: workspace.worktreeDir,
        bindingDir: path20.join(dir, "binding")
      });
      projectionCheck = {
        kind: "compare",
        expected: workspace.projectionDigest,
        observed: projection.ok ? projection.projectionDigest : `unverifiable: ${projection.blockers.map((blocker) => blocker.message).join("; ")}`.slice(0, 1900)
      };
      discoveryCheck = {
        kind: "compare",
        expected: workspace.discoveryConfigurationDigest,
        observed: await discoveryConfigurationDigestOf({
          settingsPath: workspace.settingsPath,
          bindingDir: path20.join(dir, "binding")
        }) ?? "unreadable-discovery-configuration"
      };
    }
    const recheckValues = {
      "product-trust": trustCheck,
      "repository-authority-epoch": epochCheck,
      "invocation-fence": fenceCheck,
      "registering-installation-id": installationCheck,
      "active-profile": profileCheck,
      "projection-digest": projectionCheck,
      "discovery-configuration-digest": discoveryCheck
    };
    const recheck = evaluateCanonicalRecheck({ consumption: { kind: "standard" }, values: recheckValues });
    if (!recheck.ok) {
      const failure = recheck.failures[0];
      if (failure === void 0) {
        return refuse3("recheck_failed", "The canonical recheck failed without a named value.", "Inspect the durable journal file.");
      }
      switch (failure.value) {
        case "product-trust": {
          if (reduced.state.state !== "security_blocked") {
            await recordBlockerAndTransition(store, deliveryId, reduced.state.state, "trust.generation-ineligible", failure.message.slice(0, 1900), "security_blocked");
          }
          return refuse3(
            "trust_ineligible",
            "The pinned generation is no longer execution-eligible under current local trust state.",
            "Restore local trust state through the operator maintenance lane."
          );
        }
        case "registering-installation-id":
        case "active-profile": {
          if (reduced.state.state !== "security_blocked") {
            await recordBlockerAndTransition(
              store,
              deliveryId,
              reduced.state.state,
              "trust.installation-mismatch",
              "the registering installation identity or active profile no longer matches this installation",
              "security_blocked"
            );
          }
          return refuse3(
            "installation_mismatch",
            "This delivery is bound to a different registering installation or profile.",
            "Rebinding a delivery is an explicit migration, not an ambient adoption."
          );
        }
        case "repository-authority-epoch": {
          if (reduced.state.state !== "blocked" && reduced.state.state !== "security_blocked") {
            await recordBlockerAndTransition(store, deliveryId, reduced.state.state, "authority.epoch-changed", failure.message.slice(0, 1900), "blocked");
          }
          return refuse3(
            "authority_epoch_changed",
            "The repository authority-revocation epoch changed; the delivery returns to policy evaluation.",
            "Re-evaluate under the current compiled policy before continuing."
          );
        }
        case "invocation-fence": {
          return refuse3(
            "stale_fence",
            `The invocation fence ${String(options.invokingFence)} is not the current fence ${reduced.state.lastFence}; outputs from an older fence are permanently rejected.`,
            "Only the currently fenced invocation may record outputs; resume through an authorized takeover."
          );
        }
        case "discovery-configuration-digest": {
          if (reduced.state.state !== "blocked" && reduced.state.state !== "security_blocked") {
            await recordBlockerAndTransition(store, deliveryId, reduced.state.state, "discovery.configuration-tampered", failure.message.slice(0, 1900), "blocked");
          }
          return refuse3(
            "discovery_configuration_tampered",
            "The binding-written host discovery configuration no longer matches its application digest.",
            "Quarantine the workspace and resume through an authorized takeover."
          );
        }
        default: {
          if (reduced.state.state !== "blocked" && reduced.state.state !== "security_blocked") {
            await recordBlockerAndTransition(store, deliveryId, reduced.state.state, "projection.tampered", failure.message.slice(0, 1900), "blocked");
          }
          return refuse3(
            "projection_tampered",
            "The receipted projection subtree no longer matches its materialization digest.",
            "Quarantine the workspace and resume through an authorized takeover."
          );
        }
      }
    }
    if (options.fenceRequired === true && options.verifyWorkspace === true && workspace !== void 0) {
      const marker = await readConsumptionMarker({ worktreeDir: workspace.worktreeDir });
      const observedMarker = marker.ok ? `${marker.deliveryId}@${marker.fence}` : `unreadable (${marker.blockers.map((blocker) => blocker.code).join(", ")})`;
      const expectedMarker = `${deliveryId}@${options.invokingFence ?? reduced.state.lastFence}`;
      if (observedMarker !== expectedMarker) {
        if (reduced.state.state !== "blocked" && reduced.state.state !== "security_blocked") {
          await recordBlockerAndTransition(
            store,
            deliveryId,
            reduced.state.state,
            "projection.consumption-marker-mismatch",
            `the worktree's per-run consumption marker reads ${observedMarker}, not ${expectedMarker}`.slice(0, 1900),
            "blocked"
          );
        }
        return refuse3(
          "consumption_marker_mismatch",
          `The worktree's per-run consumption marker reads ${observedMarker}, not ${expectedMarker}.`,
          "Only the projection this invocation materialized may carry its outputs; quarantine the workspace and resume through an authorized takeover."
        );
      }
    }
    if (binding.ok && binding.activeCompositionProfile === "confirmation-fixture" && !(binding.disposableRepositoryIds ?? []).includes(meta.contract.repository.repositoryId)) {
      return refuse3(
        "disposable_repository_refused",
        "A qualification installation serves only its receipt-listed disposable repositories; this repository is not listed.",
        "Qualification runs happen in the disposable repositories named at install time; production repositories need a production installation."
      );
    }
    return options.requireState !== void 0 && !options.requireState.includes(reduced.state.state) ? refuse3(
      "wrong_state",
      `This operation runs in ${options.requireState.join("/")}; the delivery is in ${reduced.state.state}.`,
      "Read `status` for the next valid checkpoint."
    ) : {
      store,
      meta,
      state: reduced.state.state,
      lastActiveState: reduced.state.lastActiveState,
      expectedRevision: reduced.state.expectedRevision,
      lastFence: reduced.state.lastFence,
      views,
      workspace,
      generationRoot: generation.ok ? generation.root : "",
      recheckValues
    };
  };
  const providerRunKeyOf = (result2) => digestCanonical({
    providerId: result2.provider.id,
    providerVersion: result2.provider.version,
    runId: result2.provider.runId,
    finalPassId: result2.provider.finalPassId
  });
  const suspendedProviderRunKeysOf = (views) => new Set(
    views.filter((view) => view.kind === "blocker.recorded" && view.payload["code"] === "review.result-replay-conflict").map((view) => view.payload["providerRunKey"]).filter((key) => typeof key === "string")
  );
  const recordedProviderAttemptsOf = (views) => views.filter((view) => view.kind === "attempt.artifact.recorded").map((view) => ({
    attemptId: view.payload["attemptId"],
    lensId: view.payload["lensId"],
    contextDigest: view.payload["contextDigest"],
    personaDigest: view.payload["personaDigest"],
    artifactDigest: view.payload["artifactDigest"]
  }));
  const acceptedProviderResultsOf = async (deliveryId, views) => {
    const dir = await deliveryDir(deliveryId);
    const results = [];
    for (const recorded of recordedProviderAttemptsOf(views)) {
      try {
        const bytes = await readFile13(persistedResultPath(dir, recorded.artifactDigest), "utf8");
        if (sha256Hex(bytes) !== recorded.artifactDigest) {
          return refuse3(
            "provider_result_artifact_unavailable",
            `Accepted provider result ${recorded.attemptId} no longer matches its journaled content address.`,
            "Restore the exact content-addressed result bytes; never append a replacement acceptance."
          );
        }
        const parsed = parseProviderReviewResult(bytes);
        if (parsed.ok && parsed.result.reviewer.attemptId === recorded.attemptId && parsed.result.reviewer.lensId === recorded.lensId && parsed.result.reviewer.contextDigest === recorded.contextDigest && parsed.result.reviewer.personaDigest === recorded.personaDigest) {
          results.push(parsed.result);
        } else {
          return refuse3(
            "provider_result_artifact_unavailable",
            `Accepted provider result ${recorded.attemptId} is malformed or disagrees with its journaled attempt binding.`,
            "Restore the exact content-addressed result bytes; never append a replacement acceptance."
          );
        }
      } catch {
        return refuse3(
          "provider_result_artifact_unavailable",
          `Accepted provider result ${recorded.attemptId} is missing from content-addressed storage.`,
          "Restore the exact content-addressed result bytes; never append a replacement acceptance."
        );
      }
    }
    return { ok: true, results };
  };
  const attemptsOf = async (deliveryId, views) => {
    const loaded = await acceptedProviderResultsOf(deliveryId, views);
    if (!loaded.ok) return loaded;
    const results = loaded.results.filter((result2) => !suspendedProviderRunKeysOf(views).has(providerRunKeyOf(result2)));
    const attempts = [];
    for (const result2 of results) {
      attempts.push({
        attemptId: result2.reviewer.attemptId,
        lensId: result2.reviewer.lensId,
        contextDigest: result2.reviewer.contextDigest,
        artifactDigest: sha256Hex(`${JSON.stringify(result2, null, 2)}
`),
        verdict: result2.verdict === "approved" ? "approved" : "findings",
        candidateTreeSha: result2.candidate.treeSha,
        personaDigest: result2.reviewer.personaDigest
      });
    }
    return { ok: true, attempts, results };
  };
  const nextCheckpointOf = (state, views) => {
    switch (state) {
      case "accepted":
      case "preparing":
        return { kind: "bind-workspace" };
      case "planning":
        return { kind: "workflow-stage", stageId: "plan", remediation: false, grantDigest: checkpointGrantDigestFor("plan") };
      case "implementing":
        return { kind: "workflow-stage", stageId: "implement", remediation: false, grantDigest: checkpointGrantDigestFor("implement") };
      case "remediating":
        return { kind: "workflow-stage", stageId: "implement", remediation: true, grantDigest: checkpointGrantDigestFor("implement") };
      case "validating":
        return { kind: "repository-sensor", capabilityId: policyBinding.sensor.capabilityId };
      case "reviewing":
        return { kind: "review", stageId: "review.acquire", lenses: policy.reviewLenses.map((lens) => lens.lensId) };
      case "admitting":
        return { kind: "admission" };
      case "recording":
        return { kind: "tracked-record" };
      case "ready":
        return { kind: "finish-line" };
      case "completed":
        return { kind: "complete" };
      case "compounding":
        return { kind: "workflow-stage", stageId: "compound", remediation: false, grantDigest: checkpointGrantDigestFor("compound") };
      default: {
        const blocker = lastOf2(views, "blocker.recorded");
        return {
          kind: "blocked",
          code: blocker?.payload["code"] ?? "blocked",
          summary: blocker?.payload["summary"] ?? `the delivery is ${state}`
        };
      }
    }
  };
  const renderChallenge = async (nonce, confirmation, subject, expiry) => {
    const binding = await registrationBinding({
      installationPath: input.installation.installationPath,
      receiptDir: input.installation.receiptDir
    });
    if (!binding.ok) {
      return refuse3("installation_unresolved", "No install receipt resolves this installation.", "Install the composition first.");
    }
    if (binding.activeCompositionProfile !== "confirmation-fixture") {
      return refuse3(
        "interactive_channel_required",
        "Production confirmations fail closed because this host has no qualified binding-owned producer.",
        "Qualify a host-native producer before enabling production contract confirmation or takeover."
      );
    }
    const pending = {
      rendered: {
        channelId: `chan-${nonce}`,
        channelOpen: true,
        interactive: true,
        challenge: hex(16),
        consumed: false,
        expiry
      },
      confirmation,
      subject
    };
    const channelPath = confirmationPath(nonce);
    await writeOwned2(channelPath, `${JSON.stringify(pending)}
`);
    return { ok: true, channelPath };
  };
  const consumeChallenge = async (nonce, echo) => {
    const channelPath = confirmationPath(nonce);
    const pending = await readJson(channelPath);
    if (pending === void 0) {
      return refuse3("confirmation_unknown", "No rendered confirmation challenge matches this nonce.", "Present the confirmation first.");
    }
    const decision = evaluateConfirmationEcho(pending.rendered, echo);
    if (!decision.completed) {
      return refuse3(
        "confirmation_refused",
        `The confirmation echo was refused: ${decision.denials.map((denial) => `${denial.code}: ${denial.message}`).join("; ")}`,
        "Complete the echo on the same open, interactive, binding-owned channel it was rendered on."
      );
    }
    await writeOwned2(channelPath, `${JSON.stringify({ ...pending, rendered: { ...pending.rendered, consumed: true } })}
`);
    return { confirmation: pending.confirmation };
  };
  const retentionContext = async () => {
    const binding = await registrationBinding({
      installationPath: input.installation.installationPath,
      receiptDir: input.installation.receiptDir
    });
    if (!binding.ok) {
      return refuse3("installation_unresolved", "No install receipt resolves this installation.", "Install the composition first.");
    }
    return {
      namespaceDir: await namespaceDir(),
      installationId: binding.registeringInstallationId,
      maintenanceJournalPath: path20.join(input.installation.installationPath, "maintenance.jsonl")
    };
  };
  const verifyDeliveryBinding = async (deliveryId) => {
    const dir = await deliveryDir(deliveryId);
    const meta = await readJson(path20.join(dir, "delivery.json"));
    if (meta === void 0) {
      return refuse3("unknown_delivery", `No registered delivery ${deliveryId}.`, "Register a delivery through the contract handoff first.");
    }
    const reduced = await (await journalStoreFor(deliveryId)).state();
    if (!reduced.ok) {
      return refuse3("journal_rejected", "The durable delivery journal does not reduce.", "Inspect the durable delivery journal file.");
    }
    if (meta.policyBindingDigest !== policyBindingDigest || reduced.state.policyBindingDigest !== policyBindingDigest || meta.policyBindingDigest !== reduced.state.policyBindingDigest) {
      return refuse3(
        "policy_binding_mismatch",
        "The current compiled adopter policy binding does not match this delivery's recorded binding.",
        "Use the exact binding captured at registration; drift requires a new owner-approved delivery."
      );
    }
    return { ok: true };
  };
  const intakePath = async (intakeId, suffix) => path20.join(await namespaceDir(), "intake", `${intakeId}${suffix}`);
  const intakeStoreFor = async (intakeId) => createIntakeJournalStore(await intakePath(intakeId, ".jsonl"));
  const intakeProjectionOf = async (intakeId) => {
    try {
      const reduced = await (await intakeStoreFor(intakeId)).state();
      return reduced.ok ? { state: reduced.state.state, expectedRevision: reduced.state.expectedRevision } : void 0;
    } catch {
      return void 0;
    }
  };
  const appendIntake = async (store, intakeId, kind, payload) => {
    const read = await store.read();
    if (!read.ok) return refuse3("intake_journal_unreadable", "The intake journal is unreadable.", "Inspect the durable intake journal file.");
    let expectedRevision = 0;
    if (read.entries.length > 0) {
      const reduced = await store.state();
      if (!reduced.ok) return refuse3("intake_journal_rejected", "The durable intake journal does not reduce.", "Inspect the durable intake journal file.");
      expectedRevision = reduced.state.expectedRevision;
    }
    const appended = await store.append({
      spec: "journal-entry/1",
      journal: "intake",
      subjectId: intakeId,
      expectedRevision,
      idempotencyKey: `e${read.entries.length}-${kind}`,
      kind,
      payload
    });
    if (!appended.ok) {
      return refuse3(
        "intake_journal_rejected",
        `The frozen intake reducer refused a ${kind} append: ${appended.rejections.map((rejection) => rejection.message).join("; ")}`,
        "The refused entry is reported verbatim; correct the calling state."
      );
    }
    return { ok: true };
  };
  const intakeStateOf = async (store) => {
    const reduced = await store.state();
    if (!reduced.ok) {
      return refuse3("intake_unknown", "No intake journal reduces under this identity.", "Open an intake or present a contract first.");
    }
    return { state: reduced.state.state, ...reduced.state.lastDraftDigest === void 0 ? {} : { lastDraftDigest: reduced.state.lastDraftDigest } };
  };
  const trustedBaseCharters = async (baseRef) => {
    const personaBytes = {};
    for (const lens of policy.reviewLenses) {
      const source = policyBinding.personaSources[lens.personaId];
      if (source === void 0) return refuse3("reviewer_charter_missing", `No resolved reviewer charter exists for ${lens.personaId}.`, "Bind every activated review lens to an authenticated persona source.");
      if (source.origin === "composition") {
        personaBytes[lens.personaId] = source.bytes;
        continue;
      }
      const shown = await exec.run({ command: "git", args: ["show", `${baseRef}:${source.trustedBasePath}`], cwd: input.repoDir });
      if (shown.code !== 0 || shown.stdout !== source.bytes) {
        return refuse3(
          "reviewer_charter_moved",
          `The trusted pre-run base ${baseRef} does not carry the exact reviewer charter ${lens.personaId} bound by policy.`,
          "Rebind the repository-owned persona from the exact trusted base bytes before presenting the contract."
        );
      }
      personaBytes[lens.personaId] = shown.stdout;
    }
    return { personaBytes };
  };
  const presentValidation = async (contractValue) => {
    const contractVerdict = validateAcceptedContract(contractValue);
    if (!contractVerdict.ok) {
      return refuse3(
        "contract_rejected",
        `The scoped contract is outside its frozen grammar: ${contractVerdict.rejections.map((rejection) => rejection.message).join("; ")}`,
        "Fix the contract; material ambiguity remains in intake."
      );
    }
    const contract2 = contractValue;
    const active = await resolveActiveGeneration(input.installation.installationPath);
    if (!active.ok) {
      return refuse3("no_active_generation", "No active composition generation is installed.", "Install and activate a composition first.");
    }
    const generation = await loadPinnedGeneration({
      installationPath: input.installation.installationPath,
      generationDigest: active.generationDigest
    });
    if (!generation.ok) {
      return refuse3(
        "trust_ineligible",
        `The active generation fails its trust checks: ${generation.blockers.map((blocker) => blocker.message).join("; ")}`,
        "Restore local trust state through the operator maintenance lane."
      );
    }
    const trust = await readTrust();
    if (trust === void 0) {
      return refuse3("trust_state_unreadable", "The installation trust store is absent or corrupt.", "Absent trust state fails closed; reinstall or repair.");
    }
    if (policy.repositoryId !== contract2.repository.repositoryId) {
      return refuse3(
        "policy_repository_mismatch",
        "The compiled adopter policy belongs to a different repository than this contract.",
        "Compile and bind the repository policy for the contract's repository identity."
      );
    }
    if (policy.productTrustRevocationEpoch !== trust.revocationEpoch) {
      return refuse3(
        "policy_trust_epoch_mismatch",
        "The compiled adopter policy was not produced under the current product trust epoch.",
        "Recompile and bind the repository policy under the current trust state."
      );
    }
    const registration = await registrationBinding({
      installationPath: input.installation.installationPath,
      receiptDir: input.installation.receiptDir
    });
    if (!registration.ok) {
      return refuse3("installation_unresolved", "No install receipt resolves this installation.", "Install the composition first.");
    }
    if (registration.activeCompositionProfile === "confirmation-fixture" && !(registration.disposableRepositoryIds ?? []).includes(contract2.repository.repositoryId)) {
      return refuse3(
        "disposable_repository_refused",
        "A qualification installation registers deliveries only in its receipt-listed disposable repositories; this repository is not listed.",
        "Qualification runs happen in the disposable repositories named at install time; production repositories need a production installation."
      );
    }
    const charters = await trustedBaseCharters(contract2.repository.baseRef);
    if (!("personaBytes" in charters)) return charters;
    const withinPolicy = checkContractWithinPolicy(contract2, policy);
    if (!withinPolicy.ok) {
      return refuse3(
        "authority_not_granted",
        `The contract requests authority the compiled policy does not grant: ${withinPolicy.rejections.map((rejection) => rejection.message).join("; ")}`,
        "Absence of a grant is denial; narrow the contract or widen repository policy through its owners."
      );
    }
    return { contract: contract2, policy, generationDigest: active.generationDigest, trust };
  };
  const presentForConfirmation = async (intakeId, contract2, validated, expiry) => {
    const nonce = `nonce-${hex(8)}`;
    const normalizedContractDigest = digestCanonical(contract2);
    const confirmation = {
      spec: "operator-confirmation/1",
      confirmationClass: "contract-confirmation",
      origin: "managed-delivery.facade",
      action: "confirm-contract",
      expiry,
      nonce,
      productTrustRevocationEpoch: validated.trust.revocationEpoch,
      repositoryAuthorityRevocationEpoch: "absent-by-state",
      intakeDraftId: intakeId,
      deliveryId: "absent-by-state",
      normalizedContractDigest,
      supersededInvocationFence: "absent-by-state",
      expectedJournalRevision: "absent-by-state",
      targetBaseCommit: "absent-by-state",
      boundInvocationFence: "absent-by-state",
      boundCandidateTreeSha: "absent-by-state"
    };
    const rendered = await renderChallenge(nonce, confirmation, intakeId, expiry);
    if (!rendered.ok) return rendered;
    await writeOwned2(
      await intakePath(intakeId, ".meta.json"),
      `${JSON.stringify({ contract: contract2, policy: validated.policy, generationDigest: validated.generationDigest, nonce, policyBindingDigest })}
`
    );
    return { ok: true, nonce, normalizedContractDigest, channelPath: rendered.channelPath };
  };
  const acceptancePreflight = async (meta) => {
    const contractVerdict = validateAcceptedContract(meta.contract);
    if (!contractVerdict.ok) {
      return refuse3(
        "contract_rejected",
        `The presented contract is outside its frozen grammar: ${contractVerdict.rejections.map((rejection) => rejection.message).join("; ")}`,
        "Fix the contract; material ambiguity remains in intake."
      );
    }
    const binding = await registrationBinding({
      installationPath: input.installation.installationPath,
      receiptDir: input.installation.receiptDir
    });
    if (!binding.ok) {
      return refuse3("installation_unresolved", "No install receipt resolves this installation.", "Install the composition first.");
    }
    const trust = await readTrust();
    if (trust === void 0) {
      return refuse3("trust_state_unreadable", "The installation trust store is absent or corrupt.", "Absent trust state fails closed; reinstall or repair.");
    }
    if (meta.policyBindingDigest !== compiledAdopterPolicyBindingDigest(policyBinding)) {
      return refuse3(
        "policy_binding_mismatch",
        "The presented intake was bound to different adopter policy material.",
        "Re-present the contract with the exact compiled adopter policy binding."
      );
    }
    if (meta.policy.repositoryId !== meta.contract.repository.repositoryId) {
      return refuse3(
        "policy_repository_mismatch",
        "The presented policy belongs to a different repository than the contract.",
        "Re-present the contract with its repository's compiled policy."
      );
    }
    const generation = await loadPinnedGeneration({
      installationPath: input.installation.installationPath,
      generationDigest: meta.generationDigest
    });
    if (!generation.ok) {
      return refuse3(
        "trust_ineligible",
        "The generation bound at presentation is not execution-eligible under current local trust state.",
        "Restore local trust state through the operator maintenance lane, then retry acceptance."
      );
    }
    if (meta.policy.productTrustRevocationEpoch !== trust.revocationEpoch) {
      return refuse3(
        "policy_trust_epoch_mismatch",
        "The presented policy was not produced under the current product trust epoch.",
        "Re-present the contract with a policy compiled under the current trust state."
      );
    }
    const withinPolicy = checkContractWithinPolicy(meta.contract, meta.policy);
    if (!withinPolicy.ok) {
      return refuse3(
        "authority_not_granted",
        `The contract requests authority the compiled policy does not grant: ${withinPolicy.rejections.map((rejection) => rejection.message).join("; ")}`,
        "Absence of a grant is denial; narrow the contract or widen repository policy through its owners."
      );
    }
    const shown = await exec.run({
      command: "git",
      args: ["show", `${meta.contract.repository.baseRef}:${policyBinding.sensor.trustedBasePath}`],
      cwd: input.repoDir
    });
    if (shown.code !== 0) {
      return refuse3(
        "trusted_sensor_missing",
        `The trusted pre-run base ${meta.contract.repository.baseRef} carries no ${policyBinding.sensor.trustedBasePath}.`,
        "The repository's sensor must exist at the base; candidate-supplied sensors never govern."
      );
    }
    const charters = await trustedBaseCharters(meta.contract.repository.baseRef);
    if (!("personaBytes" in charters)) return charters;
    for (const lens of meta.policy.reviewLenses) {
      if (sha256Hex(charters.personaBytes[lens.personaId] ?? "") === lens.personaDigest) continue;
      return refuse3(
        "reviewer_charter_moved",
        `The trusted pre-run base no longer carries the reviewer charter ${lens.personaId} that this draft's policy pinned.`,
        "Re-present the contract so the policy pins the charters the base carries now."
      );
    }
    return { binding, sensorBytes: shown.stdout, personaBytes: charters.personaBytes, trust };
  };
  const registerDelivery = async (intakeId, meta, preflight) => {
    const trust = preflight.trust;
    if (meta.nonce === void 0) {
      return refuse3("confirmation_void", "No consumed confirmation is bound to this intake draft.", "Present the draft and complete the operator confirmation first.");
    }
    const ns = await namespaceDir();
    const deliveryId = `dlv-${hex(6)}`;
    const dir = await deliveryDir(deliveryId);
    const store = await journalStoreFor(deliveryId);
    const registered = await appendEntry(store, deliveryId, "delivery.registered", {
      contractDigest: digestCanonical(meta.contract),
      intakeId,
      confirmationNonce: meta.nonce,
      activeCompositionProfile: preflight.binding.activeCompositionProfile,
      registeringInstallationId: preflight.binding.registeringInstallationId
    });
    if (!registered.ok) return registered;
    await appendEntry(store, deliveryId, "generation.pinned", {
      generationDigest: meta.generationDigest,
      releaseId: PINNED_AGENT_SKILLS.releaseId,
      profile: preflight.binding.activeCompositionProfile
    });
    await appendEntry(store, deliveryId, "policy.snapshot.bound", {
      policyDigest: meta.policy.policyDigest,
      policyBindingDigest,
      repositoryAuthorityEpoch: meta.policy.repositoryAuthorityRevocationEpoch
    });
    await appendEntry(store, deliveryId, "trust.epoch.observed", {
      productTrustEpoch: trust.revocationEpoch,
      repositoryAuthorityEpoch: meta.policy.repositoryAuthorityRevocationEpoch
    });
    await writeOwned2(path20.join(dir, "trusted-sensor.mjs"), preflight.sensorBytes);
    for (const [personaId, bytes] of Object.entries(preflight.personaBytes)) {
      await writeOwned2(path20.join(dir, "personas", `${personaId}.md`), bytes);
    }
    await writeOwned2(
      path20.join(dir, "delivery.json"),
      `${JSON.stringify({ contract: meta.contract, policy: meta.policy, generationDigest: meta.generationDigest, intakeId, policyBindingDigest })}
`
    );
    await writeOwned2(path20.join(ns, "policy-binding.json"), `${JSON.stringify(policyBinding)}
`);
    await writeOwned2(
      path20.join(ns, "facade.json"),
      `${JSON.stringify({
        installationPath: input.installation.installationPath,
        receiptDir: input.installation.receiptDir,
        hostVersion: input.hostVersion,
        policyBindingDigest
      })}
`
    );
    const transitioned = await appendEntry(store, deliveryId, "transition.committed", { from: "accepted", to: "preparing" });
    if (!transitioned.ok) return transitioned;
    return { ok: true, deliveryId };
  };
  const runAcceptance = async (intakeId, store, meta) => {
    const preflight = await acceptancePreflight(meta);
    if (!("binding" in preflight)) {
      await appendIntake(store, intakeId, "intake.state.changed", { from: "validating_acceptance", to: "blocked" });
      return preflight;
    }
    const accepted = await appendIntake(store, intakeId, "intake.state.changed", { from: "validating_acceptance", to: "accepted_contract" });
    if (!accepted.ok) return accepted;
    return registerDelivery(intakeId, meta, preflight);
  };
  const loadGraph = async (generationRoot) => {
    let archiveBytes;
    try {
      archiveBytes = await readFile13(path20.join(generationRoot, ...GENERATION_SKILLS_ARCHIVE.split("/")));
    } catch {
      return refuse3("workflow_graph_rejected", "The pinned generation's skills archive is unreadable.", "Restore the installation through the operator maintenance lane.");
    }
    const loaded = loadBundledWorkflowGraph(archiveBytes);
    if (!loaded.ok) {
      return refuse3(
        "workflow_graph_rejected",
        `The bundled workflow graph failed its pin: ${loaded.blockers.map((blocker) => blocker.message).join("; ")}`,
        "Only the exact pinned graph governs checkpoints."
      );
    }
    return { graph: loaded.graph, graphSha256: loaded.graphSha256 };
  };
  const persistedResultPath = (dir, digest2) => path20.join(dir, "results", `${digest2}.json`);
  const persistedResultOf = async (dir, digest2) => {
    try {
      const bytes = await readFile13(persistedResultPath(dir, digest2), "utf8");
      if (sha256Hex(bytes) !== digest2) return void 0;
      const parsed = JSON.parse(bytes);
      if (typeof parsed.status !== "string" || typeof parsed.stageId !== "string") return void 0;
      return {
        stageId: parsed.stageId,
        status: parsed.status,
        ...typeof parsed.output?.kind === "string" ? { outputKind: parsed.output.kind } : {},
        evidenceRefs: [],
        limitations: []
      };
    } catch {
      return void 0;
    }
  };
  const retainedSummaries = async (deliveryId, views) => {
    const map = /* @__PURE__ */ new Map();
    if (views.some((view) => view.kind === "delivery.registered")) {
      map.set("intake", { status: "succeeded", outputKind: "scoped-subject" });
    }
    const dir = await deliveryDir(deliveryId);
    for (const view of views) {
      if (view.kind !== "stage.result.recorded") continue;
      const persisted = await persistedResultOf(dir, view.payload["resultDigest"]);
      if (persisted === void 0) continue;
      map.set(view.payload["stageId"], {
        status: persisted.status,
        ...persisted.outputKind === void 0 ? {} : { outputKind: persisted.outputKind }
      });
    }
    return map;
  };
  const processStageResult = (processInput) => {
    let parsed = processInput.resultBytes;
    try {
      parsed = JSON.parse(processInput.resultBytes);
    } catch {
    }
    const verdict = validateWorkflowStageResult(parsed, {
      graph: processInput.graph,
      graphSha256: processInput.graphSha256,
      release: RELEASE_IDENTITY,
      expectedStageId: processInput.stageId,
      expectedSubject: processInput.deliveryId,
      ...processInput.currentCandidate === void 0 ? {} : { currentCandidate: processInput.currentCandidate },
      ...processInput.producedCandidate === void 0 ? {} : { producedCandidate: processInput.producedCandidate }
    });
    if (!verdict.ok) {
      return refuse3(
        "stage_result_rejected",
        `The ${processInput.stageId} result is outside the released workflow contract: ${verdict.rejections.map((rejection) => rejection.message).join("; ").slice(0, 1500)}`,
        "Submit a typed workflow-stage-result/1 document; host-facing skill text guides execution but cannot advance a checkpoint."
      );
    }
    const stage = workflowStageOf(processInput.graph, processInput.stageId);
    if (stage === void 0) {
      return refuse3("stage_result_rejected", `The pinned graph declares no ${processInput.stageId} stage.`, "Read `next-checkpoint`.");
    }
    const prerequisites = evaluateStagePrerequisites(stage, processInput.summaries, {
      ...processInput.repairLoop === void 0 ? {} : { repairLoop: processInput.repairLoop },
      ...processInput.productRealized === void 0 ? {} : { productRealized: processInput.productRealized }
    });
    if (!prerequisites.ok) {
      return refuse3(
        "stage_prerequisite_unmet",
        `The ${processInput.stageId} stage's graph-declared prerequisites are not admitted: ${prerequisites.rejections.map((rejection) => rejection.message).join("; ").slice(0, 1500)}`,
        "Admit the prerequisite stage's typed result first; the frozen checkpoint order is not advisory."
      );
    }
    return { bytes: processInput.resultBytes, digest: sha256Hex(processInput.resultBytes), result: verdict.result };
  };
  return {
    namespaceDir,
    async openIntake({ workRequest, observedAt, attestationExpiry }) {
      if (workRequest.trim().length === 0) {
        return refuse3("work_request_empty", "An intake opens over a non-empty work request.", "State the intended outcome, then open the intake.");
      }
      const trust = await readTrust();
      if (trust === void 0) {
        return refuse3("trust_state_unreadable", "The installation trust store is absent or corrupt.", "Absent trust state fails closed; reinstall or repair.");
      }
      const intakeId = `intake-${hex(6)}`;
      const expectation = {
        profile: "intake",
        hostVersion: input.hostVersion,
        productTrustRevocationEpoch: trust.revocationEpoch,
        observedAt,
        intakeDraftId: intakeId
      };
      const attestation = mintGrantAttestation({ grant: PORTABLE_INTAKE_GRANT, expectation, expiry: attestationExpiry });
      const admission = evaluateHostAdmission(expectation, PORTABLE_INTAKE_GRANT, attestation);
      if (!admission.admitted) {
        return refuse3(
          "host_admission_refused",
          `The minted intake attestation does not admit against the binding's own expectation: ${admission.denials.map((denial) => denial.code).join(", ")}`,
          "Missing or failed grant application yields no intake invocation token."
        );
      }
      const store = await intakeStoreFor(intakeId);
      const openedTransition = await appendIntake(store, intakeId, "intake.state.changed", {
        from: "draft_scope",
        to: "awaiting_clarification"
      });
      if (!openedTransition.ok) return openedTransition;
      await writeOwned2(await intakePath(intakeId, ".request.json"), `${JSON.stringify({ workRequest })}
`);
      const grantPath = await intakePath(intakeId, ".grant.json");
      await writeOwned2(grantPath, `${JSON.stringify({ grant: PORTABLE_INTAKE_GRANT, expectation, attestation, admission })}
`);
      return { ok: true, intakeId, grantDigest: admission.grantDigest, grantPath };
    },
    async recordClarification({ intakeId, question, answer }) {
      const store = await intakeStoreFor(intakeId);
      const state = await intakeStateOf(store);
      if (!("state" in state)) return state;
      return appendIntake(store, intakeId, "intake.clarification.recorded", { question, answer });
    },
    async recordDraft({ intakeId, draft }) {
      const store = await intakeStoreFor(intakeId);
      const state = await intakeStateOf(store);
      if (!("state" in state)) return state;
      if (state.state === "blocked") {
        const reopened = await appendIntake(store, intakeId, "intake.state.changed", { from: "blocked", to: "validating_acceptance" });
        if (!reopened.ok) return reopened;
        const returned = await appendIntake(store, intakeId, "intake.state.changed", {
          from: "validating_acceptance",
          to: "awaiting_confirmation"
        });
        if (!returned.ok) return returned;
      }
      const draftDigest = digestCanonical(draft);
      const recorded = await appendIntake(store, intakeId, "intake.draft.recorded", { draftDigest });
      if (!recorded.ok) return recorded;
      await writeOwned2(await intakePath(intakeId, ".draft.json"), `${JSON.stringify(draft)}
`);
      const metaPath = await intakePath(intakeId, ".meta.json");
      const meta = await readJson(metaPath);
      if (meta?.nonce !== void 0) {
        await rm8(confirmationPath(meta.nonce), { force: true });
        const { nonce: _voided, ...rest } = meta;
        await writeOwned2(metaPath, `${JSON.stringify(rest)}
`);
      }
      return { ok: true, draftDigest };
    },
    async presentDraft({ intakeId, expiry }) {
      const store = await intakeStoreFor(intakeId);
      const state = await intakeStateOf(store);
      if (!("state" in state)) return state;
      if (state.state !== "awaiting_clarification" && state.state !== "awaiting_confirmation") {
        return refuse3(
          "wrong_state",
          `A draft is presented from awaiting_clarification or awaiting_confirmation; intake is in ${state.state}.`,
          "Record the draft, then present it."
        );
      }
      const draft = await readJson(await intakePath(intakeId, ".draft.json"));
      if (draft === void 0 || state.lastDraftDigest === void 0) {
        return refuse3("draft_missing", "No draft is retained for this intake.", "Record the completed draft contract first.");
      }
      const validated = await presentValidation(draft);
      if (!("policy" in validated)) return validated;
      if (state.state === "awaiting_clarification") {
        const presentedTransition = await appendIntake(store, intakeId, "intake.state.changed", {
          from: "awaiting_clarification",
          to: "awaiting_confirmation"
        });
        if (!presentedTransition.ok) return presentedTransition;
      }
      return presentForConfirmation(intakeId, validated.contract, validated, expiry);
    },
    async presentContract({ contract: contract2, expiry }) {
      const validated = await presentValidation(contract2);
      if (!("policy" in validated)) return validated;
      const intakeId = `intake-${hex(6)}`;
      const store = await intakeStoreFor(intakeId);
      const opened = await appendIntake(store, intakeId, "intake.state.changed", { from: "draft_scope", to: "awaiting_clarification" });
      if (!opened.ok) return opened;
      const draftDigest = digestCanonical(contract2);
      const drafted = await appendIntake(store, intakeId, "intake.draft.recorded", { draftDigest });
      if (!drafted.ok) return drafted;
      await writeOwned2(await intakePath(intakeId, ".draft.json"), `${JSON.stringify(contract2)}
`);
      const presentedTransition = await appendIntake(store, intakeId, "intake.state.changed", {
        from: "awaiting_clarification",
        to: "awaiting_confirmation"
      });
      if (!presentedTransition.ok) return presentedTransition;
      const presented = await presentForConfirmation(intakeId, validated.contract, validated, expiry);
      if (!presented.ok) return presented;
      return { ok: true, intakeId, nonce: presented.nonce, normalizedContractDigest: presented.normalizedContractDigest, channelPath: presented.channelPath };
    },
    async confirmContract({ intakeId, echo }) {
      const meta = await readJson(await intakePath(intakeId, ".meta.json"));
      if (meta === void 0) {
        return refuse3("intake_unknown", `No presented intake draft ${intakeId}.`, "Present the contract first.");
      }
      if (meta.nonce === void 0) {
        return refuse3(
          "confirmation_void",
          "No confirmation is pending: the draft mutated after presentation, so the operator's confirmation covered different bytes.",
          "Present the current draft for a fresh operator confirmation."
        );
      }
      const store = await intakeStoreFor(intakeId);
      const state = await intakeStateOf(store);
      if (!("state" in state)) return state;
      if (state.state !== "awaiting_confirmation") {
        return refuse3(
          "wrong_state",
          `A contract confirmation is consumed in awaiting_confirmation; intake is in ${state.state}.`,
          state.state === "blocked" ? "Retry acceptance; the consumed confirmation stands over the unchanged draft." : "Present the draft first."
        );
      }
      const consumed = await consumeChallenge(meta.nonce, echo);
      if (!("confirmation" in consumed)) return consumed;
      const recorded = await appendIntake(store, intakeId, "operator.confirmation.recorded", { confirmation: consumed.confirmation });
      if (!recorded.ok) return recorded;
      const validating = await appendIntake(store, intakeId, "intake.state.changed", {
        from: "awaiting_confirmation",
        to: "validating_acceptance"
      });
      if (!validating.ok) return validating;
      return runAcceptance(intakeId, store, meta);
    },
    async retryAcceptance({ intakeId }) {
      const meta = await readJson(await intakePath(intakeId, ".meta.json"));
      if (meta === void 0) {
        return refuse3("intake_unknown", `No presented intake draft ${intakeId}.`, "Present the contract first.");
      }
      const store = await intakeStoreFor(intakeId);
      const state = await intakeStateOf(store);
      if (!("state" in state)) return state;
      if (state.state !== "blocked") {
        return refuse3(
          "wrong_state",
          `retryAcceptance re-runs a blocked acceptance preflight; intake is in ${state.state}.`,
          "Only a blocked validating_acceptance retries without a fresh confirmation."
        );
      }
      const retried = await appendIntake(store, intakeId, "intake.state.changed", { from: "blocked", to: "validating_acceptance" });
      if (!retried.ok) return retried;
      return runAcceptance(intakeId, store, meta);
    },
    async bindWorkspace({ deliveryId, worktreeDir, hostTaskId, observedAt, attestationExpiry, observationLifetimeSeconds, providerReviewBindingCapability }) {
      const guarded = await guard(deliveryId, { allowPendingTakeover: true });
      if (!("store" in guarded)) return guarded;
      if (!capabilityShape(providerReviewBindingCapability)) {
        return refuse3(
          "provider_binding_capability_invalid",
          "The operator-owned provider-review binding capability is missing or malformed.",
          "Have the host create a fresh high-entropy capability outside the model process before binding."
        );
      }
      const takeover = await readJson(path20.join(await deliveryDir(deliveryId), "takeover.json"));
      if (guarded.state !== "preparing" && takeover === void 0) {
        return refuse3(
          "wrong_state",
          `bindWorkspace runs in preparing or after an authorized takeover; the delivery is in ${guarded.state}.`,
          "Read `status` for the next valid checkpoint."
        );
      }
      const top = await git(worktreeDir, "rev-parse", "--show-toplevel");
      const commonOfWorktree = await git(worktreeDir, "rev-parse", "--path-format=absolute", "--git-common-dir");
      const commonOfRepo = await git(input.repoDir, "rev-parse", "--path-format=absolute", "--git-common-dir");
      if (top.code !== 0 || commonOfWorktree.code !== 0 || commonOfWorktree.out !== commonOfRepo.out) {
        return refuse3("workspace_invalid", "The supplied worktree does not belong to this repository.", "Hand in a host-created worktree of this repository.");
      }
      const porcelain = await git(worktreeDir, "status", "--porcelain");
      if (porcelain.code !== 0 || porcelain.out !== "") {
        return refuse3("workspace_dirty", "The supplied worktree carries uncommitted or untracked work.", "Dirty baselines fail closed; hand in a clean worktree.");
      }
      const branchRef = (await git(worktreeDir, "rev-parse", "--abbrev-ref", "HEAD")).out;
      const branchRefValue = (await git(worktreeDir, "rev-parse", `refs/heads/${branchRef}`)).out;
      const headCommit = (await git(worktreeDir, "rev-parse", "HEAD")).out;
      const treeSha2 = (await git(worktreeDir, "rev-parse", "HEAD^{tree}")).out;
      const baseTipSha = (await git(input.repoDir, "rev-parse", guarded.meta.contract.repository.baseRef)).out;
      if (takeover !== void 0) {
        if (headCommit !== takeover.targetBaseCommit || branchRef !== takeover.takeoverBranchRef) {
          return refuse3(
            "takeover_mismatch",
            `The fresh worktree must sit on ${takeover.takeoverBranchRef} at the authorized last trusted commit ${takeover.targetBaseCommit}.`,
            "Recreate the worktree from the takeover authorization's target base commit."
          );
        }
      }
      const dir = await deliveryDir(deliveryId);
      const bindingDir = path20.join(dir, "binding");
      const workspaceId = `ws-${hex(6)}`;
      const worktreeId = `wt-${sha256Hex(worktreeDir).slice(0, 16)}`;
      await voidSupersededBindingStates(bindingDir, guarded.lastFence + 1);
      const bound2 = await appendEntry(guarded.store, deliveryId, "workspace.bound", {
        workspaceId,
        repositoryId: guarded.meta.contract.repository.repositoryId,
        baseRef: guarded.meta.contract.repository.baseRef,
        baseTipSha,
        branchRef: `refs/heads/${branchRef}`,
        branchRefValue,
        worktreeId,
        baselineClassification: "clean"
      });
      if (!bound2.ok) return bound2;
      const fence = guarded.lastFence + 1;
      const materialized = await materializeProjection({
        worktreeDir,
        generationRoot: guarded.generationRoot,
        deliveryId,
        fence,
        bindingDir,
        exec
      });
      if (!materialized.ok) {
        return refuse3(
          "projection_failed",
          `Materializing the run-pinned projection failed: ${materialized.blockers.map((blocker) => blocker.message).join("; ")}`,
          "A missing or unmaterializable pinned root blocks rather than falling forward."
        );
      }
      const statePath = path20.join(bindingDir, bindingStateFile(fence));
      const hookEntry = await resolveStagedHookEntry(path20.join(guarded.generationRoot, ...GENERATION_HOOK_ENTRY.split("/")));
      if (hookEntry === void 0) {
        return refuse3(
          "hook_entry_missing",
          `The installed generation stages no model-external hook entry at ${GENERATION_HOOK_ENTRY}.`,
          "Reinstall or roll back to a generation whose closure verifies; a session cannot be admitted without its interceptor."
        );
      }
      const session = await composeClaudeCodeSession({
        bindingDir,
        statePath,
        hookCommand: [process.execPath, ...HOOK_RUNTIME_ARGS, hookEntry],
        // The session's own identity, baked into its hook command: a later
        // invocation overwrites the shared binding state, and this is how a
        // superseded-but-still-running session recognizes that it has been.
        fence,
        workspaceRoot: worktreeDir,
        commonGitDir: commonOfWorktree.out,
        authorityDir: path20.join(input.installation.installationPath, "provider-review-authority"),
        grant: stageGrant
      });
      if (!session.ok) {
        return refuse3(
          "session_composition_failed",
          `Composing the host admission failed: ${session.blockers.map((blocker) => blocker.message).join("; ")}`,
          "Materialize the projection before composing the session."
        );
      }
      const archiveBytes = await readFile13(path20.join(guarded.generationRoot, ...GENERATION_SKILLS_ARCHIVE.split("/")));
      const graph = loadBundledWorkflowGraph(archiveBytes);
      if (!graph.ok) {
        return refuse3(
          "workflow_graph_rejected",
          `The bundled workflow graph failed its pin: ${graph.blockers.map((blocker) => blocker.message).join("; ")}`,
          "Only the exact pinned graph governs checkpoints."
        );
      }
      const trust = await readTrust();
      if (trust === void 0) {
        return refuse3("trust_state_unreadable", "The installation trust store is absent or corrupt.", "Absent trust state fails closed; reinstall or repair.");
      }
      const registered = lastOf2(guarded.views, "delivery.registered");
      const expectation = {
        profile: "checkpoint",
        hostVersion: input.hostVersion,
        productTrustRevocationEpoch: trust.revocationEpoch,
        observedAt,
        deliveryId,
        invocationFence: fence,
        workspaceId,
        projectionDigest: materialized.projectionDigest,
        discoveryConfigurationDigest: session.discoveryConfigurationDigest,
        registeringInstallationId: registered?.payload["registeringInstallationId"],
        activeProfile: registered?.payload["activeCompositionProfile"]
      };
      const attestation = mintGrantAttestation({ grant: stageGrant, expectation, expiry: attestationExpiry });
      const admission = evaluateHostAdmission(expectation, stageGrant, attestation);
      if (!admission.admitted) {
        return refuse3(
          "host_admission_refused",
          `The minted attestation does not admit against the binding's own expectation: ${admission.denials.map((denial) => denial.code).join(", ")}`,
          "Missing or failed grant application yields no mutation-capable invocation token."
        );
      }
      const observationPath = path20.join(bindingDir, "observation.json");
      await writeOwned2(
        statePath,
        `${JSON.stringify({
          expectation,
          grant: stageGrant,
          attestation,
          workspaceRoot: worktreeDir,
          observationPath,
          projectionConsumptionPath: path20.join(bindingDir, projectionConsumptionObservationFile(fence)),
          projectionReceiptPath: path20.join(bindingDir, PROJECTION_RECEIPT_FILE),
          journalPath: guarded.store.journalPath,
          deliveryId
        })}
`
      );
      await writeOwned2(observationPath, `${JSON.stringify({ fence, observedAt })}
`);
      const lifetime = observationLifetimeSeconds ?? 900;
      const grantDigest2 = stageGrantDigest;
      const providerReviewBinding = {
        id: providerReviewBindingCapability.id,
        digest: capabilityDigest({
          domain: "workspace",
          capability: providerReviewBindingCapability,
          deliveryId,
          workspaceId,
          fence,
          discoveryConfigurationDigest: session.discoveryConfigurationDigest,
          grantDigest: grantDigest2,
          productTrustRevocationEpoch: trust.revocationEpoch
        })
      };
      await writeOwned2(
        providerAuthorityStatePath(deliveryId),
        `${JSON.stringify({
          deliveryId,
          workspaceId,
          fence,
          discoveryConfigurationDigest: session.discoveryConfigurationDigest,
          grantDigest: grantDigest2,
          productTrustRevocationEpoch: trust.revocationEpoch,
          bindingCapability: providerReviewBinding
        })}
`
      );
      await writeOwned2(
        path20.join(dir, "workspace.json"),
        `${JSON.stringify({
          worktreeDir,
          workspaceId,
          worktreeId,
          branchRef,
          observationLifetimeSeconds: lifetime,
          workflowGraphSha256: graph.graphSha256,
          discoveryConfigurationDigest: session.discoveryConfigurationDigest,
          projectionDigest: materialized.projectionDigest,
          fence,
          settingsPath: session.settingsPath
        })}
`
      );
      const fenced = await appendEntry(guarded.store, deliveryId, "invocation.fenced", {
        fence,
        hostTaskId,
        worktreeId,
        candidateTreeSha: treeSha2,
        candidateBranchRefValue: branchRefValue,
        policyDigest: guarded.meta.policy.policyDigest,
        authorityEpoch: guarded.meta.policy.repositoryAuthorityRevocationEpoch,
        observationLifetimeSeconds: lifetime
      });
      if (!fenced.ok) return fenced;
      await appendEntry(guarded.store, deliveryId, "activity.observed", { activity: "active", fence });
      if (takeover !== void 0) {
        await appendEntry(guarded.store, deliveryId, "workspace.disposition.recorded", {
          workspaceId,
          disposition: "takeover"
        });
        if (guarded.state === "blocked") {
          const resumed = await appendEntry(guarded.store, deliveryId, "transition.committed", {
            from: "blocked",
            to: guarded.lastActiveState
          });
          if (!resumed.ok) return resumed;
        }
        await rm8(path20.join(dir, "takeover.json"), { force: true });
      } else {
        const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: "preparing", to: "planning" });
        if (!transitioned.ok) return transitioned;
      }
      return {
        ok: true,
        fence,
        workspaceId,
        statePath,
        settingsPath: session.settingsPath,
        cliArgs: session.cliArgs,
        projectionDigest: materialized.projectionDigest
      };
    },
    async status({ deliveryId, observedAt }) {
      const dir = await deliveryDir(deliveryId);
      const meta = await readJson(path20.join(dir, "delivery.json"));
      if (meta === void 0) {
        return refuse3("unknown_delivery", `No registered delivery ${deliveryId}.`, "Register a delivery through the contract handoff first.");
      }
      const store = await journalStoreFor(deliveryId);
      const reduced = await store.state();
      const read = await store.read();
      if (!reduced.ok || !read.ok) {
        return refuse3("journal_rejected", "The durable journal does not reduce.", "Inspect the durable journal file.");
      }
      if (meta.policyBindingDigest !== policyBindingDigest || reduced.state.policyBindingDigest !== policyBindingDigest) {
        return refuse3(
          "policy_binding_mismatch",
          "The current compiled adopter policy binding does not match this delivery's recorded binding.",
          "Use the exact binding captured at registration; drift requires a new owner-approved delivery."
        );
      }
      const views = viewsOf(read.entries);
      const workspace = await readJson(path20.join(dir, "workspace.json"));
      const lastActivity = lastOf2(views, "activity.observed");
      let activity = lastActivity !== void 0 && lastActivity.payload["fence"] === reduced.state.lastFence ? lastActivity.payload["activity"] : "unknown";
      if (activity === "active" && workspace !== void 0) {
        const observation = await readJson(path20.join(dir, "binding", "observation.json"));
        if (observation === void 0 || observation.fence !== reduced.state.lastFence) {
          activity = "unknown";
        } else {
          const ageSeconds = instantSeconds(observedAt) - instantSeconds(observation.observedAt);
          if (Number.isNaN(ageSeconds) || ageSeconds > workspace.observationLifetimeSeconds) activity = "unknown";
        }
      }
      const confirmations = views.filter((view) => view.kind === "operator.confirmation.recorded").length;
      const interventions = views.filter(
        (view) => view.kind === "blocker.recorded" && String(view.payload["code"]).startsWith("operator.")
      ).length;
      const terminal = reduced.state.state === "completed" || reduced.state.state === "cancelled" || reduced.state.state === "failed";
      const provenance = lastOf2(views, "termination.provenance.recorded");
      const sameWorkspaceResumable = provenance !== void 0 && provenance.payload["fence"] === reduced.state.lastFence && provenance.payload["resumeEligibility"] === "same-workspace";
      const resume = terminal ? "none" : activity === "active" ? "none" : sameWorkspaceResumable ? "same-workspace" : "takeover-required";
      const blockers = reduced.state.state === "blocked" || reduced.state.state === "security_blocked" ? views.filter((view) => view.kind === "blocker.recorded").slice(-1).map((view) => ({ code: view.payload["code"], summary: view.payload["summary"] })) : [];
      const recordedBinding = recordedBindingOf(views);
      const observedBinding = await registrationBinding({
        installationPath: input.installation.installationPath,
        receiptDir: input.installation.receiptDir
      });
      const currentBinding = observedBinding.ok ? {
        registeringInstallationId: observedBinding.registeringInstallationId,
        activeCompositionProfile: observedBinding.activeCompositionProfile
      } : void 0;
      let mismatch;
      if (recordedBinding === void 0 || currentBinding === void 0) {
        mismatch = "unresolved";
      } else if (recordedBinding.activeCompositionProfile !== currentBinding.activeCompositionProfile) {
        mismatch = "profile";
      } else if (recordedBinding.registeringInstallationId !== currentBinding.registeringInstallationId) {
        mismatch = "identity";
      } else {
        mismatch = "none";
      }
      const trust = await readTrust();
      const pinnedGenerationDigest = meta.generationDigest;
      const generation = trust === void 0 ? "unreadable" : (() => {
        const decision = localDigestTrustPredicate.evaluate(pinnedGenerationDigest, trust);
        return decision.eligible ? "eligible" : decision.reason;
      })();
      const providerConfig = await loadAssertionProviderConfig(input.installation.installationPath);
      let assertionView;
      if (!providerConfig.ok) {
        assertionView = {
          availability: "unconfigured",
          detail: `assertion provider configuration is ${providerConfig.reason}`,
          lanes: assertionLaneAvailability({ hostNative: false, osNative: false })
        };
      } else {
        const probe = await assertionSourceForKind(providerConfig.config.sourceKind).probe();
        assertionView = probe.available ? {
          availability: "available",
          detail: probe.detail,
          lanes: assertionLaneAvailability({
            hostNative: probe.sourceKind === "host-native",
            osNative: probe.sourceKind !== "host-native"
          })
        } : {
          availability: "unavailable",
          detail: probe.detail,
          lanes: assertionLaneAvailability({ hostNative: false, osNative: false })
        };
      }
      if (currentBinding?.activeCompositionProfile === "confirmation-fixture") {
        assertionView = {
          ...assertionView,
          lanes: { ...assertionView.lanes, operatorConfirmations: "available" }
        };
      }
      const dispositions = views.filter((view) => view.kind === "workspace.disposition.recorded");
      const quarantinedWorkspaces = [
        ...new Set(
          dispositions.filter((view) => view.payload["disposition"] === "quarantined").map((view) => view.payload["workspaceId"])
        )
      ];
      const lastDisposition = dispositions[dispositions.length - 1]?.payload["disposition"];
      const admission = await readJson(path20.join(dir, "admission.json"));
      const intakeState = await intakeProjectionOf(meta.intakeId);
      const composed = {
        deliveryId,
        intake: intakeState,
        delivery: { state: reduced.state.state, expectedRevision: reduced.state.expectedRevision, fence: reduced.state.lastFence },
        hostActivity: activity,
        completedObligations: admission?.completedObligations ?? [],
        productTrust: {
          label: PRODUCT_TRUST_LABEL,
          pinnedGenerationDigest,
          revocationEpoch: trust?.revocationEpoch ?? 0,
          generation
        },
        assertionSource: assertionView,
        quarantinedWorkspaces,
        candidate: currentCandidateOf(views),
        pendingDecision: waiverLedgerOf(views).pending[0],
        registrationBinding: { recorded: recordedBinding, current: currentBinding, mismatch },
        lastWorkspaceDisposition: lastDisposition,
        terminationVerifiedAtCurrentFence: provenance !== void 0 && provenance.payload["fence"] === reduced.state.lastFence && provenance.payload["descendantTeardown"] === "verified",
        workspaceBound: workspace !== void 0,
        nextCheckpoint: nextCheckpointOf(reduced.state.state, views),
        resume,
        blockers,
        policyRequiredInterruptions: confirmations + 1,
        // + the intake contract confirmation
        operatorInterventions: interventions
      };
      return { ok: true, status: composeManagedStatus(composed) };
    },
    async nextCheckpoint({ deliveryId }) {
      const guarded = await guard(deliveryId);
      if (!("store" in guarded)) return guarded;
      return { ok: true, checkpoint: nextCheckpointOf(guarded.state, guarded.views) };
    },
    async submitStageResult({ deliveryId, stageId, resultBytes, fence }) {
      const expected = stageId === "plan" ? ["planning"] : ["compounding"];
      const guarded = await guard(deliveryId, { requireState: expected, verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const binding = workflowStageBindingFor(guarded.state);
      if (binding === void 0 || binding.stageId !== stageId) {
        return refuse3("wrong_stage", `Stage ${stageId} is not the bundled graph's checkpoint for ${guarded.state}.`, "Read `next-checkpoint`.");
      }
      const loaded = await loadGraph(guarded.generationRoot);
      if (!("graph" in loaded)) return loaded;
      const current = currentCandidateOf(guarded.views);
      if (stageId === "compound") {
        const treeSha2 = (await git(workspace.worktreeDir, "rev-parse", "HEAD^{tree}")).out;
        if (current !== void 0 && treeSha2 !== current.treeSha) {
          const recorded = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: "compounding", to: "validating" });
          if (!recorded.ok) return recorded;
          return { ok: true, state: "validating" };
        }
      }
      const summaries = await retainedSummaries(deliveryId, guarded.views);
      const processed = processStageResult({
        resultBytes,
        graph: loaded.graph,
        graphSha256: loaded.graphSha256,
        stageId,
        deliveryId,
        ...current === void 0 ? {} : { currentCandidate: current.treeSha },
        summaries,
        productRealized: binding.productRealizedPrerequisites
      });
      if (!("result" in processed)) return processed;
      await writeOwned2(persistedResultPath(await deliveryDir(deliveryId), processed.digest), processed.bytes);
      const stage = await appendEntry(guarded.store, deliveryId, "stage.result.recorded", {
        stageId,
        workflowGraphSha256: workspace.workflowGraphSha256,
        resultDigest: processed.digest
      });
      if (!stage.ok) return stage;
      if (processed.result.status !== "succeeded") {
        await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
          code: `workflow.stage-${processed.result.status}`,
          summary: (processed.result.nextStep ?? `the ${stageId} stage reported ${processed.result.status}`).slice(0, 1900)
        });
        const blocked4 = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: guarded.state, to: "blocked" });
        if (!blocked4.ok) return blocked4;
        return { ok: true, state: "blocked" };
      }
      const to = stageId === "plan" ? "implementing" : "admitting";
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: guarded.state, to });
      if (!transitioned.ok) return transitioned;
      return { ok: true, state: to };
    },
    async checkpointCandidate({ deliveryId, resultBytes, fence }) {
      const guarded = await guard(deliveryId, { requireState: ["implementing", "remediating"], verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const porcelain = await git(workspace.worktreeDir, "status", "--porcelain");
      if (porcelain.code !== 0 || porcelain.out !== "") {
        return refuse3(
          "candidate_uncommitted",
          "The worktree carries uncommitted work; the host commits through its native git tooling before a checkpoint.",
          "Commit the mutation in the worktree, then checkpoint."
        );
      }
      const treeSha2 = (await git(workspace.worktreeDir, "rev-parse", "HEAD^{tree}")).out;
      const branchRefValue = (await git(workspace.worktreeDir, "rev-parse", `refs/heads/${workspace.branchRef}`)).out;
      const previous = currentCandidateOf(guarded.views);
      const loaded = await loadGraph(guarded.generationRoot);
      if (!("graph" in loaded)) return loaded;
      const summaries = await retainedSummaries(deliveryId, guarded.views);
      const processed = processStageResult({
        resultBytes,
        graph: loaded.graph,
        graphSha256: loaded.graphSha256,
        stageId: "implement",
        deliveryId,
        ...previous === void 0 ? {} : { currentCandidate: previous.treeSha },
        producedCandidate: treeSha2,
        summaries
      });
      if (!("result" in processed)) return processed;
      if (processed.result.status !== "succeeded") {
        return refuse3(
          "stage_result_rejected",
          "checkpointCandidate records a PRODUCED candidate; a non-success implement result checkpoints nothing.",
          "Checkpoint only a produced candidate; a blocked implementation is reported without a checkpoint."
        );
      }
      const recaptured = await appendEntry(guarded.store, deliveryId, "candidate.recaptured", { treeSha: treeSha2, branchRefValue });
      if (!recaptured.ok) return recaptured;
      if (previous === void 0 || previous.treeSha !== treeSha2) {
        for (const pending of waiverLedgerOf(guarded.views).pending) {
          await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
            code: "approval.proposal-voided",
            summary: `the candidate changed since criterion ${pending.criterionId} was proposed; the stale proposal is void and must be re-proposed against the new candidate`.slice(
              0,
              1900
            )
          });
        }
      }
      await writeOwned2(persistedResultPath(await deliveryDir(deliveryId), processed.digest), processed.bytes);
      const stage = await appendEntry(guarded.store, deliveryId, "stage.result.recorded", {
        stageId: "implement",
        workflowGraphSha256: workspace.workflowGraphSha256,
        resultDigest: processed.digest
      });
      if (!stage.ok) return stage;
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", {
        from: guarded.state,
        to: "validating"
      });
      if (!transitioned.ok) return transitioned;
      return { ok: true, state: "validating", treeSha: treeSha2 };
    },
    async runSensor({ deliveryId, fence }) {
      const guarded = await guard(deliveryId, { requireState: ["validating"], verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const trustedSensor = path20.join(await deliveryDir(deliveryId), "trusted-sensor.mjs");
      const run = await exec.run({ command: process.execPath, args: [trustedSensor], cwd: workspace.worktreeDir });
      const outcome = run.code === 0 ? "passed" : "failed";
      const treeSha2 = (await git(workspace.worktreeDir, "rev-parse", "HEAD^{tree}")).out;
      const summaryRaw = `${run.stdout}
${run.stderr}`.trim().slice(0, 1900);
      const result2 = {
        spec: "sensor-result/1",
        capabilityId: policyBinding.sensor.capabilityId,
        outcome,
        summary: summaryRaw.length > 0 ? summaryRaw : `sensor ${outcome} with no output`,
        candidateTreeSha: treeSha2
      };
      const shape = validateSensorResult(result2);
      if (!shape.ok) {
        return refuse3("sensor_result_rejected", "The sensor result is outside its frozen shape.", "Inspect the trusted sensor's output.");
      }
      const recorded = await appendEntry(guarded.store, deliveryId, "operation.result.recorded", {
        capabilityId: result2.capabilityId,
        result: result2
      });
      if (!recorded.ok) return recorded;
      const to = outcome === "passed" ? "reviewing" : "remediating";
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: "validating", to });
      if (!transitioned.ok) return transitioned;
      return { ok: true, outcome, state: to };
    },
    async prepareProviderReviewHandoff({
      deliveryId,
      expectedFence,
      expectedWorkspaceId,
      nativeSessionId,
      nativeRunId,
      finalPassId,
      lensId,
      reviewWorkspaceDir,
      reviewInstructionsBytes,
      bindingCapability,
      invocationCapability
    }) {
      const guarded = await guard(deliveryId, {
        requireState: ["reviewing"],
        verifyWorkspace: true,
        invokingFence: expectedFence,
        fenceRequired: true
      });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      if (workspace.workspaceId !== expectedWorkspaceId || workspace.fence !== expectedFence) {
        return refuse3(
          "provider_review_scope_mismatch",
          "The expected workspace or fence is no longer the standing invocation.",
          "Discard the delayed callback and prepare from the current host binding."
        );
      }
      const authority = await readJson(providerAuthorityStatePath(deliveryId));
      const grantDigest2 = stageGrantDigest;
      const currentTrust = await readTrust();
      if (currentTrust === void 0 || authority === void 0 || authority.deliveryId !== deliveryId || authority.workspaceId !== workspace.workspaceId || authority.fence !== workspace.fence || authority.discoveryConfigurationDigest !== workspace.discoveryConfigurationDigest || authority.grantDigest !== grantDigest2 || authority.productTrustRevocationEpoch !== currentTrust.revocationEpoch) {
        return refuse3(
          "provider_binding_authority_unavailable",
          "The installation-owned provider-review authority is absent, stale, or disagrees with the admitted sandbox grant.",
          "Re-bind the workspace from the operator-owned host; repository state cannot recreate this authority."
        );
      }
      if (!capabilityShape(bindingCapability) || bindingCapability.id !== authority.bindingCapability.id || capabilityDigest({
        domain: "workspace",
        capability: bindingCapability,
        deliveryId,
        workspaceId: workspace.workspaceId,
        fence: workspace.fence,
        discoveryConfigurationDigest: workspace.discoveryConfigurationDigest,
        grantDigest: grantDigest2,
        productTrustRevocationEpoch: currentTrust.revocationEpoch
      }) !== authority.bindingCapability.digest) {
        return refuse3(
          "provider_binding_capability_refused",
          "The caller cannot prove the operator-owned provider-review binding for this delivery and fence.",
          "Only the host that retained the root capability may prepare a native reviewer invocation."
        );
      }
      if (!capabilityShape(invocationCapability)) {
        return refuse3(
          "provider_invocation_capability_invalid",
          "The native invocation capability is missing or malformed.",
          "Have the operator-owned host create a fresh high-entropy capability for this one reviewer invocation."
        );
      }
      if (!/^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(nativeSessionId)) {
        return refuse3("provider_session_invalid", "The expected native session identity is empty or unsafe.", "Use the exact host-native session identifier.");
      }
      if (reviewInstructionsBytes.length === 0) {
        return refuse3("provider_context_invalid", "The exact reviewer prompt/context bytes are empty.", "Bind the exact bytes the host will submit to the native reviewer.");
      }
      const current = currentCandidateOf(guarded.views);
      if (current === void 0) return refuse3("no_candidate", "No candidate is checkpointed.", "Checkpoint a candidate first.");
      const providerRegistration = config.providers[0];
      if (providerRegistration === void 0) {
        return refuse3("no_provider", "The repository gate registers no provider.", "Register the review provider in the harness config.");
      }
      const artifacts = createArtifactsPort();
      const allocation = await artifacts.allocateRunRoot({ providerId: providerRegistration.id, runId: nativeRunId });
      if (!allocation.ok) {
        return refuse3(
          "provider_run_invalid",
          `The native run identity cannot name an evidence run root: ${allocation.reason}.`,
          "Use the native host's safe run identifier without rewriting it into a path."
        );
      }
      if (finalPassId.length === 0 || !/^[A-Za-z0-9][A-Za-z0-9._:-]*$/.test(finalPassId)) {
        return refuse3("provider_pass_invalid", "The native final-pass identity is empty or unsafe.", "Use the native host's final-pass identifier.");
      }
      let mutableRoot;
      let reviewRoot;
      try {
        [mutableRoot, reviewRoot] = await Promise.all([realpath5(workspace.worktreeDir), realpath5(reviewWorkspaceDir)]);
      } catch {
        return refuse3("provider_review_workspace_invalid", "The host-created review snapshot is absent or unresolved.", "Create a distinct linked review snapshot before preparing the handoff.");
      }
      if (reviewRoot === mutableRoot || reviewRoot.startsWith(`${mutableRoot}${path20.sep}`) || mutableRoot.startsWith(`${reviewRoot}${path20.sep}`)) {
        return refuse3("provider_review_workspace_invalid", "The review snapshot overlaps the mutable delivery worktree.", "Have the trusted operator-owned host create a distinct snapshot outside every model/reviewer writable root.");
      }
      const commonReview = await git(reviewRoot, "rev-parse", "--path-format=absolute", "--git-common-dir");
      const commonMutable = await git(mutableRoot, "rev-parse", "--path-format=absolute", "--git-common-dir");
      if (commonReview.code !== 0 || commonReview.out !== commonMutable.out) {
        return refuse3("provider_review_workspace_invalid", "The review snapshot is not a linked workspace of the bound repository.", "Create it from the bound repository's common Git directory.");
      }
      const mutableCapture = await captureFor(mutableRoot, config, candidateRunner, storageGitRunner);
      if (!mutableCapture.ok) return mutableCapture.failure;
      const capture = await captureFor(reviewRoot, config, candidateRunner, storageGitRunner);
      if (!capture.ok) return capture.failure;
      if (mutableCapture.candidate.treeSha !== current.treeSha || capture.candidate.treeSha !== current.treeSha) {
        return refuse3("candidate_moved", "The worktree moved before the native review handoff.", "Re-checkpoint the candidate, then prepare the review handoff again.");
      }
      const productTrustRevocationEpoch = currentTrust.revocationEpoch;
      const lens = guarded.meta.policy.reviewLenses.find((entry3) => entry3.lensId === lensId);
      if (lens === void 0) {
        return refuse3("provider_lens_unselected", `Review lens ${lensId} is not selected by policy.`, "Prepare exactly one policy-selected reviewer invocation.");
      }
      const charterPath = path20.join(await deliveryDir(deliveryId), "personas", `${lens.personaId}.md`);
      let charterBytes;
      try {
        charterBytes = await readFile13(charterPath, "utf8");
      } catch {
        return refuse3("reviewer_charter_unavailable", `The trusted pre-run copy of reviewer charter ${lens.personaId} is missing.`, "Re-prepare the delivery from the trusted base.");
      }
      if (sha256Hex(charterBytes) !== lens.personaDigest) {
        return refuse3("reviewer_charter_unavailable", `The trusted reviewer charter ${lens.personaId} no longer matches policy.`, "Quarantine and re-prepare the delivery.");
      }
      const candidate2 = {
        vcs: capture.candidate.vcs,
        treeSha: capture.candidate.treeSha,
        headSha: capture.candidate.headSha,
        deliverable: capture.candidate.deliverable,
        base: capture.candidate.base,
        workspaceId: capture.candidate.workspaceId
      };
      const sensorEvidence = sensorResultsOf(guarded.views).filter((result2) => result2.candidateTreeSha === current.treeSha);
      const handoff = createProviderReviewHandoff({
        handoffId: `handoff-${hex(8)}`,
        deliveryId,
        provider: {
          id: providerRegistration.id,
          version: input.hostVersion,
          runId: nativeRunId,
          finalPassId
        },
        nativeSessionId,
        workspaceId: workspace.workspaceId,
        fence: guarded.lastFence,
        productTrustRevocationEpoch,
        candidate: candidate2,
        reviewInstructionsBytes,
        contractBytes: `${JSON.stringify(guarded.meta.contract, null, 2)}
`,
        sensorEvidenceBytes: `${JSON.stringify(sensorEvidence, null, 2)}
`,
        reviewer: {
          attemptId: `attempt-${hex(8)}`,
          lensId: lens.lensId,
          personaId: lens.personaId,
          personaDigest: lens.personaDigest,
          personaBytes: charterBytes
        }
      });
      const handoffDir = path20.join(await deliveryDir(deliveryId), "binding", "provider-review-handoffs");
      const handoffPath = path20.join(handoffDir, `${handoff.handoffId}.json`);
      const invocationCapabilityBinding = {
        id: invocationCapability.id,
        digest: capabilityDigest({
          domain: "review-invocation",
          capability: invocationCapability,
          deliveryId,
          workspaceId: workspace.workspaceId,
          fence: workspace.fence,
          handoffId: handoff.handoffId,
          nativeSessionId,
          nativeRunId,
          promptContextDigest: handoff.promptContextDigest,
          productTrustRevocationEpoch,
          reviewWorkspaceId: handoff.candidate.workspaceId
        })
      };
      await artifacts.writeTextFile(handoffPath, `${JSON.stringify(handoff, null, 2)}
`, { mode: OWNER_FILE7 });
      await writeOwned2(
        providerHandoffAuthorityPath(deliveryId, handoff.handoffId),
        `${JSON.stringify({ handoff, invocationCapability: invocationCapabilityBinding, reviewWorkspaceDir: reviewRoot }, null, 2)}
`
      );
      return { ok: true, handoff, handoffPath };
    },
    async ingestProviderReviewResult({ deliveryId, handoffId, resultBytes, fence, invocationCapability }) {
      const guarded = await guard(deliveryId, {
        requireState: ["reviewing"],
        verifyWorkspace: true,
        invokingFence: fence,
        fenceRequired: true
      });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const stored = await readJson(providerHandoffAuthorityPath(deliveryId, handoffId));
      if (stored === void 0) {
        return refuse3("provider_handoff_missing", `Provider result ${handoffId} has no binding-owned handoff.`, "Prepare the native reviewer invocation first.");
      }
      const handoff = stored.handoff;
      const currentTrust = await readTrust();
      const trustEpochFailure = () => refuse3(
        "provider_trust_epoch_mismatch",
        "The product trust revocation epoch advanced after this provider binding was prepared.",
        "Discard this callback. Use the existing operator-authorized takeover into a fresh host-created workspace and prepare review again, or cancel this delivery and start a replacement."
      );
      if (!capabilityShape(invocationCapability) || invocationCapability.id !== stored.invocationCapability.id || capabilityDigest({
        domain: "review-invocation",
        capability: invocationCapability,
        deliveryId,
        workspaceId: handoff.workspaceId,
        fence: handoff.fence,
        handoffId,
        nativeSessionId: handoff.nativeSessionId,
        nativeRunId: handoff.provider.runId,
        promptContextDigest: handoff.promptContextDigest,
        productTrustRevocationEpoch: handoff.productTrustRevocationEpoch,
        reviewWorkspaceId: handoff.candidate.workspaceId
      }) !== stored.invocationCapability.digest) {
        return refuse3(
          "provider_invocation_capability_refused",
          "The callback cannot prove the invocation-scoped capability bound before native review launch.",
          "Only the operator-owned host closure that launched this invocation may ingest its result."
        );
      }
      if (handoff.deliveryId !== deliveryId || handoff.workspaceId !== workspace.workspaceId || handoff.fence !== fence) {
        return refuse3(
          "provider_review_scope_mismatch",
          "The native callback belongs to a superseded delivery, workspace, or fence.",
          "Discard the delayed callback and prepare a new invocation from the standing workspace."
        );
      }
      if (currentTrust === void 0 || currentTrust.revocationEpoch !== handoff.productTrustRevocationEpoch) {
        return trustEpochFailure();
      }
      const parsed = parseProviderReviewResult(resultBytes);
      if (!parsed.ok) {
        await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
          code: "review.provider-result-invalid",
          summary: parsed.message
        });
        return refuse3(parsed.code, parsed.message, "Have the qualified host binding emit the complete provider-review-result/1 envelope.");
      }
      const result2 = parsed.result;
      if (result2.handoffId !== handoffId) {
        return refuse3("provider_result_binding_mismatch", "The result names a different handoff.", "Submit the result to its exact invocation handoff.");
      }
      const artifacts = createArtifactsPort();
      const refuseResult = async (code, summary, remediation) => {
        await appendEntry(guarded.store, deliveryId, "blocker.recorded", { code: `review.${code.replaceAll("_", "-")}`, summary });
        return refuse3(code, summary, remediation);
      };
      const { nativeEnvelopeBytes: _nativeEnvelopeBytes, nativeEnvelopeDigest: _nativeEnvelopeDigest, terminalState: _terminal, verdict: _verdict, findings: _findings, ...echoedResult } = result2;
      const echoedHandoff = { ...echoedResult, spec: handoff.spec };
      if (digestCanonical(echoedHandoff) !== digestCanonical(handoff)) {
        return refuseResult(
          "provider_result_binding_mismatch",
          "The native result does not repeat its binding-owned provider, session, scope, candidate, persona, and context identities exactly.",
          "Discard the mismatched result and complete a fresh review from the standing handoff."
        );
      }
      const normalizedResultBytes = `${JSON.stringify(result2, null, 2)}
`;
      const artifactDigest = sha256Hex(normalizedResultBytes);
      const providerRunKey = providerRunKeyOf(result2);
      const runSuspendedFailure = () => refuse3(
        "provider_result_run_suspended",
        `Provider run ${result2.provider.runId}/${result2.provider.finalPassId} is suspended by a conflicting replay.`,
        "Complete a coherent fresh run under new native run and final-pass identities."
      );
      const ensureProviderRunSuspended = async () => {
        for (let attempt = 0; attempt < 4; attempt += 1) {
          const observed2 = await guarded.store.read();
          if (!observed2.ok) {
            return refuse3("journal_unreadable", "The delivery journal is unreadable while suspending a conflicted provider run.", "Inspect the durable journal file.");
          }
          if (suspendedProviderRunKeysOf(viewsOf(observed2.entries)).has(providerRunKey)) return { ok: true };
          const appended = await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
            code: "review.result-replay-conflict",
            summary: `handoff ${result2.handoffId} was replayed with different provider-result bytes`,
            providerRunKey
          });
          if (!appended.ok) continue;
        }
        const observed = await guarded.store.read();
        if (observed.ok && suspendedProviderRunKeysOf(viewsOf(observed.entries)).has(providerRunKey)) return { ok: true };
        return refuse3(
          "journal_rejected",
          `The conflict marker for provider run ${result2.provider.runId}/${result2.provider.finalPassId} could not be made durable.`,
          "Reload the standing delivery journal; no result from this conflicted tuple may be accepted."
        );
      };
      const replayAgainst = async (views) => {
        if (suspendedProviderRunKeysOf(views).has(providerRunKey)) return runSuspendedFailure();
        const existingAttempt = recordedProviderAttemptsOf(views).find(
          (candidate2) => candidate2.attemptId === result2.reviewer.attemptId
        );
        if (existingAttempt === void 0) return void 0;
        const conflict2 = existingAttempt.lensId !== result2.reviewer.lensId || existingAttempt.contextDigest !== result2.reviewer.contextDigest || existingAttempt.personaDigest !== result2.reviewer.personaDigest || existingAttempt.artifactDigest !== artifactDigest;
        if (conflict2) {
          const suspended = await ensureProviderRunSuspended();
          if (!suspended.ok) return suspended;
          return refuse3(
            "provider_result_replay_conflict",
            `Handoff ${result2.handoffId} already has a different immutable result.`,
            "Treat the native run as conflicted and complete a fresh run under a new handoff."
          );
        }
        const accepted = await acceptedProviderResultsOf(deliveryId, views);
        if (!accepted.ok) return accepted;
        const existing = accepted.results.find((candidate2) => candidate2.reviewer.attemptId === result2.reviewer.attemptId);
        if (existing === void 0) {
          return refuse3(
            "provider_result_artifact_unavailable",
            `Accepted provider result ${result2.reviewer.attemptId} cannot be reconstructed from its journaled content address.`,
            "Restore the exact content-addressed result bytes; never append a replacement acceptance."
          );
        }
        return { ok: true, replay: "identical", disposition: existing.verdict };
      };
      const replay = await replayAgainst(guarded.views);
      if (replay !== void 0) return replay;
      const current = currentCandidateOf(guarded.views);
      if (current === void 0) return refuse3("no_candidate", "No candidate is checkpointed.", "Checkpoint a candidate first.");
      const captures = await captureProviderPair(workspace.worktreeDir, stored.reviewWorkspaceDir);
      if (!captures.ok) {
        return refuseResult("provider_result_review_workspace_unavailable", "The mutable candidate or host-created review snapshot is missing or invalid at ingestion.", "The trusted operator-owned host must retain the exact reviewer-read-only snapshot until its native result is ingested.");
      }
      const mutableCapture = { candidate: captures.mutable };
      const capture = { candidate: captures.review };
      const currentCandidate = {
        vcs: capture.candidate.vcs,
        treeSha: capture.candidate.treeSha,
        headSha: capture.candidate.headSha,
        deliverable: capture.candidate.deliverable,
        base: capture.candidate.base,
        workspaceId: capture.candidate.workspaceId
      };
      if (current.treeSha !== mutableCapture.candidate.treeSha || current.treeSha !== capture.candidate.treeSha || digestCanonical(currentCandidate) !== digestCanonical(result2.candidate)) {
        return refuseResult(
          "provider_result_candidate_moved",
          "The candidate or deliverable identity changed after the native review handoff.",
          "Checkpoint the changed candidate and complete a fresh native review."
        );
      }
      if (result2.terminalState !== "completed") {
        return refuseResult(
          "provider_result_not_completed",
          `The native provider run ended ${result2.terminalState}; a partial or failed run qualifies no attempt.`,
          "Complete a fresh native review run successfully."
        );
      }
      const coherenceCodes = result2.findings.flatMap(reviewFindingCoherenceCodes);
      const verdictCoherent = result2.verdict === "approved" ? coherenceCodes.length === 0 : result2.findings.length > 0;
      if (!verdictCoherent) {
        return refuseResult(
          result2.verdict === "approved" ? "provider_result_not_review_green" : "provider_result_verdict_incoherent",
          result2.verdict === "approved" ? `The approved provider result contradicts review-green coherence: ${[...new Set(coherenceCodes)].join(", ")}.` : "The provider verdict, reviewer verdicts, and findings do not describe one complete terminal result.",
          "Complete a fresh native review whose structured conclusion is internally coherent."
        );
      }
      const allocation = await artifacts.allocateRunRoot({ providerId: result2.provider.id, runId: result2.provider.runId });
      if (!allocation.ok) {
        return refuseResult(
          "provider_run_invalid",
          `The provider run root is unavailable: ${allocation.reason}.`,
          "Complete a fresh run with a safe native run identity."
        );
      }
      const acceptanceTrust = await readTrust();
      if (acceptanceTrust === void 0 || acceptanceTrust.revocationEpoch !== handoff.productTrustRevocationEpoch) {
        return trustEpochFailure();
      }
      await writeOwned2(persistedResultPath(await deliveryDir(deliveryId), artifactDigest), normalizedResultBytes);
      const recorded = await guarded.store.append({
        spec: "journal-entry/1",
        journal: "delivery",
        subjectId: deliveryId,
        expectedRevision: guarded.expectedRevision,
        idempotencyKey: `provider-attempt-${result2.reviewer.attemptId}`,
        kind: "attempt.artifact.recorded",
        payload: {
          attemptId: result2.reviewer.attemptId,
          lensId: result2.reviewer.lensId,
          contextDigest: result2.reviewer.contextDigest,
          personaDigest: result2.reviewer.personaDigest,
          artifactDigest
        }
      });
      if (!recorded.ok) {
        const raced = await guarded.store.read();
        if (!raced.ok) return refuse3("journal_unreadable", "The delivery journal is unreadable after an acceptance race.", "Inspect the durable journal file.");
        const resolved = await replayAgainst(viewsOf(raced.entries));
        if (resolved !== void 0) return resolved;
        return refuse3(
          "journal_rejected",
          `The guarded attempt acceptance lost its journal CAS: ${recorded.rejections.map((rejection) => rejection.message).join("; ")}`,
          "Reload the standing delivery journal and retry only from its current checkpoint."
        );
      }
      await artifacts.writeTextFile(
        path20.join(allocation.runRoot.path, `provider-result-${result2.reviewer.attemptId}.json`),
        normalizedResultBytes,
        { mode: OWNER_FILE7 }
      ).catch(() => void 0);
      return { ok: true, replay: "recorded", disposition: result2.verdict };
    },
    async reduceReview({ deliveryId, fence }) {
      const guarded = await guard(deliveryId, { requireState: ["reviewing"], verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const current = currentCandidateOf(guarded.views);
      if (current === void 0) return refuse3("no_candidate", "No candidate is checkpointed.", "Checkpoint a candidate first.");
      const accepted = await attemptsOf(deliveryId, guarded.views);
      if (!accepted.ok) return accepted;
      const attempts = accepted.attempts.filter((attempt) => attempt.candidateTreeSha === current.treeSha);
      const floor = checkReviewFloor({
        attempts,
        lenses: guarded.meta.policy.reviewLenses.map((selected) => ({
          lensId: selected.lensId,
          category: selected.category,
          personaDigest: selected.personaDigest
        })),
        candidateTreeSha: current.treeSha
      });
      if (!floor.ok) {
        return refuse3(
          "review_floor_unmet",
          `The mandatory review floor is not met: ${floor.rejections.map((rejection) => rejection.message).join("; ")}`,
          "Complete both mandatory lenses as distinct attempts with independently constructed contexts."
        );
      }
      const acceptedResults = accepted.results.filter(
        (result2) => result2.candidate.treeSha === current.treeSha && attempts.some((attempt) => attempt.attemptId === result2.reviewer.attemptId)
      );
      const providerRuns = new Set(acceptedResults.map(
        (result2) => `${result2.provider.id}\0${result2.provider.version}\0${result2.provider.runId}\0${result2.provider.finalPassId}`
      ));
      const nativeSessions = new Set(acceptedResults.map((result2) => result2.nativeSessionId));
      if (providerRuns.size !== 1 || nativeSessions.size !== acceptedResults.length) {
        return refuse3(
          "provider_result_unqualified",
          "Mandatory reviewer approvals must be distinct native child sessions of one exact provider run and final pass.",
          "Complete each selected reviewer as a distinct child invocation inside one provider run and final pass."
        );
      }
      const loaded = await loadGraph(guarded.generationRoot);
      if (!("graph" in loaded)) return loaded;
      const summaries = await retainedSummaries(deliveryId, guarded.views);
      const dir = await deliveryDir(deliveryId);
      const repairLoop = summaries.get("review.reduce")?.outputKind === "review-round-changes-requested";
      const composeReviewResult = (stageId, outputKind, evidence, evidenceRefs) => JSON.stringify({
        schemaVersion: WORKFLOW_STAGE_RESULT_SPEC,
        release: RELEASE_IDENTITY,
        graphSha256: loaded.graphSha256,
        stageId,
        subjectRef: { schemaVersion: WORKFLOW_SUBJECT_REF_SPEC, opaque: deliveryId },
        candidateRef: { schemaVersion: WORKFLOW_CANDIDATE_REF_SPEC, opaque: current.treeSha },
        status: "succeeded",
        output: { kind: outputKind, evidenceRef: digestCanonical(evidence) },
        evidenceRefs,
        limitations: []
      });
      const acquisitionBytes = composeReviewResult(
        "review.acquire",
        "review-acquisition-envelope",
        attempts,
        attempts.map((attempt) => attempt.attemptId)
      );
      const processedAcquire = processStageResult({
        resultBytes: acquisitionBytes,
        graph: loaded.graph,
        graphSha256: loaded.graphSha256,
        stageId: "review.acquire",
        deliveryId,
        currentCandidate: current.treeSha,
        summaries,
        repairLoop
      });
      if (!("result" in processedAcquire)) return processedAcquire;
      await writeOwned2(persistedResultPath(dir, processedAcquire.digest), processedAcquire.bytes);
      const acquireStage = await appendEntry(guarded.store, deliveryId, "stage.result.recorded", {
        stageId: "review.acquire",
        workflowGraphSha256: workspace.workflowGraphSha256,
        resultDigest: processedAcquire.digest
      });
      if (!acquireStage.ok) return acquireStage;
      const qualified = qualifyReviewAttempts(attempts, current.treeSha).qualified;
      const anyFindings = qualified.some((attempt) => attempt.verdict === "findings");
      const roundKind = anyFindings ? "review-round-changes-requested" : "review-round-aligned";
      const reductionBytes = composeReviewResult("review.reduce", roundKind, qualified, []);
      const reduceSummaries = new Map(summaries);
      reduceSummaries.set("review.acquire", { status: "succeeded", outputKind: "review-acquisition-envelope" });
      const processedReduce = processStageResult({
        resultBytes: reductionBytes,
        graph: loaded.graph,
        graphSha256: loaded.graphSha256,
        stageId: "review.reduce",
        deliveryId,
        currentCandidate: current.treeSha,
        summaries: reduceSummaries
      });
      if (!("result" in processedReduce)) return processedReduce;
      await writeOwned2(persistedResultPath(dir, processedReduce.digest), processedReduce.bytes);
      const reduceStage = await appendEntry(guarded.store, deliveryId, "stage.result.recorded", {
        stageId: "review.reduce",
        workflowGraphSha256: workspace.workflowGraphSha256,
        resultDigest: processedReduce.digest
      });
      if (!reduceStage.ok) return reduceStage;
      if (anyFindings) {
        let changesRequestedRounds = 1;
        for (const view of guarded.views) {
          if (view.kind !== "stage.result.recorded" || view.payload["stageId"] !== "review.reduce") continue;
          const persisted = await persistedResultOf(dir, view.payload["resultDigest"]);
          if (persisted === void 0 || persisted.outputKind === "review-round-changes-requested") changesRequestedRounds += 1;
        }
        if (changesRequestedRounds > REVIEW_ROUND_BOUND) {
          await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
            code: "review.loop-bound-reached",
            summary: `review round ${changesRequestedRounds} still requests changes; after ${REVIEW_ROUND_BOUND} findings-driven rounds the loop records a bounded blocker instead of repeating`
          });
          const blocked4 = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: "reviewing", to: "blocked" });
          if (!blocked4.ok) return blocked4;
          return { ok: true, state: "blocked" };
        }
      }
      const to = anyFindings ? "remediating" : "compounding";
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: "reviewing", to });
      if (!transitioned.ok) return transitioned;
      return { ok: true, state: to };
    },
    async admit({ deliveryId, recordedAtInstant, env, fence }) {
      const guarded = await guard(deliveryId, { requireState: ["admitting"], verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const current = currentCandidateOf(guarded.views);
      if (current === void 0) return refuse3("no_candidate", "No candidate is checkpointed.", "Checkpoint a candidate first.");
      const accepted = await attemptsOf(deliveryId, guarded.views);
      if (!accepted.ok) return accepted;
      const attempts = accepted.attempts.filter((attempt) => attempt.candidateTreeSha === current.treeSha);
      const floor = checkReviewFloor({
        attempts,
        lenses: guarded.meta.policy.reviewLenses.map((selected) => ({
          lensId: selected.lensId,
          category: selected.category,
          personaDigest: selected.personaDigest
        })),
        candidateTreeSha: current.treeSha
      });
      if (!floor.ok) {
        await recordBlockerAndTransition(
          guarded.store,
          deliveryId,
          guarded.state,
          "review.floor-unmet",
          floor.rejections.map((rejection) => rejection.message).join("; ").slice(0, 1900),
          "blocked"
        );
        return refuse3("review_floor_unmet", "The mandatory review floor is not met at admission.", "Complete both mandatory lenses on the exact candidate.");
      }
      const rootDir = workspace.worktreeDir;
      const capture = await captureFor(rootDir, config, candidateRunner, storageGitRunner);
      if (!capture.ok) return capture.failure;
      const captured = capture.candidate;
      if (captured.treeSha !== current.treeSha) {
        return refuse3("candidate_moved", "The worktree moved after its last checkpoint.", "Re-checkpoint the candidate, then admit.");
      }
      const outcome = composeOutcomeVerification({
        contract: guarded.meta.contract,
        candidate: { treeSha: current.treeSha, deliverableDigest: captured.deliverable.digest },
        sensorResults: sensorResultsOf(guarded.views),
        attempts,
        // A waiver is candidate-bound evidence: one approved against an
        // earlier candidate says nothing about this one.
        waivedCriteria: waiverLedgerOf(guarded.views).consumed.filter(
          (waiver) => waiver.candidateTreeSha === current.treeSha
        )
      });
      const unresolved2 = outcome.criteria.filter((criterion) => criterion.disposition === "blocked");
      if (unresolved2.length > 0) {
        await recordBlockerAndTransition(
          guarded.store,
          deliveryId,
          guarded.state,
          "outcome.criterion-unverified",
          `criterion mapping failed: ${unresolved2.map((criterion) => `${criterion.criterionId} (${criterion.evidence.reference})`).join("; ")}`.slice(0, 1900),
          "blocked"
        );
        return refuse3(
          "criterion_unverified",
          "An acceptance criterion carries no passing exact-candidate evidence; a green-but-unrelated change fails criterion mapping.",
          "Satisfy the criterion's sensor on the exact candidate, then re-validate."
        );
      }
      const positive = checkPositiveCriterion(outcome.criteria);
      if (!positive.ok) {
        await recordBlockerAndTransition(
          guarded.store,
          deliveryId,
          guarded.state,
          "outcome.blanket-waiver",
          positive.blockers.map((blocker) => blocker.message).join("; ").slice(0, 1900),
          "blocked"
        );
        return refuse3(
          "blanket_waiver",
          "No acceptance criterion passed; a blanket waiver cannot produce delivery success.",
          "Rescope or cancel the delivery; at least one positive criterion must actually pass."
        );
      }
      const storage = await resolveRecordStorage(rootDir, { storageNamespace: config.storageNamespace, runGit: storageGitRunner });
      await publishPreparationReceipt(rootDir, { config, candidate: captured }, { storageNamespace: config.storageNamespace, runGit: storageGitRunner });
      const artifacts = createArtifactsPort();
      const qualified = qualifyReviewAttempts(attempts, current.treeSha).qualified;
      const qualifiedIds = new Set(qualified.map((attempt) => attempt.attemptId));
      const selectedLenses = [...guarded.meta.policy.reviewLenses.map((lens) => lens.lensId)].sort();
      const acceptedResults = accepted.results.filter(
        (result2) => result2.terminalState === "completed" && result2.verdict === "approved" && result2.candidate.treeSha === current.treeSha && qualifiedIds.has(result2.reviewer.attemptId)
      );
      const providerResults = selectedLenses.map((lensId) => {
        const matches = acceptedResults.filter((result2) => result2.reviewer.lensId === lensId);
        return matches.length === 1 ? matches[0] : void 0;
      });
      const providerRuns = new Set(acceptedResults.map(
        (result2) => `${result2.provider.id}\0${result2.provider.version}\0${result2.provider.runId}\0${result2.provider.finalPassId}`
      ));
      const nativeSessions = new Set(acceptedResults.map((result2) => result2.nativeSessionId));
      if (providerResults.some((result2) => result2 === void 0) || acceptedResults.length !== selectedLenses.length || providerRuns.size !== 1 || nativeSessions.size !== selectedLenses.length) {
        await recordBlockerAndTransition(
          guarded.store,
          deliveryId,
          guarded.state,
          "review.provider-result-unqualified",
          "each mandatory lens requires one distinct native child invocation inside the same binding-owned provider run and final pass on the exact candidate",
          "blocked"
        );
        return refuse3(
          "provider_result_unqualified",
          "Admission has no coherent one-run native invocation receipt set for every mandatory lens.",
          "Complete one distinct native child invocation per selected reviewer within one provider run and final pass, then re-enter admission."
        );
      }
      const completeProviderResults = providerResults;
      const providerResult = completeProviderResults[0];
      if (providerResult === void 0) throw new Error("unreachable provider result selection");
      const provider2 = providerResult.provider;
      const allocation = await artifacts.allocateRunRoot({ providerId: provider2.id, runId: provider2.runId });
      if (!allocation.ok) {
        return refuse3("run_root_refused", `The artifacts port refused a run root: ${allocation.reason}`, "Inspect the artifacts port.");
      }
      const runRoot = allocation.runRoot.path;
      const candidateForManifest = {
        vcs: captured.vcs,
        treeSha: captured.treeSha,
        headSha: captured.headSha,
        deliverable: { digest: captured.deliverable.digest, identity: captured.deliverable.identity },
        base: { ref: captured.base.ref, tipSha: captured.base.tipSha, mergeBaseSha: captured.base.mergeBaseSha },
        workspaceId: captured.workspaceId
      };
      const manifestArtifacts = [];
      await mkdir11(path20.join(runRoot, "provider-results"), { recursive: true });
      await mkdir11(path20.join(runRoot, "reviewers"), { recursive: true });
      for (const result2 of completeProviderResults) {
        const reviewer2 = result2.reviewer;
        const attempt = qualified.find((candidate2) => candidate2.attemptId === reviewer2.attemptId);
        if (attempt === void 0) {
          return refuse3("provider_result_unqualified", `Attempt ${reviewer2.attemptId} no longer qualifies.`, "Complete a fresh native provider run.");
        }
        const normalizedProviderResultBytes = `${JSON.stringify(result2, null, 2)}
`;
        const providerResultRelative = `provider-results/${reviewer2.lensId}.json`;
        await writeFile9(path20.join(runRoot, providerResultRelative), normalizedProviderResultBytes, "utf8");
        manifestArtifacts.push({ path: providerResultRelative, sha256: sha256Hex(normalizedProviderResultBytes), role: "provider-review-result" });
        const approval = `${JSON.stringify({
          schemaVersion: 1,
          reviewerId: attempt.lensId,
          result: attempt.verdict === "approved" ? "approved" : "changes-requested",
          // The frozen delivery-evidence schema has one envelope provider.
          // Per-review native run identities remain exact in the adjacent
          // provider-result artifacts and in the journaled attempt digests.
          provider: { id: provider2.id, runId: provider2.runId, finalPassId: provider2.finalPassId },
          workspaceId: captured.workspaceId,
          candidate: candidateForManifest
        }, null, 2)}
`;
        const relative = `reviewers/${attempt.lensId}.json`;
        await writeFile9(path20.join(runRoot, relative), approval, "utf8");
        manifestArtifacts.push({ path: relative, sha256: sha256Hex(approval), role: "reviewer-approval" });
      }
      const manifest = {
        spec: "delivery-evidence/1",
        provider: provider2,
        candidate: candidateForManifest,
        repository: null,
        runHistory: [{ preparedTreeSha: captured.treeSha, evaluatedInPassId: provider2.finalPassId }],
        artifacts: manifestArtifacts,
        attestation: { level: "self", signatures: [] },
        recordedAt: recordedAtInstant,
        claims: [
          {
            obligation: "review.green",
            payloadSpec: "review.green/1",
            payload: {
              verdict: "green",
              finalized: true,
              editedAfterFinalPass: false,
              reviewers: {
                selected: selectedLenses,
                completed: completeProviderResults.map((result2) => result2.reviewer.lensId).sort(),
                failed: [],
                timedOut: []
              },
              findings: completeProviderResults.flatMap((result2) => result2.findings),
              telemetry: {
                iterationCount: 1,
                findingCounts: Object.fromEntries(
                  ["P0", "P1", "P2", "P3"].map((severity) => [
                    severity,
                    completeProviderResults.flatMap((result2) => result2.findings).filter((finding3) => finding3.severity === severity).length
                  ])
                ),
                deferredExpansionCount: completeProviderResults.flatMap((result2) => result2.findings).filter((finding3) => finding3.disposition === "deferred").length,
                deferredIssueIds: [
                  ...new Set(
                    completeProviderResults.flatMap((result2) => result2.findings).filter((finding3) => finding3.disposition === "deferred").map((finding3) => finding3.deferredIssueId).filter((issueId) => issueId !== void 0)
                  )
                ].sort()
              }
            }
          }
        ]
      };
      const manifestPath = path20.join(runRoot, "manifest.json");
      await writeFile9(manifestPath, `${JSON.stringify(manifest, null, 2)}
`, "utf8");
      const submission = await submitManifest(
        { rootDir, manifestPath, config },
        { captureCandidate: capture.captureCandidate, artifacts, storageNamespace: config.storageNamespace, runGit: storageGitRunner }
      );
      if (submission.status !== "accepted") {
        await recordBlockerAndTransition(
          guarded.store,
          deliveryId,
          guarded.state,
          "evidence.rejected",
          submission.blockers.map((blocker) => blocker.summary).join("; ").slice(0, 1900),
          "blocked"
        );
        return refuseWith(submission.blockers);
      }
      const admission = await runAdmission(
        { rootDir, config, context: classifyExecutionContext({ config, env, stdinIsTTY: false, stdoutIsTTY: false }) },
        {
          captureCandidate: capture.captureCandidate,
          projectActivation: (candidate2) => evaluateCandidateActivation({ rootDir, candidate: candidate2, config, run: candidateRunner }),
          storageNamespace: config.storageNamespace,
          runGit: storageGitRunner
        }
      );
      if (!admission.admitted) {
        await recordBlockerAndTransition(
          guarded.store,
          deliveryId,
          guarded.state,
          "admission.refused",
          admission.blockers.map((blocker) => blocker.summary).join("; ").slice(0, 1900),
          "blocked"
        );
        return refuseWith(admission.blockers);
      }
      const record2 = submission.records[0];
      const referenced = await appendEntry(guarded.store, deliveryId, "evidence.reference.recorded", {
        recordId: record2 === void 0 ? sha256Hex("") : record2.recordId,
        manifestDigest: submission.manifestDigest
      });
      if (!referenced.ok) return referenced;
      await writeOwned2(path20.join(await deliveryDir(deliveryId), "outcome.json"), `${JSON.stringify(outcome)}
`);
      const completedObligations = [
        .../* @__PURE__ */ new Set([
          "outcome.verification",
          ...(admission.decision?.resolutions ?? []).filter((resolution) => resolution.kind !== "blocked").map((resolution) => resolution.obligationId)
        ])
      ].sort();
      await writeOwned2(
        path20.join(await deliveryDir(deliveryId), "admission.json"),
        `${JSON.stringify({ completedObligations })}
`
      );
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: "admitting", to: "recording" });
      if (!transitioned.ok) return transitioned;
      return { ok: true, state: "recording" };
    },
    async prepareTrackedRecord({ deliveryId, env, fence }) {
      const guarded = await guard(deliveryId, { requireState: ["recording"], verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const rootDir = workspace.worktreeDir;
      const capture = await captureFor(rootDir, config, candidateRunner, storageGitRunner);
      if (!capture.ok) return capture.failure;
      const admission = await runAdmission(
        { rootDir, config, context: classifyExecutionContext({ config, env, stdinIsTTY: false, stdoutIsTTY: false }) },
        {
          captureCandidate: capture.captureCandidate,
          projectActivation: (candidate2) => evaluateCandidateActivation({ rootDir, candidate: candidate2, config, run: candidateRunner }),
          storageNamespace: config.storageNamespace,
          runGit: storageGitRunner
        }
      );
      if (!admission.admitted || admission.decision === void 0) {
        return refuseWith(admission.blockers);
      }
      const evidenceRecords = [];
      for (const obligation of config.obligations) {
        const discovery = await discoverRecords(rootDir, {
          gateId: config.gateId,
          obligationId: obligation.id,
          storageNamespace: config.storageNamespace,
          runGit: storageGitRunner
        });
        evidenceRecords.push(...discovery.records);
      }
      const context = await capturePortableEvidenceContext(config, repositoryEvidenceReader(rootDir, createArtifactsPort()), await computePreparationFingerprint(rootDir, config));
      const built = buildDeliveryRecord({ config, decision: admission.decision, evidenceRecords, context });
      if (!built.ok) return refuseWith(built.blockers);
      const relativePath = deliveryRecordPathFor(config, admission.decision.candidate.deliverable.digest);
      await mkdir11(path20.dirname(path20.join(rootDir, relativePath)), { recursive: true });
      await writeFile9(path20.join(rootDir, relativePath), deliveryRecordBytes(built.record), "utf8");
      return { ok: true, relativePath };
    },
    async confirmTrackedRecord({ deliveryId, fence }) {
      const guarded = await guard(deliveryId, { requireState: ["recording"], verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const rootDir = workspace.worktreeDir;
      const porcelain = await git(rootDir, "status", "--porcelain");
      if (porcelain.code !== 0 || porcelain.out !== "") {
        return refuse3("record_uncommitted", "The tracked record is not checkpoint-committed.", "Commit the record through the host's native git tooling.");
      }
      const capture = await captureFor(rootDir, config, candidateRunner, storageGitRunner);
      if (!capture.ok) return capture.failure;
      const captured = capture.candidate;
      const returnToValidation = async (code, summary) => {
        const recordedBlocker = await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
          code,
          summary: summary.slice(0, 1900)
        });
        if (!recordedBlocker.ok) return recordedBlocker;
        const movedTree = (await git(rootDir, "rev-parse", "HEAD^{tree}")).out;
        const movedBranch = (await git(rootDir, "rev-parse", `refs/heads/${workspace.branchRef}`)).out;
        const recaptured2 = await appendEntry(guarded.store, deliveryId, "candidate.recaptured", {
          treeSha: movedTree,
          branchRefValue: movedBranch
        });
        if (!recaptured2.ok) return recaptured2;
        return appendEntry(guarded.store, deliveryId, "transition.committed", { from: "recording", to: "validating" });
      };
      const candidateTreePaths = await candidateTreeEntries(rootDir) ?? [];
      const owned = candidateTreePaths.filter(isDeliveryOwnedTreeEntry).map((entry3) => entry3.path);
      if (owned.length > 0) {
        const returned = await returnToValidation(
          "record.protected-authority-path",
          `the candidate tree carries delivery-owned paths: ${owned.join(", ")}`
        );
        if (!returned.ok) return returned;
        return refuse3(
          "record_protected_authority_path",
          `The candidate tree carries delivery-owned paths (${owned.join(", ")}); the delivery returns to validation.`,
          "Remove the projection or discovery-configuration path from the candidate tree; delivery-owned paths are never committed."
        );
      }
      const admitted = currentCandidateOf(guarded.views);
      const recordTree = (await git(rootDir, "rev-parse", "HEAD^{tree}")).out;
      if (admitted !== void 0 && admitted.treeSha !== recordTree) {
        const changed = await git(rootDir, "diff", "--name-only", "-z", admitted.treeSha, recordTree);
        const nonNeutral = changed.out.split("\0").filter((entry3) => entry3.length > 0).filter((repoPath) => !(isReviewNeutralPath(config, repoPath) && isRecordNeutralPath(config, repoPath)));
        if (nonNeutral.length > 0) {
          const returned = await returnToValidation(
            "record.non-neutral-change",
            `the recording commit changed non-neutral paths: ${nonNeutral.join(", ")}`
          );
          if (!returned.ok) return returned;
          return refuse3(
            "record_non_neutral",
            `The recording commit changed non-neutral paths (${nonNeutral.join(", ")}); the delivery returns to validation and a fresh final review.`,
            "Stage only review-neutral and record-neutral artifacts in the recording commit."
          );
        }
      }
      const relativePath = deliveryRecordPathFor(config, captured.deliverable.digest);
      let recordText;
      try {
        recordText = await readFile13(path20.join(rootDir, relativePath), "utf8");
      } catch {
        return refuse3("record_missing", `No tracked record at ${relativePath}.`, "Prepare and commit the tracked record first.");
      }
      const parsed = parseDeliveryRecord(recordText);
      if (!parsed.ok) return refuseWith(parsed.blockers);
      const check = verifyDeliveryRecord(
        config,
        parsed.record,
        { deliverableDigest: captured.deliverable.digest, identityToken: captured.deliverable.identity },
        { ref: captured.base.ref, tipSha: captured.base.tipSha, mergeBaseSha: captured.base.mergeBaseSha },
        {
          candidateTreePaths,
          ...await capturePortableVerificationInputs(rootDir, config, captured, parsed.record, candidateRunner),
          executionContext: { kind: "agent", signal: "managed-delivery" }
        }
      );
      if (!check.ok) return refuseWith(check.blockers);
      const treeSha2 = (await git(rootDir, "rev-parse", "HEAD^{tree}")).out;
      const branchRefValue = (await git(rootDir, "rev-parse", `refs/heads/${workspace.branchRef}`)).out;
      const recaptured = await appendEntry(guarded.store, deliveryId, "candidate.recaptured", { treeSha: treeSha2, branchRefValue });
      if (!recaptured.ok) return recaptured;
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", {
        from: "recording",
        to: "ready",
        trackedRecord: { path: relativePath, sha256: sha256Hex(recordText) }
      });
      if (!transitioned.ok) return transitioned;
      return { ok: true, state: "ready" };
    },
    async completeFinishLine({ deliveryId, fence }) {
      const guarded = await guard(deliveryId, { requireState: ["ready"], verifyWorkspace: true, invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const workspace = guarded.workspace;
      if (workspace === void 0) return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      const dir = await deliveryDir(deliveryId);
      const outcome = await readJson(path20.join(dir, "outcome.json"));
      if (outcome === void 0) {
        return refuse3("outcome_missing", "No outcome verification is on file for this delivery.", "Admit the delivery first.");
      }
      const completed = await readJson(path20.join(dir, "admission.json"));
      if (completed === void 0 || !Array.isArray(completed.completedObligations)) {
        return refuse3("admission_missing", "No readable admission result is on file for this delivery.", "Admit the delivery first.");
      }
      const recordingTransition = [...guarded.views].reverse().find((view) => view.kind === "transition.committed" && view.payload["trackedRecord"] !== void 0);
      const trackedRecord = recordingTransition?.payload["trackedRecord"];
      const recordedCandidate = currentCandidateOf(guarded.views);
      if (trackedRecord === void 0 || recordedCandidate === void 0) {
        return refuse3("record_missing", "No tracked-record transition is journaled for this delivery.", "Record the delivery first.");
      }
      const rootDir = workspace.worktreeDir;
      const capture = await captureFor(rootDir, config, candidateRunner, storageGitRunner);
      if (!capture.ok) return capture.failure;
      const captured = capture.candidate;
      let externalVerification = "unavailable";
      let recordedBaseTipSha = captured.base.tipSha;
      const relativePath = deliveryRecordPathFor(config, captured.deliverable.digest);
      let recordText;
      try {
        recordText = await readFile13(path20.join(rootDir, relativePath), "utf8");
      } catch {
        recordText = void 0;
      }
      if (recordText !== void 0) {
        const parsed = parseDeliveryRecord(recordText);
        if (!parsed.ok) return refuseWith(parsed.blockers);
        recordedBaseTipSha = parsed.record.candidateBinding.baseTipSha;
        const candidateTreePaths = await candidateTreeEntries(rootDir);
        if (candidateTreePaths !== void 0) {
          const check = verifyDeliveryRecord(
            config,
            parsed.record,
            { deliverableDigest: captured.deliverable.digest, identityToken: captured.deliverable.identity },
            { ref: captured.base.ref, tipSha: captured.base.tipSha, mergeBaseSha: captured.base.mergeBaseSha },
            {
              candidateTreePaths,
              ...await capturePortableVerificationInputs(rootDir, config, captured, parsed.record, candidateRunner),
              executionContext: { kind: "agent", signal: "managed-delivery" }
            }
          );
          externalVerification = check.ok ? "passed" : "failed";
        }
      }
      const generation = await loadPinnedGeneration({
        installationPath: input.installation.installationPath,
        generationDigest: guarded.meta.generationDigest
      });
      const declaredProductTrustLabel = generation.ok ? String(generation.manifest["pin"]?.["productTrustLabel"] ?? "") : "";
      const decision = decideFinishLine({
        deliveryId,
        contract: guarded.meta.contract,
        policy: guarded.meta.policy,
        outcome,
        record: { treeSha: recordedCandidate.treeSha, baseTipSha: recordedBaseTipSha, digest: trackedRecord.sha256 },
        observed: { treeSha: captured.treeSha, baseTipSha: captured.base.tipSha },
        admission: { admitted: true, completedObligations: completed.completedObligations },
        externalVerification,
        declaredProductTrustLabel
      });
      if (decision.kind !== "completed") {
        const detail = decision.kind === "blocked" ? decision.refusals.map((refusal2) => refusal2.message).join("; ") : `the contract requests a ${guarded.meta.contract.requestedFinishLine} finish line, whose ${decision.action} action no bound adapter can invoke`;
        return refuse3(
          "finish_line_refused",
          `The merge-ready finish line was refused: ${detail}`.slice(0, 1900),
          "Resolve every criterion and obligation on the recorded candidate, then complete the finish line."
        );
      }
      const recorded = await appendEntry(guarded.store, deliveryId, "finish.line.recorded", { result: decision.result });
      if (!recorded.ok) return recorded;
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: "ready", to: "completed" });
      if (!transitioned.ok) return transitioned;
      return { ok: true, state: "completed", resultDigest: digestCanonical(decision.result) };
    },
    async sessionEnded({ deliveryId, fence }) {
      const guarded = await guard(deliveryId, { invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const appended = await appendEntry(guarded.store, deliveryId, "activity.observed", {
        activity: "paused",
        fence: guarded.lastFence
      });
      if (!appended.ok) return appended;
      return { ok: true };
    },
    async recordTerminationProvenance({ deliveryId, fence }) {
      const guarded = await guard(deliveryId, { invokingFence: fence, fenceRequired: true });
      if (!("store" in guarded)) return guarded;
      const descendantTeardown = await gradedDescendantTeardown({
        generationRoot: guarded.generationRoot,
        hostId: HOST_ID,
        hostVersion: input.hostVersion
      });
      const resumeEligibility = gradeResumeEligibility({ descendantTeardown });
      const existing = lastOf2(guarded.views, "termination.provenance.recorded");
      if (existing !== void 0 && existing.payload["fence"] === guarded.lastFence) {
        return { ok: true, descendantTeardown, resumeEligibility };
      }
      const paused = await appendEntry(guarded.store, deliveryId, "activity.observed", {
        activity: "paused",
        fence: guarded.lastFence
      });
      if (!paused.ok) return paused;
      const appended = await appendEntry(guarded.store, deliveryId, "termination.provenance.recorded", {
        fence: guarded.lastFence,
        hostVersion: input.hostVersion,
        provenance: "graceful",
        descendantTeardown,
        resumeEligibility
      });
      if (!appended.ok) return appended;
      return { ok: true, descendantTeardown, resumeEligibility };
    },
    async recordProjectionConsumption({ deliveryId, category }) {
      const guarded = await guard(deliveryId, { verifyWorkspace: true });
      if (!("store" in guarded)) return guarded;
      if (guarded.workspace === void 0) {
        return refuse3(
          "workspace_unbound",
          "No workspace is bound.",
          "Bind the host-supplied worktree first; a consumption record describes a materialized projection."
        );
      }
      const emitted = await emitProjectionConsumptionRecord({
        // Neither target nor repository identity is caller-selectable. Both
        // are derived from the protected facade context after the canonical
        // delivery recheck, so a delivery cannot redirect its evidence into a
        // different adopter's comparison authority.
        gateRecordPath: path20.join(input.repoDir, SHADOW_MILESTONE_GATE_RECORD_PATH),
        repositoryRoot: input.repoDir,
        expectedRepositoryId: guarded.meta.contract.repository.repositoryId,
        worktreeDir: guarded.workspace.worktreeDir,
        bindingDir: path20.join(await deliveryDir(deliveryId), "binding"),
        // The run the record binds is the BINDING's, read from the workspace
        // record — the caller's fence has already been checked against the
        // journal, and this is the value the binding itself materialized under.
        deliveryId,
        fence: guarded.workspace.fence,
        category
      });
      if (!emitted.ok) {
        const crossRepository = emitted.blockers.some(
          (blocker) => blocker.code === "gate_record_repository_mismatch"
        );
        return refuse3(
          crossRepository ? "consumption_record_cross_repository_refused" : "consumption_record_write_failed",
          `Recording the projection-consumption entry failed: ${emitted.blockers.map((blocker) => blocker.message).join("; ")}`,
          crossRepository ? "Restore the canonical gate record's repositoryId to the accepted delivery repository; cross-repository targets are refused." : "Restore the consuming repository's canonical milestone gate-record artifact."
        );
      }
      return emitted.emitted ? { ok: true, emitted: true, projectionDigest: emitted.record.projectionDigest } : { ok: true, emitted: false, reason: emitted.reason };
    },
    async tearDownWorkspaceProjection({ deliveryId }) {
      const guarded = await guard(deliveryId);
      if (!("store" in guarded)) return guarded;
      const dir = await deliveryDir(deliveryId);
      const workspace = await readJson(path20.join(dir, "workspace.json"));
      if (workspace === void 0) {
        return refuse3("workspace_unbound", "No workspace is bound.", "Bind the host-supplied worktree first.");
      }
      const torn = await tearDownProjection({
        worktreeDir: workspace.worktreeDir,
        bindingDir: path20.join(dir, "binding"),
        settingsPath: workspace.settingsPath,
        exec
      });
      if (!torn.ok) {
        return refuse3(
          "projection_teardown_failed",
          `Tearing the projection down failed: ${torn.blockers.map((blocker) => blocker.message).join("; ")}`,
          "Remove the projection subtree and the worktree-scoped exclusion before removing the worktree."
        );
      }
      return { ok: true };
    },
    async recordApprovalRequest({ deliveryId, requestKind, criterionId, actorId, reason, fence }) {
      const guarded = await guard(deliveryId, {
        requireState: ["reviewing", "remediating", "admitting"],
        verifyWorkspace: true,
        invokingFence: fence,
        fenceRequired: true
      });
      if (!("store" in guarded)) return guarded;
      const appended = await appendEntry(guarded.store, deliveryId, "approval.request.recorded", {
        requestKind,
        criterionId,
        actorId,
        reason
      });
      if (!appended.ok) return appended;
      return { ok: true, state: guarded.state };
    },
    async consumeWaiver({ deliveryId, approverId, outcomeChanging, fence, now, assertionSource }) {
      const guarded = await guard(deliveryId, {
        requireState: ["reviewing", "remediating", "admitting"],
        verifyWorkspace: true,
        invokingFence: fence,
        fenceRequired: true
      });
      if (!("store" in guarded)) return guarded;
      const current = currentCandidateOf(guarded.views);
      if (current === void 0) return refuse3("no_candidate", "No candidate is checkpointed.", "Checkpoint a candidate first.");
      if (outcomeChanging && guarded.state === "admitting") {
        return refuse3(
          "amendment_after_review",
          "An outcome amendment forces full re-evaluation; at admission there is no review left to re-open.",
          "Return the delivery to review, then confirm the amendment there."
        );
      }
      const trust = await readTrust();
      if (trust === void 0) {
        return refuse3("trust_state_unreadable", "The installation trust store is absent or corrupt.", "Absent trust state fails closed; reinstall or repair.");
      }
      const binding = await registrationBinding({
        installationPath: input.installation.installationPath,
        receiptDir: input.installation.receiptDir
      });
      if (!binding.ok) {
        return refuse3("installation_unresolved", "No install receipt resolves this installation.", "Install the composition first.");
      }
      const providerConfig = await loadAssertionProviderConfig(input.installation.installationPath);
      if (!providerConfig.ok) {
        return refuse3(
          "assertion_source_unavailable",
          "The assertion provider configuration is absent or corrupt; sensitive operations fail closed.",
          "An operator-performed installer repair re-establishes the assertion source."
        );
      }
      const source = assertionSource ?? assertionSourceForKind(providerConfig.config.sourceKind);
      const availability = await source.probe();
      if (!availability.available) {
        return refuse3(
          "assertion_source_unavailable",
          `The configured assertion source is unavailable: ${availability.detail}`,
          "An operator-performed installer repair re-establishes the assertion source."
        );
      }
      const ledger = waiverLedgerOf(guarded.views);
      const pendingProposal = ledger.pending[0];
      const action = outcomeChanging ? "confirm-outcome-amendment" : "waive-criterion";
      const evaluation = await source.evaluate({
        action,
        disclosure: `Approve ${action} of criterion ${pendingProposal?.criterionId ?? "(none proposed)"} on delivery ${deliveryId}, candidate ${current.treeSha}, as ${approverId}`
      });
      if (!evaluation.ok) {
        return refuse3("assertion_refused", `The interactive evaluation was not granted: ${evaluation.reason}`, "The approver declined; the proposal stays pending.");
      }
      const assertion = {
        spec: SENSITIVE_APPROVAL_ASSERTION_SPEC,
        assertionClass: "delivery-bound",
        origin: `${WAIVER_APPROVAL_ORIGIN_PREFIX}${approverId}`,
        action,
        expiry: evaluation.expiry,
        nonce: evaluation.nonce,
        assertionSource: evaluation.sourceKind,
        productTrustRevocationEpoch: trust.revocationEpoch,
        repositoryAuthorityRevocationEpoch: guarded.meta.policy.repositoryAuthorityRevocationEpoch,
        deliveryId,
        candidateTreeSha: current.treeSha,
        policyDigest: guarded.meta.policy.policyDigest,
        invocationFence: guarded.lastFence,
        targetInstallationId: "absent-by-state",
        targetGenerationDigest: "absent-by-state",
        targetHighWaterMark: "absent-by-state",
        expectedJournalRevision: "absent-by-state"
      };
      const verdict = evaluateWaiverConsumption(assertion, {
        deliveryId,
        deliveryState: guarded.state,
        candidateTreeSha: current.treeSha,
        policyDigest: guarded.meta.policy.policyDigest,
        productTrustRevocationEpoch: trust.revocationEpoch,
        repositoryAuthorityRevocationEpoch: guarded.meta.policy.repositoryAuthorityRevocationEpoch,
        invocationFence: guarded.lastFence,
        proposal: pendingProposal,
        contractCriterionIds: guarded.meta.contract.acceptanceCriteria.map((criterion) => criterion.criterionId),
        outcomeAuthorities: policyBinding.outcomeAuthorities,
        currentProfile: binding.activeCompositionProfile,
        consumedNonces: consumedAssertionNoncesOf(guarded.views),
        now
      });
      if (!verdict.ok) {
        if (verdict.blockers.some((blocker) => blocker.code === "waiver_proposal_stale")) {
          await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
            code: "approval.proposal-voided",
            summary: `the candidate changed since criterion ${String(pendingProposal?.criterionId)} was proposed; the stale proposal is void`.slice(0, 1900)
          });
        }
        return refuseWith(
          verdict.blockers.map(
            (blocker) => createBlocker({
              code: blocker.code,
              source: SOURCE,
              summary: blocker.message,
              remediations: [
                {
                  id: `${blocker.code.replaceAll("_", "-")}-remediation`,
                  kind: "manual_action",
                  summary: "A waiver is valid only as a consumed sensitive approval bound to the current candidate; the proposal stays unapproved."
                }
              ]
            })
          )
        );
      }
      const consumed = await appendEntry(guarded.store, deliveryId, "approval.assertion.consumed", {
        assertion,
        newRegisteringInstallationId: "absent-by-state"
      });
      if (!consumed.ok) return consumed;
      if (!verdict.outcomeChanging) {
        return { ok: true, criterionId: verdict.criterionId, outcomeChanging: false, contractId: guarded.meta.contract.contractId, state: guarded.state };
      }
      const previousContractId = guarded.meta.contract.contractId;
      const amendedContract = {
        ...guarded.meta.contract,
        contractId: `${previousContractId}.amended-${sha256Hex(evaluation.nonce).slice(0, 12)}`
      };
      const amended = await appendEntry(guarded.store, deliveryId, "contract.amended", {
        previousContractId,
        contractId: amendedContract.contractId,
        contractDigest: digestCanonical(amendedContract),
        criterionId: verdict.criterionId,
        assertionNonce: evaluation.nonce
      });
      if (!amended.ok) return amended;
      await writeOwned2(
        path20.join(await deliveryDir(deliveryId), "delivery.json"),
        `${JSON.stringify({ ...guarded.meta, contract: amendedContract })}
`
      );
      const to = guarded.state === "reviewing" ? "remediating" : "validating";
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", { from: guarded.state, to });
      if (!transitioned.ok) return transitioned;
      return { ok: true, criterionId: verdict.criterionId, outcomeChanging: true, contractId: amendedContract.contractId, state: to };
    },
    async blockerInventory({ deliveryId }) {
      const guarded = await guard(deliveryId, { allowPendingTakeover: true });
      if (!("store" in guarded)) return guarded;
      return { ok: true, entries: composeBlockerInventory(guarded.views) };
    },
    async requestCancellation({ deliveryId }) {
      const guarded = await guard(deliveryId, { allowPendingTakeover: true });
      if (!("store" in guarded)) return guarded;
      if (guarded.state === "cancellation_requested") {
        return refuse3(
          "cancellation_already_requested",
          "Cancellation is already requested; finalize it through quarantine or trusted termination.",
          "Call finalizeCancellation once the prior workspace is quarantined."
        );
      }
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", {
        from: guarded.state,
        to: "cancellation_requested"
      });
      if (!transitioned.ok) return transitioned;
      const cancelBindingDir = path20.join(await deliveryDir(deliveryId), "binding");
      await voidSupersededBindingStates(cancelBindingDir, Number.POSITIVE_INFINITY);
      if (guarded.lastFence > 0) {
        await appendEntry(guarded.store, deliveryId, "activity.observed", {
          activity: "cancellation_pending",
          fence: guarded.lastFence
        });
      }
      return { ok: true, state: "cancellation_requested" };
    },
    async finalizeCancellation({ deliveryId }) {
      const guarded = await guard(deliveryId, { allowPendingTakeover: true });
      if (!("store" in guarded)) return guarded;
      if (guarded.state !== "cancellation_requested") {
        return refuse3(
          "cancellation_not_requested",
          `finalizeCancellation completes a requested cancellation; the delivery is in ${guarded.state}.`,
          "Request cancellation first."
        );
      }
      const boundWorkspace = lastOf2(guarded.views, "workspace.bound");
      const disposed = await appendEntry(guarded.store, deliveryId, "workspace.disposition.recorded", {
        workspaceId: boundWorkspace?.payload["workspaceId"] ?? "ws-unbound",
        disposition: "quarantined"
      });
      if (!disposed.ok) return disposed;
      const transitioned = await appendEntry(guarded.store, deliveryId, "transition.committed", {
        from: "cancellation_requested",
        to: "cancelled"
      });
      if (!transitioned.ok) return transitioned;
      return { ok: true, state: "cancelled" };
    },
    async exportDelivery({ deliveryId }) {
      const context = await retentionContext();
      if (!("namespaceDir" in context)) return context;
      const binding = await verifyDeliveryBinding(deliveryId);
      if (!binding.ok) return binding;
      const outcome = await exportDelivery(context, deliveryId);
      if (!outcome.ok) return refuse3(outcome.code, outcome.summary, outcome.remediation);
      return { ok: true, exportPath: outcome.exportPath, artifactDigest: outcome.artifactDigest };
    },
    async deleteDelivery({ deliveryId }) {
      const context = await retentionContext();
      if (!("namespaceDir" in context)) return context;
      const binding = await verifyDeliveryBinding(deliveryId);
      if (!binding.ok) return binding;
      const outcome = await deleteDelivery(context, deliveryId);
      if (!outcome.ok) return refuse3(outcome.code, outcome.summary, outcome.remediation);
      return { ok: true, preservedAuditRecords: outcome.preservedAuditRecords };
    },
    async presentTakeover({ deliveryId, expiry }) {
      const guarded = await guard(deliveryId);
      if (!("store" in guarded)) return guarded;
      const trust = await readTrust();
      if (trust === void 0) {
        return refuse3("trust_state_unreadable", "The installation trust store is absent or corrupt.", "Absent trust state fails closed; reinstall or repair.");
      }
      const current = currentCandidateOf(guarded.views);
      const bound2 = lastOf2(guarded.views, "workspace.bound");
      const targetBaseCommit = current !== void 0 ? current.branchRefValue : bound2?.payload["baseTipSha"];
      if (targetBaseCommit === void 0) {
        return refuse3("no_trusted_commit", "No trusted commit exists to reconstruct from.", "Bind a workspace first.");
      }
      const nonce = `nonce-${hex(8)}`;
      const takeoverBranchRef = `takeover-${deliveryId}-${guarded.lastFence + 1}`;
      const collision = await git(input.repoDir, "rev-parse", "--verify", "--quiet", `refs/heads/${takeoverBranchRef}`);
      if (collision.code === 0) {
        await appendEntry(guarded.store, deliveryId, "blocker.recorded", {
          code: "workspace.branch-collision",
          summary: `branch ${takeoverBranchRef} already exists; a takeover reconstructs onto a fresh branch and never adopts an existing ref`
        });
        return refuse3(
          "branch_collision",
          `The takeover branch ${takeoverBranchRef} already exists in this repository.`,
          "Remove or rename the colliding branch through the host's native git tooling, then present the takeover again."
        );
      }
      const confirmation = {
        spec: "operator-confirmation/1",
        confirmationClass: "takeover-authorization",
        origin: "managed-delivery.facade",
        action: "authorize-takeover",
        expiry,
        nonce,
        productTrustRevocationEpoch: trust.revocationEpoch,
        repositoryAuthorityRevocationEpoch: guarded.meta.policy.repositoryAuthorityRevocationEpoch,
        intakeDraftId: "absent-by-state",
        deliveryId,
        normalizedContractDigest: "absent-by-state",
        supersededInvocationFence: guarded.lastFence,
        expectedJournalRevision: guarded.expectedRevision,
        targetBaseCommit,
        boundInvocationFence: "absent-by-state",
        boundCandidateTreeSha: "absent-by-state"
      };
      const rendered = await renderChallenge(nonce, confirmation, deliveryId, expiry);
      if (!rendered.ok) return rendered;
      await writeOwned2(
        path20.join(await deliveryDir(deliveryId), "takeover-pending.json"),
        `${JSON.stringify({ nonce, targetBaseCommit, takeoverBranchRef, supersededFence: guarded.lastFence })}
`
      );
      return {
        ok: true,
        nonce,
        channelPath: confirmationPath(nonce),
        supersededFence: guarded.lastFence,
        expectedJournalRevision: guarded.expectedRevision,
        targetBaseCommit,
        takeoverBranchRef
      };
    },
    async confirmTakeover({ deliveryId, echo }) {
      const guarded = await guard(deliveryId);
      if (!("store" in guarded)) return guarded;
      const dir = await deliveryDir(deliveryId);
      const pending = await readJson(path20.join(dir, "takeover-pending.json"));
      if (pending === void 0) {
        return refuse3("takeover_unknown", "No presented takeover authorization is pending.", "Present the takeover first.");
      }
      const consumed = await consumeChallenge(pending.nonce, echo);
      if (!("confirmation" in consumed)) return consumed;
      const confirmation = consumed.confirmation;
      if (confirmation["deliveryId"] !== deliveryId) {
        return refuse3(
          "takeover_stale",
          "The takeover authorization binds a different delivery; nothing was consumed into the journal.",
          "Present a fresh takeover against current durable state."
        );
      }
      const boundWorkspace = lastOf2(guarded.views, "workspace.bound");
      const currentTrusted = currentCandidateOf(guarded.views);
      const observedTarget = currentTrusted !== void 0 ? currentTrusted.branchRefValue : boundWorkspace?.payload["baseTipSha"] ?? "no-trusted-commit";
      const consumptionRecheck = evaluateCanonicalRecheck({
        consumption: {
          kind: "takeover",
          supersededFence: { kind: "compare", expected: Number(confirmation["supersededInvocationFence"]), observed: guarded.lastFence },
          expectedJournalRevision: { kind: "compare", expected: Number(confirmation["expectedJournalRevision"]), observed: guarded.expectedRevision },
          targetBaseCommit: { kind: "compare", expected: String(confirmation["targetBaseCommit"]), observed: observedTarget }
        },
        values: {
          ...guarded.recheckValues,
          "invocation-fence": "absent-by-state",
          "projection-digest": "absent-by-state",
          "discovery-configuration-digest": "absent-by-state"
        }
      });
      if (!consumptionRecheck.ok) {
        return refuse3(
          "takeover_stale",
          `The takeover authorization no longer matches durable state (${consumptionRecheck.failures.map((failure) => failure.value).join(", ")}); nothing was consumed into the journal.`,
          "Present a fresh takeover against current durable state."
        );
      }
      const recorded = await appendEntry(guarded.store, deliveryId, "operator.confirmation.recorded", { confirmation });
      if (!recorded.ok) return recorded;
      const bound2 = lastOf2(guarded.views, "workspace.bound");
      const priorWorkspace = bound2?.payload["workspaceId"] ?? "ws-unbound";
      await appendEntry(guarded.store, deliveryId, "workspace.disposition.recorded", {
        workspaceId: priorWorkspace,
        disposition: "quarantined"
      });
      await writeOwned2(
        path20.join(dir, "takeover.json"),
        `${JSON.stringify({
          targetBaseCommit: pending.targetBaseCommit,
          takeoverBranchRef: pending.takeoverBranchRef,
          supersededFence: pending.supersededFence
        })}
`
      );
      await rm8(path20.join(dir, "takeover-pending.json"), { force: true });
      return { ok: true, targetBaseCommit: pending.targetBaseCommit, takeoverBranchRef: pending.takeoverBranchRef };
    },
    async explainBlocker({ deliveryId }) {
      const binding = await verifyDeliveryBinding(deliveryId);
      if (!binding.ok) return binding;
      const store = await journalStoreFor(deliveryId);
      const read = await store.read();
      if (!read.ok) return refuse3("journal_unreadable", "The delivery journal is unreadable.", "Inspect the durable journal file.");
      const blocker = lastOf2(viewsOf(read.entries), "blocker.recorded");
      if (blocker === void 0) return { ok: true, blocker: void 0 };
      const code = blocker.payload["code"];
      const remediation = code.startsWith("trust.") ? "Restore local product trust through the operator maintenance lane, then resume." : code.startsWith("projection.") ? "Quarantine the workspace and resume through an authorized takeover into a fresh worktree." : code.startsWith("outcome.") ? "Satisfy the named acceptance criterion on the exact candidate, then re-validate." : code.startsWith("review.") ? "Complete both mandatory review lenses on the exact candidate, then re-admit." : "Read the summary; the journal carries the full typed record.";
      return { ok: true, blocker: { code, summary: blocker.payload["summary"], remediation } };
    },
    async updateComposition(maintenance) {
      const outcome = await updateComposition({
        ...maintenance,
        installationPath: input.installation.installationPath,
        receiptDir: input.installation.receiptDir
      });
      if (!outcome.ok) return substrateRefusal(outcome.blockers);
      return {
        ok: true,
        generationDigest: outcome.generationDigest,
        priorGenerationDigest: outcome.priorGenerationDigest,
        noOp: outcome.noOp
      };
    },
    async rollbackComposition(maintenance) {
      const outcome = await rollbackComposition({
        ...maintenance,
        installationPath: input.installation.installationPath,
        receiptDir: input.installation.receiptDir
      });
      if (!outcome.ok) return substrateRefusal(outcome.blockers);
      return { ok: true, generationDigest: outcome.generationDigest };
    },
    async maintainTrustState(maintenance) {
      const outcome = await maintainTrustState({
        ...maintenance,
        installationPath: input.installation.installationPath,
        receiptDir: input.installation.receiptDir
      });
      if (!outcome.ok) return substrateRefusal(outcome.blockers);
      return { ok: true, state: outcome.state };
    },
    async recoverSecurityBlocked({ deliveryId, targetGenerationDigest, assertionSource, now }) {
      const dir = await deliveryDir(deliveryId);
      const meta = await readJson(path20.join(dir, "delivery.json"));
      if (meta === void 0) {
        return refuse3("unknown_delivery", `No registered delivery ${deliveryId}.`, "Register a delivery through the contract handoff first.");
      }
      const store = await journalStoreFor(deliveryId);
      const reduced = await store.state();
      const read = await store.read();
      if (!reduced.ok || !read.ok) {
        return refuse3("journal_rejected", "The durable journal does not reduce.", "Inspect the durable journal file.");
      }
      if (meta.policyBindingDigest !== policyBindingDigest || reduced.state.policyBindingDigest !== policyBindingDigest) {
        return refuse3(
          "policy_binding_mismatch",
          "The current compiled adopter policy binding does not match this delivery's recorded binding.",
          "Use the exact binding captured at registration; drift requires a new owner-approved delivery."
        );
      }
      if (reduced.state.state !== "security_blocked") {
        return refuse3(
          "wrong_state",
          `Leaving security_blocked is a maintenance-lane operation; the delivery is in ${reduced.state.state}.`,
          "Read `status` for the next valid checkpoint."
        );
      }
      const views = viewsOf(read.entries);
      const recorded = recordedBindingOf(views);
      const recordedPin = reduced.state.generationDigest;
      if (recorded === void 0 || recordedPin === void 0) {
        return refuse3("unregistered", "The delivery has no recorded registration binding or generation pin.", "Register the delivery first.");
      }
      const binding = await registrationBinding({
        installationPath: input.installation.installationPath,
        receiptDir: input.installation.receiptDir
      });
      if (!binding.ok) {
        return refuse3("installation_unresolved", "No install receipt resolves this installation.", "Install the composition first.");
      }
      const trust = await readTrust();
      if (trust === void 0) {
        return refuse3("trust_state_unreadable", "The installation trust store is absent or corrupt.", "Absent trust state fails closed; reinstall or repair.");
      }
      const target = targetGenerationDigest ?? recordedPin;
      const rebinding = binding.registeringInstallationId !== recorded.registeringInstallationId;
      const generationChange = target !== recordedPin;
      const mode = rebinding ? "rebinding-migration" : generationChange ? "generation-change-migration" : "re-preparation";
      if (mode === "re-preparation") {
        const load = await loadPinnedGeneration({
          installationPath: input.installation.installationPath,
          generationDigest: recordedPin
        });
        if (!load.ok) {
          return refuse3(
            "trust_ineligible",
            "The recorded generation pin is not execution-eligible under current local trust state.",
            "Restore trust through the operator maintenance lane, or migrate to an accepted generation."
          );
        }
      } else {
        const config2 = await loadAssertionProviderConfig(input.installation.installationPath);
        if (!config2.ok) {
          return refuse3(
            "assertion_source_unavailable",
            "The assertion provider configuration is absent or corrupt; sensitive operations fail closed.",
            "An operator-performed installer repair re-establishes the assertion source."
          );
        }
        const source = assertionSource ?? assertionSourceForKind(config2.config.sourceKind);
        const availability = await source.probe();
        if (!availability.available) {
          return refuse3(
            "assertion_source_unavailable",
            `The configured assertion source is unavailable: ${availability.detail}`,
            "An operator-performed installer repair re-establishes the assertion source."
          );
        }
        const evaluation = await source.evaluate({
          action: SECURITY_BLOCKED_MIGRATION_ACTION,
          disclosure: `Approve security-blocked migration of delivery ${deliveryId} at journal revision ${reduced.state.expectedRevision} to generation ${target} on installation ${binding.registeringInstallationId}`
        });
        if (!evaluation.ok) {
          return refuse3("assertion_refused", `The interactive evaluation was not granted: ${evaluation.reason}`, "The operator declined; the delivery remains security_blocked.");
        }
        const assertion = {
          spec: "sensitive-approval-assertion/1",
          assertionClass: "security-blocked-migration",
          origin: "managed-delivery.facade",
          action: SECURITY_BLOCKED_MIGRATION_ACTION,
          expiry: evaluation.expiry,
          nonce: evaluation.nonce,
          assertionSource: evaluation.sourceKind,
          productTrustRevocationEpoch: trust.revocationEpoch,
          repositoryAuthorityRevocationEpoch: "absent-by-state",
          deliveryId,
          candidateTreeSha: "absent-by-state",
          policyDigest: "absent-by-state",
          invocationFence: "absent-by-state",
          targetInstallationId: binding.registeringInstallationId,
          targetGenerationDigest: target,
          targetHighWaterMark: "absent-by-state",
          expectedJournalRevision: reduced.state.expectedRevision
        };
        const consumption = evaluateMigrationConsumption(assertion, {
          deliveryId,
          expectedJournalRevision: reduced.state.expectedRevision,
          currentInstallationId: binding.registeringInstallationId,
          currentProfile: binding.activeCompositionProfile,
          recordedInstallationId: recorded.registeringInstallationId,
          recordedProfile: recorded.activeCompositionProfile,
          trustState: trust,
          consumedNonces: consumedAssertionNoncesOf(views),
          now
        });
        if (!consumption.ok) {
          return refuseWith(
            consumption.blockers.map(
              (blocker) => createBlocker({
                code: blocker.code,
                source: SOURCE,
                summary: blocker.message,
                remediations: [
                  {
                    id: `${blocker.code.replaceAll("_", "-")}-remediation`,
                    kind: "manual_action",
                    summary: "The migration assertion rejects on any binding mismatch; the delivery remains security_blocked."
                  }
                ]
              })
            )
          );
        }
        const load = await loadPinnedGeneration({
          installationPath: input.installation.installationPath,
          generationDigest: target
        });
        if (!load.ok) {
          return refuse3(
            "trust_ineligible",
            "The migration's target generation is not a retained, execution-eligible root on this installation.",
            "Install or update to the target generation first."
          );
        }
        const consumed = await appendEntry(store, deliveryId, "approval.assertion.consumed", {
          assertion,
          newRegisteringInstallationId: rebinding ? binding.registeringInstallationId : "absent-by-state"
        });
        if (!consumed.ok) return consumed;
        if (target !== recordedPin) {
          const pinned = await appendEntry(store, deliveryId, "generation.pinned", {
            generationDigest: target,
            releaseId: PINNED_AGENT_SKILLS.releaseId,
            profile: binding.activeCompositionProfile
          });
          if (!pinned.ok) return pinned;
        }
      }
      const attemptsDir = path20.join(dir, "attempts");
      try {
        await readdir5(attemptsDir);
        const { rename: rename6 } = await import("node:fs/promises");
        await rename6(attemptsDir, path20.join(dir, `attempts-invalidated-r${reduced.state.expectedRevision}`));
      } catch {
      }
      await rm8(path20.join(dir, "workspace.json"), { force: true });
      await rm8(path20.join(dir, "takeover.json"), { force: true });
      const transitioned = await appendEntry(store, deliveryId, "transition.committed", {
        from: "security_blocked",
        to: "preparing"
      });
      if (!transitioned.ok) return transitioned;
      return { ok: true, mode, state: "preparing" };
    }
  };
}
async function captureFor(rootDir, config, run, runGit) {
  const storage = await resolveRecordStorage(rootDir, { storageNamespace: config.storageNamespace, runGit });
  const captureCandidate = createCandidateCapture({
    rootDir,
    config,
    workspaceId: storage.workspaceId,
    computeIdentity: withDeliverableIdentity(),
    run
  });
  const capture = await captureCandidate();
  if (!capture.ok) {
    return { ok: false, failure: { ok: false, blockers: capture.blockers } };
  }
  return { ok: true, candidate: capture.candidate, captureCandidate };
}
function instantSeconds(instant3) {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})Z$/.exec(instant3);
  if (match === null) return Number.NaN;
  return Date.UTC(
    Number(match[1]),
    Number(match[2]) - 1,
    Number(match[3]),
    Number(match[4]),
    Number(match[5]),
    Number(match[6])
  ) / 1e3;
}

// packages/kernel/src/provider-rails.ts
import { spawn as spawn4 } from "node:child_process";
import { createInterface } from "node:readline";
var DELIVERY_PROVIDER_RAILS_VERSION = "delivery-provider-rails/1";
function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function exactMembers(value, required, optional = []) {
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  return required.every((member2) => Object.hasOwn(value, member2)) && Object.keys(value).every((member2) => allowed.has(member2));
}
var IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:-]*$/;
function identifier(value) {
  return typeof value === "string" && value.length >= 1 && value.length <= 64 && IDENTIFIER.test(value);
}
function text3(value) {
  return typeof value === "string" && value.length >= 1 && value.length <= 1024;
}
function opaque(value) {
  return isObject(value);
}
function sequence(value) {
  return typeof value === "number" && Number.isInteger(value) && value >= 1;
}
function validNegotiation(value) {
  if (!isObject(value) || !exactMembers(value, ["kind", "outcome", "selectedVersion", "supportedVersions"])) return false;
  if (value["kind"] !== "negotiation") return false;
  if (!Array.isArray(value["supportedVersions"]) || value["supportedVersions"].length !== 1 || value["supportedVersions"][0] !== DELIVERY_PROVIDER_RAILS_VERSION) return false;
  if (value["outcome"] === "supported") return value["selectedVersion"] === DELIVERY_PROVIDER_RAILS_VERSION;
  if (value["outcome"] === "unsupported") return value["selectedVersion"] === null;
  return false;
}
function eventBase(value) {
  return value["version"] === DELIVERY_PROVIDER_RAILS_VERSION && identifier(value["requestId"]) && sequence(value["sequence"]) && text3(value["summary"]);
}
function validEvent(value) {
  if (!isObject(value) || typeof value["kind"] !== "string") return false;
  switch (value["kind"]) {
    case "progress":
      return exactMembers(value, ["kind", "requestId", "sequence", "summary", "version"], ["details"]) && eventBase(value) && (value["details"] === void 0 || opaque(value["details"]));
    case "evidence":
      return exactMembers(value, ["evidenceId", "kind", "requestId", "sequence", "summary", "version"], ["details"]) && eventBase(value) && identifier(value["evidenceId"]) && (value["details"] === void 0 || opaque(value["details"]));
    case "blocker":
      return exactMembers(value, ["blockerId", "kind", "requestId", "sequence", "summary", "version"], ["action", "details"]) && eventBase(value) && identifier(value["blockerId"]) && (value["action"] === void 0 || text3(value["action"])) && (value["details"] === void 0 || opaque(value["details"]));
    case "terminal":
      return exactMembers(value, ["kind", "outcome", "requestId", "sequence", "summary", "version"], ["action", "details", "result"]) && eventBase(value) && ["success", "blocked", "failed", "cancelled", "indeterminate"].includes(String(value["outcome"])) && (value["action"] === void 0 || text3(value["action"])) && (value["details"] === void 0 || opaque(value["details"])) && (value["result"] === void 0 || opaque(value["result"]));
    default:
      return false;
  }
}
function consumeProviderRailMessages(messages, options = {}) {
  let negotiated = false;
  let status = "malformed";
  let terminalClosed = false;
  let failedClosed = false;
  let activeRequestId = options.requestId;
  let acceptedCount = 0;
  let duplicateCount = 0;
  let rejectedCount = 0;
  let terminal = null;
  const events = [];
  const seenByRequest = /* @__PURE__ */ new Map();
  const accept = (message) => {
    if (terminalClosed || failedClosed) {
      rejectedCount += 1;
      return;
    }
    if (validNegotiation(message)) {
      negotiated = false;
      if (seenByRequest.size > 0) {
        status = "malformed";
        failedClosed = true;
        return;
      }
      if (message.outcome === "supported") {
        negotiated = true;
        status = "supported";
      } else {
        status = "unsupported";
        failedClosed = true;
      }
      return;
    }
    if (!negotiated || !validEvent(message)) {
      status = "malformed";
      failedClosed = true;
      return;
    }
    if (activeRequestId === void 0) activeRequestId = message.requestId;
    else if (message.requestId !== activeRequestId) {
      status = "malformed";
      failedClosed = true;
      return;
    }
    const encoded = canonicalize(message);
    const seen = seenByRequest.get(message.requestId) ?? /* @__PURE__ */ new Map();
    seenByRequest.set(message.requestId, seen);
    const prior = seen.get(message.sequence);
    if (prior !== void 0) {
      if (prior === encoded) duplicateCount += 1;
      else {
        status = "malformed";
        failedClosed = true;
      }
      return;
    }
    const expected = Math.max(0, ...seen.keys()) + 1;
    if (message.sequence !== expected) {
      status = "malformed";
      failedClosed = true;
      return;
    }
    if (options.cancellationAccepted === true && message.kind === "terminal" && message.outcome !== "cancelled" && message.outcome !== "indeterminate") {
      status = "malformed";
      rejectedCount += 1;
      failedClosed = true;
      return;
    }
    seen.set(message.sequence, encoded);
    acceptedCount += 1;
    events.push(message);
    if (message.kind === "terminal") {
      status = message.outcome;
      terminal = message;
      terminalClosed = true;
    }
  };
  for (const message of messages) accept(message);
  if (options.interrupted === true && negotiated && !terminalClosed && !failedClosed) {
    status = "indeterminate";
    terminalClosed = true;
  }
  for (const message of options.afterInterruption ?? []) accept(message);
  return { status, acceptedCount, duplicateCount, rejectedCount, events, terminal };
}
var DEFAULT_PROVIDER_RAIL_DEADLINE_MS = 10 * 6e4;
var DEFAULT_TERMINATION_GRACE_MS = 1e3;
var RailLifecycleEnded = class extends Error {
  causeKind;
  constructor(causeKind) {
    super(causeKind === "deadline" ? "Provider lifecycle deadline expired." : "Provider lifecycle was aborted.");
    this.name = "RailLifecycleEnded";
    this.causeKind = causeKind;
  }
};
var RailDeadline = class {
  signal;
  #controller = new AbortController();
  #timer;
  #parent;
  #onParentAbort;
  constructor(timeoutMs, parent) {
    this.signal = this.#controller.signal;
    this.#parent = parent;
    this.#onParentAbort = () => this.#controller.abort(new RailLifecycleEnded("abort"));
    parent?.addEventListener("abort", this.#onParentAbort, { once: true });
    if (parent?.aborted === true) this.#onParentAbort();
    this.#timer = setTimeout(
      () => this.#controller.abort(new RailLifecycleEnded("deadline")),
      Math.max(1, Math.floor(timeoutMs))
    );
  }
  async wait(operation) {
    if (this.signal.aborted) throw this.reason();
    const pending = operation();
    let onAbort;
    const aborted = new Promise((_resolve, reject2) => {
      onAbort = () => reject2(this.reason());
      this.signal.addEventListener("abort", onAbort, { once: true });
    });
    try {
      return await Promise.race([pending, aborted]);
    } finally {
      if (onAbort !== void 0) this.signal.removeEventListener("abort", onAbort);
    }
  }
  dispose() {
    clearTimeout(this.#timer);
    this.#parent?.removeEventListener("abort", this.#onParentAbort);
  }
  reason() {
    return this.signal.reason instanceof RailLifecycleEnded ? this.signal.reason : new RailLifecycleEnded("abort");
  }
};
async function settlesWithin(operation, milliseconds) {
  let timer;
  const elapsed = new Promise((resolve) => {
    timer = setTimeout(() => resolve(false), Math.max(1, Math.floor(milliseconds)));
  });
  try {
    return await Promise.race([operation.then(() => true, () => true), elapsed]);
  } finally {
    if (timer !== void 0) clearTimeout(timer);
  }
}
function openProviderRailProcess(input) {
  const [executable, ...args] = input.command;
  const child = spawn4(executable, args, {
    cwd: input.cwd,
    env: input.env,
    stdio: ["pipe", "pipe", "pipe"],
    shell: false
  });
  child.stdin.on("error", () => {
  });
  const lines = createInterface({ input: child.stdout });
  child.stderr.resume();
  const queued = [];
  const waiters = [];
  let closed2 = false;
  let resolveClosed;
  const childClosed = new Promise((resolve) => {
    resolveClosed = resolve;
  });
  let closing;
  const deliver = (value) => {
    const waiter = waiters.shift();
    if (waiter !== void 0) waiter(value);
    else if (value !== null) queued.push(value);
  };
  lines.on("line", (line) => {
    try {
      const parsed = JSON.parse(line);
      deliver(parsed === null ? line : parsed);
    } catch {
      deliver(line);
    }
  });
  const close = () => {
    if (closed2) return;
    closed2 = true;
    while (waiters.length > 0) waiters.shift()?.(null);
    resolveClosed?.();
  };
  child.once("close", close);
  child.once("error", close);
  return Promise.resolve({
    async send(message) {
      if (closed2 || child.stdin.destroyed) throw new Error("Provider transport is closed.");
      await new Promise((resolve, reject2) => {
        child.stdin.write(`${JSON.stringify(message)}
`, (error) => error === null || error === void 0 ? resolve() : reject2(error));
      });
    },
    receive() {
      const next = queued.shift();
      if (next !== void 0) return Promise.resolve(next);
      if (closed2) return Promise.resolve(null);
      return new Promise((resolve) => waiters.push(resolve));
    },
    close(options = {}) {
      closing ??= (async () => {
        lines.close();
        if (!child.stdin.destroyed) child.stdin.end();
        if (closed2 || child.exitCode !== null || child.signalCode !== null) {
          await childClosed;
          return;
        }
        child.kill("SIGTERM");
        const grace = options.terminationGraceMs ?? DEFAULT_TERMINATION_GRACE_MS;
        if (!await settlesWithin(childClosed, grace) && child.exitCode === null && child.signalCode === null) {
          child.kill("SIGKILL");
        }
        await childClosed;
      })();
      return closing;
    }
  });
}
var RETRY_PROVIDER = {
  id: "retry-provider",
  kind: "retry",
  summary: "Start a new provider attempt after checking the provider process and retained diagnostics."
};
function detailsOf(value) {
  if (value === void 0) return void 0;
  if (value instanceof Error) return value.message;
  try {
    return canonicalize(value);
  } catch {
    return String(value);
  }
}
function railBlocker(providerId2, status, summary, details, action) {
  return createBlocker({
    code: `provider_rail_${status}`,
    source: { kind: "provider", id: providerId2 },
    summary,
    ...details === void 0 ? {} : { details: detailsOf(details) },
    remediations: [
      action === void 0 ? RETRY_PROVIDER : { id: "follow-provider-action", kind: "manual_action", summary: action }
    ]
  });
}
function outcomeBlockers(providerId2, consumption) {
  const reported = consumption.events.filter((event) => event.kind === "blocker");
  if (reported.length > 0) {
    return reported.map(
      (event) => railBlocker(
        providerId2,
        "blocked",
        event.summary,
        { blockerId: event.blockerId, ...event.details === void 0 ? {} : { details: event.details } },
        event.action
      )
    );
  }
  const terminal = consumption.terminal;
  return [
    railBlocker(
      providerId2,
      consumption.status,
      terminal?.summary ?? `Provider ${providerId2} ended ${consumption.status}.`,
      terminal?.details,
      terminal?.action
    )
  ];
}
function manifestPathOf(terminal) {
  const value = terminal.result?.["manifestPath"];
  return typeof value === "string" && value.length > 0 ? value : void 0;
}
async function invokeProviderRail(input, options) {
  const deadline = new RailDeadline(options.deadlineMs ?? DEFAULT_PROVIDER_RAIL_DEADLINE_MS, options.signal);
  const terminationGraceMs = options.terminationGraceMs ?? DEFAULT_TERMINATION_GRACE_MS;
  let session;
  let requestStarted = false;
  try {
    session = await deadline.wait(options.open);
    const activeSession = session;
    await deadline.wait(() => activeSession.send({ kind: "negotiate", supportedVersions: [DELIVERY_PROVIDER_RAILS_VERSION] }));
    const negotiation = await deadline.wait(() => activeSession.receive());
    if (negotiation === null) {
      return {
        kind: "blocked",
        status: "indeterminate",
        runId: input.requestId,
        blockers: [railBlocker(input.providerId, "indeterminate", "The provider transport closed before version negotiation completed.")]
      };
    }
    const received = [negotiation];
    const negotiated = consumeProviderRailMessages(received, { requestId: input.requestId });
    if (negotiated.status === "unsupported") {
      return { kind: "blocked", status: "unsupported", runId: input.requestId, blockers: outcomeBlockers(input.providerId, negotiated) };
    }
    if (negotiated.status !== "supported") {
      return { kind: "blocked", status: "malformed", runId: input.requestId, blockers: outcomeBlockers(input.providerId, negotiated) };
    }
    requestStarted = true;
    await deadline.wait(
      () => activeSession.send({
        kind: "request",
        version: DELIVERY_PROVIDER_RAILS_VERSION,
        requestId: input.requestId,
        idempotencyKey: input.idempotencyKey,
        payload: input.payload
      })
    );
    for (; ; ) {
      const message = await deadline.wait(() => activeSession.receive());
      if (message === null) {
        const interrupted = consumeProviderRailMessages(received, {
          requestId: input.requestId,
          interrupted: true
        });
        return { kind: "blocked", status: "indeterminate", runId: input.requestId, blockers: outcomeBlockers(input.providerId, interrupted) };
      }
      received.push(message);
      const consumption = consumeProviderRailMessages(received, {
        requestId: input.requestId
      });
      if (consumption.status === "supported") continue;
      if (consumption.status === "malformed") {
        return { kind: "blocked", status: "malformed", runId: input.requestId, blockers: outcomeBlockers(input.providerId, consumption) };
      }
      if (consumption.terminal === null) continue;
      deadline.dispose();
      if (consumption.status === "cancelled") {
        return { kind: "interrupted", status: "cancelled", runId: input.requestId, blockers: outcomeBlockers(input.providerId, consumption) };
      }
      if (consumption.status !== "success") {
        return { kind: "blocked", status: consumption.status, runId: input.requestId, blockers: outcomeBlockers(input.providerId, consumption) };
      }
      let records = [];
      if (input.requiresEvidence) {
        const manifestPath = manifestPathOf(consumption.terminal);
        if (manifestPath === void 0 || options.publishManifest === void 0) {
          return {
            kind: "blocked",
            status: "malformed",
            runId: input.requestId,
            blockers: [railBlocker(input.providerId, "malformed", "Provider success did not identify a manifest for retained evidence publication.")]
          };
        }
        let publication;
        try {
          publication = await options.publishManifest(manifestPath);
        } catch (error) {
          return {
            kind: "blocked",
            status: "failed",
            runId: input.requestId,
            blockers: error instanceof BlockedError ? error.blockers : [railBlocker(input.providerId, "failed", "Provider evidence publication did not complete.", error)]
          };
        }
        if (publication.status !== "accepted") {
          return {
            kind: "blocked",
            status: "failed",
            runId: input.requestId,
            blockers: publication.blockers.length > 0 ? publication.blockers : [railBlocker(input.providerId, "failed", "Provider evidence publication was not accepted.")]
          };
        }
        records = publication.records;
      }
      return {
        kind: "success",
        status: "success",
        liveResult: { providerId: input.providerId, runId: input.requestId, status: "green", findings: [] },
        events: consumption.events,
        records
      };
    }
  } catch (error) {
    if (session !== void 0 && requestStarted && error instanceof RailLifecycleEnded) {
      await settlesWithin(
        Promise.resolve().then(
          () => session?.send({
            kind: "cancel",
            version: DELIVERY_PROVIDER_RAILS_VERSION,
            requestId: input.requestId,
            cancellationId: options.cancellationId ?? `cancel-${input.requestId}`,
            reason: error.causeKind === "deadline" ? "Consumer deadline expired" : "Consumer interrupted the provider attempt"
          })
        ),
        terminationGraceMs
      );
    }
    const summary = error instanceof RailLifecycleEnded ? error.causeKind === "deadline" ? "The provider lifecycle deadline expired without a trustworthy terminal outcome." : "The provider invocation was interrupted without a trustworthy terminal outcome." : session === void 0 ? "The provider process could not be started." : "The provider transport closed without a trustworthy terminal outcome.";
    const blockers = [railBlocker(input.providerId, "indeterminate", summary, error)];
    return error instanceof RailLifecycleEnded && error.causeKind === "abort" ? { kind: "interrupted", status: "indeterminate", runId: input.requestId, blockers } : { kind: "blocked", status: "indeterminate", runId: input.requestId, blockers };
  } finally {
    deadline.dispose();
    try {
      await session?.close({ terminationGraceMs });
    } catch {
    }
  }
}

// packages/kernel/src/live-providers.ts
import { randomUUID as randomUUID4 } from "node:crypto";
function refusal(code, summary) {
  return createBlocker({
    code,
    source: { kind: "gate", id: "delivery-harness.live-verification" },
    summary,
    remediations: [{
      id: "rerun-live-verification",
      kind: "manual_action",
      summary: "Use the exact candidate checkout, restore its policy and wiring, and rerun verification."
    }]
  });
}
function candidateKey(candidate2) {
  return digestCanonical({
    treeSha: candidate2.treeSha,
    headSha: candidate2.headSha,
    base: candidate2.base,
    deliverable: candidate2.deliverable
  });
}
async function collectLiveProviderResults(input) {
  const requested = /* @__PURE__ */ new Map();
  for (const obligation of input.config.obligations) {
    if (obligation.freshness !== "live" || !isObligationActive(obligation.activation, input.projection, input.config.activationThreshold)) continue;
    for (const id of obligation.providers) {
      requested.set(id, [...requested.get(id) ?? [], obligation.id]);
    }
  }
  if (requested.size === 0) return { liveResults: [], blockers: [] };
  const liveResults = [];
  const blockers = [];
  try {
    const current = () => captureGitCandidate({
      rootDir: input.rootDir,
      config: input.config,
      workspaceId: input.candidate.workspaceId,
      computeIdentity: withDeliverableIdentity(input.run === void 0 ? {} : { run: input.run }),
      ...input.run === void 0 ? {} : { run: input.run }
    });
    const before = await current();
    if (!before.ok) return { liveResults: [], blockers: before.blockers };
    if (candidateKey(before.candidate) !== candidateKey(input.candidate)) {
      return {
        liveResults: [],
        blockers: [refusal("live_provider_candidate_mismatch", "The provider workspace is not the candidate being verified.")]
      };
    }
    const wiring = await computeCheckWiringFingerprint(input.rootDir, input.config);
    const expectedWiring = digestCanonical({
      preparation: input.evidenceContext.preparationFingerprint,
      release: input.evidenceContext.release
    });
    if (wiring !== expectedWiring) {
      return {
        liveResults: [],
        blockers: [refusal("live_provider_wiring_mismatch", "The provider workspace wiring or installed release differs from the candidate being verified.")]
      };
    }
    for (const [providerId2, obligationIds] of requested) {
      if (input.signal?.aborted) {
        return { liveResults: [], blockers: [refusal("live_provider_cancelled", "Live verification was cancelled.")] };
      }
      const command = input.config.providers.find((provider2) => provider2.id === providerId2)?.command;
      if (command === void 0) continue;
      const requestId = randomUUID4();
      const result2 = await invokeProviderRail({
        providerId: providerId2,
        requestId,
        idempotencyKey: randomUUID4(),
        requiresEvidence: false,
        payload: {
          gateId: input.config.gateId,
          providerId: providerId2,
          obligationIds: [...new Set(obligationIds)].sort(),
          candidate: before.candidate
        }
      }, {
        open: () => openProviderRailProcess({ command, cwd: input.rootDir, env: input.env }),
        ...input.signal === void 0 ? {} : { signal: input.signal }
      });
      if (result2.kind === "success") {
        liveResults.push(result2.liveResult);
      } else {
        blockers.push(...result2.blockers);
        liveResults.push({ providerId: providerId2, runId: result2.runId, status: "failed", findings: [] });
      }
    }
    const after = await current();
    if (!after.ok) return { liveResults: [], blockers: [...blockers, ...after.blockers] };
    if (candidateKey(after.candidate) !== candidateKey(before.candidate) || wiring !== await computeCheckWiringFingerprint(input.rootDir, input.config)) {
      return {
        liveResults: [],
        blockers: [...blockers, refusal(
          "live_provider_candidate_changed",
          "The candidate, base, policy wiring or installed release changed during live verification."
        )]
      };
    }
    return { liveResults, blockers };
  } catch (error) {
    return {
      liveResults: [],
      blockers: error instanceof BlockedError ? error.blockers : [refusal(
        "live_provider_observation_failed",
        `Live verification could not capture trustworthy inputs: ${error instanceof Error ? error.message : String(error)}`
      )]
    };
  }
}

// packages/kernel/src/index.ts
var PACKAGE_NAME = "@agent-delivery-harness/kernel";
export {
  ABSENT_BY_STATE,
  ACTION_APPROVALS,
  ACTION_VERIFICATIONS,
  ACTIVATION_KINDS,
  ACTIVE_POINTER_SPEC,
  ADAPTER_CAPABILITY_SPEC,
  ADMISSION_DENIAL_CODES,
  APPROVAL_REQUEST_KINDS,
  APPROVAL_REQUIREMENTS,
  ARCHIVE_RELEASE_MANIFEST_ENTRY,
  ARTIFACT_OBSERVATION_STATUSES,
  ASSERTION_CLASSES,
  ASSERTION_PROVIDER_SPEC,
  ASSERTION_SOURCES,
  ATTESTATION_LABEL,
  ATTESTATION_LEVELS,
  AUTHORITY_REVOCATION_SPEC,
  BASE_MOVEMENT_POLICIES,
  BLOCKER_CONTRACT_VERSION,
  BLOCKER_SOURCE_KINDS,
  BlockedError,
  CANDIDATE_CAPTURE_CODES,
  CANDIDATE_DIFF_UNREADABLE,
  CANDIDATE_DRIFT_CLASSES,
  CANDIDATE_MODES,
  CANDIDATE_PATH_CLASSES,
  CANDIDATE_VCS,
  CAPABILITY_DESCRIPTOR_SPEC,
  CAPABILITY_KINDS,
  CLAUDE_SKILL_EXPOSURE_PREFIX,
  COMPILED_POLICY_SPEC,
  COMPOSITION_MANIFEST_FILE,
  COMPOSITION_MANIFEST_SPEC,
  COMPOSITION_PROFILES,
  CONFIG_FINDING_CODES,
  CONFIRMATION_CLASSES,
  CONFIRMATION_DENIAL_CODES,
  CONFIRMATION_FIXTURE_PROFILE,
  CONFIRMATION_OPERATION_PREFIX,
  CONFORMING_ATTESTATION_LEVEL,
  CONSUMPTION_GATE_RECORD_BLOCKER_CODES,
  CRITERION_DISPOSITIONS,
  CanonicalizationError,
  DEFAULT_BASE_MOVEMENT_POLICY,
  DEFAULT_BASE_REF,
  DEFAULT_CAPTURE_ATTEMPTS,
  DEFAULT_STORAGE_NAMESPACE,
  DELIVERABLE_TREE_V1,
  DELIVERABLE_TREE_V1_NARRATION_SET,
  DELIVERY_BLOCKER_REMEDIATIONS,
  DELIVERY_EVIDENCE_1,
  DELIVERY_OWNED_TREE_PREFIXES,
  DELIVERY_PROVIDER_RAILS_VERSION,
  DELIVERY_RECORD_DRIFT_CLASSES,
  DELIVERY_RECORD_VERSION,
  DELIVERY_STATES,
  DELIVERY_TRANSITION_TABLE,
  DESCENDANT_TEARDOWN_STATUSES,
  DISPOSABLE_OUTCOME_AUTHORITIES,
  DISPOSABLE_REVIEW_LENSES,
  DISPOSABLE_SENSOR_CAPABILITY,
  DISPOSABLE_STAGE_GRANT,
  DigestError,
  EVENT_VOCABULARY,
  EVIDENCE_KINDS,
  EXECUTION_CONTEXT_KINDS,
  EXECUTION_GRANT_SPEC,
  EXTERNAL_ACTIONS,
  EXTERNAL_ACTION_OUTCOMES,
  EXTERNAL_VERIFICATIONS,
  FACADE_CAPABILITY_CLASSES,
  FACADE_OPERATIONS,
  FACADE_SURFACES,
  FINDING_DISPOSITIONS,
  FINDING_SCOPES,
  FINDING_SEVERITIES,
  FINISH_LINES,
  FINISH_LINE_ACTIONS,
  FINISH_LINE_RESULT_SPEC,
  FRESHNESS_KINDS,
  GATE_STRUCTURAL_FINDING_CODES,
  GRANT_ATTESTATION_SPEC,
  GRANT_PROFILES,
  HARNESS_VERSION,
  HOST_ACTIVITY_STATES,
  HOST_ADMISSION_SCENARIOS,
  HOST_BINDING_BLOCKER_CODES,
  HOST_CONFORMANCE_CASES,
  HOST_INTERCEPTION_SCENARIOS,
  IDENTITY_DOMAIN,
  IDENTITY_FINDING_CODES,
  INSTALL_RECEIPT_SPEC,
  INTAKE_STATES,
  INTERNAL_ERROR_CODE,
  INVOCATION_FENCE_SPEC,
  INVOCATION_WAIVER_SCOPE,
  JOURNALS,
  JOURNAL_ENTRY_SPEC,
  MANAGED_DELIVERY_NAMESPACE,
  MANDATORY_LENS_CATEGORIES,
  MANIFEST_REJECTION_CODES,
  MANIFEST_REJECTION_REGISTRY,
  MANIFEST_RULE_IDS,
  MAX_BLOCKER_DETAIL_LENGTH,
  MAX_PORTABLE_RECORD_BYTES,
  MAX_RUN_LABEL,
  MAX_RUN_LENSES,
  MAX_RUN_PATH,
  MAX_RUN_PROVIDER_ID,
  MAX_RUN_URL,
  META_RULE_IDS,
  MINIMUM_NODE,
  MINIMUM_PYTHON,
  NON_WAIVABLE_INTEGRITY_CODES,
  OBSERVATION_ONLY_KINDS,
  OPERATION_CLAIM_SPEC,
  OPERATION_RESULT_SPEC,
  OPERATOR_CONFIRMATION_SPEC,
  OTHER_INSTALLATION_ARTIFACTS,
  OUTCOME_VERIFICATION_SPEC,
  PACKAGE_NAME,
  PACKED_HARNESS_PACKAGES,
  PATH_MATCHER_KINDS,
  PERSONA_MANIFEST_ENTRY,
  PERSONA_MANIFEST_SPEC,
  PINNED_AGENT_SKILLS,
  POLICY_CAPABILITY_KINDS,
  POLICY_COMPILE_CODES,
  POLICY_SNAPSHOT_SPEC,
  PORTABLE_INTAKE_GRANT,
  PORTABLE_MODEL_DRIVEN_STAGES,
  PORTABLE_PRIVILEGED_CREDENTIALS,
  PORTABLE_STAGE_GRANT,
  PREPARATION_FAILURE_CLASSES,
  PREPARATION_RECEIPT_LEAF,
  PREPARATION_RECEIPT_SCHEMA_VERSION,
  PRIVILEGED_ACTIONS,
  PRIVILEGED_CAPABILITY_KINDS,
  PRODUCT_COMPOSITION_PIN_SPEC,
  PRODUCT_TRUST_LABEL,
  PRODUCT_TRUST_STATE_SPEC,
  PROJECTION_CONSUMPTION_OBSERVATION_SPEC,
  PROJECTION_DIR,
  PROJECTION_RECEIPT_FILE,
  PROVIDER_POLICIES,
  PROVIDER_REVIEW_HANDOFF_SPEC,
  PROVIDER_REVIEW_RESULT_SPEC,
  READ_ONLY_CAPABILITY_KINDS,
  RECEIPTED_SKILLS_ROOT,
  RECHECKED_VALUES,
  RECORDER_EMITTED_CODES,
  RECORDS_LEAF,
  RECORD_QUARANTINE_REASONS,
  RECORD_SCHEMA_VERSION,
  REPOSITORY_POLICY_DOCUMENT_SPEC,
  RESOLUTION_KINDS,
  RESOLUTION_OUTCOMES,
  RESUME_ELIGIBILITIES,
  REVIEWER_APPROVAL_ROLE,
  REVIEWER_ATTEMPT_SPEC,
  REVIEWER_RESULTS,
  REVIEW_GREEN_1,
  REVIEW_LENS_CATEGORIES,
  REVIEW_VERDICTS,
  RUN_ACTOR_ROLES,
  RUN_CANDIDATE_TREE_SHA,
  RUN_COMMAND_OUTCOMES,
  RUN_ENDED_RESULTS,
  RUN_EVENT_KINDS,
  RUN_EVENT_SPEC,
  RUN_FREE_TEXT_MEMBERS,
  RUN_GATE_REPORTED_OUTCOMES,
  RUN_JOURNAL_REQUIRED_ENTRIES,
  RUN_JOURNAL_STATUSES,
  RUN_JOURNAL_VIOLATIONS,
  RUN_PROVIDER_ID,
  RUN_ROOT_LEAF,
  RUN_ROOT_NAMESPACE,
  RUN_ROOT_REFUSAL_REASONS,
  RUN_STORE_DIRECTORY,
  RUN_STORE_ID,
  RUN_TICKET,
  ReviewInputError,
  SCOPED_DELIVERY_CONTRACT_SPEC,
  SECRET_PATTERNS,
  SECURITY_BLOCKED_MIGRATION_ACTION,
  SENSITIVE_APPROVAL_ASSERTION_SPEC,
  SENSITIVE_MAINTENANCE_ACTIONS,
  SENSOR_OUTCOMES,
  SENSOR_RESULT_SPEC,
  SHADOW_MILESTONE_GATE_RECORD_SPEC,
  SHADOW_MILESTONE_GATE_RECORD_SPEC_SUFFIX,
  SPINE_GIT_OID,
  SPINE_ID,
  SPINE_INSTANT,
  SPINE_SHA256,
  SUBMISSION_CANDIDATE_FIELDS,
  SUBSTRATE_BLOCKER_CODES,
  SUPPORTED_CONTRACT_VERSIONS,
  SUPPORTED_ENVELOPE_SPECS,
  SUPPORTED_PAYLOAD_SPECS,
  SUPPORTED_PLATFORMS,
  SUSPENDED_DELIVERY_STATES,
  TERMINAL_DELIVERY_STATES,
  TERMINATION_PROVENANCE_KINDS,
  TERMINATION_PROVENANCE_OPERATION,
  TOOL_DENIAL_CODES,
  TRACKER_ABSENCE_FALLBACKS,
  UNBOUND_EXTERNAL_ACTION_PORT,
  UNKNOWN_CONTEXT_REASONS,
  V1_ATTESTATION_LEVEL,
  VALIDATOR_EMITTED_CODES,
  WAIVER_ACTIONS,
  WAIVER_APPROVAL_ORIGIN_PREFIX,
  WAIVER_SCOPES,
  WORKFLOW_CHECKPOINT_BINDINGS,
  WORKFLOW_GRAPH_ENTRY,
  WORKSPACE_DISPOSITIONS,
  adaptClaudeCodeReviewResult,
  applySecretDiscipline,
  assertSha256Hex,
  assertionClassOf,
  assertionLaneAvailability,
  assertionProviderConfigPathFor,
  authorizeFinishLineAction,
  bindingOf,
  buildCompositionManifest,
  buildDeliveryRecord,
  candidateTreeEvidenceReader,
  canonicalBytes,
  canonicalize,
  captureCheckBindings,
  captureCheckOutputSnapshots,
  captureCheckOutputs,
  captureGitCandidate,
  capturePortableEvidenceContext,
  capturePortableVerificationInputs,
  checkActionAuthorization,
  checkBoundPolicy,
  checkClaimAuthorized,
  checkContractWithinPolicy,
  checkFacadeSurfaceInvariants,
  checkMergeReadyAgainstOutcome,
  checkMutationLane,
  checkNoDowngrade,
  checkOutcomeCoversContract,
  checkPositiveCriterion,
  checkReviewFloor,
  classifyCandidateDrift,
  classifyCandidatePath,
  classifyEventKind,
  classifyExecutionContext,
  collectLiveProviderResults,
  compareSubmissionCandidate,
  compareUtf16CodeUnits,
  compileDisposableCompiledPolicy,
  compileDisposablePolicy,
  compileRepositoryPolicy,
  compiledAdopterPolicyBindingDigest,
  composeBlockerInventory,
  composeClaudeCodeSession,
  composeManagedStatus,
  composeOutcomeVerification,
  compositionManifestBytes,
  computeCheckWiringFingerprint,
  computeDeliverableIdentity,
  computePreparationFingerprint,
  computeRecordId,
  confirmationClassOf,
  consumeProviderRailMessages,
  createArtifactsPort,
  createBlocker,
  createCandidateCapture,
  createExecPort,
  createFakeHostConformancePort,
  createIntakeJournalStore,
  createInternalErrorBlocker,
  createJournalStore,
  createMaintenanceJournalStore,
  createManagedDeliveryFacade,
  createOsNativeAssertionSource,
  createProviderReviewHandoff,
  createQualificationFixtureAssertionSource,
  createRunStore,
  decideFinishLine,
  defaultRunRootBase,
  defineHarnessConfig,
  deleteDelivery,
  deliveryRecordBytes,
  deliveryRecordPathFor,
  deriveDeliveryRecordPath,
  deriveTelemetry,
  digestCanonical,
  digestDeliverableEntries,
  digestsEqual,
  discoverRecords,
  discriminateInstall,
  effectiveDeliveryAuthority,
  emittableFindingCodes,
  enforceAllowedResolution,
  evaluateCandidateActivation,
  evaluateCanonicalRecheck,
  evaluateConfirmationEcho,
  evaluateGate,
  evaluateHostAdmission,
  evaluateMigrationConsumption,
  evaluatePreparationReceipt,
  evaluateRunJournal,
  evaluateToolInvocation,
  evaluateWaiverConsumption,
  exportDelivery,
  facadeOperation,
  garbageCollectGenerations,
  generationDigestOf,
  gitNamespaceClearedEnvironment,
  grantDigest,
  identityDefinitionOf,
  inspectInstallation,
  installComposition,
  invalidatePreparationReceipt,
  invokeProviderRail,
  isDeliveryOwnedTreeEntry,
  isDeliveryOwnedTreePath,
  isDeliveryTransitionValid,
  isEnvSignalPresent,
  isInsideResolved,
  isIntakeTransitionValid,
  isManifestRejectionCode,
  isObligationActive,
  isRecordFreshForCandidate,
  isRecordNeutralPath,
  isReviewNeutralPath,
  isRunEventKind,
  isRunInstant,
  isSafeRelativePath2 as isSafeRelativePath,
  isSha256Hex,
  listArchiveEntries,
  livePreflightProbes,
  loadAssertionProviderConfig,
  loadBundledWorkflowGraph,
  loadPinnedGeneration,
  localDigestTrustPredicate,
  maintainTrustState,
  manifestDigest,
  matchesNeutralSet,
  matchesPathMatcher,
  materializeProjection,
  mintGrantAttestation,
  needsCommittedSymlinkTarget,
  neutralizeForDisplay,
  observeAuthorityEpoch,
  openProviderRailProcess,
  operationsOnSurface,
  packComposition,
  parseCandidateNumstat,
  parseCandidateTreeListing,
  parseDeliveryRecord,
  parseProjectionConsumptionObservation,
  parseProviderReviewResult,
  parseReviewOutcome,
  parseTreeEntries,
  parseTrustState,
  portableArtifactContents,
  projectReviewActivation,
  projectShippedPersonas,
  projectionConsumptionObservationFile,
  publishPreparationReceipt,
  publishRecord,
  qualifyReviewAttempts,
  readArchiveEntry,
  readConsumptionMarker,
  readWorkflowRelease,
  receiptFileName,
  receiptPathFor,
  recordFileName,
  recordIdentity,
  recoverInterruptedMaintenance,
  redactSecretText,
  reduceDeliveryJournal,
  reduceIntakeJournal,
  reduceToProviderId,
  registrationBinding,
  remediationFor,
  renderBlockers,
  repairInstallation,
  repositoryEvidenceReader,
  resolveActiveGeneration,
  resolveCommonDirectoryNamespace,
  resolveReceiptStorage,
  resolveRecordStorage,
  resolveReviewCharters,
  resolveRunStoreLocation,
  retainedCheckOutput,
  reviewerLists,
  rollbackComposition,
  runAdmission,
  runGitCommand,
  runGitDirect,
  runHostIntegrationConformance,
  runJournalCarries,
  runPrimaryTicket,
  sanitizedDetail,
  selectDeliveryRecordForIdentity,
  sensitiveGroupsFor,
  serializeBlockers,
  sha256Hex,
  submitManifest,
  trustStorePathFor,
  updateComposition,
  validateAcceptedContract,
  validateAdapterCapability,
  validateAdapterSet,
  validateAuthorityRevocation,
  validateCapabilityDescriptor,
  validateCompositionManifest,
  validateCompositionPin,
  validateExecutionGrant,
  validateFinishLineResult,
  validateGrantAttestation,
  validateHarnessConfig,
  validateInvocationFence,
  validateJournalEntry,
  validateManifest,
  validateOperatorConfirmation,
  validateOutcomeVerification,
  validatePolicySnapshot,
  validateProductTrustState,
  validateRepositoryPolicyDocument,
  validateReviewGreenClaim,
  validateReviewedContext,
  validateReviewerAttempt,
  validateRunEvent,
  validateRunEventInput,
  validateSensitiveApprovalAssertion,
  validateSensorResult,
  verifyCompiledPolicy,
  verifyDeliveryRecord,
  verifyGenerationClosure,
  verifyPortableEvidence,
  verifyProjection,
  withDeliverableIdentity,
  workflowStageBindingFor,
  writeAssertionProviderConfig
};
